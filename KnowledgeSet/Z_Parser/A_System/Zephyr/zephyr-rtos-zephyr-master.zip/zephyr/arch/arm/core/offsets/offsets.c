/*
 * Copyright (c) 2019 Carlo Caione <ccaione@baylibre.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <gen_offset.h>

#include "offsets_aarch32.c"

GEN_ABS_SYM_END
