/*
 * 平台ARM_CM4F
 */

//调度的上层索引
#include "FreeRTOS.h"
#include "task.h"

//硬件浮点数FPU支持
#ifndef __TARGET_FPU_VFP
	#error This port can only be used when the project options are configured to enable hardware floating point support.
#endif

//最大系统回调中断优先级
#if configMAX_SYSCALL_INTERRUPT_PRIORITY == 0
	#error configMAX_SYSCALL_INTERRUPT_PRIORITY must not be set to 0.  See http://www.FreeRTOS.org/RTOS-Cortex-M3-M4.html
#endif

//系统时钟滴答HZ
#ifndef configSYSTICK_CLOCK_HZ
	#define configSYSTICK_CLOCK_HZ configCPU_CLOCK_HZ	//系统时钟滴答与内核HZ一致
	#define portNVIC_SYSTICK_CLK_BIT	( 1UL << 2UL )
#else
	#define portNVIC_SYSTICK_CLK_BIT	( 0 )
#endif

//如果希望重写默认时钟配置:vPortSetupTimerInterrupt()则该配置设置为1
#ifndef configOVERRIDE_DEFAULT_TICK_CONFIGURATION
	#define configOVERRIDE_DEFAULT_TICK_CONFIGURATION 0
#endif

//中断系统时钟滴答有关的几个寄存器地址,可以直接对其写入
#define portNVIC_SYSTICK_CTRL_REG			( * ( ( volatile uint32_t * ) 0xe000e010 ) )
#define portNVIC_SYSTICK_LOAD_REG			( * ( ( volatile uint32_t * ) 0xe000e014 ) )
#define portNVIC_SYSTICK_CURRENT_VALUE_REG	( * ( ( volatile uint32_t * ) 0xe000e018 ) )
#define portNVIC_SYSPRI2_REG				( * ( ( volatile uint32_t * ) 0xe000ed20 ) )
//关键寄存器中关键的几个位
#define portNVIC_SYSTICK_INT_BIT			( 1UL << 1UL )
#define portNVIC_SYSTICK_ENABLE_BIT			( 1UL << 0UL )
#define portNVIC_SYSTICK_COUNT_FLAG_BIT		( 1UL << 16UL )
#define portNVIC_PENDSVCLEAR_BIT 			( 1UL << 27UL )
#define portNVIC_PEND_SYSTICK_CLEAR_BIT		( 1UL << 25UL )

//内核消息
#define portCPUID							( * ( ( volatile uint32_t * ) 0xE000ed00 ) )
#define portCORTEX_M7_r0p1_ID				( 0x410FC271UL )
#define portCORTEX_M7_r0p0_ID				( 0x410FC270UL )

//确定其优先级为内核中断优先级的最小
//悬挂异常 系统时钟滴答中断
#define portNVIC_PENDSV_PRI					( ( ( uint32_t ) configKERNEL_INTERRUPT_PRIORITY ) << 16UL )
#define portNVIC_SYSTICK_PRI				( ( ( uint32_t ) configKERNEL_INTERRUPT_PRIORITY ) << 24UL )

//中断优先级检查所用
#define portFIRST_USER_INTERRUPT_NUMBER		( 16 )
#define portNVIC_IP_REGISTERS_OFFSET_16 	( 0xE000E3F0 )
#define portAIRCR_REG						( * ( ( volatile uint32_t * ) 0xE000ED0C ) )
#define portMAX_8_BIT_VALUE					( ( uint8_t ) 0xff )
#define portTOP_BIT_OF_BYTE					( ( uint8_t ) 0x80 )
#define portMAX_PRIGROUP_BITS				( ( uint8_t ) 7 )
#define portPRIORITY_GROUP_MASK				( 0x07UL << 8UL )
#define portPRIGROUP_SHIFT					( 8UL )

//掩码,向量掩码,位屏蔽
#define portVECTACTIVE_MASK					( 0xFFUL )

//寄存器,浮点数上下文控制
#define portFPCCR					( ( volatile uint32_t * ) 0xe000ef34 )
#define portASPEN_AND_LSPEN_BITS	( 0x3UL << 30UL )

//堆栈初始化所用
#define portINITIAL_XPSR			( 0x01000000 )
#define portINITIAL_EXC_RETURN		( 0xfffffffd )

//系统滴答的最大时间长度,寄存器最大为
#define portMAX_24_BIT_NUMBER		( 0xffffffUL )

//计数遗失因子查询
#define portMISSED_COUNTS_FACTOR	( 45UL )

//起始地址掩码,0位要清除,在中断ISR时要被送入堆栈中
#define portSTART_ADDRESS_MASK		( ( StackType_t ) 0xfffffffeUL )

//设置时钟滴答中断
void vPortSetupTimerInterrupt( void );

//三个系统所需的中断回调函数,用于为操作系统所使用
void xPortPendSVHandler( void );
void xPortSysTickHandler( void );
void vPortSVCHandler( void );

//启动第一个任务
static void prvStartFirstTask( void );

//使能VFP
static void prvEnableVFP( void );

//任务退出错误
static void prvTaskExitError( void );

//临界区嵌套维护所用
static UBaseType_t uxCriticalNesting = 0xaaaaaaaa;

//滴答计数变量
#if( configUSE_TICKLESS_IDLE == 1 )
	static uint32_t ulTimerCountsForOneTick = 0;
#endif

//最大滴答数
#if( configUSE_TICKLESS_IDLE == 1 )
	static uint32_t xMaximumPossibleSuppressedTicks = 0;
#endif

//时钟滴答中止时的CPU周期补偿
#if( configUSE_TICKLESS_IDLE == 1 )
	static uint32_t ulStoppedTimerCompensation = 0;
#endif

//系统回调优先级和最大优先级,对应的中断优先级的寄存器
#if ( configASSERT_DEFINED == 1 )
	 static uint8_t ucMaxSysCallPriority = 0;
	 static uint32_t ulMaxPRIGROUPValue = 0;
	 static const volatile uint8_t * const pcInterruptPriorityRegisters = ( uint8_t * ) portNVIC_IP_REGISTERS_OFFSET_16;
#endif

//栈的初始化
StackType_t *pxPortInitialiseStack( StackType_t *pxTopOfStack, TaskFunction_t pxCode, void *pvParameters )
{	//由下可知,实际内容占据俩个栈单元

	pxTopOfStack--;//栈顶向下偏移一次
	*pxTopOfStack = portINITIAL_XPSR;	//写入xPSR寄存器初始化内容
	
	pxTopOfStack--;//继续向下偏移一次
	*pxTopOfStack = ( ( StackType_t ) pxCode ) & portSTART_ADDRESS_MASK;//写入当前任务运行的位置
																		//(开始时是任务入口,也就是函数名地址)
	
	pxTopOfStack--;//继续向下偏移一次
	*pxTopOfStack = ( StackType_t ) prvTaskExitError;//写入栈退出的错误码

	pxTopOfStack -= 5;	// R12, R3, R2, R1 这四个寄存器初始化时没有值
	*pxTopOfStack = ( StackType_t ) pvParameters;	// R0 在初始化时保存参数地址

	pxTopOfStack--;	//维护任务自己exec的返回值
	*pxTopOfStack = portINITIAL_EXC_RETURN;//0xFFFFFFFD返回到Thread

	pxTopOfStack -= 8;	// R11, R10, R9, R8, R7, R6, R5, R4 这八个寄存器初始化时没有值

	return pxTopOfStack;//返回新的入口地址,那么将来按此顺序逆向将对应的数据弹出栈
	//写入到对应寄存器中,即可完成任务的启动,同样的这也适用于现场保护和现场还原
}

//栈错误退出时的回调
static void prvTaskExitError( void )
{
	configASSERT( uxCriticalNesting == ~0UL );
	portDISABLE_INTERRUPTS();//关闭中断并进入死循环
	for( ;; );
}

//汇编实现的SVC(系统服务)异常服务例程
//如果用户强行调用OS的系统服务函数时进入此异常
__asm void vPortSVCHandler( void )
{
	PRESERVE8//指令8位对齐
	//pxCurrentTCB保存当前任务TCB的地址
	//当前任务TCB(pxTopOfStack)的地址
	//而pxTopOfStack保存实际任务堆栈栈顶位置
	ldr	r3, =pxCurrentTCB//将内存中pxCurrentTCB的地址 写入到 R3寄存器中
	ldr r1, [r3]//将R3的内容作为地址 取对应地址的内容也就是TCB(也等价于pxTopOfStack)的地址
	ldr r0, [r1]//将R1的内容作为地址 取对应地址的内容也就是指向的pxTopOfStack的实际地址
	//最终R0保存了当前任务栈顶的地址
	ldmia r0!, {r4-r11, r14}//现在将栈里面的内容批量加载到R4-R11,R14中,R0同步更新
	msr psp, r0//R0的值写入到psp
	isb//指令同步隔离,清理流水线中所有微操作,相当于代码屏蔽
	mov r0, #0//R0寄存器清0,用于清除中断限制
	msr	basepri, r0//R0的值写入到basepri,清除限制
	bx r14//跳转到R14指定的地址,根据其做低位切换微处理器状态
}

//启动第一个任务
__asm void prvStartFirstTask( void )
{
	PRESERVE8//指令8字节对齐

	ldr r0, =0xE000ED08	//使用终端偏移寄存器加载栈
	ldr r0, [r0]
	ldr r0, [r0]
	
	msr msp, r0//R0中的栈保存到msp中
	mov r0, #0//清0
	msr control, r0//清0
	cpsie i//开全局中断
	cpsie f//关全局中断
	dsb//数据同步内存屏障
	isb//指令同步隔离,清理流水线中所有微操作,相当于代码屏蔽
	svc 0//生成0号SVC中断,执行0号SVC系统服务例程
	nop//空
	nop//空
}

//使能VFP(浮点协处理器)
__asm void prvEnableVFP( void )
{
	PRESERVE8//指令8位对齐
	
	//CPACR中保存了FPU的使能位,拿到它
	ldr.w r0, =0xE000ED88
	ldr	r1, [r0]
	orr	r1, r1, #( 0xf << 20 )//然后去使能对应的俩个位
	str r1, [r0]
	bx	r14//跳到R14那里去执行
	
	nop
}

//启动调度
BaseType_t xPortStartScheduler( void )
{	//断言检查
	configASSERT( configMAX_SYSCALL_INTERRUPT_PRIORITY );
	configASSERT( portCPUID != portCORTEX_M7_r0p1_ID );
	configASSERT( portCPUID != portCORTEX_M7_r0p0_ID );

	#if( configASSERT_DEFINED == 1 )
	{
		volatile uint32_t ulOriginalPriority;
		volatile uint8_t * const pucFirstUserPriorityRegister = ( uint8_t * ) ( portNVIC_IP_REGISTERS_OFFSET_16 + portFIRST_USER_INTERRUPT_NUMBER );
		volatile uint8_t ucMaxPriorityValue;

		//第一个用户进程的中断优先级寄存器的值做一个本地备份
		ulOriginalPriority = *pucFirstUserPriorityRegister;

		//用户可用的优先级位数
		*pucFirstUserPriorityRegister = portMAX_8_BIT_VALUE;

		//最大优先级被确认下来
		ucMaxPriorityValue = *pucFirstUserPriorityRegister;

		configASSERT( ucMaxPriorityValue == ( configKERNEL_INTERRUPT_PRIORITY & ucMaxPriorityValue ) );

		//确认最大的系统调用优先级,使用最大优先级掩码运算出
		ucMaxSysCallPriority = configMAX_SYSCALL_INTERRUPT_PRIORITY & ucMaxPriorityValue;

		//最大优先级组的值确认
		ulMaxPRIGROUPValue = portMAX_PRIGROUP_BITS;
		while( ( ucMaxPriorityValue & portTOP_BIT_OF_BYTE ) == portTOP_BIT_OF_BYTE )
		{	//最大优先级低位保留组优先级信息
			ulMaxPRIGROUPValue--;
			ucMaxPriorityValue <<= ( uint8_t ) 0x01;
		}

		#ifdef __NVIC_PRIO_BITS
		{
			configASSERT( ( portMAX_PRIGROUP_BITS - ulMaxPRIGROUPValue ) == __NVIC_PRIO_BITS );
		}
		#endif

		#ifdef configPRIO_BITS
		{
			configASSERT( ( portMAX_PRIGROUP_BITS - ulMaxPRIGROUPValue ) == configPRIO_BITS );
		}
		#endif

		//优先级偏移调整,回写到AIRCR寄存器
		ulMaxPRIGROUPValue <<= portPRIGROUP_SHIFT;
		ulMaxPRIGROUPValue &= portPRIORITY_GROUP_MASK;

		//还原之前的中断优先级
		*pucFirstUserPriorityRegister = ulOriginalPriority;
	}
	#endif
	
	//PendSV和SYSTICK的优先级为最低的优先级
	portNVIC_SYSPRI2_REG |= portNVIC_PENDSV_PRI;
	portNVIC_SYSPRI2_REG |= portNVIC_SYSTICK_PRI;

	//配置时钟中断,启动或等待启动
	vPortSetupTimerInterrupt();

	//清空临界区嵌套次数
	uxCriticalNesting = 0;

	//使能FPU
	prvEnableVFP();

	//惰性保存??
	*( portFPCCR ) |= portASPEN_AND_LSPEN_BITS;

	//启动第一个任务
	prvStartFirstTask();

	//因为BX跳转指令,后面的程序一直留在主系统栈中不能被执行
	return 0;
}

//结束调度
void vPortEndScheduler( void )
{
	configASSERT( uxCriticalNesting == 1000UL );
}

//进入临界区
void vPortEnterCritical( void )
{
	portDISABLE_INTERRUPTS();//关闭中断
	uxCriticalNesting++;//临界区嵌套次数+1
	if( uxCriticalNesting == 1 )
	{
		configASSERT( ( portNVIC_INT_CTRL_REG & portVECTACTIVE_MASK ) == 0 );
	}
}

//退出临界区
void vPortExitCritical( void )
{
	configASSERT( uxCriticalNesting );
	uxCriticalNesting--;//临界区嵌套次数-1
	if( uxCriticalNesting == 0 )
	{	//无嵌套时恢复中断
		portENABLE_INTERRUPTS();
	}
}

//悬挂异常,用于任务调度
__asm void xPortPendSVHandler( void )
{	//外部变量引用
	extern uxCriticalNesting;
	extern pxCurrentTCB;
	extern vTaskSwitchContext;

	PRESERVE8//8字节对齐

	mrs r0, psp//psp(当前任务栈指针)到R0寄存器
	isb//指令同步隔离,清理流水线中所有微操作,相当于代码屏蔽
	
	ldr	r3, =pxCurrentTCB//加载当前任务TCB
	ldr	r2, [r3]//取TCB地址对应内容,即pxTopOfStack的地址

	//如果任务使用FPU上下文的话,压入VFP寄存器的位
	tst r14, #0x10//按位与动作
	it eq//Z标志判断为1,执行下一行汇编
	vstmdbeq r0!, {s16-s31}

	stmdb r0!, {r4-r11, r14}//任务栈压入数据从对应的寄存器(现场保护)

	str r0, [r2]//栈顶位置存到R0里面

	stmdb sp!, {r0, r3}//将CurrentTCB的地址和pxTopOfStack的地址保存至主堆栈
	mov r0, #configMAX_SYSCALL_INTERRUPT_PRIORITY//R0写最大中断优先级
	msr basepri, r0//最大中断优先级写入寄存器(屏蔽低优先级中断)
	dsb//数据同步隔离,全部数据都被同步更新(而非延迟更新)
	isb//指令同步隔离,清理流水线中所有微操作,相当于代码屏蔽
	bl vTaskSwitchContext//跳转到指定的函数中去
	//注意上文的动作是更新新的CurrentTCB,前面保存的是地址而不是内容,这里更新内容
	mov r0, #0//R0寄存器清0,用于清除中断限制
	msr basepri, r0//R0的值写入到basepri,清除限制
	ldmia sp!, {r0, r3}//将CurrentTCB的地址和pxTopOfStack的地址从主堆栈恢复

	ldr r1, [r3]//加载当前任务TCB的位置地址R1
	ldr r0, [r1]//加载pxTopOfStack的位置地址到R0

	ldmia r0!, {r4-r11, r14}//任务栈弹出数据到对应的寄存器(现场还原)
							//也就是说这里的还原是还原之前被打断的任务的 CPU内核环境
							//而不是上面那个,因为中间执行上下文切换更新了CurrentTCB的内容
							//对应的pxTopOfStack也相应的发生了改变

	//如果任务使用FPU上下文的话,压入VFP寄存器的位
	tst r14, #0x10
	it eq
	vldmiaeq r0!, {s16-s31}

	msr psp, r0//R0寄存器写入到psp(更新当前任务栈指针)
	isb//指令同步隔离,清理流水线中所有微操作,相当于代码屏蔽
	#ifdef WORKAROUND_PMU_CM001 /* XMC4000 specific errata */
		#if WORKAROUND_PMU_CM001 == 1
			push { r14 }	//一种特殊平台,将R14的地址入栈
			pop { pc }		//然后弹出到PC(程序计数器)
			nop
		#endif
	#endif

	bx r14//跳到R14那里去执行(即退出),由上面可知R14保存了程序的入口地址(或被打断的位置)
}

void xPortSysTickHandler( void )
{	//系统响应优先级有一套特殊机制,自身优先级是水平线,低于该优先级的中断异常一律屏蔽
	vPortRaiseBASEPRI();//提升最大优先级(是系统响应的优先级并非它自己的优先级)
	{//防止被其他中断打断,因为时钟中断优先级最低所以需要这样子做
		if( xTaskIncrementTick() != pdFALSE )
		{	//增加一次时钟滴答计数,如果满足任务切换条件
			//为中断控制位写PendSV异常使能,为中断做好准备
			portNVIC_INT_CTRL_REG = portNVIC_PENDSVSET_BIT;
		}
	}//临时提升的最大优先级现在就需要放开限制,以便其他优先级中断正常响应
	vPortClearBASEPRIFromISR();
}

#if( configUSE_TICKLESS_IDLE == 1 )
	//低功耗模式
	__weak void vPortSuppressTicksAndSleep( TickType_t xExpectedIdleTime )
	{
	uint32_t ulReloadValue, ulCompleteTickPeriods, ulCompletedSysTickDecrements;
	TickType_t xModifiableIdleTime;

		if( xExpectedIdleTime > xMaximumPossibleSuppressedTicks )
		{	//空闲时间不可溢出时钟的滴答计数
			xExpectedIdleTime = xMaximumPossibleSuppressedTicks;
		}

		//关闭系统时钟滴答中断
		portNVIC_SYSTICK_CTRL_REG &= ~portNVIC_SYSTICK_ENABLE_BIT;

		//获取将来唤醒时间,为当前时间滴答数 加上 空闲时间的滴答数
		ulReloadValue = portNVIC_SYSTICK_CURRENT_VALUE_REG + ( ulTimerCountsForOneTick * ( xExpectedIdleTime - 1UL ) );
		if( ulReloadValue > ulStoppedTimerCompensation )
		{	//重载时间不可溢出最大CPU补偿,因为这里要睡眠,那么将来这段
			//时间滴答要用于同步到内核的延迟队列中,保证能够使任务达到正常延时
			ulReloadValue -= ulStoppedTimerCompensation;
		}

		//关闭全部中断
		__disable_irq();
		__dsb( portSY_FULL_READ_WRITE );//数据同步内存屏障
		__isb( portSY_FULL_READ_WRITE );//指令同步内存屏障

		//如果上下文切换被挂起或任务被等待取消挂起时,中止睡眠模式
		if( eTaskConfirmSleepModeStatus() == eAbortSleep )
		{	//重写当前时钟滴答值,为之前的值
			portNVIC_SYSTICK_LOAD_REG = portNVIC_SYSTICK_CURRENT_VALUE_REG;
			//重启时钟滴答计数
			portNVIC_SYSTICK_CTRL_REG |= portNVIC_SYSTICK_ENABLE_BIT;
			//重置时钟滴答的加载值
			portNVIC_SYSTICK_LOAD_REG = ulTimerCountsForOneTick - 1UL;
			//使能全部中断
			__enable_irq();
		}
		else//现在满足睡眠条件了
		{	//设置时钟滴答为预期要唤醒的值
			portNVIC_SYSTICK_LOAD_REG = ulReloadValue;
			//清空当前时钟滴答中断计数
			portNVIC_SYSTICK_CURRENT_VALUE_REG = 0UL;
			//重启时钟滴答中断
			portNVIC_SYSTICK_CTRL_REG |= portNVIC_SYSTICK_ENABLE_BIT;
			//休眠直到
			xModifiableIdleTime = xExpectedIdleTime;
			configPRE_SLEEP_PROCESSING( xModifiableIdleTime );//该宏可能会设置参数为0用于确定
															  //是否已经在wfi中了
			if( xModifiableIdleTime > 0 )
			{	//检查是否是在Wait For Interrupt模式
				__dsb( portSY_FULL_READ_WRITE );//数据同步内存屏障
				__wfi();//在该模式下时不应该执行该指令(注意在时钟中断产生前程序一直都会停在这里)
												//因为上面关闭全部中断后只打开了时钟中断
												//该指令会等待任意中断响应
				__isb( portSY_FULL_READ_WRITE );//指令同步内存屏障
			}
			configPOST_SLEEP_PROCESSING( xExpectedIdleTime );//如上

			//使能全部中断
			__enable_irq();//使用中断去脱离低功耗模式(响应时钟中断例程)
			__dsb( portSY_FULL_READ_WRITE );//数据同步内存屏障
			__isb( portSY_FULL_READ_WRITE );//指令同步内存屏障

			//时钟中断服务结束了,那么再关一次,因为如果其他中断在这段时间响应的话
			//会照成一定的时钟偏移,导致实际的计数值有误差,因为其他中断可能占据多个时钟滴答
			__disable_irq();
			__dsb( portSY_FULL_READ_WRITE );
			__isb( portSY_FULL_READ_WRITE );

			//关闭系统时钟滴答,确保portNVIC_SYSTICK_COUNT_FLAG_BIT设置后不清除(？？？)
			portNVIC_SYSTICK_CTRL_REG = ( portNVIC_SYSTICK_CLK_BIT | portNVIC_SYSTICK_INT_BIT );

			if( ( portNVIC_SYSTICK_CTRL_REG & portNVIC_SYSTICK_COUNT_FLAG_BIT ) != 0 )
			{	//时钟计数完毕了,回滚了
				uint32_t ulCalculatedLoadValue;

				//时钟中断已经挂起,现在需要重置它
				//将剩下的滴答作为重加载值,注意这里是 亏欠时间,即相对于现在的过去时间
				ulCalculatedLoadValue = ( ulTimerCountsForOneTick - 1UL ) - ( ulReloadValue - portNVIC_SYSTICK_CURRENT_VALUE_REG );

				if( ( ulCalculatedLoadValue < ulStoppedTimerCompensation ) || ( ulCalculatedLoadValue > ulTimerCountsForOneTick ) )
				{	//范围溢出检查
					ulCalculatedLoadValue = ( ulTimerCountsForOneTick - 1UL );
				}
				//下次溢出重载值更新为现在的计数值
				portNVIC_SYSTICK_LOAD_REG = ulCalculatedLoadValue;
				ulCompleteTickPeriods = xExpectedIdleTime - 1UL;
			}
			else
			{
				//亏欠时间计算,即还差多少时间到预期的唤醒时间
				ulCompletedSysTickDecrements = ( xExpectedIdleTime * ulTimerCountsForOneTick ) - portNVIC_SYSTICK_CURRENT_VALUE_REG;
				ulCompleteTickPeriods = ulCompletedSysTickDecrements / ulTimerCountsForOneTick;
				//现在下一次重载时需要补偿这部分时间
				portNVIC_SYSTICK_LOAD_REG = ( ( ulCompleteTickPeriods + 1UL ) * ulTimerCountsForOneTick ) - ulCompletedSysTickDecrements;
			}

			//重启时钟滴答中断
			portNVIC_SYSTICK_CURRENT_VALUE_REG = 0UL;
			portNVIC_SYSTICK_CTRL_REG |= portNVIC_SYSTICK_ENABLE_BIT;
			vTaskStepTick( ulCompleteTickPeriods );//步伐调整
			portNVIC_SYSTICK_LOAD_REG = ulTimerCountsForOneTick - 1UL;
			//全部中断使能
			__enable_irq();
		}
	}

#endif

//时钟中断的配置
#if( configOVERRIDE_DEFAULT_TICK_CONFIGURATION == 0 )
	void vPortSetupTimerInterrupt( void )
	{
		#if( configUSE_TICKLESS_IDLE == 1 )
		{	//时钟一次滴答要记的数,保证与内核系统滴答时钟同步
			ulTimerCountsForOneTick = ( configSYSTICK_CLOCK_HZ / configTICK_RATE_HZ );
			//时钟所支持的最大滴答数(容量)
			xMaximumPossibleSuppressedTicks = portMAX_24_BIT_NUMBER / ulTimerCountsForOneTick;
			//时钟滴答中止时的CPU周期补偿
			ulStoppedTimerCompensation = portMISSED_COUNTS_FACTOR / ( configCPU_CLOCK_HZ / configSYSTICK_CLOCK_HZ );
		}
		#endif
		
		//寄存器重置
		portNVIC_SYSTICK_CTRL_REG = 0UL;
		portNVIC_SYSTICK_CURRENT_VALUE_REG = 0UL;
		//配置时钟中断并使能它
		portNVIC_SYSTICK_LOAD_REG = ( configSYSTICK_CLOCK_HZ / configTICK_RATE_HZ ) - 1UL;
		portNVIC_SYSTICK_CTRL_REG = ( portNVIC_SYSTICK_CLK_BIT | portNVIC_SYSTICK_INT_BIT | portNVIC_SYSTICK_ENABLE_BIT );
	}

#endif

//获取中断程序状态寄存器
__asm uint32_t vPortGetIPSR( void )
{
	PRESERVE8//指令8字节对齐
	mrs r0, ipsr//中断程序状态寄存器内容复制到R0(默认的Return就是将其存入到R0中)
	bx r14//返回到R14也就是原调用位置
}

//中断优先级验证
#if( configASSERT_DEFINED == 1 )
	void vPortValidateInterruptPriority( void )
	{
	uint32_t ulCurrentInterrupt;
	uint8_t ucCurrentPriority;

		//获取当前中断程序状态寄存器内容
		ulCurrentInterrupt = vPortGetIPSR();
		//中断是用户自定义的？
		if( ulCurrentInterrupt >= portFIRST_USER_INTERRUPT_NUMBER )
		{	//中断优先级查找
			ucCurrentPriority = pcInterruptPriorityRegisters[ ulCurrentInterrupt ];

			configASSERT( ucCurrentPriority >= ucMaxSysCallPriority );
		}

		configASSERT( ( portAIRCR_REG & portPRIORITY_GROUP_MASK ) <= ulMaxPRIGROUPValue );
	}

#endif


