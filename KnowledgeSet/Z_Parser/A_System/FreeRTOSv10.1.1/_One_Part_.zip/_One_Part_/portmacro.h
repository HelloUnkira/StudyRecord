/*
 * 平台ARM_CM4F
 */


#ifndef PORTMACRO_H
#define PORTMACRO_H

#ifdef __cplusplus
extern "C" {
#endif

//平台类型配置
#define portCHAR		char
#define portFLOAT		float
#define portDOUBLE		double
#define portLONG		long
#define portSHORT		short
#define portSTACK_TYPE	uint32_t
#define portBASE_TYPE	long

//其他类型配置
typedef portSTACK_TYPE StackType_t;
typedef long BaseType_t;
typedef unsigned long UBaseType_t;

//最大延迟项
#if( configUSE_16_BIT_TICKS == 1 )
	typedef uint16_t TickType_t;
	#define portMAX_DELAY ( TickType_t ) 0xffff
#else
	typedef uint32_t TickType_t;
	#define portMAX_DELAY ( TickType_t ) 0xffffffffUL

	//时钟滴答类型是否是原子态
	#define portTICK_TYPE_IS_ATOMIC 1
#endif

//栈增长方向,滴答周期,字节对齐方向
#define portSTACK_GROWTH			( -1 )
#define portTICK_PERIOD_MS			( ( TickType_t ) 1000 / configTICK_RATE_HZ )
#define portBYTE_ALIGNMENT			8

//用于内存屏障
#define portSY_FULL_READ_WRITE		( 15 )


/* Scheduler utilities. */
#define portYIELD()																\
{	/*启用PendSV中断实现任务切换*/												\
	portNVIC_INT_CTRL_REG = portNVIC_PENDSVSET_BIT;								\
																				\
	__dsb( portSY_FULL_READ_WRITE );/*数据内存屏障*/							\
	__isb( portSY_FULL_READ_WRITE );/*指令内存屏障*/							\
}

//中断控制寄存器
#define portNVIC_INT_CTRL_REG		( * ( ( volatile uint32_t * ) 0xe000ed04 ) )
//中断PendSV异常启动位
#define portNVIC_PENDSVSET_BIT		( 1UL << 28UL )
//中断上下文切换结束
#define portEND_SWITCHING_ISR( xSwitchRequired ) if( xSwitchRequired != pdFALSE ) portYIELD()
//中断上下文切换
#define portYIELD_FROM_ISR( x ) portEND_SWITCHING_ISR( x )

//临界区进入和退出
extern void vPortEnterCritical( void );
extern void vPortExitCritical( void );

//中断,临界区 开启和关闭
#define portDISABLE_INTERRUPTS()				vPortRaiseBASEPRI()
#define portENABLE_INTERRUPTS()					vPortSetBASEPRI( 0 )
#define portENTER_CRITICAL()					vPortEnterCritical()
#define portEXIT_CRITICAL()						vPortExitCritical()
#define portSET_INTERRUPT_MASK_FROM_ISR()		ulPortRaiseBASEPRI()
#define portCLEAR_INTERRUPT_MASK_FROM_ISR(x)	vPortSetBASEPRI(x)

//需要使用低功耗模式时
#ifndef portSUPPRESS_TICKS_AND_SLEEP
	extern void vPortSuppressTicksAndSleep( TickType_t xExpectedIdleTime );
	#define portSUPPRESS_TICKS_AND_SLEEP( xExpectedIdleTime ) vPortSuppressTicksAndSleep( xExpectedIdleTime )
#endif

//使用任务优化选项
#ifndef configUSE_PORT_OPTIMISED_TASK_SELECTION
	#define configUSE_PORT_OPTIMISED_TASK_SELECTION 1
#endif

#if configUSE_PORT_OPTIMISED_TASK_SELECTION == 1
	#if( configMAX_PRIORITIES > 32 )//优先级溢出错误
		#error configUSE_PORT_OPTIMISED_TASK_SELECTION can only be set to 1 when configMAX_PRIORITIES is less than or equal to 32.  It is very rare that a system requires more than 10 to 15 difference priorities as tasks that share a priority will time slice.
	#endif

	//就绪优先级位图保存(类似Linux就绪队列)
	#define portRECORD_READY_PRIORITY( uxPriority, uxReadyPriorities ) ( uxReadyPriorities ) |= ( 1UL << ( uxPriority ) )
	#define portRESET_READY_PRIORITY( uxPriority, uxReadyPriorities ) ( uxReadyPriorities ) &= ~( 1UL << ( uxPriority ) )
	//获取最高优先级    __clz获取第一个1之前的0的位数
	#define portGET_HIGHEST_PRIORITY( uxTopPriority, uxReadyPriorities ) uxTopPriority = ( 31UL - ( uint32_t ) __clz( ( uxReadyPriorities ) ) )

#endif

//任务
#define portTASK_FUNCTION_PROTO( vFunction, pvParameters ) void vFunction( void *pvParameters )
#define portTASK_FUNCTION( vFunction, pvParameters ) void vFunction( void *pvParameters )

//断言
#ifdef configASSERT
	void vPortValidateInterruptPriority( void );
	#define portASSERT_IF_INTERRUPT_PRIORITY_INVALID() 	vPortValidateInterruptPriority()
#endif

//空指令
#define portNOP()

//内联
#define portINLINE __inline

//强制内联
#ifndef portFORCE_INLINE
	#define portFORCE_INLINE __forceinline
#endif

//设置基础优先级
static portFORCE_INLINE void vPortSetBASEPRI( uint32_t ulBASEPRI )
{
	__asm
	{	//将优先级从内存写入寄存器
		msr basepri, ulBASEPRI
	}
}

//提升至最大优先级限制
static portFORCE_INLINE void vPortRaiseBASEPRI( void )
{	//获取最大优先级
uint32_t ulNewBASEPRI = configMAX_SYSCALL_INTERRUPT_PRIORITY;
	__asm
	{	//最大优先级写入到基础优先级,低于该优先级的中断请求一律忽略
		msr basepri, ulNewBASEPRI
		dsb//数据内存屏障
		isb//指令内存屏障
	}
}

//取消优先级限制
static portFORCE_INLINE void vPortClearBASEPRIFromISR( void )
{
	__asm
	{	//基础优先级寄存器清0
		msr basepri, #0
	}
}

//提升至最大优先级限制
static portFORCE_INLINE uint32_t ulPortRaiseBASEPRI( void )
{
uint32_t ulReturn, ulNewBASEPRI = configMAX_SYSCALL_INTERRUPT_PRIORITY;
	__asm
	{
		mrs ulReturn, basepri
		msr basepri, ulNewBASEPRI
		dsb
		isb
	}//返回之前基础优先级
	return ulReturn;
}

//是否处于中断环境下
static portFORCE_INLINE BaseType_t xPortIsInsideInterrupt( void )
{
uint32_t ulCurrentInterrupt;
BaseType_t xReturn;
	__asm
	{	//当前中断状态寄存器获取中断状态
		mrs ulCurrentInterrupt, ipsr
	}
	if( ulCurrentInterrupt == 0 )//无中断
	{
		xReturn = pdFALSE;
	}
	else
	{
		xReturn = pdTRUE;
	}

	return xReturn;
}


#ifdef __cplusplus
}
#endif

#endif
