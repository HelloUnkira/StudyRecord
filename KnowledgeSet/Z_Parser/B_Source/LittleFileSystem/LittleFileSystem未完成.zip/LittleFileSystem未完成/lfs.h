/*
 * The little filesystem
 */
#ifndef LFS_H
#define LFS_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif

///版本信息///

//软件库版本
#define LFS_VERSION 0x00020001
#define LFS_VERSION_MAJOR (0xffff & (LFS_VERSION >> 16)) //半字节nibble
#define LFS_VERSION_MINOR (0xffff & (LFS_VERSION >>  0))

//在磁盘数据结构上的版本
#define LFS_DISK_VERSION 0x00020000
#define LFS_DISK_VERSION_MAJOR (0xffff & (LFS_DISK_VERSION >> 16))
#define LFS_DISK_VERSION_MINOR (0xffff & (LFS_DISK_VERSION >>  0))


///定义///

//为lfs规定类型定义
typedef uint32_t lfs_size_t;
typedef uint32_t lfs_off_t;

typedef int32_t  lfs_ssize_t;
typedef int32_t  lfs_soff_t;

typedef uint32_t lfs_block_t;

//文件名字限制,可以降低它节约空间,限制最大修改为1022,存储超级块中,被驱动程序重视
#ifndef LFS_NAME_MAX
#define LFS_NAME_MAX 255
#endif

//文件最大大小(字节为单位),重定义用于限制支持其他驱动程序,限制最大修改为4294967296
//在2147483647上面的函数lfs_file_seek、lfs_file_size和lfs_file_tell将返回不正确的值
//因为使用了带符号整数,存储超级块中,被驱动程序重视
#ifndef LFS_FILE_MAX
#define LFS_FILE_MAX 2147483647
#endif

//限制自定义熟悉最大大小,降低它没什么实际意义
#ifndef LFS_ATTR_MAX
#define LFS_ATTR_MAX 1022
#endif

//错误码定义
enum lfs_error {
    LFS_ERR_OK          = 0,    //没有错误
    LFS_ERR_IO          = -5,   //设备操作错误
    LFS_ERR_CORRUPT     = -84,  //崩溃
    LFS_ERR_NOENT       = -2,   //项不存在
    LFS_ERR_EXIST       = -17,  //项已经存在
    LFS_ERR_NOTDIR      = -20,  //项不是一个路径
    LFS_ERR_ISDIR       = -21,  //项是一个路径
    LFS_ERR_NOTEMPTY    = -39,  //项不为空
    LFS_ERR_BADF        = -9,   //文件数错误
    LFS_ERR_FBIG        = -27,  //文件过大
    LFS_ERR_INVAL       = -22,  //错误的参数
    LFS_ERR_NOSPC       = -28,  //设备上没有盈余空间
    LFS_ERR_NOMEM       = -12,  //内存不足
    LFS_ERR_NOATTR      = -61,  //数据或地址错误
    LFS_ERR_NAMETOOLONG = -36,  //文件名过长
};

//LittleFS用到的类型
enum lfs_type {
    //文件类型
    LFS_TYPE_REG            = 0x001,	//初始化id+name为普通文件
    LFS_TYPE_DIR            = 0x002,	//初始化id+name为目录

    //内部使用的类型
    LFS_TYPE_SPLICE         = 0x400,
	//此id关联文件名和文件类型,chunk表明文件类型
    LFS_TYPE_NAME           = 0x000,
	//通过id关联数据结构,具体不加取件于数据结构的type
    LFS_TYPE_STRUCT         = 0x200,
    LFS_TYPE_USERATTR       = 0x300,
    LFS_TYPE_FROM           = 0x100,
	//metadata pair的tail指针,将所有pairs连接成链表
    LFS_TYPE_TAIL           = 0x600,
	
    LFS_TYPE_GLOBALS        = 0x700,
    //表明合并结束,提供校验信息,初值是0xFFFFFFFF
	LFS_TYPE_CRC            = 0x500,

    //特殊的内部使用的类型
	//新建文件使用该id,inline file无需此tag
	//创建的工作时移动使用此ID的任何文件
	//创建类似于插入虚构的文件数组中
    LFS_TYPE_CREATE         = 0x401,
    //删除文件时使用此id,此标记将移至于该id相邻的任何文件
	//删除类似于虚构的文件数组中删除
	LFS_TYPE_DELETE         = 0x4ff,
	//初始化id为超级块
    LFS_TYPE_SUPERBLOCK     = 0x0ff,
	//目录数据结构,目录通过metadata pair链表形式存储
	//每个pair包含任意数量文件,文件按字母顺序排列
    LFS_TYPE_DIRSTRUCT      = 0x200,
	//CTZ skip-list结构,存储大文件,文件存储在反向的skip-list中
	//一个指针指向skip-list的head,通过skip-list head和size即可读取文件
    LFS_TYPE_CTZSTRUCT      = 0x202,
	//inline结构,用于存储小文件,它直接存在metadata pair中
	//数据存储在tag的data字段中
    LFS_TYPE_INLINESTRUCT   = 0x201,
	//下一个metadata pair不属于当前目录,仅为了方便文件系统遍历
    LFS_TYPE_SOFTTAIL       = 0x600,
	//下一个metadata pair属于当前目录
	//目录按字母排序,下一个文件名只比当前大
    LFS_TYPE_HARDTAIL       = 0x601,
	//存储导致文件缺失sync的动作信息
    LFS_TYPE_MOVESTATE      = 0x7ff,

    //芯片内部资源
    LFS_FROM_NOOP           = 0x000,
    LFS_FROM_MOVE           = 0x101,
	//用户属性结构
    LFS_FROM_USERATTRS      = 0x102,
};

//文件打开标志
enum lfs_open_flags {
    //打开标志
    LFS_O_RDONLY = 1,         //只读打开
    LFS_O_WRONLY = 2,         //只写打开
    LFS_O_RDWR   = 3,         //读写打开
    LFS_O_CREAT  = 0x0100,    //如果文件不存在就创建
    LFS_O_EXCL   = 0x0200,    //如果文件存在就失败
    LFS_O_TRUNC  = 0x0400,    //文件打开时截断
    LFS_O_APPEND = 0x0800,    //打开时光标移动到末尾

    //内部使用标志
    LFS_F_DIRTY   = 0x010000, //文件不匹配存储区
    LFS_F_WRITING = 0x020000, //自上次刷新以来文件已经被写入
    LFS_F_READING = 0x040000, //自上次刷新以来文件已经被读取
    LFS_F_ERRED   = 0x080000, //写入过程错误
    LFS_F_INLINE  = 0x100000, //当前被内联在目录项中
    LFS_F_OPENED  = 0x200000, //文件已经被打开
};

//文件偏移标志
enum lfs_whence_flags {
    LFS_SEEK_SET = 0,   //偏移到文件开头
    LFS_SEEK_CUR = 1,   //偏移到当前位置
    LFS_SEEK_END = 2,   //偏移到结尾位置
};


//初始化时的配置
struct lfs_config {
    //不透明的用户提供的上下文,可用于向块设备操作传递信息
    void *context;

    //读取块中的一个区域
	//负错误码会被推送给用户
    int (*read)(const struct lfs_config *c, lfs_block_t block,
            lfs_off_t off, void *buffer, lfs_size_t size);

    //在一个块中编写一个区域,该块必须先前已被擦除
	//负错误码会被推送给用户,如果块被认为是坏的,可能返回LFS_ERR_CORRUPT
    int (*prog)(const struct lfs_config *c, lfs_block_t block,
            lfs_off_t off, const void *buffer, lfs_size_t size);

    //擦除一个块,一个块在被编程之前必须被擦除,被擦除的块的状态是未定义的
	//负错误码会被推送给用户,如果块被认为是坏的,可能返回LFS_ERR_CORRUPT
    int (*erase)(const struct lfs_config *c, lfs_block_t block);

    //同步底层块设备的状态,负错误码会被推送给用户
    int (*sync)(const struct lfs_config *c);

    //读取块的最小大小,所有读操作都是这个值的倍数
    lfs_size_t read_size;

    //块程序的最小大小,所有程序操作都将是这个值的倍数
    lfs_size_t prog_size;

    //可擦块的大小
	//这不会影响ram的消耗,并且可能比物理擦除大小更大
	//但是,非内联文件至少占用一个块,必须是读和程序大小的倍数
    lfs_size_t block_size;

    //设备上可擦除的块的数量
    lfs_size_t block_count;

    //在littlefs清除元数据日志并将元数据移动到另一个块之前的擦除周期数
	//建议值在100-1000范围内,大的值具有更好的性能,但代价是磨损不均匀
    //设置为-1时，禁用块级磨损均衡
    int32_t block_cycles;

    //块缓存的大小,每个高速缓存在RAM中缓冲一个块的一部分
	//littlefs需要一个读缓存、一个程序缓存和每个文件一个额外的缓存
	//更大的缓存可以通过存储更多的数据和减少磁盘访问数量来提高性能
	//必须是读大小和程序大小的倍数,以及块大小的因数
    lfs_size_t cache_size;

    //前向缓冲区大小(以字节为单位),较大的前向缓冲区增加了在分配过程中发现的块的数量
	//前向缓冲区被存储为一个紧凑的位图,所以RAM的每个字节可以跟踪8个块,必须是8的倍数
    lfs_size_t lookahead_size;

    //可选的静态分配的读缓冲区,必须cache_size
	//默认情况下,使用lfs_malloc分配这个缓冲区
    void *read_buffer;

    //可选的静态分配的写缓冲区,必须cache_size
	//默认情况下,使用lfs_malloc分配这个缓冲区
    void *prog_buffer;

    //可选的静态分配前向缓冲区,必须是lookahead_size并且对齐到32位边界
	//默认情况下,使用lfs_malloc分配这个缓冲区
    void *lookahead_buffer;

    //可选的文件名长度上限(以字节为单位)
	//对于更大的名称,除了由LFS_NAME_MAX定义控制的info结构体的大小之外,没有坏处
	//0时默认为LFS_NAME_MAX,存储在超级块中,必须被其他littlefs驱动程序所重视
    lfs_size_t name_max;

    //可选的文件上限(以字节为单位),对于更大的文件没有坏处,但必须是LFS_FILE_MAX
	//0时默认为LFS_FILE_MAX,存储在超级块中,必须被其他littlefs驱动程序所重视
    lfs_size_t file_max;

    //可选的自定义属性上限(以字节为单位)
	//更大的属性大小没有坏处,但必须是LFS_ATTR_MAX
	//0时默认为LFS_ATTR_MAX
    lfs_size_t attr_max;
};

//文件信息结构体
struct lfs_info {
    //文件类型,LFS_TYPE_REG或LFS_TYPE_DIR
    uint8_t type;

    //文件大小,仅对REG文件有效,限制为32位
    lfs_size_t size;

    //以空结束字符串形式存储的文件的名称,限制为LFS_NAME_MAX+1
	//可以通过重新定义LFS_NAME_MAX来减少RAM
	//LFS_NAME_MAX存储在superblock中,其他littlefs驱动必须重视它
    char name[LFS_NAME_MAX+1];
};

//自定义属性结构,用于描述在文件写过程中自动提交的自定义属性
struct lfs_attr {
    //8位类型的属性,由用户提供,用于标识属性
    uint8_t type;

    //指向包含该属性的缓冲区的指针
    void *buffer;

    //属性大小(字节),限制为LFS_ATTR_MAX
    lfs_size_t size;
};

//lfs_file_opencfg中提供的可选配置
struct lfs_file_config {
    //可选的静态分配的文件缓冲区,必须cache_size
	//默认情况下,使用lfs_malloc分配这个缓冲区
    void *buffer;

    //与文件相关的自定义属性的可选列表
	//如果文件以读访问权限打开,这些属性将在open调用期间从磁盘读取
	//如果文件以写访问方式打开,则每次同步或关闭文件时都会将属性写入磁盘
	//这个写入是自动发生的,更新文件的内容
    //
    //自定义属性由8位类型唯一标识,并且限制为LFS_ATTR_MAX字节
	//当读取时,如果存储的属性比缓冲区小,它将用零填充
	//如果存储的属性更大,那么它将被静默地截断,如果没有找到该属性,将隐式创建它
    struct lfs_attr *attrs;

    //列表中自定义属性的数量
    lfs_size_t attr_count;
};

///内部littlefs数据结构///

//缓冲区
typedef struct lfs_cache {
    lfs_block_t block;		//缓冲区的数据属于的块
    lfs_off_t off;			//缓冲区在块中的偏移量
    lfs_size_t size;		//缓冲区的大小
    uint8_t *buffer;		//缓冲区数据存放的地址
} lfs_cache_t;

typedef struct lfs_mdir {
    lfs_block_t pair[2];	//Dir的metadata pair所在的块
    uint32_t rev;			//metadata pair的修订
    lfs_off_t off;			//tag的偏移地址
    uint32_t etag;
    uint16_t count;
    bool erased;
    bool split;				//metadata pair是否为链表
    lfs_block_t tail[2];	//用于metadata pair链表
} lfs_mdir_t;

//littlefs目录类型
typedef struct lfs_dir {
    struct lfs_dir *next;	//下一目录
    uint16_t id;
    uint8_t type;			//LFS_TYPE_DIR
    lfs_mdir_t m;			//代表Dir的metadata pair

    lfs_off_t pos;			//目录中的当前位置,用于seek,tell,rewind
    lfs_block_t head[2];
} lfs_dir_t;

//littlefs文件类型
typedef struct lfs_file {
    struct lfs_file *next;
    uint16_t id;			//metadata tag中的id,文件open时获取
    uint8_t type;			//LFS_TYPE_REG或LFS_TYPE_DIR
    lfs_mdir_t m;			//文件所在的目录的metadata pair

    struct lfs_ctz {
        lfs_block_t head;
        lfs_size_t size;
    } ctz;					//指向大文件的CTZ skip_list,小文件直接inline

    uint32_t flags;			//lfs_open_flags中的值
    lfs_off_t pos;			//文件访问时的偏移
    lfs_block_t block;		//file当前的块
    lfs_off_t off;			//在块内的偏移
    lfs_cache_t cache;		//文件访问时的缓冲区

							//文件open时的配置参数,包含一个缓冲区以及用户属性
    const struct lfs_file_config *cfg;	
} lfs_file_t;

typedef struct lfs_superblock {
    uint32_t version;		//文件系统版本号
    lfs_size_t block_size;	//文件系统的块大小,与Flash大小不一定相同
    lfs_size_t block_count;	//文件系统包含的块数量
    lfs_size_t name_max;	//文件名的最大长度
    lfs_size_t file_max;	//文件的最大长度
    lfs_size_t attr_max;	//用户属性的最大长度
} lfs_superblock_t;

//littlefs文件系统类型
typedef struct lfs {
    lfs_cache_t rcache;			//读缓冲区
    lfs_cache_t pcache;			//写缓冲区

    lfs_block_t root[2];		//根目录所在的块
    struct lfs_mlist {
        struct lfs_mlist *next;	//指向下一个节点
        uint16_t id;			//metadata pair的id
        uint8_t type;			//metadata pair的类型
        lfs_mdir_t m;			//metadata pair
    } *mlist;					//metadata pair list
    uint32_t seed;				//块分配器的随机数生成

    struct lfs_gstate {
        uint32_t tag;
        lfs_block_t pair[2];
    } gstate, gpending, gdelta;	//目录操作sync的全局状态

    struct lfs_free {
        lfs_block_t off;		//记录前向缓冲区中起始块的偏移
        lfs_block_t size;		//前向缓冲区中块的数量
								//前向缓冲区以位图的形式,实际大小要*8
        lfs_block_t i;			//前向缓冲区内部的偏移地址
        lfs_block_t ack;		//剩余块数量,初始时为block count
								//该值为0表明没有空余块了
        uint32_t *buffer;		//缓冲区起始位置,长度为lookahead size
    } free;						//前向缓冲区,用于分配空余块

    const struct lfs_config *cfg;	//文件系统的配置参数
    lfs_size_t name_max;		//文件名最大长度,与superblock中一致
    lfs_size_t file_max;		//文件的最大长度,与superblock中一致
    lfs_size_t attr_max;		//用户属性的最大长度,与superblock中一致

#ifdef LFS_MIGRATE				//前置版本兼容
    struct lfs1 *lfs1;
#endif
} lfs_t;


///文件系统函数///

//使用littlefs格式化块设备
//
//需要一个littlefs对象和配置结构
//这将破坏littlefs对象，并且不会使文件系统挂载
//config结构必须为默认和向后兼容置零
int lfs_format(lfs_t *lfs, const struct lfs_config *config);

//安装一个littlefs
//
//需要一个littlefs对象和配置结构
//可以使用多个littlefs对象同时装载多个文件系统,挂载时必须分配lfs和config
//config结构必须为默认和向后兼容置零
int lfs_mount(lfs_t *lfs, const struct lfs_config *config);

//卸载littlefs
//
//除了释放已分配的资源之外,什么也不做
int lfs_unmount(lfs_t *lfs);

///一般操作///

//删除文件或目录
//
//删除目录时,目录必须为空
int lfs_remove(lfs_t *lfs, const char *path);

//重命名或移动文件或目录
//
//如果目标存在,它必须在类型上与源匹配
//如果目标是一个目录,目录必须为空
int lfs_rename(lfs_t *lfs, const char *oldpath, const char *newpath);

//查找文件或目录的信息
//
//根据指定的文件或目录填写信息结构
int lfs_stat(lfs_t *lfs, const char *path, struct lfs_info *info);

//获取自定义属性
//
//自定义属性由8位类型唯一标识,并且限制为LFS_ATTR_MAX字节
//当读取时,如果存储的属性比缓冲区小,它将用零填充
//如果存储的属性更大，那么它将被静默地截断
//如果没有找到属性,则返回错误LFS_ERR_NOATTR,缓冲区填充0
//
//返回属性的大小,失败时返回否定的错误代码
//注意,返回的大小是磁盘上属性的大小,与缓冲区的大小无关
//这可用于动态分配缓冲区或检查是否存在
lfs_ssize_t lfs_getattr(lfs_t *lfs, const char *path,
        uint8_t type, void *buffer, lfs_size_t size);

//设置自定义属性
//
//自定义属性由8位类型唯一标识,并且限制为LFS_ATTR_MAX字节
//如果没有找到某个属性,则将隐式创建该属性
int lfs_setattr(lfs_t *lfs, const char *path,
        uint8_t type, const void *buffer, lfs_size_t size);

//删除自定义属性
//
//如果没有找到属性,什么也不会发生
int lfs_removeattr(lfs_t *lfs, const char *path, uint8_t type);


///文件操作///

//打开文件
//
//打开文件的方式由标志决定,标志是枚举lfs_open_flags中的值,按位排列在一起
int lfs_file_open(lfs_t *lfs, lfs_file_t *file,
        const char *path, int flags);

//打开一个附加配置文件
//
//打开文件的方式由标志决定,标志是枚举lfs_open_flags中的值,按位排列在一起
//
//配置结构提供了额外的配置选项,每个文件如上所述
//配置结构必须在文件打开时分配,并且配置结构必须为默认和向后兼容置零
int lfs_file_opencfg(lfs_t *lfs, lfs_file_t *file,
        const char *path, int flags,
        const struct lfs_file_config *config);

//关闭文件
//
//任何挂起的写入都被写入存储,就像调用了sync一样,并释放任何分配的资源
int lfs_file_close(lfs_t *lfs, lfs_file_t *file);

//同步存储上的文件
//
//任何挂起的写入都被写入存储
int lfs_file_sync(lfs_t *lfs, lfs_file_t *file);

//从文件读取数据
//
//获取一个缓冲区和大小来指示读取数据的存储位置
//
//返回读取的字节数
lfs_ssize_t lfs_file_read(lfs_t *lfs, lfs_file_t *file,
        void *buffer, lfs_size_t size);

//向文件写入数据
//
//获取一个缓冲区和大小来指示要写的数据
//在调用sync或close之前文件实际上不会在存储上更新
//
//返回写入的字节数
lfs_ssize_t lfs_file_write(lfs_t *lfs, lfs_file_t *file,
        const void *buffer, lfs_size_t size);

//修改文件的位置
//
//位置的变化由偏移量和位置标志决定
//
//返回文件的新位置
lfs_soff_t lfs_file_seek(lfs_t *lfs, lfs_file_t *file,
        lfs_soff_t off, int whence);

//将文件的大小截断为指定的大小
int lfs_file_truncate(lfs_t *lfs, lfs_file_t *file, lfs_off_t size);

//返回文件的位置
//
//等于lfs_file_seek(lfs, file, 0, LFS_SEEK_CUR)
//
//返回文件的位置
lfs_soff_t lfs_file_tell(lfs_t *lfs, lfs_file_t *file);

//将文件的位置改为文件的开头
//
//相当于lfs_file_seek(lfs, file, 0, LFS_SEEK_SET)
int lfs_file_rewind(lfs_t *lfs, lfs_file_t *file);

//返回文件大小
//
//类似lfs_file_seek(lfs, file, 0, LFS_SEEK_END)
lfs_soff_t lfs_file_size(lfs_t *lfs, lfs_file_t *file);


///目录操作///

//创建目录
int lfs_mkdir(lfs_t *lfs, const char *path);

//打开目录
//
//打开一个目录后，可以使用read来遍历文件
int lfs_dir_open(lfs_t *lfs, lfs_dir_t *dir, const char *path);

//关闭目录
//
//释放所有已分配的资源
int lfs_dir_close(lfs_t *lfs, lfs_dir_t *dir);

//读取目录中的条目
//
//根据指定的文件或目录填写信息结构
//
//成功时返回正值,目录末尾返回0
int lfs_dir_read(lfs_t *lfs, lfs_dir_t *dir, struct lfs_info *info);

//修改目录的位置
//
//新的off必须是之前从tell返回的值,并指定了directory seek中的绝对偏移量
int lfs_dir_seek(lfs_t *lfs, lfs_dir_t *dir, lfs_off_t off);

//返回目录的位置
//
//返回的偏移量仅用于seek,可能没有意义,但确实指示了目录迭代中的当前位置
//
//返回目录的位置
lfs_soff_t lfs_dir_tell(lfs_t *lfs, lfs_dir_t *dir);

//修改目录的位置到目录的开头
int lfs_dir_rewind(lfs_t *lfs, lfs_dir_t *dir);


///文件系统级进行文件系统操作///

//查找文件系统的当前大小
//
//注意:结果是最好的努力
//如果文件共享COW结构,则返回的大小可能大于文件系统实际的大小
//
//返回分配的块的数量
lfs_ssize_t lfs_fs_size(lfs_t *lfs);

//遍历文件系统中使用的所有块
//
//提供的回调函数将被文件系统当前使用的每个块地址调用
//这可用于确定使用了哪些块或有多少存储可用
int lfs_fs_traverse(lfs_t *lfs, int (*cb)(void*, lfs_block_t), void *data);

#ifdef LFS_MIGRATE

//尝试迁移littlefs的前一个版本
//
//类似于lfs_format函数
//尝试挂载littlefs的前一个版本并更新文件系统,以便它可以挂载到littlefs的当前版本
//
//需要一个littlefs对象和配置结构
//这将破坏littlefs对象,并且不会使文件系统挂载,config结构必须为默认和向后兼容置零
int lfs_migrate(lfs_t *lfs, const struct lfs_config *cfg);
#endif


#ifdef __cplusplus
}
#endif

#endif
