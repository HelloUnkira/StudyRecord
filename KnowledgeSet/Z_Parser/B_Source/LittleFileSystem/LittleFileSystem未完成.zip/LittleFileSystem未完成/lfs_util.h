/*
 * lfs 配置封装层
 */
#ifndef LFS_UTIL_H
#define LFS_UTIL_H


#ifdef LFS_CONFIG
//配置裁剪宏,使用该配置用户可在上方#include "xxx.h"
//而在对应的.h中添加LFS_CONFIG宏用于屏蔽默认配置
//此时配置变成下述三条"无用"宏
#define LFS_STRINGIZE(x) LFS_STRINGIZE2(x)
#define LFS_STRINGIZE2(x) #x
#include LFS_STRINGIZE(LFS_CONFIG)

#else
//当然,直接修改.h也可以达到该效果,修改部分在此处
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <inttypes.h>

#ifndef LFS_NO_MALLOC
#include <stdlib.h>
#endif
#ifndef LFS_NO_ASSERT
#include <assert.h>
#endif

#if !defined(LFS_NO_DEBUG) || \
        !defined(LFS_NO_WARN) || \
        !defined(LFS_NO_ERROR) || \
        defined(LFS_YES_TRACE)
#include <stdio.h>
#endif

#ifdef __cplusplus
extern "C"
{
#endif

//指令追踪的宏,用于程序定位
#ifdef LFS_YES_TRACE
#define LFS_TRACE(fmt, ...) \
    printf("lfs_trace:%d: " fmt "\n", __LINE__, __VA_ARGS__)
#else
#define LFS_TRACE(fmt, ...)
#endif

#ifndef LFS_NO_DEBUG
#define LFS_DEBUG(fmt, ...) \
    DEBUG_PRINT("lfs_debug:%d: " fmt "\n", __LINE__, __VA_ARGS__)
#else
#define LFS_DEBUG(fmt, ...)
#endif

#ifndef LFS_NO_WARN
#define LFS_WARN(fmt, ...) \
    DEBUG_PRINT("lfs_warn:%d: " fmt "\n", __LINE__, __VA_ARGS__)
#else
#define LFS_WARN(fmt, ...)
#endif

#ifndef LFS_NO_ERROR
#define LFS_ERROR(fmt, ...) \
    DEBUG_PRINT("lfs_error:%d: " fmt "\n", __LINE__, __VA_ARGS__)
#else
#define LFS_ERROR(fmt, ...)
#endif

// 断言
#ifndef LFS_NO_ASSERT
extern void sys_assert_check(bool sert, const uint8_t * file_name,uint16_t line_num);
#define LFS_ASSERT(test) sys_assert_check(test,(uint8_t *)__FILE__,(uint16_t)__LINE__)
#else
#define LFS_ASSERT(test)
#endif

//可进行编译器优化的代码
static inline uint32_t lfs_max(uint32_t a, uint32_t b) {
    return (a > b) ? a : b;
}
static inline uint32_t lfs_min(uint32_t a, uint32_t b) {
    return (a < b) ? a : b;
}
//地址字节对齐,对齐到字节的低位
static inline uint32_t lfs_aligndown(uint32_t a, uint32_t alignment) {
    return a - (a % alignment);
}
//对齐到下一字节的低位,跳过本字中不对齐的部分
static inline uint32_t lfs_alignup(uint32_t a, uint32_t alignment) {
    return lfs_aligndown(a + alignment-1, alignment);
}

//求一个与a 最近 且 小于等于a 的2次幂数的幂
static inline uint32_t lfs_npw2(uint32_t a) {
#if !defined(LFS_NO_INTRINSICS) && (defined(__GNUC__) || defined(__CC_ARM))
    return 32 - __builtin_clz(a-1);//求比a最近的一个小于等于a的数 a-1 前导0的个数
#else
    uint32_t r = 0;
    uint32_t s;
    a -= 1;//先扣除1
    s = (a > 0xffff) << 4; a >>= s; r |= s; //如果一个数比16位最大数大就先去掉尾部16位
    s = (a > 0xff  ) << 3; a >>= s; r |= s; //如果一个数比8位最大数大就先去掉尾部8位
    s = (a > 0xf   ) << 2; a >>= s; r |= s; //如果一个数比4位最大数大就先去掉尾部4位
    s = (a > 0x3   ) << 1; a >>= s; r |= s; //如果一个数比2位最大数大就先去掉尾部2位
    return (r | (a >> 1)) + 1;				//如果一个数比2位最大数大就先去掉尾部1位
											//每次运算r记录了a右移的次数,此时移动完后计算出了
											//其后缀有效值的长度大小,也即目标
#endif
}

//求一个数的后缀0的个数
static inline uint32_t lfs_ctz(uint32_t a) {
#if !defined(LFS_NO_INTRINSICS) && defined(__GNUC__)
    return __builtin_ctz(a);//求一个数的后缀0的个数
#else//一个数原码与补码做与运算,仅最高位被保留其它位全部清空
    return lfs_npw2((a & -a) + 1) - 1;
#endif
}

//一个数多少位为1
static inline uint32_t lfs_popc(uint32_t a) {
#if !defined(LFS_NO_INTRINSICS) && (defined(__GNUC__) || defined(__CC_ARM))
    return __builtin_popcount(a);//一个数多少位为1
#else
    a = a - ((a >> 1) & 0x55555555);//计算相邻俩位的1的个数
	//例:二进制数abcdefgh - (0abcdefg & 01010101) = abcdefgh - 0a0c0e0g
	//一个二进制数 ab - 0a,不管ab是否都为1,都可以计算ab中1的有效位
    a = (a & 0x33333333) + ((a >> 2) & 0x33333333);//计算相邻四位的1的个数
	//例:二进制数(abcdefgh & 00110011) + (00abcdef & 00110011) = 00cd00gh + 00ab00cd
    return (((a + (a >> 4)) & 0xf0f0f0f) * 0x1010101) >> 24;//如上
	//例:二进制数(abcdefgh + 0000abcd) & 00001111
	//十六进制数0(X1)0(X2)0(X3)0(X4) * 0x01010101 = 
	//0(X1)0(X2)0(X3)0(X4) + 0(X2)0(X3)0(X4)00 + 0(X3)0(X4)0000 + 0(X4)000000 =
	//( 0(X1) + 0(X2) + 0(X3) + 0(X4) )xxxxxx >> 24
#endif
}

//比较ab序列的距离
static inline int lfs_scmp(uint32_t a, uint32_t b) {
    return (int)(unsigned)(a - b);
}

//本地序列(如果本地序列是大端)转化为小端序列
static inline uint32_t lfs_fromle32(uint32_t a) {
#if !defined(LFS_NO_INTRINSICS) && ( \
    (defined(  BYTE_ORDER  ) && defined(  ORDER_LITTLE_ENDIAN  ) &&   BYTE_ORDER   ==   ORDER_LITTLE_ENDIAN  ) || \
    (defined(__BYTE_ORDER  ) && defined(__ORDER_LITTLE_ENDIAN  ) && __BYTE_ORDER   == __ORDER_LITTLE_ENDIAN  ) || \
    (defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__))
    return a;//小端序列不需转化
#elif !defined(LFS_NO_INTRINSICS) && ( \
    (defined(  BYTE_ORDER  ) && defined(  ORDER_BIG_ENDIAN  ) &&   BYTE_ORDER   ==   ORDER_BIG_ENDIAN  ) || \
    (defined(__BYTE_ORDER  ) && defined(__ORDER_BIG_ENDIAN  ) && __BYTE_ORDER   == __ORDER_BIG_ENDIAN  ) || \
    (defined(__BYTE_ORDER__) && defined(__ORDER_BIG_ENDIAN__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__))
    return __builtin_bswap32(a);//大段序列需要转化
#else
	//以字节来中心交换一个四字节数
    return (((uint8_t*)&a)[0] <<  0) |
           (((uint8_t*)&a)[1] <<  8) |
           (((uint8_t*)&a)[2] << 16) |
           (((uint8_t*)&a)[3] << 24);
#endif
}

static inline uint32_t lfs_tole32(uint32_t a) {
    return lfs_fromle32(a);
}

//本地序列(如果本地序列是小端)转化为大端序列
static inline uint32_t lfs_frombe32(uint32_t a) {
#if !defined(LFS_NO_INTRINSICS) && ( \
    (defined(  BYTE_ORDER  ) && defined(  ORDER_LITTLE_ENDIAN  ) &&   BYTE_ORDER   ==   ORDER_LITTLE_ENDIAN  ) || \
    (defined(__BYTE_ORDER  ) && defined(__ORDER_LITTLE_ENDIAN  ) && __BYTE_ORDER   == __ORDER_LITTLE_ENDIAN  ) || \
    (defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__))
    return __builtin_bswap32(a);
#elif !defined(LFS_NO_INTRINSICS) && ( \
    (defined(  BYTE_ORDER  ) && defined(  ORDER_BIG_ENDIAN  ) &&   BYTE_ORDER   ==   ORDER_BIG_ENDIAN  ) || \
    (defined(__BYTE_ORDER  ) && defined(__ORDER_BIG_ENDIAN  ) && __BYTE_ORDER   == __ORDER_BIG_ENDIAN  ) || \
    (defined(__BYTE_ORDER__) && defined(__ORDER_BIG_ENDIAN__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__))
    return a;
#else
	//以字节来中心交换一个四字节数
    return (((uint8_t*)&a)[0] << 24) |
           (((uint8_t*)&a)[1] << 16) |
           (((uint8_t*)&a)[2] <<  8) |
           (((uint8_t*)&a)[3] <<  0);
#endif
}

static inline uint32_t lfs_tobe32(uint32_t a) {
    return lfs_frombe32(a);
}

//计算多项式polynomial = 0x04c11db7的CRC-32
uint32_t lfs_crc(uint32_t crc, const void *buffer, size_t size);

//内存分配函数,如果系统没有给lfs提供缓冲区时,需要添加此处实现
#include "xxx.h"
#include "stdlib.h"
static inline void *lfs_malloc(size_t size) {
#ifndef LFS_NO_MALLOC
    return XXX_MALLOC(size);//修改
	return malloc(size);
#else
    (void)size;//阻止编译器警告
    return NULL;
#endif
}

//内存释放函数,如果系统没有给lfs提供缓冲区时,需要添加此处实现
static inline void lfs_free(void *p) {
#ifndef LFS_NO_MALLOC
    XXX_FREE(p);//修改
	free(p);
#else
    (void)p;//阻止编译器警告
#endif
}


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
#endif
