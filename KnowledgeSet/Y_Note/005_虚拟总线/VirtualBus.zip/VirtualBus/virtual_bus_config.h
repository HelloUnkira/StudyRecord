/*
 * Virtual Bus 配置文件
 */
