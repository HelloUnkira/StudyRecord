/*
 * Virtual Bus 接口
 */