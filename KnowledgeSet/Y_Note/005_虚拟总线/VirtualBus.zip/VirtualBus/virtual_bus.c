/*
 * Virtual Bus 源
 */

//一种优化版本的 vbus总线,适用于各个注册入总线的设备
//之间的自由通信,并为其准备了设备广播功能,和事务暂存功能

///////////////////////////////////////////////////////////////////////////////////////////////////
//依赖项
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
///////////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
//重定向的动态分配函数
void* vbus_malloc(unsigned int length)
{
	void* temp = malloc(length);
	memset(mem_space, 0, length);
	return temp;
}

void vbus_free(void* mem_space)
{
	free(mem_space);
}

void* vbus_realloc(void* mem_space, unsigned int old_length, unsigned int more_length)
{	//因为未使用到底层realloc,所以只能以此作替换
	void* temp = malloc(old_length + more_length);
	memcpy(temp, mem_space, old_length);
	free(mem_space);
	if (temp != NULL)
		max_number += more_length;
	return temp;
}
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////////////////////////
//事务与数据的处理回调
typedef void (*driver_funtion)(void* event, void* data, int data_length);
//vbus中设备的项
struct virtual_bus
{
	char*			register_name;		//设备注册时的名字
	int				register_id;		//设备注册时被分配的ID
	driver_funtion	send_function;		//设备的事务发送处理
	driver_funtion	receive_function;	//设备的事务接收处理
#ifdef USE_DRIVER_NAME_MATCH	
	//总线自身所需的hash
	struct virtual_bus* prev;
	struct virtual_bus* next;
#endif
} virtual_bus_t;
//总线需要为其维护一些列本地的缓冲数据
//所以需要为总线提供malloc函数和free函数
//以用于动态分配管理空间
virtual_bus_t**	vbus_mem;
unsigned int	max_number = 10;
unsigned int	cur_number = 0;
///////////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef USE_DRIVER_NAME_MATCH
//默认使用的散列函数,JS散列
static int JSHash(char* str)  
{  
	long hash = 1315423911;  
	while(*str != '\0')  
		hash ^= ((hash << 5) + (hash >> 2) + *str++);
	return (int)hash;  
}

//默认散列函数
typedef int (*default_hash)(char* driver_name);
default_hash default_vbus_hash = JSHash;
virtual_bus_t** vbus_dirver_hash;
unsigned int	hash_length = 26;

virtual_bus_t* item_add_to_head(virtual_bus_t* list, virtual_bus_t* item)
{
	if (item == NULL)
		return list;
	item->next = list;
	if (list != NULL)
		list->prev = item;	
	return item;
}

virtual_bus_t* item_remove_from_list(virtual_bus_t* list, virtual_bus_t* item)
{
	if (item == NULL || list == NULL)
		return list;
	if (item->prev == NULL) {
		item->next->prev = NULL;
		return item->next;
	} else if (item->next == NULL) {
		item->prev->next = NULL;
		return list;
	} esle {
		item->prev->next = item->next;
		item->next->prev = item->prev;
	}
}

unsigned int search_vbus_driver(virtual_bus_t* list, char* driver_name)
{
	if (list == NULL || driver_name == NULL)
		return (~(0));
	while (list != NULL) {
		if (strcmp(list->register_name,driver_name) == 0)
			return list->register_id;
		list = list->next;
	}
	return (~(0));
}

#endif
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
void vbus_init()
{	//默认时只需要开辟十个空间足够
	vbus_mem = (virtual_bus_t**)vbus_malloc(max_number * sizeof(void*));
#ifdef USE_DRIVER_NAME_MATCH	
	vbus_dirver_hash = (virtual_bus_t**)vbus_malloc(hash_length * sizeof(void*));
#endif
}

unsigned int vbus_add_driver(char* driver_name, driver_funtion send, driver_funtion receive)
{
	if (cur_number == max_number)
		vbus_mem = (virtual_bus_t**)vbus_realloc(vbus_mem, max_number, 10);
	for (int i = 0; i < max_number; i++)
		if (vbus_mem[i] == NULL) {
			vbus_mem[i] = vbus_malloc(sizeof(virtual_bus_t));
			if (vbus_mem[i] != NULL) {
				int length = strlen(driver_name);
				vbus_mem[i]->register_name = (char*)vbus_malloc(length + 1);
				if (vbus_mem[i]->register_name != NULL) {
					memcpy((vbus_mem[i]->register_name), dirver_name, length + 1);
					vbus_mem[i]->register_id = i;
					vbus_mem[i]->send_function = send;
					vbus_mem[i]->receive_function = receive;
					cur_number++;
#ifdef USE_DRIVER_NAME_MATCH//将设备名字关联到总线散列集中	
					int index = default_vbus_hash(vbus_mem[i]->register_name) % hash_length;
					vbus_dirver_hash[index] = item_add_to_head(vbus_dirver_hash[index], vbus_mem[i]);
#endif		
				return vbus_mem[i]->register_id;					
				} else return (~(0));
			}else return (~(0));
		}
	return (~(0));
}

void vbus_remove_driver(char* driver_name, unsigned int driver_id)
{	
	if (driver_id >= 0 && driver_id < max_number) {
		vbus_free(vbus_mem[driver_id]);
		vbus_mem[driver_id] = NULL;	
		cur_number--;
	} else {
		virtual_bus* temp = NULL;
#ifdef USE_DRIVER_NAME_MATCH
		if (driver_name != NULL) {
			int index = default_vbus_hash(driver_name) % hash_length;
			for (temp = vbus_dirver_hash[index]; temp != NULL; temp = temp->next)
				if (strcmp(temp->register_name, driver_name) == 0)
					vbus_dirver_hash[index] = item_remove_from_list(vbus_dirver_hash[index], temp);
		}
#endif		
		if (temp != NULL) {
			vbus_mem[temp->register_id] = NULL;
			vbus_free(temp);
			cur_number--;
		}		
	}
}

bool vbus_event_data_send(void* event, void* data, int data_length,
						  char* target_driver_name, unsigned int target_id)
{
	if (target_id >= 0 && target_id < max_number) {
		vbus_mem[target_id]->receive(event, data, data_length);
		return true;
	} else {
#ifdef USE_DRIVER_NAME_MATCH			
		int index = default_vbus_hash(driver_name) % hash_length; 
		target_id = search_vbus_driver(vbus_mem[index],target_driver_name);
		if (target_id >= 0 && target_id < max_number) {
			vbus_mem[target_id]->receive(event, data, data_length);
			return true;
		}  
#endif
		return false;
	}
}

void vbus_event_data_adv(int target_number, void* event, void* data, int data_length,...)
{
	//……
	va_list arg;
	va_start(arg, target_number);
	
	//……不记得了,解析参数后循环调用上面的就可以了
	
	va_end(arg);
}


//为send设置一个send集让设备本地维护,那么设备可将其托管到总线上











