/*
 * 任务
 */

#include <stdlib.h>
#include <string.h>

//接口重包含,提前定义一下用于屏蔽mpu_wappers.h造成的影响
#define MPU_WRAPPERS_INCLUDED_FROM_API_FILE

#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "stack_macros.h"

//取消重包含,因为已经没必要了
#undef MPU_WRAPPERS_INCLUDED_FROM_API_FILE

//参数为2时取消对stdio.h的包含,否则包含所有的 STATS格式化函数
#if ( configUSE_STATS_FORMATTING_FUNCTIONS == 1 )
	//方便生成人类好阅读的文本
	#include <stdio.h>
#endif

//协程的使用时,任务切换需要谨慎
#if( configUSE_PREEMPTION == 0 )
	#define taskYIELD_IF_USING_PREEMPTION()
#else
	#define taskYIELD_IF_USING_PREEMPTION() portYIELD_WITHIN_API()
#endif

//TCB程序控制块的ucNotifyState状态通知成员可被分配为以下三个之一的成员
#define taskNOT_WAITING_NOTIFICATION	( ( uint8_t ) 0 )
#define taskWAITING_NOTIFICATION		( ( uint8_t ) 1 )
#define taskNOTIFICATION_RECEIVED		( ( uint8_t ) 2 )

//设置的栈满标志
#define tskSTACK_FILL_BYTE	( 0xa5U )

//内核对TCB的分配有时静态有时动态,看具体的情况,它的更改会影响Static Task_t的定义
#define tskSTATIC_AND_DYNAMIC_ALLOCATION_POSSIBLE	( ( configSUPPORT_STATIC_ALLOCATION == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
#define tskDYNAMICALLY_ALLOCATED_STACK_AND_TCB 		( ( uint8_t ) 0 )
#define tskSTATICALLY_ALLOCATED_STACK_ONLY 			( ( uint8_t ) 1 )
#define tskSTATICALLY_ALLOCATED_STACK_AND_TCB		( ( uint8_t ) 2 )

//新的堆栈需要被配置为一个确定的值吗？如果需要的话,配置它。会与memset形成不同的依赖
#if( ( configCHECK_FOR_STACK_OVERFLOW > 1 ) || ( configUSE_TRACE_FACILITY == 1 ) || ( INCLUDE_uxTaskGetStackHighWaterMark == 1 ) )
	#define tskSET_NEW_STACKS_TO_KNOWN_VALUE	1
#else
	#define tskSET_NEW_STACKS_TO_KNOWN_VALUE	0
#endif

//任务状态配置,以字符确定任务状态
#define tskRUNNING_CHAR		( 'X' )
#define tskBLOCKED_CHAR		( 'B' )
#define tskREADY_CHAR		( 'R' )
#define tskDELETED_CHAR		( 'D' )
#define tskSUSPENDED_CHAR	( 'S' )

//去除静态变量这一修饰方式,将所有static替换为空,为某些全部调试使用到
#ifdef portREMOVE_STATIC_QUALIFIER
	#define static
#endif

//空闲任务名字
#ifndef configIDLE_TASK_NAME
	#define configIDLE_TASK_NAME "IDLE"
#endif

//使用平台优化选择,实现任务优化
#if ( configUSE_PORT_OPTIMISED_TASK_SELECTION == 0 )
	#define taskRECORD_READY_PRIORITY( uxPriority )														\
	{	/*修改就绪任务队列中最大优先级*/																				\
		if( ( uxPriority ) > uxTopReadyPriority )														\
		{																								\
			uxTopReadyPriority = ( uxPriority );														\
		}																								\
	}
	
	#define taskSELECT_HIGHEST_PRIORITY_TASK()															\
	{																									\
	UBaseType_t uxTopPriority = uxTopReadyPriority;														\
		while( listLIST_IS_EMPTY( &( pxReadyTasksLists[ uxTopPriority ] ) ) )							\
		{	/*最高优先级任务从就绪队列集中后往前找,第一个非空项*/																\
			configASSERT( uxTopPriority );																\
			--uxTopPriority;																			\
		}																								\
																										\
		/*当前任务被设置为最高优先级任务*/																				\
		listGET_OWNER_OF_NEXT_ENTRY( pxCurrentTCB, &( pxReadyTasksLists[ uxTopPriority ] ) );			\
		uxTopReadyPriority = uxTopPriority;																\
	}

	//仅仅平台被配置,任务就绪优先级重置和平台就绪优先级重置功能才存在
	#define taskRESET_READY_PRIORITY( uxPriority )
	#define portRESET_READY_PRIORITY( uxPriority, uxTopReadyPriority )

#else 
	//修正最大就绪优先级
	#define taskRECORD_READY_PRIORITY( uxPriority )	portRECORD_READY_PRIORITY( uxPriority, uxTopReadyPriority )

	//获取平台的最大优先级
	#define taskSELECT_HIGHEST_PRIORITY_TASK()														\
	{																								\
	UBaseType_t uxTopPriority;																		\
		portGET_HIGHEST_PRIORITY( uxTopPriority, uxTopReadyPriority );								\
		configASSERT( listCURRENT_LIST_LENGTH( &( pxReadyTasksLists[ uxTopPriority ] ) ) > 0 );		\
		listGET_OWNER_OF_NEXT_ENTRY( pxCurrentTCB, &( pxReadyTasksLists[ uxTopPriority ] ) );		\
	}
	
	//使用平台接口重置任务就绪优先级
	#define taskRESET_READY_PRIORITY( uxPriority )														\
	{																									\
		if( listCURRENT_LIST_LENGTH( &( pxReadyTasksLists[ ( uxPriority ) ] ) ) == ( UBaseType_t ) 0 )	\
		{																								\
			portRESET_READY_PRIORITY( ( uxPriority ), ( uxTopReadyPriority ) );							\
		}																								\
	}

#endif

//延迟任务链表与溢出延迟任务链表交换
#define taskSWITCH_DELAYED_LISTS()																	\
{																									\
	List_t *pxTemp;																					\
	configASSERT( ( listLIST_IS_EMPTY( pxDelayedTaskList ) ) );										\
																									\
	pxTemp = pxDelayedTaskList;																		\
	pxDelayedTaskList = pxOverflowDelayedTaskList;													\
	pxOverflowDelayedTaskList = pxTemp;																\
	xNumOfOverflows++;																				\
	/*重置下一个未阻塞任务的事件点位*/																				\
	prvResetNextTaskUnblockTime();																	\
}

//任务加入到就绪队列中
#define prvAddTaskToReadyList( pxTCB )																\
	traceMOVED_TASK_TO_READY_STATE( pxTCB );														\
	taskRECORD_READY_PRIORITY( ( pxTCB )->uxPriority );												\
	/*将该任务加入到就绪任务链表集的,uxPriority位置的末尾*/																\
	vListInsertEnd( &( pxReadyTasksLists[ ( pxTCB )->uxPriority ] ), &( ( pxTCB )->xStateListItem ) ); \
	tracePOST_MOVED_TASK_TO_READY_STATE( pxTCB )

//当不存在句柄时,返回当前程序控制块TCB
#define prvGetTCBFromHandle( pxHandle ) ( ( ( pxHandle ) == NULL ) ? pxCurrentTCB : ( pxHandle ) )

//使用中的事件链表项的值
#if( configUSE_16_BIT_TICKS == 1 )
	#define taskEVENT_LIST_ITEM_VALUE_IN_USE	0x8000U			//32位 4 * 1字节(8位)
#else
	#define taskEVENT_LIST_ITEM_VALUE_IN_USE	0x80000000UL	//64位
#endif

//任务控制块(程序控制块)
typedef struct tskTaskControlBlock 
{	//栈顶指针,必须是TCB的第一个项,那么栈顶指针相对于TCB的偏移量为0(地址共享)
	//这有很多好处,如可以任意时刻任意位置根据 TCB 或 Stack 的地址寻找到对方
	//甚至根据当前PC(CPU当前保存的程序计数器)加上Stack的掩码Mask也可以求出TCB的存储位置
	volatile StackType_t	*pxTopOfStack;
	#if ( portUSING_MPU_WRAPPERS == 1 )
	//MPU的硬件抽象配置,被设置为第二个值也具备上述所述的功能,只需偏移一个指针的位置而已
	//因为指针的位数就是平台对应的总线位数,所以也是很方便可以确定了的
		xMPU_SETTINGS	xMPUSettings;
	#endif

	ListItem_t			xStateListItem;		//一个链表存放TCB的状态(就绪,挂起,阻塞),每个TCB对应其中一个项
	ListItem_t			xEventListItem;		//一个链表存放TCB的事件组,那么这是特定的TCB事件集中的事件
	UBaseType_t			uxPriority;			//优先级,0是最低优先级
	StackType_t			*pxStack;			//栈的起始位置
	char				pcTaskName[ configMAX_TASK_NAME_LEN ];//任务名字

	#if ( ( portSTACK_GROWTH > 0 ) || ( configRECORD_STACK_HIGH_ADDRESS == 1 ) )
		StackType_t		*pxEndOfStack;		//根据增长的方向去分析确定栈的结束位置
	#endif

	#if ( portCRITICAL_NESTING_IN_TCB == 1 )
		UBaseType_t		uxCriticalNesting;	//临界区嵌套深度
	#endif

	#if ( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t		uxTCBNumber;		//任务控制块的数量
		UBaseType_t		uxTaskNumber;		//任务的数量(调试所用)
	#endif

	#if ( configUSE_MUTEXES == 1 )			//使用互斥锁？
		UBaseType_t		uxBasePriority;		//任务最后被分配的优先级
		UBaseType_t		uxMutexesHeld;		//互斥锁的所有者
	#endif

	#if ( configUSE_APPLICATION_TASK_TAG == 1 )
		TaskHookFunction_t pxTaskTag;		//应用程序(上层)传递的函数钩子
	#endif

	#if( configNUM_THREAD_LOCAL_STORAGE_POINTERS > 0 )
											//本地线程数的地址保存数量
		void			*pvThreadLocalStoragePointers[ configNUM_THREAD_LOCAL_STORAGE_POINTERS ];
	#endif

	#if( configGENERATE_RUN_TIME_STATS == 1 )
		uint32_t		ulRunTimeCounter;	//任务运行用了多少时间
	#endif

	#if ( configUSE_NEWLIB_REENTRANT == 1 )
		struct	_reent xNewLib_reent; 		//面向嵌入式系统的C运行库,提供接口但本身不实现
									  		//如果实现malloc需要自带锁
	#endif

	#if( configUSE_TASK_NOTIFICATIONS == 1 )
		volatile uint32_t ulNotifiedValue;	//通知值
		volatile uint8_t ucNotifyState;		//通知状态
	#endif

	#if( tskSTATIC_AND_DYNAMIC_ALLOCATION_POSSIBLE != 0 )
		uint8_t	ucStaticallyAllocated; 		//防止错误的free掉静态分配的TCB提供标签
	#endif

	#if( INCLUDE_xTaskAbortDelay == 1 )
		uint8_t ucDelayAborted; 			//延迟中断
	#endif

	#if( configUSE_POSIX_ERRNO == 1 )
		int iTaskErrno;						//POSIX的任务错误码
	#endif

} tskTCB;

//重命名
typedef tskTCB TCB_t;

//特权数据区,唯一全局的当前任务控制块TCB
PRIVILEGED_DATA TCB_t * volatile pxCurrentTCB = NULL;
//特权数据区,其他任务控制块TCB的维护区
PRIVILEGED_DATA static List_t pxReadyTasksLists[ configMAX_PRIORITIES ];//按优先级排列的 就绪 任务链表 集
PRIVILEGED_DATA static List_t xDelayedTaskList1;						//延迟 任务链表
PRIVILEGED_DATA static List_t xDelayedTaskList2;						//延迟 任务链表(其中有一个作为延时溢出(过期)的任务集)
PRIVILEGED_DATA static List_t * volatile pxDelayedTaskList;				//延时 任务链表,即上述俩个链表之一
PRIVILEGED_DATA static List_t * volatile pxOverflowDelayedTaskList;		//溢出 延时 任务链表,即上述俩个链表之一
PRIVILEGED_DATA static List_t xPendingReadyList;						//挂起的 就绪任务链表,调度程序会将其 移入到 就绪任务链表集中

#if( INCLUDE_vTaskDelete == 1 )
	PRIVILEGED_DATA static List_t xTasksWaitingTermination;				//任务被删除但,其动态占用的空间仍未释放,那么暂时丢到这里
	PRIVILEGED_DATA static volatile UBaseType_t uxDeletedTasksWaitingCleanUp = ( UBaseType_t ) 0U;
#endif

#if ( INCLUDE_vTaskSuspend == 1 )
	PRIVILEGED_DATA static List_t xSuspendedTaskList;					//当前被挂起的任务链表

#endif

#if ( configUSE_POSIX_ERRNO == 1 )	//全局的POSIX错误码,在上下文切换时被修改
	int FreeRTOS_errno = 0;
#endif

//其他数据特权段的数据变量,用以维护内核的稳定运行
PRIVILEGED_DATA static volatile UBaseType_t uxCurrentNumberOfTasks 	= ( UBaseType_t ) 0U;	//当前任务数量
PRIVILEGED_DATA static volatile TickType_t xTickCount 				= ( TickType_t ) configINITIAL_TICK_COUNT;	//时钟滴答
PRIVILEGED_DATA static volatile UBaseType_t uxTopReadyPriority 		= tskIDLE_PRIORITY;		//最高的就绪优先级位置
PRIVILEGED_DATA static volatile BaseType_t xSchedulerRunning 		= pdFALSE;				//正在调度中
PRIVILEGED_DATA static volatile UBaseType_t uxPendedTicks 			= ( UBaseType_t ) 0U;	//调度程序挂起时产生的节拍
PRIVILEGED_DATA static volatile BaseType_t xYieldPending 			= pdFALSE;				//挂起重入
PRIVILEGED_DATA static volatile BaseType_t xNumOfOverflows 			= ( BaseType_t ) 0;		//溢出的任务数量
PRIVILEGED_DATA static UBaseType_t uxTaskNumber 					= ( UBaseType_t ) 0U;	//任务数量
PRIVILEGED_DATA static volatile TickType_t xNextTaskUnblockTime		= ( TickType_t ) 0U; 	//下一个阻塞任务的解除阻塞时间,调度开始时portMAX_DELAY
PRIVILEGED_DATA static TaskHandle_t xIdleTaskHandle					= NULL;					//空闲任务句柄,在调度开始时被自动创建

PRIVILEGED_DATA static volatile UBaseType_t uxSchedulerSuspended	= ( UBaseType_t ) pdFALSE;	//调度程序挂起标记

#if ( configGENERATE_RUN_TIME_STATS == 1 )
	PRIVILEGED_DATA static uint32_t ulTaskSwitchedInTime = 0UL;	//上一次任务切换时的时间值(计数值)
	PRIVILEGED_DATA static uint32_t ulTotalRunTime = 0UL;		//保存总运行时

#endif


#if(  configCHECK_FOR_STACK_OVERFLOW > 0 )	//栈溢出回调
	extern void vApplicationStackOverflowHook( TaskHandle_t xTask, char *pcTaskName );

#endif

#if( configUSE_TICK_HOOK > 0 )	//时钟滴答回调
	extern void vApplicationTickHook( void );
#endif

#if( configSUPPORT_STATIC_ALLOCATION == 1 )	//空闲任务的静态内存分配
	extern void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );
#endif

#if ( INCLUDE_vTaskSuspend == 1 )	//任务是否挂起,挂起检查
	static BaseType_t prvTaskIsTaskSuspended( const TaskHandle_t xTask ) PRIVILEGED_FUNCTION;
#endif

//初始化任务链表
static void prvInitialiseTaskLists( void ) PRIVILEGED_FUNCTION;

//一个 为特定端口或编译器 定义函数原型,等效于void prvIdleTask( void *pvParameters ); 
//空闲任务会在调度前自动创建并创建第一个一个用户任务
static portTASK_FUNCTION_PROTO( prvIdleTask, pvParameters );


#if ( INCLUDE_vTaskDelete == 1 )	//TCB的去除,会回收调度程序分配的内存,包括栈,任务本身分配的内存不会被释放
	static void prvDeleteTCB( TCB_t *pxTCB ) PRIVILEGED_FUNCTION;
#endif

//IDLE任务专用,查看任务的部分内存是否被回收
static void prvCheckTasksWaitingTermination( void ) PRIVILEGED_FUNCTION;

//阻塞当前执行的任务,并丢入到延迟链表中
static void prvAddCurrentTaskToDelayedList( TickType_t xTicksToWait, const BaseType_t xCanBlockIndefinitely ) PRIVILEGED_FUNCTION;

//调试用
#if ( configUSE_TRACE_FACILITY == 1 )
	static UBaseType_t prvListTasksWithinSingleList( TaskStatus_t *pxTaskStatusArray, List_t *pxList, eTaskState eState ) PRIVILEGED_FUNCTION;

#endif

//在一个链表中找特定名字的任务,找到即返回任务,否则返回NULL
#if ( INCLUDE_xTaskGetHandle == 1 )
	static TCB_t *prvSearchForNameWithinSingleList( List_t *pxList, const char pcNameToQuery[] ) PRIVILEGED_FUNCTION;

#endif

//Stack初始化时被一个很大的掩码值填满的,检查当前还有多少的区域是保存之前被初始化的那个状态的
#if ( ( configUSE_TRACE_FACILITY == 1 ) || ( INCLUDE_uxTaskGetStackHighWaterMark == 1 ) )
	static configSTACK_DEPTH_TYPE prvTaskCheckFreeStackSpace( const uint8_t * pucStackByte ) PRIVILEGED_FUNCTION;
#endif

//任务从阻塞态到运行态所用到的时间
#if ( configUSE_TICKLESS_IDLE != 0 )
	//条件编译时应该使其不为0和1,确保用户使用portSUPPRESS_TICKS_AND_SLEEP()
	static TickType_t prvGetExpectedIdleTime( void ) PRIVILEGED_FUNCTION;
#endif

//设置下一个阻塞任务的解除阻塞时间
static void prvResetNextTaskUnblockTime( void );

//辅助函数,去打印交互信息
#if ( ( configUSE_TRACE_FACILITY == 1 ) && ( configUSE_STATS_FORMATTING_FUNCTIONS > 0 ) )
	static char *prvWriteNameToBuffer( char *pcBuffer, const char *pcTaskName ) PRIVILEGED_FUNCTION;
#endif

//新任务的初始化
static void prvInitialiseNewTask( 	TaskFunction_t pxTaskCode,
									const char * const pcName, 		//任务名字
									const uint32_t ulStackDepth,	//堆栈大小
									void * const pvParameters,
									UBaseType_t uxPriority,			//优先级
									TaskHandle_t * const pxCreatedTask,
									TCB_t *pxNewTCB,				//新生成的TCB
									const MemoryRegion_t * const xRegions ) PRIVILEGED_FUNCTION;

//新任务加入到就绪队列中
static void prvAddNewTaskToReadyList( TCB_t *pxNewTCB ) PRIVILEGED_FUNCTION;

//
#ifdef FREERTOS_TASKS_C_ADDITIONS_INIT
	static void freertos_tasks_c_additions_init( void ) PRIVILEGED_FUNCTION;

#endif

//新任务的静态初始化
#if( configSUPPORT_STATIC_ALLOCATION == 1 )
	TaskHandle_t xTaskCreateStatic(	TaskFunction_t pxTaskCode,
									const char * const pcName,			//TCB名字
									const uint32_t ulStackDepth,		//堆栈大小
									void * const pvParameters,
									UBaseType_t uxPriority,				//优先级
									StackType_t * const puxStackBuffer,	//堆栈缓冲区地址
									StaticTask_t * const pxTaskBuffer )	//任务缓冲区地址
	{
	TCB_t *pxNewTCB;
	TaskHandle_t xReturn;
		configASSERT( puxStackBuffer != NULL );
		configASSERT( pxTaskBuffer != NULL );

		#if( configASSERT_DEFINED == 1 )
		{	//校验静态区大小和标准区大小
			volatile size_t xSize = sizeof( StaticTask_t );
			configASSERT( xSize == sizeof( TCB_t ) );
			( void ) xSize; //编译器警告
		}
		#endif

		if( ( pxTaskBuffer != NULL ) && ( puxStackBuffer != NULL ) )
		{	//任务的静态缓冲区和任务的堆栈静态缓冲缓冲区是唯二的一定给定的数据
			pxNewTCB = ( TCB_t * ) pxTaskBuffer;
			pxNewTCB->pxStack = ( StackType_t * ) puxStackBuffer;
			#if( tskSTATIC_AND_DYNAMIC_ALLOCATION_POSSIBLE != 0 )
			{	//打上标记,说明任务和任务的堆栈都是静态
				pxNewTCB->ucStaticallyAllocated = tskSTATICALLY_ALLOCATED_STACK_AND_TCB;
			}
			#endif
			//初始化新任务
			prvInitialiseNewTask( pxTaskCode, pcName, ulStackDepth, pvParameters, uxPriority, &xReturn, pxNewTCB, NULL );
			//将新任务加入到就绪链表中
			prvAddNewTaskToReadyList( pxNewTCB );
		}
		else
		{
			xReturn = NULL;
		}

		return xReturn;
	}

#endif 

//平台受限的静态任务创建
#if( ( portUSING_MPU_WRAPPERS == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 1 ) )
	BaseType_t xTaskCreateRestrictedStatic( const TaskParameters_t * const pxTaskDefinition, TaskHandle_t *pxCreatedTask )
	{
	TCB_t *pxNewTCB;
	BaseType_t xReturn = errCOULD_NOT_ALLOCATE_REQUIRED_MEMORY;
		configASSERT( pxTaskDefinition->puxStackBuffer != NULL );
		configASSERT( pxTaskDefinition->pxTaskBuffer != NULL );
		if( ( pxTaskDefinition->puxStackBuffer != NULL ) && ( pxTaskDefinition->pxTaskBuffer != NULL ) )
		{	//TCB是原任务参数的一部分,现在需要与那块区域进行绑定
			pxNewTCB = ( TCB_t * ) pxTaskDefinition->pxTaskBuffer;
			pxNewTCB->pxStack = pxTaskDefinition->puxStackBuffer;
			#if( tskSTATIC_AND_DYNAMIC_ALLOCATION_POSSIBLE != 0 )
			{	//打上静态分配的标签
				pxNewTCB->ucStaticallyAllocated = tskSTATICALLY_ALLOCATED_STACK_AND_TCB;
			}
			#endif
			//初始化整个Task区域
			prvInitialiseNewTask(	pxTaskDefinition->pvTaskCode,
									pxTaskDefinition->pcName,
									( uint32_t ) pxTaskDefinition->usStackDepth,
									pxTaskDefinition->pvParameters,
									pxTaskDefinition->uxPriority,
									pxCreatedTask, pxNewTCB,
									pxTaskDefinition->xRegions );
			//加入到就绪队列中
			prvAddNewTaskToReadyList( pxNewTCB );
			xReturn = pdPASS;
		}

		return xReturn;
	}

#endif

//平台受限的创建任务
#if( ( portUSING_MPU_WRAPPERS == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
	BaseType_t xTaskCreateRestricted( const TaskParameters_t * const pxTaskDefinition, TaskHandle_t *pxCreatedTask )
	{
	TCB_t *pxNewTCB;
	BaseType_t xReturn = errCOULD_NOT_ALLOCATE_REQUIRED_MEMORY;
		configASSERT( pxTaskDefinition->puxStackBuffer );
		if( pxTaskDefinition->puxStackBuffer != NULL )
		{	//使用平台自定义的malloc函数分配TCB空间
			pxNewTCB = ( TCB_t * ) pvPortMalloc( sizeof( TCB_t ) );
			if( pxNewTCB != NULL )
			{	//为新创建的TCB绑定栈空间
				pxNewTCB->pxStack = pxTaskDefinition->puxStackBuffer;
				#if( configSUPPORT_STATIC_ALLOCATION == 1 )
				{	//标记
					pxNewTCB->ucStaticallyAllocated = tskSTATICALLY_ALLOCATED_STACK_ONLY;
				}
				#endif

				//初始化
				prvInitialiseNewTask(	pxTaskDefinition->pvTaskCode,
										pxTaskDefinition->pcName,
										( uint32_t ) pxTaskDefinition->usStackDepth,
										pxTaskDefinition->pvParameters,
										pxTaskDefinition->uxPriority,
										pxCreatedTask, pxNewTCB,
										pxTaskDefinition->xRegions );
				//加入就绪队列
				prvAddNewTaskToReadyList( pxNewTCB );
				xReturn = pdPASS;
			}
		}

		return xReturn;
	}

#endif

//创建动态任务
#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
	BaseType_t xTaskCreate(	TaskFunction_t pxTaskCode,		//任务的地址
							const char * const pcName,		//任务名字
							const configSTACK_DEPTH_TYPE usStackDepth, //堆栈大小
							void * const pvParameters,
							UBaseType_t uxPriority,	//优先级
							TaskHandle_t * const pxCreatedTask )	//句柄
	{
	TCB_t *pxNewTCB;
	BaseType_t xReturn;
		#if( portSTACK_GROWTH > 0 )
		{	//自增长栈,低地址往高地址增长
			pxNewTCB = ( TCB_t * ) pvPortMalloc( sizeof( TCB_t ) );
			if( pxNewTCB != NULL )
			{	//动态申请TCB的内存空间和堆栈的内存空间
				pxNewTCB->pxStack = ( StackType_t * ) pvPortMalloc( ( ( ( size_t ) usStackDepth ) * sizeof( StackType_t ) ) );
				if( pxNewTCB->pxStack == NULL )
				{
					vPortFree( pxNewTCB );
					pxNewTCB = NULL;
				}
			}
		}
		#else //自降低栈,高地址向低地址增长
		{
		StackType_t *pxStack;	
			pxStack = pvPortMalloc( ( ( ( size_t ) usStackDepth ) * sizeof( StackType_t ) ) );
			if( pxStack != NULL )
			{	//动态申请栈空间,申请成功继续申请TCB内存空间
				pxNewTCB = ( TCB_t * ) pvPortMalloc( sizeof( TCB_t ) );
				if( pxNewTCB != NULL )
				{	//无论自增长还是自降低的话,栈空间的起始地址不变
					pxNewTCB->pxStack = pxStack;
				}
				else
				{
					vPortFree( pxStack );
				}
			}
			else
			{
				pxNewTCB = NULL;
			}
		}
		#endif

		if( pxNewTCB != NULL )
		{	//前面的动作成功
			#if( tskSTATIC_AND_DYNAMIC_ALLOCATION_POSSIBLE != 0 )
			{	//为动态申请打上标签,以便日后释放
				pxNewTCB->ucStaticallyAllocated = tskDYNAMICALLY_ALLOCATED_STACK_AND_TCB;
			}
			#endif
			//初始化TCB,并将其加入到就绪队列中
			prvInitialiseNewTask( pxTaskCode, pcName, ( uint32_t ) usStackDepth, pvParameters, uxPriority, pxCreatedTask, pxNewTCB, NULL );
			prvAddNewTaskToReadyList( pxNewTCB );
			xReturn = pdPASS;
		}
		else
		{
			xReturn = errCOULD_NOT_ALLOCATE_REQUIRED_MEMORY;
		}

		return xReturn;
	}

#endif


static void prvInitialiseNewTask( 	TaskFunction_t pxTaskCode,			//任务的入口地址
									const char * const pcName,			//任务名字
									const uint32_t ulStackDepth,		//栈大小
									void * const pvParameters,			//参数,一般为空
									UBaseType_t uxPriority,				//指定的优先级
									TaskHandle_t * const pxCreatedTask,	//提供的回调
									TCB_t *pxNewTCB,					//创建的TCB
									const MemoryRegion_t * const xRegions )
{
StackType_t *pxTopOfStack;
UBaseType_t x;
	#if( portUSING_MPU_WRAPPERS == 1 )
		BaseType_t xRunPrivileged;//特权级检查
		if( ( uxPriority & portPRIVILEGE_BIT ) != 0U )
		{
			xRunPrivileged = pdTRUE;
		}
		else
		{
			xRunPrivileged = pdFALSE;
		}
		uxPriority &= ~portPRIVILEGE_BIT;
	#endif
	
	configASSERT( pcName );

	#if( tskSET_NEW_STACKS_TO_KNOWN_VALUE == 1 )
	{	//初始化栈为一个指定的值
		( void ) memset( pxNewTCB->pxStack, ( int ) tskSTACK_FILL_BYTE, ( size_t ) ulStackDepth * sizeof( StackType_t ) );
	}
	#endif 
	
	#if( portSTACK_GROWTH < 0 )
	{	//非自增长栈,需要重新确认栈顶地址,栈顶地址为数组最后一个元素
		pxTopOfStack = &( pxNewTCB->pxStack[ ulStackDepth - ( uint32_t ) 1 ] );
		pxTopOfStack = ( StackType_t * ) ( ( ( portPOINTER_SIZE_TYPE ) pxTopOfStack ) & ( ~( ( portPOINTER_SIZE_TYPE ) portBYTE_ALIGNMENT_MASK ) ) );

		configASSERT( ( ( ( portPOINTER_SIZE_TYPE ) pxTopOfStack & ( portPOINTER_SIZE_TYPE ) portBYTE_ALIGNMENT_MASK ) == 0UL ) );

		#if( configRECORD_STACK_HIGH_ADDRESS == 1 )
		{	//栈尾在栈顶
			pxNewTCB->pxEndOfStack = pxTopOfStack;
		}
		#endif
	}
	#else
	{	//自增长栈,栈顶在栈的起始位置
		pxTopOfStack = pxNewTCB->pxStack;
		configASSERT( ( ( ( portPOINTER_SIZE_TYPE ) pxNewTCB->pxStack & ( portPOINTER_SIZE_TYPE ) portBYTE_ALIGNMENT_MASK ) == 0UL ) );
		//栈的结束位置在数组的尾部
		pxNewTCB->pxEndOfStack = pxNewTCB->pxStack + ( ulStackDepth - ( uint32_t ) 1 );
	}
	#endif

	for( x = ( UBaseType_t ) 0; x < ( UBaseType_t ) configMAX_TASK_NAME_LEN; x++ )
	{	//任务名字,按字节拷贝,字符串结束字符为'\0'
		pxNewTCB->pcTaskName[ x ] = pcName[ x ];
		if( pcName[ x ] == ( char ) 0x00 )
		{
			break;
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	//防止意外的字符串越界,即使毁掉了任务名字也要保住安全性
	pxNewTCB->pcTaskName[ configMAX_TASK_NAME_LEN - 1 ] = '\0';

	if( uxPriority >= ( UBaseType_t ) configMAX_PRIORITIES )
	{	//优先级太高了,给默认最大优先级
		uxPriority = ( UBaseType_t ) configMAX_PRIORITIES - ( UBaseType_t ) 1U;
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	//优先级拷贝
	pxNewTCB->uxPriority = uxPriority;
	#if ( configUSE_MUTEXES == 1 )
	{	//如果使用互斥锁的话,那么对互斥锁初始化
		pxNewTCB->uxBasePriority = uxPriority;
		pxNewTCB->uxMutexesHeld = 0;
	}
	#endif
	//初始化任务的 用于描述自己状态和事件的 链表项
	vListInitialiseItem( &( pxNewTCB->xStateListItem ) );
	vListInitialiseItem( &( pxNewTCB->xEventListItem ) );
	//为状态链表项绑定所有者 为自己
	listSET_LIST_ITEM_OWNER( &( pxNewTCB->xStateListItem ), pxNewTCB );
	//将优先级写入到 事件组链表项 的项值中
	listSET_LIST_ITEM_VALUE( &( pxNewTCB->xEventListItem ), ( TickType_t ) configMAX_PRIORITIES - ( TickType_t ) uxPriority ); 
	//为事件链表项绑定所有者 为自己
	listSET_LIST_ITEM_OWNER( &( pxNewTCB->xEventListItem ), pxNewTCB );

	#if ( portCRITICAL_NESTING_IN_TCB == 1 )
	{	//如果使用临界区嵌套,初始化嵌套层次
		pxNewTCB->uxCriticalNesting = ( UBaseType_t ) 0U;
	}
	#endif

	#if ( configUSE_APPLICATION_TASK_TAG == 1 )
	{	//如果使用应用程序传递的函数钩子,初始化为空
		pxNewTCB->pxTaskTag = NULL;
	}
	#endif
	
	#if ( configGENERATE_RUN_TIME_STATS == 1 )
	{	//初始化任务运行时
		pxNewTCB->ulRunTimeCounter = 0UL;
	}
	#endif
	
	#if ( portUSING_MPU_WRAPPERS == 1 )
	{	//平台初始化配置,关联内存信息和使用到的堆栈
		vPortStoreTaskMPUSettings( &( pxNewTCB->xMPUSettings ), xRegions, pxNewTCB->pxStack, ulStackDepth );
	}
	#else
	{	//禁止编译器警告
		( void ) xRegions;
	}
	#endif

	#if( configNUM_THREAD_LOCAL_STORAGE_POINTERS != 0 )
	{	//初始化本地线程存储表
		for( x = 0; x < ( UBaseType_t ) configNUM_THREAD_LOCAL_STORAGE_POINTERS; x++ )
		{
			pxNewTCB->pvThreadLocalStoragePointers[ x ] = NULL;
		}
	}
	#endif

	#if ( configUSE_TASK_NOTIFICATIONS == 1 )
	{	//初始化任务通知项
		pxNewTCB->ulNotifiedValue = 0;
		pxNewTCB->ucNotifyState = taskNOT_WAITING_NOTIFICATION;
	}
	#endif

	#if ( configUSE_NEWLIB_REENTRANT == 1 )
	{	//初始化 New Lib reent
		_REENT_INIT_PTR( ( &( pxNewTCB->xNewLib_reent ) ) );
	}
	#endif

	#if( INCLUDE_xTaskAbortDelay == 1 )
	{	//初始化延迟终止
		pxNewTCB->ucDelayAborted = pdFALSE;
	}
	#endif

	#if( portUSING_MPU_WRAPPERS == 1 )
	{	//使用平台提供的栈初始化,检查当前栈顶指针位置,最后确定TCB栈顶指针位置
		pxNewTCB->pxTopOfStack = pxPortInitialiseStack( pxTopOfStack, pxTaskCode, pvParameters, xRunPrivileged );
	}
	#else
	{
		pxNewTCB->pxTopOfStack = pxPortInitialiseStack( pxTopOfStack, pxTaskCode, pvParameters );
	}
	#endif
	
	if( pxCreatedTask != NULL )
	{	//返回新创建的TCB的句柄,绑定
		*pxCreatedTask = ( TaskHandle_t ) pxNewTCB;
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
}

//新任务加入到就绪队列中
static void prvAddNewTaskToReadyList( TCB_t *pxNewTCB )
{
	taskENTER_CRITICAL();//临界区
	{	//当前运行态的任务+1
		uxCurrentNumberOfTasks++;
		if( pxCurrentTCB == NULL )	//当前恰好无任务运行
		{	//现在当前运行任务的TCB更新为新加入任务的TCB
			pxCurrentTCB = pxNewTCB;

			if( uxCurrentNumberOfTasks == ( UBaseType_t ) 1 )
			{	//仅仅只有初始化时产生IDLE任务时这部分会被执行
				//因为无论之后多少情况,任务数都一定大于1,除非关机
				prvInitialiseTaskLists();
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{	//当前有任务正在运行,看调度是否存在
			if( xSchedulerRunning == pdFALSE )
			{	//调度未运行时,手动确认优先级并更换新任务
				if( pxCurrentTCB->uxPriority <= pxNewTCB->uxPriority )
				{
					pxCurrentTCB = pxNewTCB;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		uxTaskNumber++;//任务数+1

		#if ( configUSE_TRACE_FACILITY == 1 )
		{	//追踪,更新当前任务数
			pxNewTCB->uxTCBNumber = uxTaskNumber;
		}
		#endif
		traceTASK_CREATE( pxNewTCB );
		//将任务加入到就绪队列
		prvAddTaskToReadyList( pxNewTCB );
		//平台程序控制块设置
		portSETUP_TCB( pxNewTCB );
	}
	taskEXIT_CRITICAL();//退出临界区

	if( xSchedulerRunning != pdFALSE )
	{	//调度程序未运行,手动比较优先级
		if( pxCurrentTCB->uxPriority < pxNewTCB->uxPriority )
		{	//手动启动抢占调度程序
			taskYIELD_IF_USING_PREEMPTION();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
}

//任务的删除
#if ( INCLUDE_vTaskDelete == 1 )
	void vTaskDelete( TaskHandle_t xTaskToDelete )
	{
	TCB_t *pxTCB;
		taskENTER_CRITICAL();//临界区
		{	//通过句柄获取程序控制块TCB
			pxTCB = prvGetTCBFromHandle( xTaskToDelete );
			if( uxListRemove( &( pxTCB->xStateListItem ) ) == ( UBaseType_t ) 0 )
			{	//状态队列移除自己
				taskRESET_READY_PRIORITY( pxTCB->uxPriority );
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}

			if( listLIST_ITEM_CONTAINER( &( pxTCB->xEventListItem ) ) != NULL )
			{	//事件组队列移除自己
				( void ) uxListRemove( &( pxTCB->xEventListItem ) );
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}

			//增加它以表明任务列表需要重新生成
			uxTaskNumber++;

			if( pxTCB == pxCurrentTCB )
			{	//将任务的状态项丢入到等待终结任务链表中
				vListInsertEnd( &xTasksWaitingTermination, &( pxTCB->xStateListItem ) );
				//需要删除任务,加标记
				++uxDeletedTasksWaitingCleanUp;

				//Windows模拟器实现Windows特有动作
				portPRE_TASK_DELETE_HOOK( pxTCB, &xYieldPending );
			}
			else
			{	//非当前TCB,直接删了就行
				--uxCurrentNumberOfTasks;
				prvDeleteTCB( pxTCB );
				//重置下一个阻塞的线程,将其变为未阻塞状态
				prvResetNextTaskUnblockTime();
			}

			traceTASK_DELETE( pxTCB );
		}
		taskEXIT_CRITICAL();//临界区退出

		//调度器正在执行时
		if( xSchedulerRunning != pdFALSE )
		{
			if( pxTCB == pxCurrentTCB )
			{	//强行执行调度
				configASSERT( uxSchedulerSuspended == 0 );
				portYIELD_WITHIN_API();
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
	}

#endif

//当前的任务延迟,直到……
#if ( INCLUDE_vTaskDelayUntil == 1 )
	void vTaskDelayUntil( TickType_t * const pxPreviousWakeTime, const TickType_t xTimeIncrement )
	{
	TickType_t xTimeToWake;
	BaseType_t xAlreadyYielded, xShouldDelay = pdFALSE;
		configASSERT( pxPreviousWakeTime );
		configASSERT( ( xTimeIncrement > 0U ) );
		configASSERT( uxSchedulerSuspended == 0 );

		vTaskSuspendAll();//调度器挂起,用于挂起其他全部任务,因为其他任务是调度器给权限
		{	//获取当前时钟Tick数
			const TickType_t xConstTickCount = xTickCount;
			//任务何时想被唤醒
			xTimeToWake = *pxPreviousWakeTime + xTimeIncrement;

			if( xConstTickCount < *pxPreviousWakeTime )
			{	//当前Tick小于之前的唤醒时间,所以表明Tick溢出了
				if( ( xTimeToWake < *pxPreviousWakeTime ) && ( xTimeToWake > xConstTickCount ) )
				{	//唤醒时间也溢出了,延时标记打上
					xShouldDelay = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{	//Tick未溢出
				if( ( xTimeToWake < *pxPreviousWakeTime ) || ( xTimeToWake > xConstTickCount ) )
				{	//唤醒时间溢出,延迟标记打上
					xShouldDelay = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}

			//下一次唤醒时间被更新到现在
			*pxPreviousWakeTime = xTimeToWake;

			if( xShouldDelay != pdFALSE )
			{	//是否需要延迟
				traceTASK_DELAY_UNTIL( xTimeToWake );
				//唤醒时间溢出了,那么将其加入到延迟链表中阻塞,配置好阻塞时间
				prvAddCurrentTaskToDelayedList( xTimeToWake - xConstTickCount, pdFALSE );
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		//全部任务的恢复
		xAlreadyYielded = xTaskResumeAll();
		if( xAlreadyYielded == pdFALSE )
		{	//任务恢复失败,手动启动任务调度,可能会导致自己的沉睡
			portYIELD_WITHIN_API();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}

#endif

//任务延迟多少时间
#if ( INCLUDE_vTaskDelay == 1 )
	void vTaskDelay( const TickType_t xTicksToDelay )
	{
	BaseType_t xAlreadyYielded = pdFALSE;
		if( xTicksToDelay > ( TickType_t ) 0U )
		{	//任务延迟时间存在
			configASSERT( uxSchedulerSuspended == 0 );
			vTaskSuspendAll();//挂起全部任务,关闭调度器
			{	//将当前运行的任务加入到延迟队列中
				traceTASK_DELAY();
				prvAddCurrentTaskToDelayedList( xTicksToDelay, pdFALSE );
			}//恢复全部任务
			xAlreadyYielded = xTaskResumeAll();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
		if( xAlreadyYielded == pdFALSE )
		{	//调度失败,强制手动启动,可能导致自己沉睡
			portYIELD_WITHIN_API();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}

#endif 

//任务状态的获取
#if( ( INCLUDE_eTaskGetState == 1 ) || ( configUSE_TRACE_FACILITY == 1 ) )
	eTaskState eTaskGetState( TaskHandle_t xTask )
	{
	eTaskState eReturn;
	List_t const * pxStateList, *pxDelayedList, *pxOverflowedDelayedList;
	const TCB_t * const pxTCB = xTask;//通过句柄获取TCB,事实上它们是一个东西
		configASSERT( pxTCB );
		if( pxTCB == pxCurrentTCB )
		{	
			eReturn = eRunning;
		}
		else
		{	//进入临界区
			taskENTER_CRITICAL();
			{	//获取状态链表项的(组长),延迟链表,溢出延迟链表
				pxStateList = listLIST_ITEM_CONTAINER( &( pxTCB->xStateListItem ) );
				pxDelayedList = pxDelayedTaskList;
				pxOverflowedDelayedList = pxOverflowDelayedTaskList;
			}
			taskEXIT_CRITICAL();

			if( ( pxStateList == pxDelayedList ) || ( pxStateList == pxOverflowedDelayedList ) )
			{	//查看当前的状态链表是延迟链表之一,说明当前任务队列为阻塞态
				eReturn = eBlocked;
			}

			#if ( INCLUDE_vTaskSuspend == 1 )
				else if( pxStateList == &xSuspendedTaskList )	//是挂起链表
				{	//所有者不存在
					if( listLIST_ITEM_CONTAINER( &( pxTCB->xEventListItem ) ) == NULL )
					{
						#if( configUSE_TASK_NOTIFICATIONS == 1 )
						{	//该任务在等待事件通知
							if( pxTCB->ucNotifyState == taskWAITING_NOTIFICATION )
							{	//阻塞态
								eReturn = eBlocked;
							}
							else
							{	//不等待事件通知,所以是挂起态
								eReturn = eSuspended;
							}
						}
						#else
						{	//无事件通知,挂起态
							eReturn = eSuspended;
						}
						#endif
					}
					else
					{	//存在所有者,表明被挂起
						eReturn = eBlocked;
					}
				}
			#endif

			#if ( INCLUDE_vTaskDelete == 1 )
				else if( ( pxStateList == &xTasksWaitingTermination ) || ( pxStateList == NULL ) )
				{	//如果任务被丢到了等待终结的队列中,那么是已经删除了
					eReturn = eDeleted;
				}
			#endif

			else 
			{	//诶嘿,最后一种情况,就绪态
				eReturn = eReady;
			}
		}
		return eReturn;
	}

#endif

//获取任务优先级
#if ( INCLUDE_uxTaskPriorityGet == 1 )
	UBaseType_t uxTaskPriorityGet( const TaskHandle_t xTask )
	{
	TCB_t const *pxTCB;
	UBaseType_t uxReturn;
		taskENTER_CRITICAL();
		{	//进入临界区,通过Handle获取TCB,然后获取优先级
			pxTCB = prvGetTCBFromHandle( xTask );
			uxReturn = pxTCB->uxPriority;
		}
		taskEXIT_CRITICAL();
		return uxReturn;
	}

#endif

//中断环境获取优先级
#if ( INCLUDE_uxTaskPriorityGet == 1 )
	UBaseType_t uxTaskPriorityGetFromISR( const TaskHandle_t xTask )
	{
	TCB_t const *pxTCB;
	UBaseType_t uxReturn, uxSavedInterruptState;
		//检查中断优先级的合法性
		portASSERT_IF_INTERRUPT_PRIORITY_INVALID();
		//检查中断环境的参数
		uxSavedInterruptState = portSET_INTERRUPT_MASK_FROM_ISR();
		{	//通过Handle获取TCB,然后获取优先级
			pxTCB = prvGetTCBFromHandle( xTask );
			uxReturn = pxTCB->uxPriority;
		}
		//清除中断
		portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptState );
		return uxReturn;
	}

#endif

//设置优先级
#if ( INCLUDE_vTaskPrioritySet == 1 )
	void vTaskPrioritySet( TaskHandle_t xTask, UBaseType_t uxNewPriority )
	{
	TCB_t *pxTCB;
	UBaseType_t uxCurrentBasePriority, uxPriorityUsedOnEntry;
	BaseType_t xYieldRequired = pdFALSE;
		configASSERT( ( uxNewPriority < configMAX_PRIORITIES ) );

		if( uxNewPriority >= ( UBaseType_t ) configMAX_PRIORITIES )
		{	//优先级合法性检查
			uxNewPriority = ( UBaseType_t ) configMAX_PRIORITIES - ( UBaseType_t ) 1U;
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		taskENTER_CRITICAL();
		{	//通过Handle获取TCB
			pxTCB = prvGetTCBFromHandle( xTask );
			traceTASK_PRIORITY_SET( pxTCB, uxNewPriority );
			#if ( configUSE_MUTEXES == 1 )
			{	//获取互斥锁的基础优先级
				uxCurrentBasePriority = pxTCB->uxBasePriority;
			}
			#else
			{
				uxCurrentBasePriority = pxTCB->uxPriority;
			}
			#endif

			if( uxCurrentBasePriority != uxNewPriority )
			{	//新优先级较大
				if( uxNewPriority > uxCurrentBasePriority )
				{
					if( pxTCB != pxCurrentTCB )
					{	//出现一个比当前优先级更大的优先级
						if( uxNewPriority >= pxCurrentTCB->uxPriority )
						{	//为调度打一个标记
							xYieldRequired = pdTRUE;
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else
					{	//修改自己的优先级,啥也不要做
					}
				}
				else if( pxTCB == pxCurrentTCB )
				{	//优先级被降低了,但是是当前任务,那么需要把自己的执行权限
					//让出给优先级更高的任务
					xYieldRequired = pdTRUE;
				}
				else
				{
				}
				uxPriorityUsedOnEntry = pxTCB->uxPriority;
				#if ( configUSE_MUTEXES == 1 )
				{	//更新TCB优先级
					if( pxTCB->uxBasePriority == pxTCB->uxPriority )
					{
						pxTCB->uxPriority = uxNewPriority;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					//基础优先级是一定需要被更新的
					pxTCB->uxBasePriority = uxNewPriority;
				}
				#else
				{	//更新当前优先级
					pxTCB->uxPriority = uxNewPriority;
				}
				#endif

				if( ( listGET_LIST_ITEM_VALUE( &( pxTCB->xEventListItem ) ) & taskEVENT_LIST_ITEM_VALUE_IN_USE ) == 0UL )
				{	//重置项的值
					listSET_LIST_ITEM_VALUE( &( pxTCB->xEventListItem ), ( ( TickType_t ) configMAX_PRIORITIES - ( TickType_t ) uxNewPriority ) );
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}

				//检查TCB是否在就绪队列中,因为优先级已经更新,所以原有的优先级队列中优先级失效了
				if( listIS_CONTAINED_WITHIN( &( pxReadyTasksLists[ uxPriorityUsedOnEntry ] ), &( pxTCB->xStateListItem ) ) != pdFALSE )
				{	//如果在的话就要移除它
					if( uxListRemove( &( pxTCB->xStateListItem ) ) == ( UBaseType_t ) 0 )
					{	//然后重置最高优先级
						portRESET_READY_PRIORITY( uxPriorityUsedOnEntry, uxTopReadyPriority );
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					//将其重新加入到优先级队列中对应优先级之下
					prvAddTaskToReadyList( pxTCB );
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}

				if( xYieldRequired != pdFALSE )
				{	//需要执行内核抢占 任务调度
					taskYIELD_IF_USING_PREEMPTION();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}

				( void ) uxPriorityUsedOnEntry;
			}
		}
		taskEXIT_CRITICAL();
	}

#endif

//任务挂起
#if ( INCLUDE_vTaskSuspend == 1 )
	void vTaskSuspend( TaskHandle_t xTaskToSuspend )
	{
	TCB_t *pxTCB;
		taskENTER_CRITICAL();
		{	//通过句柄获取任务控制块TCB
			pxTCB = prvGetTCBFromHandle( xTaskToSuspend );
			traceTASK_SUSPEND( pxTCB );

			//将状态项从 就绪,运行 任务队列中移除
			if( uxListRemove( &( pxTCB->xStateListItem ) ) == ( UBaseType_t ) 0 )
			{
				taskRESET_READY_PRIORITY( pxTCB->uxPriority );
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}

			if( listLIST_ITEM_CONTAINER( &( pxTCB->xEventListItem ) ) != NULL )
			{	//任务事件的事件组存在,从事件组中移除任务事件
				( void ) uxListRemove( &( pxTCB->xEventListItem ) );
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
			//将任务的状态项 插入到 挂起任务链表尾部
			vListInsertEnd( &xSuspendedTaskList, &( pxTCB->xStateListItem ) );

			#if( configUSE_TASK_NOTIFICATIONS == 1 )
			{	//清空任务 通知状态
				if( pxTCB->ucNotifyState == taskWAITING_NOTIFICATION )
				{
					pxTCB->ucNotifyState = taskNOT_WAITING_NOTIFICATION;
				}
			}
			#endif
		}
		taskEXIT_CRITICAL();

		if( xSchedulerRunning != pdFALSE )
		{	//调度程序正在运行时
			taskENTER_CRITICAL();
			{	//重置下一个阻塞的状态的 未阻塞事件
				prvResetNextTaskUnblockTime();
			}
			taskEXIT_CRITICAL();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		if( pxTCB == pxCurrentTCB )
		{	//如果是当前正在运行的TCB要被挂起
			if( xSchedulerRunning != pdFALSE )
			{	//手动执行任务调度
				configASSERT( uxSchedulerSuspended == 0 );
				portYIELD_WITHIN_API();
			}
			else
			{	//当前挂起的任务集中 是有 全部任务
				if( listCURRENT_LIST_LENGTH( &xSuspendedTaskList ) == uxCurrentNumberOfTasks )
				{	//那么当前运行任务 为空
					pxCurrentTCB = NULL;
				}
				else
				{	//进行任务上下文切换
					vTaskSwitchContext();
				}
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}

#endif

//检查任务是否被挂起
#if ( INCLUDE_vTaskSuspend == 1 )
	static BaseType_t prvTaskIsTaskSuspended( const TaskHandle_t xTask )
	{
	BaseType_t xReturn = pdFALSE;
	const TCB_t * const pxTCB = xTask;
		configASSERT( xTask );
		//检查当前状态项是否属于挂起任务链表集中
		if( listIS_CONTAINED_WITHIN( &xSuspendedTaskList, &( pxTCB->xStateListItem ) ) != pdFALSE )
		{	//检查当前事件项是否属于挂起就绪链表集中
			if( listIS_CONTAINED_WITHIN( &xPendingReadyList, &( pxTCB->xEventListItem ) ) == pdFALSE )
			{	//事件项不属于任何集合中
				if( listIS_CONTAINED_WITHIN( NULL, &( pxTCB->xEventListItem ) ) != pdFALSE ) /*lint !e961.  The cast is only redundant when NULL is used. */
				{	//状态项属于挂起集,事件项不属于任何集,那么是挂起态
					xReturn = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		return xReturn;
	}
#endif 

//恢复任务
#if ( INCLUDE_vTaskSuspend == 1 )
	void vTaskResume( TaskHandle_t xTaskToResume )
	{
	TCB_t * const pxTCB = xTaskToResume;
		configASSERT( xTaskToResume );
		if( ( pxTCB != pxCurrentTCB ) && ( pxTCB != NULL ) )
		{	//任务不属于当前运行任务,且存在
			taskENTER_CRITICAL();//进入临界区
			{	//检查任务是否是挂起
				if( prvTaskIsTaskSuspended( pxTCB ) != pdFALSE )
				{	//是挂起态
					traceTASK_RESUME( pxTCB );
					//将状态集移出挂起链表集
					( void ) uxListRemove(  &( pxTCB->xStateListItem ) );
					//将自己加入到就绪链表集
					prvAddTaskToReadyList( pxTCB );
					//刚恢复的任务优先级比当前执行的优先级大
					if( pxTCB->uxPriority >= pxCurrentTCB->uxPriority )
					{	//手动调用 内核抢占 任务调度
						taskYIELD_IF_USING_PREEMPTION();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			taskEXIT_CRITICAL();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
#endif

//中断环境下任务恢复
#if ( ( INCLUDE_xTaskResumeFromISR == 1 ) && ( INCLUDE_vTaskSuspend == 1 ) )
	BaseType_t xTaskResumeFromISR( TaskHandle_t xTaskToResume )
	{
	BaseType_t xYieldRequired = pdFALSE;
	TCB_t * const pxTCB = xTaskToResume;
	UBaseType_t uxSavedInterruptStatus;
		configASSERT( xTaskToResume );
		//检查中断优先级合法性
		portASSERT_IF_INTERRUPT_PRIORITY_INVALID();
		//获取中断状态
		uxSavedInterruptStatus = portSET_INTERRUPT_MASK_FROM_ISR();
		{	//检查任务是否挂起
			if( prvTaskIsTaskSuspended( pxTCB ) != pdFALSE )
			{
				traceTASK_RESUME_FROM_ISR( pxTCB );
				if( uxSchedulerSuspended == ( UBaseType_t ) pdFALSE )
				{	//检查任务优先级确定,是否要被调度
					if( pxTCB->uxPriority >= pxCurrentTCB->uxPriority )
					{	//需要调度
						xYieldRequired = pdTRUE;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					//将状态项从挂起链表中移出
					( void ) uxListRemove( &( pxTCB->xStateListItem ) );
					//将任务加入到就绪链表中
					prvAddTaskToReadyList( pxTCB );
				}
				else
				{	//调度程序未挂起,那么直接将事件加入到挂起就绪链表中即可
					vListInsertEnd( &( xPendingReadyList ), &( pxTCB->xEventListItem ) );
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		//清除中断状态
		portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );
		return xYieldRequired;
	}

#endif 

//任务开始调度
void vTaskStartScheduler( void )
{
BaseType_t xReturn;
	#if( configSUPPORT_STATIC_ALLOCATION == 1 )
	{	//如果支持静态内存分配,优先静态内存分配 IDLE任务的 TCB空间和Stack空间
		StaticTask_t *pxIdleTaskTCBBuffer = NULL;
		StackType_t *pxIdleTaskStackBuffer = NULL;
		uint32_t ulIdleTaskStackSize;
		//IDLE任务 的各个空间 的实际内存区域 来源于用户空间
		vApplicationGetIdleTaskMemory( &pxIdleTaskTCBBuffer, &pxIdleTaskStackBuffer, &ulIdleTaskStackSize );
		//利用用户提供的空间,静态创建 IDLE任务
		xIdleTaskHandle = xTaskCreateStatic(	prvIdleTask,	//IDLE任务实体
												configIDLE_TASK_NAME,	//IDLE名字
												ulIdleTaskStackSize,	//栈大小
												( void * ) NULL,
												portPRIVILEGE_BIT, 		//优先级
												pxIdleTaskStackBuffer,	//栈的内存首地址
												pxIdleTaskTCBBuffer ); 	//TCB的内存首地址
		
		if( xIdleTaskHandle != NULL )
		{	//创建任务成功
			xReturn = pdPASS;
		}
		else
		{
			xReturn = pdFAIL;
		}
	}
	#else
	{	//替代的方式使用 动态创建 IDLE任务
		xReturn = xTaskCreate(	prvIdleTask,
								configIDLE_TASK_NAME,		//IDLE名字
								configMINIMAL_STACK_SIZE,	//栈空间默认最小
								( void * ) NULL,
								portPRIVILEGE_BIT,
								&xIdleTaskHandle );			//句柄的地址
	}
	#endif

	#if ( configUSE_TIMERS == 1 )
	{	//创建动态定时器任务,处理动态定时器集合
		if( xReturn == pdPASS )
		{
			xReturn = xTimerCreateTimerTask();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	#endif

	if( xReturn == pdPASS )
	{	//特殊的函数,由特殊的宏调用,C++ ？
		#ifdef FREERTOS_TASKS_C_ADDITIONS_INIT
		{
			freertos_tasks_c_additions_init();
		}
		#endif

		//平台中断的禁用
		portDISABLE_INTERRUPTS();

		#if ( configUSE_NEWLIB_REENTRANT == 1 )
		{	//New Lib库使用,需要为当前TCB绑定库
			_impure_ptr = &( pxCurrentTCB->xNewLib_reent );
		}
		#endif
		//初始化下一个阻塞任务的解除阻塞时间,调度正在运行中
		xNextTaskUnblockTime = portMAX_DELAY;
		xSchedulerRunning = pdTRUE;
		xTickCount = ( TickType_t ) configINITIAL_TICK_COUNT;

		//用于配置运行时计数器的 计时器/定时器
		portCONFIGURE_TIMER_FOR_RUN_TIME_STATS();

		traceTASK_SWITCHED_IN();

		//启动平台调度
		if( xPortStartScheduler() != pdFALSE )
		{	//调度开始时,这里后面就不会被执行了
		}
		else
		{	//调度开始时,这里后面就不会被执行了
		}
	}
	else
	{
		configASSERT( xReturn != errCOULD_NOT_ALLOCATE_REQUIRED_MEMORY );
	}
	( void ) xIdleTaskHandle;//编译器警告的终止
}


//任务结束调度
void vTaskEndScheduler( void )
{
	portDISABLE_INTERRUPTS();	//中断关闭
	xSchedulerRunning = pdFALSE;//标志配置
	vPortEndScheduler();		//平台中断调度的启动
}

//全部任务挂起
void vTaskSuspendAll( void )
{	//直接配置挂起参数即可
	++uxSchedulerSuspended;
}

//IDLE任务的预期时间的获取
#if ( configUSE_TICKLESS_IDLE != 0 )
	static TickType_t prvGetExpectedIdleTime( void )
	{
	TickType_t xReturn;
	UBaseType_t uxHigherPriorityReadyTasks = pdFALSE;
		#if( configUSE_PORT_OPTIMISED_TASK_SELECTION == 0 )
		{	//存在比IDLE任务 更高优先级的任务
			if( uxTopReadyPriority > tskIDLE_PRIORITY )
			{	
				uxHigherPriorityReadyTasks = pdTRUE;
			}
		}
		#else
		{
			const UBaseType_t uxLeastSignificantBit = ( UBaseType_t ) 0x01;
			//存在比IDLE任务 更高优先级的任务
			if( uxTopReadyPriority > uxLeastSignificantBit )
			{
				uxHigherPriorityReadyTasks = pdTRUE;
			}
		}
		#endif

		if( pxCurrentTCB->uxPriority > tskIDLE_PRIORITY )
		{	//当前运行的任务优先级大于IDLE任务
			xReturn = 0;
		}
		else if( listCURRENT_LIST_LENGTH( &( pxReadyTasksLists[ tskIDLE_PRIORITY ] ) ) > 1 )
		{	//当前运行队列集的 0优先级集 中不止一个任务
			xReturn = 0;
		}
		else if( uxHigherPriorityReadyTasks != pdFALSE )
		{	//有存在比IDLE优先级更高的任务可以执行
			xReturn = 0;
		}
		else
		{	//在下一个阻塞任务解除阻塞之前到当前这段时间是IDLE可用的时间
			xReturn = xNextTaskUnblockTime - xTickCount;
		}
		return xReturn;
	}

#endif /* configUSE_TICKLESS_IDLE */
/*----------------------------------------------------------*/

BaseType_t xTaskResumeAll( void )
{
TCB_t *pxTCB = NULL;
BaseType_t xAlreadyYielded = pdFALSE;
	configASSERT( uxSchedulerSuspended );

	taskENTER_CRITICAL();//进入临界区
	{	//调度挂起参数-1,如果存在嵌套时,维护嵌套的稳定性
		--uxSchedulerSuspended;
		//如果还不能满足非挂起态,那等到下一次任务恢复的执行继续尝试
		if( uxSchedulerSuspended == ( UBaseType_t ) pdFALSE )
		{	//当前已经满足非挂起态
			if( uxCurrentNumberOfTasks > ( UBaseType_t ) 0U )
			{	//当前存在可运行任务
				while( listLIST_IS_EMPTY( &xPendingReadyList ) == pdFALSE )
				{	//那么将挂起就绪队列中全部任务都激活
					//取出挂起就绪队列中优先级最高的一项(一个一个的取,直到集合取空)
					pxTCB = listGET_OWNER_OF_HEAD_ENTRY( ( &xPendingReadyList ) );
					//将任务的事件集和状态集从 挂起链表集合 中移除
					( void ) uxListRemove( &( pxTCB->xEventListItem ) );
					( void ) uxListRemove( &( pxTCB->xStateListItem ) );
					//将该任务加入到可运行任务集中
					prvAddTaskToReadyList( pxTCB );
					//是否存在优先级大于当前任务优先级的,如果有的话那就需要配置调度参数
					if( pxTCB->uxPriority >= pxCurrentTCB->uxPriority )
					{
						xYieldPending = pdTRUE;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				//至此为止,挂起就绪队列被清空了,它们都被加入到就绪队列中
				if( pxTCB != NULL )
				{	//上述至少做了一次任务的更新
					//那么更新 阻塞态任务中 下一个 变成未阻塞任务 的时间
					prvResetNextTaskUnblockTime();
				}

				
				{	//处理调度程序挂起时产生的节拍需要被处理,以便所有延迟的准确
					UBaseType_t uxPendedCounts = uxPendedTicks;
					if( uxPendedCounts > ( UBaseType_t ) 0U )
					{	//节拍产生了,需要处理
						do
						{	//将这些节拍单次执行,找到延迟任务中结束项,加入到就绪队列
							if( xTaskIncrementTick() != pdFALSE )
							{
								xYieldPending = pdTRUE;
							}
							else
							{
								mtCOVERAGE_TEST_MARKER();
							}
							--uxPendedCounts;//产生的节拍被处理了一次,所以-1
						} while( uxPendedCounts > ( UBaseType_t ) 0U );
						uxPendedTicks = 0;//重置
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}

				if( xYieldPending != pdFALSE )
				{	//需要调度的话
					#if( configUSE_PREEMPTION != 0 )
					{	//内核抢占被配置,配置抢占为真
						xAlreadyYielded = pdTRUE;
					}
					#endif
					//任务切换
					taskYIELD_IF_USING_PREEMPTION();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	taskEXIT_CRITICAL();//退出临界区

	return xAlreadyYielded;
}

//任务获取滴答数
TickType_t xTaskGetTickCount( void )
{
TickType_t xTicks;
	portTICK_TYPE_ENTER_CRITICAL();
	{	//获取滴答
		xTicks = xTickCount;
	}
	portTICK_TYPE_EXIT_CRITICAL();
	return xTicks;
}

//中断环境下获取滴答数
TickType_t xTaskGetTickCountFromISR( void )
{
TickType_t xReturn;
UBaseType_t uxSavedInterruptStatus;

	//中断优先级的合法性检查
	portASSERT_IF_INTERRUPT_PRIORITY_INVALID();
	//获取中断状态
	uxSavedInterruptStatus = portTICK_TYPE_SET_INTERRUPT_MASK_FROM_ISR();
	{
		xReturn = xTickCount;
	}
	//清除中断状态
	portTICK_TYPE_CLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );
	return xReturn;
}

//当前任务的数量
UBaseType_t uxTaskGetNumberOfTasks( void )
{
	return uxCurrentNumberOfTasks;
}

//获取任务名字
char *pcTaskGetName( TaskHandle_t xTaskToQuery )
{
TCB_t *pxTCB;
	//提供句柄获取任务控制块
	pxTCB = prvGetTCBFromHandle( xTaskToQuery );
	configASSERT( pxTCB );
	return &( pxTCB->pcTaskName[ 0 ] );//返回任务名地址
}

//通过任务名从单独的链表集合中找到对应的 任务TCB
#if ( INCLUDE_xTaskGetHandle == 1 )
	static TCB_t *prvSearchForNameWithinSingleList( List_t *pxList, const char pcNameToQuery[] )
	{
	TCB_t *pxNextTCB, *pxFirstTCB, *pxReturn = NULL;
	UBaseType_t x;
	char cNextChar;
	BaseType_t xBreakLoop;
		if( listCURRENT_LIST_LENGTH( pxList ) > ( UBaseType_t ) 0 )
		{	//检查链表存在,获得当前链表的第一个TCB
			listGET_OWNER_OF_NEXT_ENTRY( pxFirstTCB, pxList );
			do
			{	//然后一直获取下一个项
				listGET_OWNER_OF_NEXT_ENTRY( pxNextTCB, pxList );
				
				xBreakLoop = pdFALSE;
				for( x = ( UBaseType_t ) 0; x < ( UBaseType_t ) configMAX_TASK_NAME_LEN; x++ )
				{	//检查名字匹配
					cNextChar = pxNextTCB->pcTaskName[ x ];

					if( cNextChar != pcNameToQuery[ x ] )
					{	//匹配失败
						xBreakLoop = pdTRUE;
					}
					else if( cNextChar == ( char ) 0x00 )
					{	//匹配成功
						pxReturn = pxNextTCB;
						xBreakLoop = pdTRUE;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}

					if( xBreakLoop != pdFALSE )
					{	//匹配成功时退出
						break;
					}
				}

				if( pxReturn != NULL )
				{	//找到了对应的TCB
					break;
				}
			} while( pxNextTCB != pxFirstTCB );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
		return pxReturn;
	}

#endif

//获取任务句柄
#if ( INCLUDE_xTaskGetHandle == 1 )
	TaskHandle_t xTaskGetHandle( const char *pcNameToQuery ) 
	{
	UBaseType_t uxQueue = configMAX_PRIORITIES;
	TCB_t* pxTCB;
		configASSERT( strlen( pcNameToQuery ) < configMAX_TASK_NAME_LEN );

		vTaskSuspendAll();//挂起所有任务
		{
			do
			{	//搜索就绪队列集 的全部队列
				uxQueue--;
				pxTCB = prvSearchForNameWithinSingleList( ( List_t * ) &( pxReadyTasksLists[ uxQueue ] ), pcNameToQuery );
				if( pxTCB != NULL )
				{	//找到了
					break;
				}

			} while( uxQueue > ( UBaseType_t ) tskIDLE_PRIORITY );
				
			if( pxTCB == NULL )
			{	//继续找延迟队列
				pxTCB = prvSearchForNameWithinSingleList( ( List_t * ) pxDelayedTaskList, pcNameToQuery );
			}

			if( pxTCB == NULL )
			{	//找溢出延迟队列
				pxTCB = prvSearchForNameWithinSingleList( ( List_t * ) pxOverflowDelayedTaskList, pcNameToQuery );
			}

			#if ( INCLUDE_vTaskSuspend == 1 )
			{
				if( pxTCB == NULL )
				{	//找挂起队列
					pxTCB = prvSearchForNameWithinSingleList( &xSuspendedTaskList, pcNameToQuery );
				}
			}
			#endif

			#if( INCLUDE_vTaskDelete == 1 )
			{
				if( pxTCB == NULL )
				{	//要删除但还未实际删除的队列
					pxTCB = prvSearchForNameWithinSingleList( &xTasksWaitingTermination, pcNameToQuery );
				}
			}
			#endif
		}
		( void ) xTaskResumeAll();//都找了一次,恢复任务调度
		return pxTCB;
	}
#endif

//获取系统状态
#if ( configUSE_TRACE_FACILITY == 1 )
	UBaseType_t uxTaskGetSystemState( TaskStatus_t * const pxTaskStatusArray, const UBaseType_t uxArraySize, uint32_t * const pulTotalRunTime )
	{
	UBaseType_t uxTask = 0, uxQueue = configMAX_PRIORITIES;
		vTaskSuspendAll();//挂起任务
		{	//提供的空间足够的话
			if( uxArraySize >= uxCurrentNumberOfTasks )
			{
				do
				{
					uxQueue--;//读取全部就绪队列集的每一个队列,除去IDLE队列集
					uxTask += prvListTasksWithinSingleList( &( pxTaskStatusArray[ uxTask ] ), &( pxReadyTasksLists[ uxQueue ] ), eReady );
				} while( uxQueue > ( UBaseType_t ) tskIDLE_PRIORITY ); 
				//继续读取俩个延迟任务队列
				uxTask += prvListTasksWithinSingleList( &( pxTaskStatusArray[ uxTask ] ), ( List_t * ) pxDelayedTaskList, eBlocked );
				uxTask += prvListTasksWithinSingleList( &( pxTaskStatusArray[ uxTask ] ), ( List_t * ) pxOverflowDelayedTaskList, eBlocked );

				#if( INCLUDE_vTaskDelete == 1 )
				{	//读取等待终止的任务队列
					uxTask += prvListTasksWithinSingleList( &( pxTaskStatusArray[ uxTask ] ), &xTasksWaitingTermination, eDeleted );
				}
				#endif

				#if ( INCLUDE_vTaskSuspend == 1 )
				{	//读取挂起任务队列
					uxTask += prvListTasksWithinSingleList( &( pxTaskStatusArray[ uxTask ] ), &xSuspendedTaskList, eSuspended );
				}
				#endif

				#if ( configGENERATE_RUN_TIME_STATS == 1)
				{	//总运行时存在
					if( pulTotalRunTime != NULL )
					{
						#ifdef portALT_GET_RUN_TIME_COUNTER_VALUE
							//获取总运行时计数
							portALT_GET_RUN_TIME_COUNTER_VALUE( ( *pulTotalRunTime ) );
						#else
							*pulTotalRunTime = portGET_RUN_TIME_COUNTER_VALUE();
						#endif
					}
				}
				#else
				{	//默认为0,因为没记录
					if( pulTotalRunTime != NULL )
					{
						*pulTotalRunTime = 0;
					}
				}
				#endif
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		( void ) xTaskResumeAll();//恢复使用任务
		return uxTask;
	}
#endif 

//IDLE任务的句柄
#if ( INCLUDE_xTaskGetIdleTaskHandle == 1 )
	TaskHandle_t xTaskGetIdleTaskHandle( void )
	{
		configASSERT( ( xIdleTaskHandle != NULL ) );
		return xIdleTaskHandle;
	}
#endif

//滴答数跳跃
#if ( configUSE_TICKLESS_IDLE != 0 )
	void vTaskStepTick( const TickType_t xTicksToJump )
	{
		/* Correct the tick count value after a period during which the tick
		was suppressed.  Note this does *not* call the tick hook function for
		each stepped tick. */
		configASSERT( ( xTickCount + xTicksToJump ) <= xNextTaskUnblockTime );
		xTickCount += xTicksToJump;//当前滴答数跳跃
		traceINCREASE_TICK_COUNT( xTicksToJump );
	}
#endif

//任务中止延迟
#if ( INCLUDE_xTaskAbortDelay == 1 )
	BaseType_t xTaskAbortDelay( TaskHandle_t xTask )
	{
	TCB_t *pxTCB = xTask;
	BaseType_t xReturn;
		configASSERT( pxTCB );
		//挂起所有任务
		vTaskSuspendAll();
		{	//任务是否是阻塞态
			if( eTaskGetState( xTask ) == eBlocked )
			{
				xReturn = pdPASS;
				//将任务从阻塞态集中移除
				( void ) uxListRemove( &( pxTCB->xStateListItem ) );
				taskENTER_CRITICAL();//进入临界区
				{	//查看事件是否存在于事件集
					if( listLIST_ITEM_CONTAINER( &( pxTCB->xEventListItem ) ) != NULL )
					{	//移除它,并配置任务为延迟中止
						( void ) uxListRemove( &( pxTCB->xEventListItem ) );
						pxTCB->ucDelayAborted = pdTRUE;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				taskEXIT_CRITICAL();//退出临界区
				//任务加入到就绪链表中
				prvAddTaskToReadyList( pxTCB );
				#if (  configUSE_PREEMPTION == 1 )
				{	//检查是否需要调度
					if( pxTCB->uxPriority > pxCurrentTCB->uxPriority )
					{	//配置挂起态,以便后续的调度
						xYieldPending = pdTRUE;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				#endif
			}
			else
			{
				xReturn = pdFAIL;
			}
		}
		( void ) xTaskResumeAll();//恢复全部任务
		return xReturn;
	}

#endif

//更新时钟滴答,并处理可以被放入到就绪队列的延迟任务
BaseType_t xTaskIncrementTick( void )
{
TCB_t * pxTCB;
TickType_t xItemValue;
BaseType_t xSwitchRequired = pdFALSE;
	traceTASK_INCREMENT_TICK( xTickCount );
	if( uxSchedulerSuspended == ( UBaseType_t ) pdFALSE )
	{	//当前调度已被挂起,增加一次时钟滴答
		const TickType_t xConstTickCount = xTickCount + ( TickType_t ) 1;
		xTickCount = xConstTickCount;//更新任务时钟滴答
		if( xConstTickCount == ( TickType_t ) 0U ) 
		{	//延迟链表切换,将溢出过期延迟链表与普通延迟链表切换
			//因为发送了一次时钟滴答的溢出
			taskSWITCH_DELAYED_LISTS();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		if( xConstTickCount >= xNextTaskUnblockTime )
		{	//当前时钟滴答大于下一次 释放最近阻塞态任务的时间
			for( ;; )
			{	//延迟任务链表为空时
				if( listLIST_IS_EMPTY( pxDelayedTaskList ) != pdFALSE )
				{	//重新更新下一次 释放阻塞任务 的时间
					xNextTaskUnblockTime = portMAX_DELAY;
					break;
				}
				else
				{	//取延迟任务链表的首项,获取下次延迟中止的事件
					pxTCB = listGET_OWNER_OF_HEAD_ENTRY( pxDelayedTaskList );
					xItemValue = listGET_LIST_ITEM_VALUE( &( pxTCB->xStateListItem ) );

					if( xConstTickCount < xItemValue )
					{	//当前时钟滴答小于下一延迟任务释放的时间
						//那可以直接指定下一延迟任务释放时间,并中止
						xNextTaskUnblockTime = xItemValue;
						break; 
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					//程序走到这里,表明有些延迟任务,早就到达对应延迟时间但一直未处理
					//将它移出延迟链表中,处理它
					( void ) uxListRemove( &( pxTCB->xStateListItem ) );
					//如果事件组存在就一并移除
					if( listLIST_ITEM_CONTAINER( &( pxTCB->xEventListItem ) ) != NULL )
					{
						( void ) uxListRemove( &( pxTCB->xEventListItem ) );
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}

					//最终将这个已到达延迟时间的任务加入到就绪链表中
					prvAddTaskToReadyList( pxTCB );

					#if (  configUSE_PREEMPTION == 1 )
					{	//调度检查,是否需要调度,取决于是否定义抢占
						if( pxTCB->uxPriority >= pxCurrentTCB->uxPriority )
						{
							xSwitchRequired = pdTRUE;
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					#endif
				}
				//继续检查下一个延迟任务,是否经过延迟时间
			}
		}
		
		#if ( ( configUSE_PREEMPTION == 1 ) && ( configUSE_TIME_SLICING == 1 ) )
		{	//就绪队列存在和当前优先级一致的任务
			if( listCURRENT_LIST_LENGTH( &( pxReadyTasksLists[ pxCurrentTCB->uxPriority ] ) ) > ( UBaseType_t ) 1 )
			{	//也需要设置标记,让调度程序重新调整执行权限
				xSwitchRequired = pdTRUE;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		#endif
		
		#if ( configUSE_TICK_HOOK == 1 )
		{	//如果出现时钟滴答的钩子,那么有必要执行该钩子
			if( uxPendedTicks == ( UBaseType_t ) 0U )
			{	//因为延迟滴答刚好到达过期点
				vApplicationTickHook();
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		#endif
	}
	else
	{	//如果调度未挂起,那么记录新的调度挂起滴答
		++uxPendedTicks;
		#if ( configUSE_TICK_HOOK == 1 )
		{	//滴答回调钩子执行
			vApplicationTickHook();
		}
		#endif
	}

	#if ( configUSE_PREEMPTION == 1 )
	{	//最后检查是否需要调度
		if( xYieldPending != pdFALSE )
		{
			xSwitchRequired = pdTRUE;
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	#endif
	return xSwitchRequired;
}

//配置应用的回调钩子
#if ( configUSE_APPLICATION_TASK_TAG == 1 )
	void vTaskSetApplicationTaskTag( TaskHandle_t xTask, TaskHookFunction_t pxHookFunction )
	{
	TCB_t *xTCB;
		if( xTask == NULL )
		{	//确定为哪一个任务添加应用回调,如果自身为空就加入到当前任务中
			xTCB = ( TCB_t * ) pxCurrentTCB;
		}
		else
		{
			xTCB = xTask;
		}
		taskENTER_CRITICAL();
		{
			xTCB->pxTaskTag = pxHookFunction;
		}
		taskEXIT_CRITICAL();
	}
#endif 

//获取应用的回调钩子
#if ( configUSE_APPLICATION_TASK_TAG == 1 )
	TaskHookFunction_t xTaskGetApplicationTaskTag( TaskHandle_t xTask )
	{
	TCB_t *xTCB;
	TaskHookFunction_t xReturn;
		if( xTask == NULL )
		{	//确认索要哪个任务携带的应用回调钩子
			xTCB = ( TCB_t * ) pxCurrentTCB;
		}
		else
		{
			xTCB = xTask;
		}
		taskENTER_CRITICAL();
		{
			xReturn = xTCB->pxTaskTag;
		}
		taskEXIT_CRITICAL();

		return xReturn;
	}

#endif

//执行应用回调钩子
#if ( configUSE_APPLICATION_TASK_TAG == 1 )
	BaseType_t xTaskCallApplicationTaskHook( TaskHandle_t xTask, void *pvParameter )
	{
	TCB_t *xTCB;
	BaseType_t xReturn;
		if( xTask == NULL )
		{	//确认索要哪一个回调钩子去执行
			xTCB = pxCurrentTCB;
		}
		else
		{
			xTCB = xTask;
		}
		if( xTCB->pxTaskTag != NULL )
		{	//利用传入的参数进行回调执行
			xReturn = xTCB->pxTaskTag( pvParameter );
		}
		else
		{
			xReturn = pdFAIL;
		}

		return xReturn;
	}

#endif 

//上下文切换的封装
void vTaskSwitchContext( void )
{
	if( uxSchedulerSuspended != ( UBaseType_t ) pdFALSE )
	{	//调度程序在运行时无需手动进行上下文切换
		xYieldPending = pdTRUE;
	}
	else
	{
		xYieldPending = pdFALSE;
		traceTASK_SWITCHED_OUT();
		#if ( configGENERATE_RUN_TIME_STATS == 1 )
		{		//使用平台自带的,运行值计数获取当前 运行态所用时间计数
				#ifdef portALT_GET_RUN_TIME_COUNTER_VALUE
					portALT_GET_RUN_TIME_COUNTER_VALUE( ulTotalRunTime );
				#else
					ulTotalRunTime = portGET_RUN_TIME_COUNTER_VALUE();
				#endif
				if( ulTotalRunTime > ulTaskSwitchedInTime )
				{	//重新更新一下任务的总运行时,从任务切换开始到总运行时之间
					pxCurrentTCB->ulRunTimeCounter += ( ulTotalRunTime - ulTaskSwitchedInTime );
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
				ulTaskSwitchedInTime = ulTotalRunTime;
		}
		#endif
		//堆栈溢出检查
		taskCHECK_FOR_STACK_OVERFLOW();
		#if( configUSE_POSIX_ERRNO == 1 )
		{	//错误码更新
			pxCurrentTCB->iTaskErrno = FreeRTOS_errno;
		}
		#endif
		//高优先级任务选择
		taskSELECT_HIGHEST_PRIORITY_TASK();
		traceTASK_SWITCHED_IN();
		#if( configUSE_POSIX_ERRNO == 1 )
		{	//获取新的错误码
			FreeRTOS_errno = pxCurrentTCB->iTaskErrno;
		}
		#endif
		#if ( configUSE_NEWLIB_REENTRANT == 1 )
		{	//使用New Lib reent
			_impure_ptr = &( pxCurrentTCB->xNewLib_reent );
		}
		#endif
	}
}

//更换当前任务的事件组
void vTaskPlaceOnEventList( List_t * const pxEventList, const TickType_t xTicksToWait )
{
	configASSERT( pxEventList );
	//将当前任务的事件加入到指定的事件组中
	vListInsert( pxEventList, &( pxCurrentTCB->xEventListItem ) );
	//将当前任务加入到延迟链表中
	prvAddCurrentTaskToDelayedList( xTicksToWait, pdTRUE );
}

//当前任务更新值后加入到指定事件组尾,因为都是尾插所以无法保证事件组 有序
void vTaskPlaceOnUnorderedEventList( List_t * pxEventList, const TickType_t xItemValue, const TickType_t xTicksToWait )
{
	configASSERT( pxEventList );
	configASSERT( uxSchedulerSuspended != 0 );
	//更新当前任务的值
	listSET_LIST_ITEM_VALUE( &( pxCurrentTCB->xEventListItem ), xItemValue | taskEVENT_LIST_ITEM_VALUE_IN_USE );
	//当前任务加入到指定事件组末尾
	vListInsertEnd( pxEventList, &( pxCurrentTCB->xEventListItem ) );
	//当前任务加入到延迟链表中
	prvAddCurrentTaskToDelayedList( xTicksToWait, pdTRUE );
}

//当前任务加入到受限事件组中
#if( configUSE_TIMERS == 1 )
	void vTaskPlaceOnEventListRestricted( List_t * const pxEventList, TickType_t xTicksToWait, const BaseType_t xWaitIndefinitely )
	{
		configASSERT( pxEventList );
		//将当前任务加入到指定事件组末尾
		vListInsertEnd( pxEventList, &( pxCurrentTCB->xEventListItem ) );
		//是否选择最大延迟,将其加入到延迟链表中
		if( xWaitIndefinitely != pdFALSE )
		{
			xTicksToWait = portMAX_DELAY;
		}
		traceTASK_DELAY_UNTIL( ( xTickCount + xTicksToWait ) );
		//以指定的延迟,将当前任务加入到延迟链表中
		prvAddCurrentTaskToDelayedList( xTicksToWait, xWaitIndefinitely );
	}

#endif

//将事件组的首任务从事件组中移除(处理它)
BaseType_t xTaskRemoveFromEventList( const List_t * const pxEventList )
{
TCB_t *pxUnblockedTCB;
BaseType_t xReturn;
	//获取事件组的首项
	pxUnblockedTCB = listGET_OWNER_OF_HEAD_ENTRY( pxEventList );
	configASSERT( pxUnblockedTCB );
	//将首项从事件组中移除
	( void ) uxListRemove( &( pxUnblockedTCB->xEventListItem ) );
	if( uxSchedulerSuspended == ( UBaseType_t ) pdFALSE )
	{	//调度程序挂起时,那么手动执行任务添加
		//任务状态项从状态链表中移除
		( void ) uxListRemove( &( pxUnblockedTCB->xStateListItem ) );
		//将任务加入到就绪链表中
		prvAddTaskToReadyList( pxUnblockedTCB );
	}
	else
	{	//调度程序在执行,那将任务事件加入到挂起就绪队列,让调度程序移入到就绪队列中
		vListInsertEnd( &( xPendingReadyList ), &( pxUnblockedTCB->xEventListItem ) );
	}
	if( pxUnblockedTCB->uxPriority > pxCurrentTCB->uxPriority )
	{	//是否需要调度？新激活的任务优先级是否比当前运行任务大,先挂起任务切换
		xReturn = pdTRUE;
		xYieldPending = pdTRUE;
	}
	else
	{
		xReturn = pdFALSE;
	}
	#if( configUSE_TICKLESS_IDLE != 0 )
	{	//更新下一个脱离阻塞态的任务的 脱离时间
		prvResetNextTaskUnblockTime();
	}
	#endif
	return xReturn;
}

//无序事件组中移除指定事件
void vTaskRemoveFromUnorderedEventList( ListItem_t * pxEventListItem, const TickType_t xItemValue )
{
TCB_t *pxUnblockedTCB;
	configASSERT( uxSchedulerSuspended != pdFALSE );
	//修正指定事件的事件值
	listSET_LIST_ITEM_VALUE( pxEventListItem, xItemValue | taskEVENT_LIST_ITEM_VALUE_IN_USE );
	//获取指定事件的任务TCB
	pxUnblockedTCB = listGET_LIST_ITEM_OWNER( pxEventListItem );
	configASSERT( pxUnblockedTCB );
	( void ) uxListRemove( pxEventListItem );//将事件从事件组中移除
	//将状态从状态集中移除
	( void ) uxListRemove( &( pxUnblockedTCB->xStateListItem ) );
	//将其加入到就绪队列中
	prvAddTaskToReadyList( pxUnblockedTCB );
	if( pxUnblockedTCB->uxPriority > pxCurrentTCB->uxPriority )
	{	//高优先级检查,是否需要调度,先考虑挂起不处理它
		xYieldPending = pdTRUE;
	}
}

//任务超时状态设置
void vTaskSetTimeOutState( TimeOut_t * const pxTimeOut )
{
	configASSERT( pxTimeOut );
	taskENTER_CRITICAL();
	{	//溢出次数和超时进入时间
		pxTimeOut->xOverflowCount = xNumOfOverflows;
		pxTimeOut->xTimeOnEntering = xTickCount;
	}
	taskEXIT_CRITICAL();
}

//内部设置,无需考虑被打断
void vTaskInternalSetTimeOutState( TimeOut_t * const pxTimeOut )
{
	pxTimeOut->xOverflowCount = xNumOfOverflows;
	pxTimeOut->xTimeOnEntering = xTickCount;
}

//任务超时检查
BaseType_t xTaskCheckForTimeOut( TimeOut_t * const pxTimeOut, TickType_t * const pxTicksToWait )
{
BaseType_t xReturn;

	configASSERT( pxTimeOut );
	configASSERT( pxTicksToWait );
	taskENTER_CRITICAL();
	{
		const TickType_t xConstTickCount = xTickCount;
		const TickType_t xElapsedTime = xConstTickCount - pxTimeOut->xTimeOnEntering;

		#if( INCLUDE_xTaskAbortDelay == 1 )
			if( pxCurrentTCB->ucDelayAborted != ( uint8_t ) pdFALSE )
			{	//打断延时中止标志,因为可能需要延时
				pxCurrentTCB->ucDelayAborted = pdFALSE;
				xReturn = pdTRUE;
			}
			else
		#endif
		#if ( INCLUDE_vTaskSuspend == 1 )
			if( *pxTicksToWait == portMAX_DELAY )
			{	//延时标志检查,要最大延时？
				xReturn = pdFALSE;
			}
			else
		#endif

		if( ( xNumOfOverflows != pxTimeOut->xOverflowCount ) && ( xConstTickCount >= pxTimeOut->xTimeOnEntering ) )
		{	//出现了溢出重置,但溢出次数与当前不相等,表明 超时进入时间自己溢出了
			xReturn = pdTRUE;
		}
		else if( xElapsedTime < *pxTicksToWait )
		{	//等待时间更新,因为已经产生了一定的过期时间
			*pxTicksToWait -= xElapsedTime;
			//重新配置超时时间
			vTaskInternalSetTimeOutState( pxTimeOut );
			xReturn = pdFALSE;
		}
		else
		{	//等待时间重置,因为产生了过多的过期时间
			*pxTicksToWait = 0;
			xReturn = pdTRUE;
		}
	}
	taskEXIT_CRITICAL();

	return xReturn;
}

//调度缺失,挂起调度
void vTaskMissedYield( void )
{
	xYieldPending = pdTRUE;
}

//获取任务数
#if ( configUSE_TRACE_FACILITY == 1 )
	UBaseType_t uxTaskGetTaskNumber( TaskHandle_t xTask )
	{
	UBaseType_t uxReturn;
	TCB_t const *pxTCB;

		if( xTask != NULL )
		{
			pxTCB = xTask;
			uxReturn = pxTCB->uxTaskNumber;
		}
		else
		{
			uxReturn = 0U;
		}

		return uxReturn;
	}

#endif

//设置任务数
#if ( configUSE_TRACE_FACILITY == 1 )
	void vTaskSetTaskNumber( TaskHandle_t xTask, const UBaseType_t uxHandle )
	{
	TCB_t * pxTCB;

		if( xTask != NULL )
		{
			pxTCB = xTask;
			pxTCB->uxTaskNumber = uxHandle;
		}
	}

#endif

//它等价于 IDLE任务,允许编译器等做更多的动作
static portTASK_FUNCTION( prvIdleTask, pvParameters )
{
	( void ) pvParameters;//编译器警告
	//安全机制,保证上下文安全
	portTASK_CALLS_SECURE_FUNCTIONS();

	for( ;; )
	{	//任务等待被终止吗,如果是,终止该任务
		prvCheckTasksWaitingTermination();

		#if ( configUSE_PREEMPTION == 0 )
		{	//使能内核抢占,开启调度
			taskYIELD();
		}
		#endif
		
		#if ( ( configUSE_PREEMPTION == 1 ) && ( configIDLE_SHOULD_YIELD == 1 ) )
		{	//IDLE任务是否需要被抢占掉,检查是否存在同级任务
			if( listCURRENT_LIST_LENGTH( &( pxReadyTasksLists[ tskIDLE_PRIORITY ] ) ) > ( UBaseType_t ) 1 )
			{	//抢占
				taskYIELD();
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		#endif
		#if ( configUSE_IDLE_HOOK == 1 )
		{
			extern void vApplicationIdleHook( void );
			//如果有用户空闲任务的回调钩子,调用它
			vApplicationIdleHook();
		}
		#endif
		#if ( configUSE_TICKLESS_IDLE != 0 )
		{
		TickType_t xExpectedIdleTime;//预测IDLE任务是否可以运行
			xExpectedIdleTime = prvGetExpectedIdleTime();
			if( xExpectedIdleTime >= configEXPECTED_IDLE_TIME_BEFORE_SLEEP )
			{	//达到预期可能时,挂起全部任务
				vTaskSuspendAll();
				{
					configASSERT( xNextTaskUnblockTime >= xTickCount );
					xExpectedIdleTime = prvGetExpectedIdleTime();//重新预测一次
					//记录
					configPRE_SUPPRESS_TICKS_AND_SLEEP_PROCESSING( xExpectedIdleTime );
					if( xExpectedIdleTime >= configEXPECTED_IDLE_TIME_BEFORE_SLEEP )
					{
						traceLOW_POWER_IDLE_BEGIN();
						portSUPPRESS_TICKS_AND_SLEEP( xExpectedIdleTime );
						traceLOW_POWER_IDLE_END();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				( void ) xTaskResumeAll();//恢复全部任务
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		#endif 
	}
}

//任务检查,是哪一种睡眠模式下
#if( configUSE_TICKLESS_IDLE != 0 )
	eSleepModeStatus eTaskConfirmSleepModeStatus( void )
	{
	const UBaseType_t uxNonApplicationTasks = 1;
	eSleepModeStatus eReturn = eStandardSleep;

		if( listCURRENT_LIST_LENGTH( &xPendingReadyList ) != 0 )
		{	//挂起就绪队列不为空,表明有任务是被中止,所以是中止导致的睡眠
			eReturn = eAbortSleep;
		}
		else if( xYieldPending != pdFALSE )
		{	//调度被挂起,所以也是中止导致的睡眠
			eReturn = eAbortSleep;
		}
		else
		{	//所有任务都被挂起了,挂起意味着拥有无限睡眠的时间
			if( listCURRENT_LIST_LENGTH( &xSuspendedTaskList ) == ( uxCurrentNumberOfTasks - uxNonApplicationTasks ) )
			{	//所以他们根本没有超时等待
				eReturn = eNoTasksWaitingTimeout;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		return eReturn;
	}

#endif

//设置本地线程存储地址
#if ( configNUM_THREAD_LOCAL_STORAGE_POINTERS != 0 )
	void vTaskSetThreadLocalStoragePointer( TaskHandle_t xTaskToSet, BaseType_t xIndex, void *pvValue )
	{
	TCB_t *pxTCB;
		if( xIndex < configNUM_THREAD_LOCAL_STORAGE_POINTERS )
		{	//确认是到哪一个句柄到任务
			pxTCB = prvGetTCBFromHandle( xTaskToSet );//将地址写入进去
			pxTCB->pvThreadLocalStoragePointers[ xIndex ] = pvValue;
		}
	}

#endif

//获取本地线程存储地址
#if ( configNUM_THREAD_LOCAL_STORAGE_POINTERS != 0 )
	void *pvTaskGetThreadLocalStoragePointer( TaskHandle_t xTaskToQuery, BaseType_t xIndex )
	{
	void *pvReturn = NULL;
	TCB_t *pxTCB;
		if( xIndex < configNUM_THREAD_LOCAL_STORAGE_POINTERS )
		{	//通过句柄找到任务TCB,然后找到对应下标的地址
			pxTCB = prvGetTCBFromHandle( xTaskToQuery );
			pvReturn = pxTCB->pvThreadLocalStoragePointers[ xIndex ];
		}
		else
		{
			pvReturn = NULL;
		}
		return pvReturn;
	}
#endif

//MPU的封装,为MPU分配Regions
#if ( portUSING_MPU_WRAPPERS == 1 )
	void vTaskAllocateMPURegions( TaskHandle_t xTaskToModify, const MemoryRegion_t * const xRegions )
	{
	TCB_t *pxTCB;//通过句柄获取TCB,然后设置TCB的参数xMPUSetting,使用指定的存储区域
		pxTCB = prvGetTCBFromHandle( xTaskToModify );
		vPortStoreTaskMPUSettings( &( pxTCB->xMPUSettings ), xRegions, NULL, 0 );
	}
#endif

//全部任务链表初始化
static void prvInitialiseTaskLists( void )
{
UBaseType_t uxPriority;
	for( uxPriority = ( UBaseType_t ) 0U; uxPriority < ( UBaseType_t ) configMAX_PRIORITIES; uxPriority++ )
	{	//使用链表初始化的接口初始化即可
		vListInitialise( &( pxReadyTasksLists[ uxPriority ] ) );
	}
	vListInitialise( &xDelayedTaskList1 );
	vListInitialise( &xDelayedTaskList2 );
	vListInitialise( &xPendingReadyList );
	#if ( INCLUDE_vTaskDelete == 1 )
	{
		vListInitialise( &xTasksWaitingTermination );
	}
	#endif
	#if ( INCLUDE_vTaskSuspend == 1 )
	{
		vListInitialise( &xSuspendedTaskList );
	}
	#endif 
	//指定延迟链表和过期延迟链表为俩个初始化表之一
	pxDelayedTaskList = &xDelayedTaskList1;
	pxOverflowDelayedTaskList = &xDelayedTaskList2;
}

//任务等待终止检查,清除任务
static void prvCheckTasksWaitingTermination( void )
{
	#if ( INCLUDE_vTaskDelete == 1 )
	{
		TCB_t *pxTCB;
		while( uxDeletedTasksWaitingCleanUp > ( UBaseType_t ) 0U )
		{	//循环清理每一个需要终止的任务
			taskENTER_CRITICAL();
			{	//从 等待终止任务链表 头一个一个的取
				pxTCB = listGET_OWNER_OF_HEAD_ENTRY( ( &xTasksWaitingTermination ) );
				( void ) uxListRemove( &( pxTCB->xStateListItem ) );//移除
				--uxCurrentNumberOfTasks;
				--uxDeletedTasksWaitingCleanUp;
			}
			taskEXIT_CRITICAL();
			//删除指定的TCB
			prvDeleteTCB( pxTCB );
		}
	}
	#endif 
}

//任务信息的获取
#if( configUSE_TRACE_FACILITY == 1 )
	void vTaskGetInfo( TaskHandle_t xTask, TaskStatus_t *pxTaskStatus, BaseType_t xGetFreeStackSpace, eTaskState eState )
	{
	TCB_t *pxTCB;
		//句柄到TCB
		pxTCB = prvGetTCBFromHandle( xTask );
		//获取TCB各个信息的存储地址
		pxTaskStatus->xHandle = ( TaskHandle_t ) pxTCB;
		pxTaskStatus->pcTaskName = ( const char * ) &( pxTCB->pcTaskName [ 0 ] );
		pxTaskStatus->uxCurrentPriority = pxTCB->uxPriority;
		pxTaskStatus->pxStackBase = pxTCB->pxStack;
		pxTaskStatus->xTaskNumber = pxTCB->uxTCBNumber;
		#if ( configUSE_MUTEXES == 1 )
		{	//
			pxTaskStatus->uxBasePriority = pxTCB->uxBasePriority;
		}
		#else
		{
			pxTaskStatus->uxBasePriority = 0;
		}
		#endif
		#if ( configGENERATE_RUN_TIME_STATS == 1 )
		{
			pxTaskStatus->ulRunTimeCounter = pxTCB->ulRunTimeCounter;
		}
		#else
		{
			pxTaskStatus->ulRunTimeCounter = 0;
		}
		#endif
		if( eState != eInvalid )
		{	//状态检查
			if( pxTCB == pxCurrentTCB )
			{	//确认是否是运行状态
				pxTaskStatus->eCurrentState = eRunning;
			}
			else
			{	//非运行态
				pxTaskStatus->eCurrentState = eState;

				#if ( INCLUDE_vTaskSuspend == 1 )
				{	//如果是挂起态
					if( eState == eSuspended )
					{
						vTaskSuspendAll();//挂起所有任务
						{
							if( listLIST_ITEM_CONTAINER( &( pxTCB->xEventListItem ) ) != NULL )
							{	//检查是否为阻塞态
								pxTaskStatus->eCurrentState = eBlocked;
							}
						}
						( void ) xTaskResumeAll();
					}
				}
				#endif
			}
		}
		else
		{	//直接获取TCB的当前任务状态
			pxTaskStatus->eCurrentState = eTaskGetState( pxTCB );
		}
		if( xGetFreeStackSpace != pdFALSE )
		{	//栈地址的获取
			#if ( portSTACK_GROWTH > 0 )
			{
				pxTaskStatus->usStackHighWaterMark = prvTaskCheckFreeStackSpace( ( uint8_t * ) pxTCB->pxEndOfStack );
			}
			#else
			{
				pxTaskStatus->usStackHighWaterMark = prvTaskCheckFreeStackSpace( ( uint8_t * ) pxTCB->pxStack );
			}
			#endif
		}
		else
		{
			pxTaskStatus->usStackHighWaterMark = 0;
		}
	}
#endif

//数据拷贝,将一个链表中的全部TCB信息按顺序拷贝出来
#if ( configUSE_TRACE_FACILITY == 1 )
	static UBaseType_t prvListTasksWithinSingleList( TaskStatus_t *pxTaskStatusArray, List_t *pxList, eTaskState eState )
	{
	configLIST_VOLATILE TCB_t *pxNextTCB, *pxFirstTCB;
	UBaseType_t uxTask = 0;
		if( listCURRENT_LIST_LENGTH( pxList ) > ( UBaseType_t ) 0 )
		{	//链表合法性检查
			listGET_OWNER_OF_NEXT_ENTRY( pxFirstTCB, pxList ); 
			do
			{	//变量链表的每一项,检查
				listGET_OWNER_OF_NEXT_ENTRY( pxNextTCB, pxList ); /*lint !e9079 void * is used as this macro is used with timers and co-routines too.  Alignment is known to be fine as the type of the pointer stored and retrieved is the same. */
				//消息拷贝到数组的一项中,然后继续拷贝下一项
				vTaskGetInfo( ( TaskHandle_t ) pxNextTCB, &( pxTaskStatusArray[ uxTask ] ), pdTRUE, eState );
				uxTask++;
			} while( pxNextTCB != pxFirstTCB );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		return uxTask;
	}

#endif

//检查空余栈地址空间
#if ( ( configUSE_TRACE_FACILITY == 1 ) || ( INCLUDE_uxTaskGetStackHighWaterMark == 1 ) )
	static configSTACK_DEPTH_TYPE prvTaskCheckFreeStackSpace( const uint8_t * pucStackByte )
	{
	uint32_t ulCount = 0U;
		while( *pucStackByte == ( uint8_t ) tskSTACK_FILL_BYTE )
		{
			pucStackByte -= portSTACK_GROWTH;
			ulCount++;//从末尾遍历到历史最大栈顶,直到找到第一个非空块
		}
		ulCount /= ( uint32_t ) sizeof( StackType_t );//空余块计算
		
		return ( configSTACK_DEPTH_TYPE ) ulCount;
	}
#endif

//栈的高位掩码值获取
#if ( INCLUDE_uxTaskGetStackHighWaterMark == 1 )
	UBaseType_t uxTaskGetStackHighWaterMark( TaskHandle_t xTask )
	{
	TCB_t *pxTCB;
	uint8_t *pucEndOfStack;
	UBaseType_t uxReturn;
		pxTCB = prvGetTCBFromHandle( xTask );//通过句柄获取TCB
		#if portSTACK_GROWTH < 0
		{	//获取栈末尾位置
			pucEndOfStack = ( uint8_t * ) pxTCB->pxStack;
		}
		#else
		{
			pucEndOfStack = ( uint8_t * ) pxTCB->pxEndOfStack;
		}
		#endif//获取栈的空余块
		uxReturn = ( UBaseType_t ) prvTaskCheckFreeStackSpace( pucEndOfStack );
		return uxReturn;
	}
#endif

//任务TCB的删除
#if ( INCLUDE_vTaskDelete == 1 )
	static void prvDeleteTCB( TCB_t *pxTCB )
	{	//平台层对TCB的清除工作
		portCLEAN_UP_TCB( pxTCB );
		//应用层接口释放内存空间,New Lib库释放空间
		#if ( configUSE_NEWLIB_REENTRANT == 1 )
		{
			_reclaim_reent( &( pxTCB->xNewLib_reent ) );
		}
		#endif

		#if( ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 0 ) && ( portUSING_MPU_WRAPPERS == 0 ) )
		{	//平台层释放实际内存空间,注意这里没有静态分配所以直接释放
			vPortFree( pxTCB->pxStack );
			vPortFree( pxTCB );
		}
		#elif( tskSTATIC_AND_DYNAMIC_ALLOCATION_POSSIBLE != 0 ) 
		{	//根据事件的静态内存分配情况,去释放那些动态内存分配的部分
			if( pxTCB->ucStaticallyAllocated == tskDYNAMICALLY_ALLOCATED_STACK_AND_TCB )
			{
				vPortFree( pxTCB->pxStack );
				vPortFree( pxTCB );
			}
			else if( pxTCB->ucStaticallyAllocated == tskSTATICALLY_ALLOCATED_STACK_ONLY )
			{
				vPortFree( pxTCB );
			}
			else
			{	//很显然这里因为都是静态分配,所以不能动态释放
				configASSERT( pxTCB->ucStaticallyAllocated == tskSTATICALLY_ALLOCATED_STACK_AND_TCB	);
				mtCOVERAGE_TEST_MARKER();
			}
		}
		#endif
	}

#endif

//更新 最近一个需要被解除阻塞的阻塞块 下一个解除阻塞的时间
static void prvResetNextTaskUnblockTime( void )
{
TCB_t *pxTCB;
	if( listLIST_IS_EMPTY( pxDelayedTaskList ) != pdFALSE )
	{	//延迟链表为空,那么没有下一个要解除阻塞的阻塞块
		xNextTaskUnblockTime = portMAX_DELAY;
	}
	else
	{	//获取第一个阻塞块 也就是下一个要解除阻塞的阻塞块
		//因为链表是从小到大的 按xItemValue 排列的,而这个值也代表延迟时间
		( pxTCB ) = listGET_OWNER_OF_HEAD_ENTRY( pxDelayedTaskList );
		//获取它的延迟时间,那么那一刻的到来紧接着就是解除阻塞的时间
		xNextTaskUnblockTime = listGET_LIST_ITEM_VALUE( &( ( pxTCB )->xStateListItem ) );
	}
}

//获取当前任务的句柄
#if ( ( INCLUDE_xTaskGetCurrentTaskHandle == 1 ) || ( configUSE_MUTEXES == 1 ) )
	TaskHandle_t xTaskGetCurrentTaskHandle( void )
	{
	TaskHandle_t xReturn;
		xReturn = pxCurrentTCB;
		return xReturn;
	}

#endif

//获取任务调度状态
#if ( ( INCLUDE_xTaskGetSchedulerState == 1 ) || ( configUSE_TIMERS == 1 ) )
	BaseType_t xTaskGetSchedulerState( void )
	{
	BaseType_t xReturn;
		if( xSchedulerRunning == pdFALSE )
		{	//当前调度器未启动
			xReturn = taskSCHEDULER_NOT_STARTED;
		}
		else
		{
			if( uxSchedulerSuspended == ( UBaseType_t ) pdFALSE )
			{	//调度器正在运行(因为未挂起)
				xReturn = taskSCHEDULER_RUNNING;
			}
			else
			{	//调度器被挂起(其他值)
				xReturn = taskSCHEDULER_SUSPENDED;
			}
		}

		return xReturn;
	}

#endif

//互斥锁优先级继承
#if ( configUSE_MUTEXES == 1 )
	BaseType_t xTaskPriorityInherit( TaskHandle_t const pxMutexHolder )
	{	//句柄与任务控制块是0偏移量的转化,它们本质是一个实体的俩种称呼方式
	TCB_t * const pxMutexHolderTCB = pxMutexHolder;//所以也可以直接强制转化
	BaseType_t xReturn = pdFALSE;
		if( pxMutexHolder != NULL )
		{	//优先级检查
			if( pxMutexHolderTCB->uxPriority < pxCurrentTCB->uxPriority )
			{	//对应任务的事件未使用
				if( ( listGET_LIST_ITEM_VALUE( &( pxMutexHolderTCB->xEventListItem ) ) & taskEVENT_LIST_ITEM_VALUE_IN_USE ) == 0UL )
				{	//修改任务的事件优先级
					listSET_LIST_ITEM_VALUE( &( pxMutexHolderTCB->xEventListItem ), ( TickType_t ) configMAX_PRIORITIES - ( TickType_t ) pxCurrentTCB->uxPriority );
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
				//状态存在于就绪队列集中
				if( listIS_CONTAINED_WITHIN( &( pxReadyTasksLists[ pxMutexHolderTCB->uxPriority ] ), &( pxMutexHolderTCB->xStateListItem ) ) != pdFALSE )
				{	//将其从原有状态集中移除
					if( uxListRemove( &( pxMutexHolderTCB->xStateListItem ) ) == ( UBaseType_t ) 0 )
					{	//重置它的就绪优先级
						taskRESET_READY_PRIORITY( pxMutexHolderTCB->uxPriority );
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					//继承当前这个高优先级任务的优先级,然后将其加入到就绪队列(优先级拉高意味着需要将其加入到就绪队列,因为同等优先级的当前任务已经在运行)
					pxMutexHolderTCB->uxPriority = pxCurrentTCB->uxPriority;
					prvAddTaskToReadyList( pxMutexHolderTCB );
				}
				else
				{	//只需要继承当前这个高优先级任务的优先级,它自己是不存在于就绪队列中的
					pxMutexHolderTCB->uxPriority = pxCurrentTCB->uxPriority;
				}
				//继承当前任务优先级
				traceTASK_PRIORITY_INHERIT( pxMutexHolderTCB, pxCurrentTCB->uxPriority );
				xReturn = pdTRUE;
			}
			else
			{	//优先级过低,不需要向下继承,继承是提升优先级级别而不是降低优先级级别
				if( pxMutexHolderTCB->uxBasePriority < pxCurrentTCB->uxPriority )
				{	//互斥锁的默认优先级低于当前要继承的优先级
					xReturn = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		return xReturn;
	}

#endif

//互斥锁优先级取消继承
#if ( configUSE_MUTEXES == 1 )
	BaseType_t xTaskPriorityDisinherit( TaskHandle_t const pxMutexHolder )
	{
	TCB_t * const pxTCB = pxMutexHolder;
	BaseType_t xReturn = pdFALSE;
		if( pxMutexHolder != NULL )
		{
			configASSERT( pxTCB == pxCurrentTCB );
			configASSERT( pxTCB->uxMutexesHeld );
			( pxTCB->uxMutexesHeld )--;//释放互斥锁

			if( pxTCB->uxPriority != pxTCB->uxBasePriority )
			{	//未持有互斥锁时
				if( pxTCB->uxMutexesHeld == ( UBaseType_t ) 0 )
				{	//将其从继承的状态集中移除
					if( uxListRemove( &( pxTCB->xStateListItem ) ) == ( UBaseType_t ) 0 )
					{	//重置就绪优先级
						taskRESET_READY_PRIORITY( pxTCB->uxPriority );
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					traceTASK_PRIORITY_DISINHERIT( pxTCB, pxTCB->uxBasePriority );
					//同步更新自己的运行时优先级					
					pxTCB->uxPriority = pxTCB->uxBasePriority;
					//反重置当前优先级,这样子就可以还原其原有的优先级(注意这里的值与继承时做的值)
					//该俩部分值其和是全集configMax_PRIORITIES,本身是相对于对方的补集
					listSET_LIST_ITEM_VALUE( &( pxTCB->xEventListItem ), ( TickType_t ) configMAX_PRIORITIES - ( TickType_t ) pxTCB->uxPriority );
					prvAddTaskToReadyList( pxTCB );//加入就绪队列中
					xReturn = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		return xReturn;
	}

#endif

//超时后的互斥锁优先级取消继承
#if ( configUSE_MUTEXES == 1 )
	void vTaskPriorityDisinheritAfterTimeout( TaskHandle_t const pxMutexHolder, UBaseType_t uxHighestPriorityWaitingTask )
	{
	TCB_t * const pxTCB = pxMutexHolder;
	UBaseType_t uxPriorityUsedOnEntry, uxPriorityToUse;
	const UBaseType_t uxOnlyOneMutexHeld = ( UBaseType_t ) 1;
		if( pxMutexHolder != NULL )
		{
			configASSERT( pxTCB->uxMutexesHeld );
			//获取抢夺互斥锁资源时遇到的最大优先级
			if( pxTCB->uxBasePriority < uxHighestPriorityWaitingTask )
			{
				uxPriorityToUse = uxHighestPriorityWaitingTask;
			}
			else
			{
				uxPriorityToUse = pxTCB->uxBasePriority;
			}

			if( pxTCB->uxPriority != uxPriorityToUse )
			{	//仅仅只有一个对象持有锁时才可以这样子做,否则在获取锁时产生多次优先级继承
				//会使情况复杂化
				if( pxTCB->uxMutexesHeld == uxOnlyOneMutexHeld )
				{
					configASSERT( pxTCB != pxCurrentTCB );
					traceTASK_PRIORITY_DISINHERIT( pxTCB, pxTCB->uxBasePriority );
					//更新优先级,获得锁当前最大优先级,用于下面优先级还原
					uxPriorityUsedOnEntry = pxTCB->uxPriority;
					pxTCB->uxPriority = uxPriorityToUse;
					if( ( listGET_LIST_ITEM_VALUE( &( pxTCB->xEventListItem ) ) & taskEVENT_LIST_ITEM_VALUE_IN_USE ) == 0UL )
					{	//仅仅在事件项未被使用时,才考虑取消优先级继承策略
						listSET_LIST_ITEM_VALUE( &( pxTCB->xEventListItem ), ( TickType_t ) configMAX_PRIORITIES - ( TickType_t ) uxPriorityToUse ); 
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					
					if( listIS_CONTAINED_WITHIN( &( pxReadyTasksLists[ uxPriorityUsedOnEntry ] ), &( pxTCB->xStateListItem ) ) != pdFALSE )
					{	//修改优先级代表着优先队列有一项存在于错误的位置,找到它
						if( uxListRemove( &( pxTCB->xStateListItem ) ) == ( UBaseType_t ) 0 )
						{	//删除它
							taskRESET_READY_PRIORITY( pxTCB->uxPriority );
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
						//重新以现有优先级加入到就绪队列中
						prvAddTaskToReadyList( pxTCB );
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}

#endif

//任务临界区的进入
#if ( portCRITICAL_NESTING_IN_TCB == 1 )
	void vTaskEnterCritical( void )
	{	//中断禁用
		portDISABLE_INTERRUPTS();
		if( xSchedulerRunning != pdFALSE )
		{	//临界区嵌套计数增加
			( pxCurrentTCB->uxCriticalNesting )++;
			if( pxCurrentTCB->uxCriticalNesting == 1 )
			{	//中断环境检查
				portASSERT_IF_IN_ISR();
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}

#endif

//任务临界区的退出
#if ( portCRITICAL_NESTING_IN_TCB == 1 )
	void vTaskExitCritical( void )
	{	//调度程序正在运行时
		if( xSchedulerRunning != pdFALSE )
		{	
			if( pxCurrentTCB->uxCriticalNesting > 0U )
			{	//临界区嵌套次数-1
				( pxCurrentTCB->uxCriticalNesting )--;

				if( pxCurrentTCB->uxCriticalNesting == 0U )
				{	//如果未在临界区时,开启中断
					portENABLE_INTERRUPTS();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}

#endif

//出现宏configUSE_TRACE_FACILITY表明是调试,参数pcBuffer就是打印所收集的数据

//将任务名字写入指定缓冲区
#if ( ( configUSE_TRACE_FACILITY == 1 ) && ( configUSE_STATS_FORMATTING_FUNCTIONS > 0 ) )
	static char *prvWriteNameToBuffer( char *pcBuffer, const char *pcTaskName )
	{
	size_t x;//字符串拷贝
		strcpy( pcBuffer, pcTaskName );
		for( x = strlen( pcBuffer ); x < ( size_t ) ( configMAX_TASK_NAME_LEN - 1 ); x++ )
		{	//字符串后面填空格,保证填满
			pcBuffer[ x ] = ' ';
		}
		//字符串结尾字符
		pcBuffer[ x ] = ( char ) 0x00;
		return &( pcBuffer[ x ] );
	}

#endif

//当前任务链表写入缓冲区
#if ( ( configUSE_TRACE_FACILITY == 1 ) && ( configUSE_STATS_FORMATTING_FUNCTIONS > 0 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
	void vTaskList( char * pcWriteBuffer )
	{
	TaskStatus_t *pxTaskStatusArray;
	UBaseType_t uxArraySize, x;
	char cStatus;
		//内容清空,清空字符串
		*pcWriteBuffer = ( char ) 0x00;
		uxArraySize = uxCurrentNumberOfTasks;
		pxTaskStatusArray = pvPortMalloc( uxCurrentNumberOfTasks * sizeof( TaskStatus_t ) ); 
		if( pxTaskStatusArray != NULL )
		{	//使用临时动态分配的空间,拷贝任务信息
			uxArraySize = uxTaskGetSystemState( pxTaskStatusArray, uxArraySize, NULL );
			for( x = 0; x < uxArraySize; x++ )
			{	//更新任务的状态
				switch( pxTaskStatusArray[ x ].eCurrentState )
				{
					case eRunning:		cStatus = tskRUNNING_CHAR;
										break;

					case eReady:		cStatus = tskREADY_CHAR;
										break;

					case eBlocked:		cStatus = tskBLOCKED_CHAR;
										break;

					case eSuspended:	cStatus = tskSUSPENDED_CHAR;
										break;

					case eDeleted:		cStatus = tskDELETED_CHAR;
										break;

					case eInvalid:		
					default:			cStatus = ( char ) 0x00;
										break;
				}
				//内容拷贝到指定空间中
				pcWriteBuffer = prvWriteNameToBuffer( pcWriteBuffer, pxTaskStatusArray[ x ].pcTaskName );
				sprintf( pcWriteBuffer, "\t%c\t%u\t%u\t%u\r\n", cStatus, ( unsigned int ) pxTaskStatusArray[ x ].uxCurrentPriority, ( unsigned int ) pxTaskStatusArray[ x ].usStackHighWaterMark, ( unsigned int ) pxTaskStatusArray[ x ].xTaskNumber );
				pcWriteBuffer += strlen( pcWriteBuffer );
			}
			//循环拷贝完后释放空间
			vPortFree( pxTaskStatusArray );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
#endif

//获取任务运行时状态
#if ( ( configGENERATE_RUN_TIME_STATS == 1 ) && ( configUSE_STATS_FORMATTING_FUNCTIONS > 0 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
	void vTaskGetRunTimeStats( char *pcWriteBuffer )
	{
	TaskStatus_t *pxTaskStatusArray;
	UBaseType_t uxArraySize, x;
	uint32_t ulTotalTime, ulStatsAsPercentage;
		#if( configUSE_TRACE_FACILITY != 1 )
		{	//条件检查
			#error configUSE_TRACE_FACILITY must also be set to 1 in FreeRTOSConfig.h to use vTaskGetRunTimeStats().
		}
		#endif
		*pcWriteBuffer = ( char ) 0x00;//字符串清空
		uxArraySize = uxCurrentNumberOfTasks;
		pxTaskStatusArray = pvPortMalloc( uxCurrentNumberOfTasks * sizeof( TaskStatus_t ) );
		if( pxTaskStatusArray != NULL )
		{	//使用临时分配的空间获取数据
			uxArraySize = uxTaskGetSystemState( pxTaskStatusArray, uxArraySize, &ulTotalTime );
			ulTotalTime /= 100UL;
			if( ulTotalTime > 0UL )
			{
				for( x = 0; x < uxArraySize; x++ )
				{	//获取它的百分比,写入到缓冲区
					ulStatsAsPercentage = pxTaskStatusArray[ x ].ulRunTimeCounter / ulTotalTime;
					pcWriteBuffer = prvWriteNameToBuffer( pcWriteBuffer, pxTaskStatusArray[ x ].pcTaskName );
					if( ulStatsAsPercentage > 0UL )
					{
						#ifdef portLU_PRINTF_SPECIFIER_REQUIRED//字符串拼接使用到的 无符号长整形变量 的预判断
						{
							sprintf( pcWriteBuffer, "\t%lu\t\t%lu%%\r\n", pxTaskStatusArray[ x ].ulRunTimeCounter, ulStatsAsPercentage );
						}
						#else
						{
							sprintf( pcWriteBuffer, "\t%u\t\t%u%%\r\n", ( unsigned int ) pxTaskStatusArray[ x ].ulRunTimeCounter, ( unsigned int ) ulStatsAsPercentage );
						}
						#endif
					}
					else
					{
						#ifdef portLU_PRINTF_SPECIFIER_REQUIRED
						{
							sprintf( pcWriteBuffer, "\t%lu\t\t<1%%\r\n", pxTaskStatusArray[ x ].ulRunTimeCounter );
						}
						#else
						{
							sprintf( pcWriteBuffer, "\t%u\t\t<1%%\r\n", ( unsigned int ) pxTaskStatusArray[ x ].ulRunTimeCounter ); 
						}
						#endif
					}

					pcWriteBuffer += strlen( pcWriteBuffer );
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
			//释放空间
			vPortFree( pxTaskStatusArray );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}

#endif

//重置事件组的值
TickType_t uxTaskResetEventItemValue( void )
{
TickType_t uxReturn;
	uxReturn = listGET_LIST_ITEM_VALUE( &( pxCurrentTCB->xEventListItem ) );
	//与继承优先级类似的方式重置事件组中事件的值,这个语句是对称执行的,连续执行俩次会还原原有值
	listSET_LIST_ITEM_VALUE( &( pxCurrentTCB->xEventListItem ), ( ( TickType_t ) configMAX_PRIORITIES - ( TickType_t ) pxCurrentTCB->uxPriority ) ); 
	return uxReturn;
}

//互斥锁所有计数增加一次
#if ( configUSE_MUTEXES == 1 )
	TaskHandle_t pvTaskIncrementMutexHeldCount( void )
	{	//当前任务互斥锁持有数+1
		if( pxCurrentTCB != NULL )
		{
			( pxCurrentTCB->uxMutexesHeld )++;
		}
		return pxCurrentTCB;
	}

#endif

//通知获取
#if( configUSE_TASK_NOTIFICATIONS == 1 )
	uint32_t ulTaskNotifyTake( BaseType_t xClearCountOnExit, TickType_t xTicksToWait )
	{
	uint32_t ulReturn;
		taskENTER_CRITICAL();
		{	//如果值空表明在等待通知
			if( pxCurrentTCB->ulNotifiedValue == 0UL )
			{
				pxCurrentTCB->ucNotifyState = taskWAITING_NOTIFICATION;
				if( xTicksToWait > ( TickType_t ) 0 )
				{	//如果指定等待延时就将其加入到等待队列
					prvAddCurrentTaskToDelayedList( xTicksToWait, pdTRUE );
					traceTASK_NOTIFY_TAKE_BLOCK();
					//手动进行任务调度
					portYIELD_WITHIN_API();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		taskEXIT_CRITICAL();

		taskENTER_CRITICAL();
		{
			traceTASK_NOTIFY_TAKE();
			ulReturn = pxCurrentTCB->ulNotifiedValue;
			if( ulReturn != 0UL )
			{	//是否产生了通知
				if( xClearCountOnExit != pdFALSE )
				{
					pxCurrentTCB->ulNotifiedValue = 0UL;
				}
				else
				{
					pxCurrentTCB->ulNotifiedValue = ulReturn - ( uint32_t ) 1;
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
			//通知已经产生了
			pxCurrentTCB->ucNotifyState = taskNOT_WAITING_NOTIFICATION;
		}
		taskEXIT_CRITICAL();

		return ulReturn;
	}

#endif

//等待通知
#if( configUSE_TASK_NOTIFICATIONS == 1 )
	BaseType_t xTaskNotifyWait( uint32_t ulBitsToClearOnEntry, uint32_t ulBitsToClearOnExit, uint32_t *pulNotificationValue, TickType_t xTicksToWait )
	{
	BaseType_t xReturn;
		taskENTER_CRITICAL();
		{	//只有在没有接受到通知时才需要等待
			if( pxCurrentTCB->ucNotifyState != taskNOTIFICATION_RECEIVED )
			{	//进入等待时清除位
				pxCurrentTCB->ulNotifiedValue &= ~ulBitsToClearOnEntry;
				//设置状态为等待通知状态
				pxCurrentTCB->ucNotifyState = taskWAITING_NOTIFICATION;
				if( xTicksToWait > ( TickType_t ) 0 )
				{	//有指定的等待延时时,将任务加入到延迟链表中
					prvAddCurrentTaskToDelayedList( xTicksToWait, pdTRUE );
					traceTASK_NOTIFY_WAIT_BLOCK();
					//任务调度
					portYIELD_WITHIN_API();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		taskEXIT_CRITICAL();

		taskENTER_CRITICAL();
		{
			traceTASK_NOTIFY_WAIT();
			if( pulNotificationValue != NULL )
			{	//获取等待值
				*pulNotificationValue = pxCurrentTCB->ulNotifiedValue;
			}
			if( pxCurrentTCB->ucNotifyState != taskNOTIFICATION_RECEIVED )
			{	//没有得到数据接受通知,失败
				xReturn = pdFALSE;
			}
			else
			{	//得到了数据接受通知,清除退出位
				pxCurrentTCB->ulNotifiedValue &= ~ulBitsToClearOnExit;
				xReturn = pdTRUE;
			}
			//设置为不再等待通知了
			pxCurrentTCB->ucNotifyState = taskNOT_WAITING_NOTIFICATION;
		}
		taskEXIT_CRITICAL();
		return xReturn;
	}

#endif

//任务的通用等待操作
#if( configUSE_TASK_NOTIFICATIONS == 1 )
	BaseType_t xTaskGenericNotify( TaskHandle_t xTaskToNotify, uint32_t ulValue, eNotifyAction eAction, uint32_t *pulPreviousNotificationValue )
	{
	TCB_t * pxTCB;
	BaseType_t xReturn = pdPASS;
	uint8_t ucOriginalNotifyState;
		configASSERT( xTaskToNotify );
		pxTCB = xTaskToNotify;
		taskENTER_CRITICAL();
		{	//获取先前等待通知值
			if( pulPreviousNotificationValue != NULL )
			{
				*pulPreviousNotificationValue = pxTCB->ulNotifiedValue;
			}
			//获取原来通知状态
			ucOriginalNotifyState = pxTCB->ucNotifyState;
			//获取通知状态为接受通知状态
			pxTCB->ucNotifyState = taskNOTIFICATION_RECEIVED;
			switch( eAction )
			{	//根据传入的标记确定如何更新通知的值
				case eSetBits	:	
					pxTCB->ulNotifiedValue |= ulValue;
					break;
				case eIncrement	:
					( pxTCB->ulNotifiedValue )++;
					break;
				case eSetValueWithOverwrite	:
					pxTCB->ulNotifiedValue = ulValue;
					break;
				case eSetValueWithoutOverwrite :
					if( ucOriginalNotifyState != taskNOTIFICATION_RECEIVED )
					{
						pxTCB->ulNotifiedValue = ulValue;
					}
					else
					{
						xReturn = pdFAIL;
					}
					break;
				case eNoAction:
					break;

				default:
					configASSERT( pxTCB->ulNotifiedValue == ~0UL );

					break;
			}
			traceTASK_NOTIFY();
			if( ucOriginalNotifyState == taskWAITING_NOTIFICATION )
			{	//等待通知的项不应该继续阻塞,将其移除并加入到就绪队列中
				( void ) uxListRemove( &( pxTCB->xStateListItem ) );
				prvAddTaskToReadyList( pxTCB );
				configASSERT( listLIST_ITEM_CONTAINER( &( pxTCB->xEventListItem ) ) == NULL );

				#if( configUSE_TICKLESS_IDLE != 0 )
				{	//更新下一个 要准备解除阻塞的阻塞任务,让它尽可能更早的响应事件
					//上面解除阻塞的项很有可能对应于的就是下一个解除阻塞的值,防止这种情况的出现
					prvResetNextTaskUnblockTime();
				}
				#endif

				if( pxTCB->uxPriority > pxCurrentTCB->uxPriority )
				{	//是否需要进行 内核抢占,优先级被满足到了
					taskYIELD_IF_USING_PREEMPTION();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		taskEXIT_CRITICAL();
		return xReturn;
	}

#endif

//中断环境下通用通知的配置
#if( configUSE_TASK_NOTIFICATIONS == 1 )
	BaseType_t xTaskGenericNotifyFromISR( TaskHandle_t xTaskToNotify, uint32_t ulValue, eNotifyAction eAction, uint32_t *pulPreviousNotificationValue, BaseType_t *pxHigherPriorityTaskWoken )
	{
	TCB_t * pxTCB;
	uint8_t ucOriginalNotifyState;
	BaseType_t xReturn = pdPASS;
	UBaseType_t uxSavedInterruptStatus;
		configASSERT( xTaskToNotify );//断言纠错
		//中断合法性检查
		portASSERT_IF_INTERRUPT_PRIORITY_INVALID();
		pxTCB = xTaskToNotify;//获取任务的TCB
		//中断状态的本地保留
		uxSavedInterruptStatus = portSET_INTERRUPT_MASK_FROM_ISR();
		{	//保留原来的通知的内容
			if( pulPreviousNotificationValue != NULL )
			{
				*pulPreviousNotificationValue = pxTCB->ulNotifiedValue;
			}
			//保留原始的通知的状态,并现在配置为接受态
			ucOriginalNotifyState = pxTCB->ucNotifyState;
			pxTCB->ucNotifyState = taskNOTIFICATION_RECEIVED;
			switch( eAction )	//重新配置新的,指定的通知值
			{
				case eSetBits	:
					pxTCB->ulNotifiedValue |= ulValue;
					break;
				case eIncrement	:
					( pxTCB->ulNotifiedValue )++;
					break;
				case eSetValueWithOverwrite	:
					pxTCB->ulNotifiedValue = ulValue;
					break;
				case eSetValueWithoutOverwrite :
					if( ucOriginalNotifyState != taskNOTIFICATION_RECEIVED )
					{
						pxTCB->ulNotifiedValue = ulValue;
					}
					else
					{
						xReturn = pdFAIL;
					}
					break;

				case eNoAction :
					break;
				default:
					configASSERT( pxTCB->ulNotifiedValue == ~0UL );
					break;
			}

			traceTASK_NOTIFY_FROM_ISR();

			if( ucOriginalNotifyState == taskWAITING_NOTIFICATION )
			{	//等待通知的项不应该被阻塞
				configASSERT( listLIST_ITEM_CONTAINER( &( pxTCB->xEventListItem ) ) == NULL );
				if( uxSchedulerSuspended == ( UBaseType_t ) pdFALSE )
				{	//在未调度时,手动移除原有状态集并加入到就绪队列中
					( void ) uxListRemove( &( pxTCB->xStateListItem ) );
					prvAddTaskToReadyList( pxTCB );
				}
				else
				{	//调度时不可以访问就绪链表,所以挂起该任务到 就绪挂起链表集中,让调度程序恢复
					vListInsertEnd( &( xPendingReadyList ), &( pxTCB->xEventListItem ) );
				}

				if( pxTCB->uxPriority > pxCurrentTCB->uxPriority )
				{	//优先级检查
					if( pxHigherPriorityTaskWoken != NULL )
					{
						*pxHigherPriorityTaskWoken = pdTRUE;
					}
					//如果用户未使用高优先级唤醒的话,挂起调度
					xYieldPending = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
		//清除中断状态
		portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );
		return xReturn;
	}

#endif

//中断环境下通知的获取
#if( configUSE_TASK_NOTIFICATIONS == 1 )
	void vTaskNotifyGiveFromISR( TaskHandle_t xTaskToNotify, BaseType_t *pxHigherPriorityTaskWoken )
	{
	TCB_t * pxTCB;
	uint8_t ucOriginalNotifyState;
	UBaseType_t uxSavedInterruptStatus;
		configASSERT( xTaskToNotify );
		//中断合法性检查
		portASSERT_IF_INTERRUPT_PRIORITY_INVALID();
		pxTCB = xTaskToNotify;//通过句柄获取任务TCB
		//保留中断状态
		uxSavedInterruptStatus = portSET_INTERRUPT_MASK_FROM_ISR();
		{	//保留原来的通知状态,并配置现在为接受通知
			ucOriginalNotifyState = pxTCB->ucNotifyState;
			pxTCB->ucNotifyState = taskNOTIFICATION_RECEIVED;
			( pxTCB->ulNotifiedValue )++;//giving等价于计数信号量中+1
			traceTASK_NOTIFY_GIVE_FROM_ISR();
			if( ucOriginalNotifyState == taskWAITING_NOTIFICATION )
			{//如果状态是处于等待通知的情况下,那么不应该被阻塞
				configASSERT( listLIST_ITEM_CONTAINER( &( pxTCB->xEventListItem ) ) == NULL );
				if( uxSchedulerSuspended == ( UBaseType_t ) pdFALSE )
				{	//未调度时,取消阻塞,加入到就绪链表集中
					( void ) uxListRemove( &( pxTCB->xStateListItem ) );
					prvAddTaskToReadyList( pxTCB );
				}
				else
				{	//调度时不可以访问就绪链表,所以挂起该任务到 就绪挂起链表集中,让调度程序恢复
					vListInsertEnd( &( xPendingReadyList ), &( pxTCB->xEventListItem ) );
				}

				if( pxTCB->uxPriority > pxCurrentTCB->uxPriority )
				{	//优先级满足调度,是否调度
					if( pxHigherPriorityTaskWoken != NULL )
					{
						*pxHigherPriorityTaskWoken = pdTRUE;
					}
					//未知用户的态度,是否允许调度,挂起调度
					xYieldPending = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
		//中断状态的清除
		portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );
	}

#endif

//通知状态的清除
#if( configUSE_TASK_NOTIFICATIONS == 1 )
	BaseType_t xTaskNotifyStateClear( TaskHandle_t xTask )
	{
	TCB_t *pxTCB;
	BaseType_t xReturn;//通过句柄获取任务TCB
		pxTCB = prvGetTCBFromHandle( xTask );
		taskENTER_CRITICAL();
		{	//清除通知状态
			if( pxTCB->ucNotifyState == taskNOTIFICATION_RECEIVED )
			{
				pxTCB->ucNotifyState = taskNOT_WAITING_NOTIFICATION;
				xReturn = pdPASS;
			}
			else
			{
				xReturn = pdFAIL;
			}
		}
		taskEXIT_CRITICAL();
		return xReturn;
	}

#endif

//当前任务以一定延时加入到延时队列中
static void prvAddCurrentTaskToDelayedList( TickType_t xTicksToWait, const BaseType_t xCanBlockIndefinitely )
{
TickType_t xTimeToWake;
const TickType_t xConstTickCount = xTickCount;
	#if( INCLUDE_xTaskAbortDelay == 1 )
	{	//取消延时中止,表明要进行延迟了
		pxCurrentTCB->ucDelayAborted = pdFALSE;
	}
	#endif
	if( uxListRemove( &( pxCurrentTCB->xStateListItem ) ) == ( UBaseType_t ) 0 )
	{	//将当前任务TCB移除状态队列中,重置一下就绪的优先级
		portRESET_READY_PRIORITY( pxCurrentTCB->uxPriority, uxTopReadyPriority );
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}

	#if ( INCLUDE_vTaskSuspend == 1 )
	{	//是采用最大延迟？那就丢到挂起队列的末尾,挂起它
		if( ( xTicksToWait == portMAX_DELAY ) && ( xCanBlockIndefinitely != pdFALSE ) )
		{
			vListInsertEnd( &xSuspendedTaskList, &( pxCurrentTCB->xStateListItem ) );
		}
		else
		{	//确认其唤醒时间,写入到状态项中
			xTimeToWake = xConstTickCount + xTicksToWait;
			listSET_LIST_ITEM_VALUE( &( pxCurrentTCB->xStateListItem ), xTimeToWake );
			if( xTimeToWake < xConstTickCount )
			{	//溢出了,那就丢到溢出延迟链表中
				vListInsert( pxOverflowDelayedTaskList, &( pxCurrentTCB->xStateListItem ) );
			}
			else
			{	//插入到延迟链表中
				vListInsert( pxDelayedTaskList, &( pxCurrentTCB->xStateListItem ) );
				if( xTimeToWake < xNextTaskUnblockTime )
				{	//更新下次未阻塞时间,如果运气好变成了DelayList首项的话
					xNextTaskUnblockTime = xTimeToWake;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
	}
	#else//不能挂起的话
	{	//配置唤醒时间
		xTimeToWake = xConstTickCount + xTicksToWait;
		listSET_LIST_ITEM_VALUE( &( pxCurrentTCB->xStateListItem ), xTimeToWake );
		if( xTimeToWake < xConstTickCount )
		{	//丢入到溢出延迟中(portMAX_DELAY也会是一个具体值,不过导致溢出而已)
			vListInsert( pxOverflowDelayedTaskList, &( pxCurrentTCB->xStateListItem ) );
		}
		else
		{	//未溢出,加入到普通延时队列中
			vListInsert( pxDelayedTaskList, &( pxCurrentTCB->xStateListItem ) );
			if( xTimeToWake < xNextTaskUnblockTime )
			{	//考虑更新
				xNextTaskUnblockTime = xTimeToWake;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		( void ) xCanBlockIndefinitely;//关闭编译器警告
	}
	#endif
}


#ifdef FREERTOS_MODULE_TEST
	#include "tasks_test_access_functions.h"
#endif


#if( configINCLUDE_FREERTOS_TASK_C_ADDITIONS_H == 1 )
	//这个是 C附加库 还是C++库 未知
	#include "freertos_tasks_c_additions.h"

	#ifdef FREERTOS_TASKS_C_ADDITIONS_INIT
		static void freertos_tasks_c_additions_init( void )
		{
			FREERTOS_TASKS_C_ADDITIONS_INIT();
		}
	#endif

#endif


