/*
 * 堆
 */

#include <stdlib.h>

//接口重包含,提前定义一下用于屏蔽mpu_wappers.h造成的影响
#define MPU_WRAPPERS_INCLUDED_FROM_API_FILE

#include "FreeRTOS.h"
#include "task.h"

//取消重包含,因为已经没必要了
#undef MPU_WRAPPERS_INCLUDED_FROM_API_FILE

//必须定义动态内存分配
#if( configSUPPORT_DYNAMIC_ALLOCATION == 0 )
	#error This file must not be used if configSUPPORT_DYNAMIC_ALLOCATION is 0
#endif

//堆的调整尺寸
#define configADJUSTED_HEAP_SIZE	( configTOTAL_HEAP_SIZE - portBYTE_ALIGNMENT )

//动态分配堆
#if( configAPPLICATION_ALLOCATED_HEAP == 1 )
	extern uint8_t ucHeap[ configTOTAL_HEAP_SIZE ];	//如果堆是来源于外界
#else
	static uint8_t ucHeap[ configTOTAL_HEAP_SIZE ]; //否则堆来源于本地
#endif


//下一个空闲字节
static size_t xNextFreeByte = ( size_t ) 0;

/*-----------------------------------------------------------*/

//动态分配
void *pvPortMalloc( size_t xWantedSize )
{
void *pvReturn = NULL;
static uint8_t *pucAlignedHeap = NULL;


	#if( portBYTE_ALIGNMENT != 1 )
	{
		if( xWantedSize & portBYTE_ALIGNMENT_MASK )
		{	//字节对齐检查
			xWantedSize += ( portBYTE_ALIGNMENT - ( xWantedSize & portBYTE_ALIGNMENT_MASK ) );
		}
	}
	#endif

	vTaskSuspendAll();
	{
		if( pucAlignedHeap == NULL )
		{	//边界起始位值
			pucAlignedHeap = ( uint8_t * ) ( ( ( portPOINTER_SIZE_TYPE ) &ucHeap[ portBYTE_ALIGNMENT ] ) & ( ~( ( portPOINTER_SIZE_TYPE ) portBYTE_ALIGNMENT_MASK ) ) );
		}

		//从下一个空闲区域开始直接往后分配
		if( ( ( xNextFreeByte + xWantedSize ) < configADJUSTED_HEAP_SIZE ) &&
			( ( xNextFreeByte + xWantedSize ) > xNextFreeByte )	)//溢出检查
		{
			pvReturn = pucAlignedHeap + xNextFreeByte;
			xNextFreeByte += xWantedSize;
		}

		traceMALLOC( pvReturn, xWantedSize );
	}
	( void ) xTaskResumeAll();//任务恢复

	#if( configUSE_MALLOC_FAILED_HOOK == 1 )
	{
		if( pvReturn == NULL )
		{	//如果用户提供了 动态内存分配失败 的事件处理
			//执行它重写的回调钩子
			extern void vApplicationMallocFailedHook( void );
			vApplicationMallocFailedHook();
		}
	}
	#endif

	return pvReturn;
}

//动态释放
void vPortFree( void *pv )
{
	( void ) pv;
	configASSERT( pv == NULL );
}

void vPortInitialiseBlocks( void )
{
	xNextFreeByte = ( size_t ) 0;
}

size_t xPortGetFreeHeapSize( void )
{
	return ( configADJUSTED_HEAP_SIZE - xNextFreeByte );
}



