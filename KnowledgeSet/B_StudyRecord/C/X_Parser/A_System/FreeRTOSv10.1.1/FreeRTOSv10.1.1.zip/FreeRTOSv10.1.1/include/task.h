/*
 * 任务
 */


#ifndef INC_TASK_H
#define INC_TASK_H

//前置条件
#ifndef INC_FREERTOS_H
	#error "include FreeRTOS.h must appear in source files before include task.h"
#endif

//链表的实现
#include "list.h"	

//C++扩展
#ifdef __cplusplus	
extern "C" {
#endif

//内核版本定义
#define tskKERNEL_VERSION_NUMBER "V10.1.1"
#define tskKERNEL_VERSION_MAJOR 10
#define tskKERNEL_VERSION_MINOR 1
#define tskKERNEL_VERSION_BUILD 1

//任务控制块声明
struct tskTaskControlBlock;
//任务句柄声明
typedef struct tskTaskControlBlock* TaskHandle_t;
//给任务注册的回调钩子
typedef BaseType_t (*TaskHookFunction_t)( void * );


//任务状态的取值范围
typedef enum
{
	eRunning = 0,	//任务正在运行
	eReady,			//任务准备就绪
	eBlocked,		//任务被阻塞
	eSuspended,		//任务被挂起
	eDeleted,		//任务被删除
	eInvalid		//非法状态
} eTaskState;

//被 vTaskNotify()使用,一些Notify的取值类型
typedef enum
{
	eNoAction = 0,				//不跟新Value情况下更新通知任务
	eSetBits,					//为Value设置位
	eIncrement,					//自增Value的一次值
	eSetValueWithOverwrite,		//指定Value的值,是否读取之前的值都做写覆盖
	eSetValueWithoutOverwrite	//指定Value的值,仅仅在之前的值被读取之后才做写覆盖
} eNotifyAction;

//内部使用,超时记录
typedef struct xTIME_OUT
{
	BaseType_t xOverflowCount;	//溢出次数
	TickType_t xTimeOnEntering;	//进入时间
} TimeOut_t;

//当MPU使用时,为其提供的空间
typedef struct xMEMORY_REGION
{
	void *pvBaseAddress;		//内存首地址
	uint32_t ulLengthInBytes;	//长度范围
	uint32_t ulParameters;		//参数
} MemoryRegion_t;

//为MPU保护任务提供的参数需求
typedef struct xTASK_PARAMETERS
{
	TaskFunction_t pvTaskCode;	//任务体
	const char * const pcName;	//任务名
	uint16_t usStackDepth;		//堆栈大小
	void *pvParameters;			//参数
	UBaseType_t uxPriority;		//任务优先级
	StackType_t *puxStackBuffer;//堆栈缓冲区起始地址
	MemoryRegion_t xRegions[ portNUM_CONFIGURABLE_REGIONS ];//为MPU的使用开辟的内存空间,用户分配
	#if ( ( portUSING_MPU_WRAPPERS == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 1 ) )
		StaticTask_t * const pxTaskBuffer;//堆栈起始地址
	#endif
} TaskParameters_t;

//uxTaskGetSystemState()所使用的,任务信息体
typedef struct xTASK_STATUS
{
	TaskHandle_t xHandle;			//任务句柄
	const char *pcTaskName;			//任务名
	UBaseType_t xTaskNumber;		//任务所需的一个变量
	eTaskState eCurrentState;		//任务状态
	UBaseType_t uxCurrentPriority;	//任务优先级
	UBaseType_t uxBasePriority;		//互斥锁所用基础优先级(锁优先级继承所用)
	uint32_t ulRunTimeCounter;		//任务运行时计数器
	StackType_t *pxStackBase;		//栈起始地址
	configSTACK_DEPTH_TYPE usStackHighWaterMark;	//高优先级唤醒标志
} TaskStatus_t;

//eTaskConfirmSleepModeStatus()所返回的,任务的状态之一
typedef enum
{
	eAbortSleep = 0,		//中止睡眠模式
	eStandardSleep,			//标准睡眠模式,受时间限制
	eNoTasksWaitingTimeout	//无任务等待超时,仅仅被外部中断退出才安全
} eSleepModeStatus;

//IDLE任务优先级(最小)
#define tskIDLE_PRIORITY			( ( UBaseType_t ) 0U )

//任务上下文切换
#define taskYIELD()					portYIELD()

//临界区保护和退出
#define taskENTER_CRITICAL()		portENTER_CRITICAL()
#define taskENTER_CRITICAL_FROM_ISR() portSET_INTERRUPT_MASK_FROM_ISR()

#define taskEXIT_CRITICAL()			portEXIT_CRITICAL()
#define taskEXIT_CRITICAL_FROM_ISR( x ) portCLEAR_INTERRUPT_MASK_FROM_ISR( x )

//中断禁止和使能
#define taskDISABLE_INTERRUPTS()	portDISABLE_INTERRUPTS()
#define taskENABLE_INTERRUPTS()		portENABLE_INTERRUPTS()

//调度的状态,由xTaskGetSchedulerState()返回
#define taskSCHEDULER_SUSPENDED		( ( BaseType_t ) 0 )
#define taskSCHEDULER_NOT_STARTED	( ( BaseType_t ) 1 )
#define taskSCHEDULER_RUNNING		( ( BaseType_t ) 2 )


//任务的创建,动态创建
#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
	BaseType_t xTaskCreate(	TaskFunction_t pxTaskCode,
							const char * const pcName,	/*lint !e971 Unqualified char types are allowed for strings and single characters only. */
							const configSTACK_DEPTH_TYPE usStackDepth,
							void * const pvParameters,
							UBaseType_t uxPriority,
							TaskHandle_t * const pxCreatedTask ) PRIVILEGED_FUNCTION;
#endif

//任务的创建,静态创建
#if( configSUPPORT_STATIC_ALLOCATION == 1 )
	TaskHandle_t xTaskCreateStatic(	TaskFunction_t pxTaskCode,
									const char * const pcName, /*lint !e971 Unqualified char types are allowed for strings and single characters only. */
									const uint32_t ulStackDepth,
									void * const pvParameters,
									UBaseType_t uxPriority,
									StackType_t * const puxStackBuffer,
									StaticTask_t * const pxTaskBuffer ) PRIVILEGED_FUNCTION;
#endif 

//任务的创建,动态受限创建,需要MPU支持
#if( portUSING_MPU_WRAPPERS == 1 )
	BaseType_t xTaskCreateRestricted( const TaskParameters_t * const pxTaskDefinition, TaskHandle_t *pxCreatedTask ) PRIVILEGED_FUNCTION;
#endif

//任务的创建,静态受限创建,需要MPU支持
#if( ( portUSING_MPU_WRAPPERS == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 1 ) )
	BaseType_t xTaskCreateRestrictedStatic( const TaskParameters_t * const pxTaskDefinition, TaskHandle_t *pxCreatedTask ) PRIVILEGED_FUNCTION;
#endif

//为受限创建打造内存空间分配
void vTaskAllocateMPURegions( TaskHandle_t xTask, const MemoryRegion_t * const pxRegions ) PRIVILEGED_FUNCTION;

//任务的删除
void vTaskDelete( TaskHandle_t xTaskToDelete ) PRIVILEGED_FUNCTION;

//任务的延迟
void vTaskDelay( const TickType_t xTicksToDelay ) PRIVILEGED_FUNCTION;

//指定延时时间的任务延时
void vTaskDelayUntil( TickType_t * const pxPreviousWakeTime, const TickType_t xTimeIncrement ) PRIVILEGED_FUNCTION;

//中止延时
BaseType_t xTaskAbortDelay( TaskHandle_t xTask ) PRIVILEGED_FUNCTION;

//获取优先级
UBaseType_t uxTaskPriorityGet( const TaskHandle_t xTask ) PRIVILEGED_FUNCTION;
UBaseType_t uxTaskPriorityGetFromISR( const TaskHandle_t xTask ) PRIVILEGED_FUNCTION;

//获取状态
eTaskState eTaskGetState( TaskHandle_t xTask ) PRIVILEGED_FUNCTION;

//获取任务信息
void vTaskGetInfo( TaskHandle_t xTask, TaskStatus_t *pxTaskStatus, BaseType_t xGetFreeStackSpace, eTaskState eState ) PRIVILEGED_FUNCTION;

//任务优先级设置
void vTaskPrioritySet( TaskHandle_t xTask, UBaseType_t uxNewPriority ) PRIVILEGED_FUNCTION;

//任务挂起
void vTaskSuspend( TaskHandle_t xTaskToSuspend ) PRIVILEGED_FUNCTION;

//任务恢复
void vTaskResume( TaskHandle_t xTaskToResume ) PRIVILEGED_FUNCTION;

BaseType_t xTaskResumeFromISR( TaskHandle_t xTaskToResume ) PRIVILEGED_FUNCTION;

//启动调度器与关闭调度器
void vTaskStartScheduler( void ) PRIVILEGED_FUNCTION;
void vTaskEndScheduler( void ) PRIVILEGED_FUNCTION;

//任务挂起与恢复
void vTaskSuspendAll( void ) PRIVILEGED_FUNCTION;

BaseType_t xTaskResumeAll( void ) PRIVILEGED_FUNCTION;

//任务时钟计数值获取
TickType_t xTaskGetTickCount( void ) PRIVILEGED_FUNCTION;

TickType_t xTaskGetTickCountFromISR( void ) PRIVILEGED_FUNCTION;

//获取任务数
UBaseType_t uxTaskGetNumberOfTasks( void ) PRIVILEGED_FUNCTION;

//获取任务名
char *pcTaskGetName( TaskHandle_t xTaskToQuery ) PRIVILEGED_FUNCTION;

//任务句柄获取
TaskHandle_t xTaskGetHandle( const char *pcNameToQuery ) PRIVILEGED_FUNCTION;

//堆栈剩余空间
UBaseType_t uxTaskGetStackHighWaterMark( TaskHandle_t xTask ) PRIVILEGED_FUNCTION;


#ifdef configUSE_APPLICATION_TASK_TAG
	#if configUSE_APPLICATION_TASK_TAG == 1
	
		void vTaskSetApplicationTaskTag( TaskHandle_t xTask, TaskHookFunction_t pxHookFunction ) PRIVILEGED_FUNCTION;

		TaskHookFunction_t xTaskGetApplicationTaskTag( TaskHandle_t xTask ) PRIVILEGED_FUNCTION;
	#endif
#endif

#if( configNUM_THREAD_LOCAL_STORAGE_POINTERS > 0 )
	void vTaskSetThreadLocalStoragePointer( TaskHandle_t xTaskToSet, BaseType_t xIndex, void *pvValue ) PRIVILEGED_FUNCTION;

	void *pvTaskGetThreadLocalStoragePointer( TaskHandle_t xTaskToQuery, BaseType_t xIndex ) PRIVILEGED_FUNCTION;

#endif

//用户任务回调的执行
BaseType_t xTaskCallApplicationTaskHook( TaskHandle_t xTask, void *pvParameter ) PRIVILEGED_FUNCTION;

//IDLE任务的句柄
TaskHandle_t xTaskGetIdleTaskHandle( void ) PRIVILEGED_FUNCTION;

//系统状态的获取
UBaseType_t uxTaskGetSystemState( TaskStatus_t * const pxTaskStatusArray, const UBaseType_t uxArraySize, uint32_t * const pulTotalRunTime ) PRIVILEGED_FUNCTION;

//就绪任务集
void vTaskList( char * pcWriteBuffer ) PRIVILEGED_FUNCTION; 


void vTaskGetRunTimeStats( char *pcWriteBuffer ) PRIVILEGED_FUNCTION; /*lint !e971 Unqualified char types are allowed for strings and single characters only. */


BaseType_t xTaskGenericNotify( TaskHandle_t xTaskToNotify, uint32_t ulValue, eNotifyAction eAction, uint32_t *pulPreviousNotificationValue ) PRIVILEGED_FUNCTION;
#define xTaskNotify( xTaskToNotify, ulValue, eAction ) xTaskGenericNotify( ( xTaskToNotify ), ( ulValue ), ( eAction ), NULL )
#define xTaskNotifyAndQuery( xTaskToNotify, ulValue, eAction, pulPreviousNotifyValue ) xTaskGenericNotify( ( xTaskToNotify ), ( ulValue ), ( eAction ), ( pulPreviousNotifyValue ) )


BaseType_t xTaskGenericNotifyFromISR( TaskHandle_t xTaskToNotify, uint32_t ulValue, eNotifyAction eAction, uint32_t *pulPreviousNotificationValue, BaseType_t *pxHigherPriorityTaskWoken ) PRIVILEGED_FUNCTION;
#define xTaskNotifyFromISR( xTaskToNotify, ulValue, eAction, pxHigherPriorityTaskWoken ) xTaskGenericNotifyFromISR( ( xTaskToNotify ), ( ulValue ), ( eAction ), NULL, ( pxHigherPriorityTaskWoken ) )
#define xTaskNotifyAndQueryFromISR( xTaskToNotify, ulValue, eAction, pulPreviousNotificationValue, pxHigherPriorityTaskWoken ) xTaskGenericNotifyFromISR( ( xTaskToNotify ), ( ulValue ), ( eAction ), ( pulPreviousNotificationValue ), ( pxHigherPriorityTaskWoken ) )


BaseType_t xTaskNotifyWait( uint32_t ulBitsToClearOnEntry, uint32_t ulBitsToClearOnExit, uint32_t *pulNotificationValue, TickType_t xTicksToWait ) PRIVILEGED_FUNCTION;


#define xTaskNotifyGive( xTaskToNotify ) xTaskGenericNotify( ( xTaskToNotify ), ( 0 ), eIncrement, NULL )

void vTaskNotifyGiveFromISR( TaskHandle_t xTaskToNotify, BaseType_t *pxHigherPriorityTaskWoken ) PRIVILEGED_FUNCTION;


uint32_t ulTaskNotifyTake( BaseType_t xClearCountOnExit, TickType_t xTicksToWait ) PRIVILEGED_FUNCTION;

BaseType_t xTaskNotifyStateClear( TaskHandle_t xTask );


 
BaseType_t xTaskIncrementTick( void ) PRIVILEGED_FUNCTION;


void vTaskPlaceOnEventList( List_t * const pxEventList, const TickType_t xTicksToWait ) PRIVILEGED_FUNCTION;
void vTaskPlaceOnUnorderedEventList( List_t * pxEventList, const TickType_t xItemValue, const TickType_t xTicksToWait ) PRIVILEGED_FUNCTION;


void vTaskPlaceOnEventListRestricted( List_t * const pxEventList, TickType_t xTicksToWait, const BaseType_t xWaitIndefinitely ) PRIVILEGED_FUNCTION;


BaseType_t xTaskRemoveFromEventList( const List_t * const pxEventList ) PRIVILEGED_FUNCTION;
void vTaskRemoveFromUnorderedEventList( ListItem_t * pxEventListItem, const TickType_t xItemValue ) PRIVILEGED_FUNCTION;


void vTaskSwitchContext( void ) PRIVILEGED_FUNCTION;


TickType_t uxTaskResetEventItemValue( void ) PRIVILEGED_FUNCTION;

TaskHandle_t xTaskGetCurrentTaskHandle( void ) PRIVILEGED_FUNCTION;

void vTaskSetTimeOutState( TimeOut_t * const pxTimeOut ) PRIVILEGED_FUNCTION;


BaseType_t xTaskCheckForTimeOut( TimeOut_t * const pxTimeOut, TickType_t * const pxTicksToWait ) PRIVILEGED_FUNCTION;

void vTaskMissedYield( void ) PRIVILEGED_FUNCTION;

BaseType_t xTaskGetSchedulerState( void ) PRIVILEGED_FUNCTION;

BaseType_t xTaskPriorityInherit( TaskHandle_t const pxMutexHolder ) PRIVILEGED_FUNCTION;

BaseType_t xTaskPriorityDisinherit( TaskHandle_t const pxMutexHolder ) PRIVILEGED_FUNCTION;

void vTaskPriorityDisinheritAfterTimeout( TaskHandle_t const pxMutexHolder, UBaseType_t uxHighestPriorityWaitingTask ) PRIVILEGED_FUNCTION;

UBaseType_t uxTaskGetTaskNumber( TaskHandle_t xTask ) PRIVILEGED_FUNCTION;

void vTaskSetTaskNumber( TaskHandle_t xTask, const UBaseType_t uxHandle ) PRIVILEGED_FUNCTION;

void vTaskStepTick( const TickType_t xTicksToJump ) PRIVILEGED_FUNCTION;

eSleepModeStatus eTaskConfirmSleepModeStatus( void ) PRIVILEGED_FUNCTION;

TaskHandle_t pvTaskIncrementMutexHeldCount( void ) PRIVILEGED_FUNCTION;

void vTaskInternalSetTimeOutState( TimeOut_t * const pxTimeOut ) PRIVILEGED_FUNCTION;


#ifdef __cplusplus
}
#endif
#endif



