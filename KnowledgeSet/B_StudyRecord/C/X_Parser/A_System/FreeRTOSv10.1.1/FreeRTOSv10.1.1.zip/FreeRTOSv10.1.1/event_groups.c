/*
 * 事件组
 */

#include <stdlib.h>

//接口重包含,提前定义一下用于屏蔽mpu_wappers.h造成的影响
#define MPU_WRAPPERS_INCLUDED_FROM_API_FILE

#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "event_groups.h"

//取消重包含,因为已经没必要了
#undef MPU_WRAPPERS_INCLUDED_FROM_API_FILE

//事件组所需要使用到的几个几个位标识
//利用位标识去确认数据或状态是一件既节省内存又不增加时间的俩宜的方法
#if configUSE_16_BIT_TICKS == 1
	#define eventCLEAR_EVENTS_ON_EXIT_BIT	0x0100U
	#define eventUNBLOCKED_DUE_TO_BIT_SET	0x0200U
	#define eventWAIT_FOR_ALL_BITS			0x0400U
	#define eventEVENT_BITS_CONTROL_BYTES	0xff00U
#else
	#define eventCLEAR_EVENTS_ON_EXIT_BIT	0x01000000UL
	#define eventUNBLOCKED_DUE_TO_BIT_SET	0x02000000UL
	#define eventWAIT_FOR_ALL_BITS			0x04000000UL
	#define eventEVENT_BITS_CONTROL_BYTES	0xff000000UL
#endif

typedef struct EventGroupDef_t
{
	EventBits_t uxEventBits;			//事件位
	List_t xTasksWaitingForBits;		//等待事件位的任务链表

	#if( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t uxEventGroupNumber; //事件组数量
	#endif

	#if( ( configSUPPORT_STATIC_ALLOCATION == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
		uint8_t ucStaticallyAllocated;  //事件组本身是被静态分配还是动态分配的
	#endif
} EventGroup_t;


//测试事件组设置的位,是否满足等待条件
static BaseType_t prvTestWaitCondition( const EventBits_t uxCurrentEventBits, const EventBits_t uxBitsToWaitFor, const BaseType_t xWaitForAllBits ) PRIVILEGED_FUNCTION;


//静态创建事件组
#if( configSUPPORT_STATIC_ALLOCATION == 1 )
	EventGroupHandle_t xEventGroupCreateStatic( StaticEventGroup_t *pxEventGroupBuffer )
	{
	EventGroup_t *pxEventBits;
		configASSERT( pxEventGroupBuffer );
		#if( configASSERT_DEFINED == 1 )
		{	//调试
			volatile size_t xSize = sizeof( StaticEventGroup_t );
			configASSERT( xSize == sizeof( EventGroup_t ) );
		}
		#endif
		//向事件组缓冲区索要静态空间
		pxEventBits = ( EventGroup_t * ) pxEventGroupBuffer; 
		if( pxEventBits != NULL )
		{	//初始化配置事件组
			pxEventBits->uxEventBits = 0;
			vListInitialise( &( pxEventBits->xTasksWaitingForBits ) );//初始化等待任务集
			#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
			{	//打上静态创建标记
				pxEventBits->ucStaticallyAllocated = pdTRUE;
			}
			#endif
			traceEVENT_GROUP_CREATE( pxEventBits );
		}
		else
		{
			traceEVENT_GROUP_CREATE_FAILED();
		}
		return pxEventBits;
	}

#endif

//动态创建事件组
#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
	EventGroupHandle_t xEventGroupCreate( void )
	{
	EventGroup_t *pxEventBits;
		//动态创建事件组空间
		pxEventBits = ( EventGroup_t * ) pvPortMalloc( sizeof( EventGroup_t ) );
		if( pxEventBits != NULL )
		{	//初始化
			pxEventBits->uxEventBits = 0;//初始化等待任务集
			vListInitialise( &( pxEventBits->xTasksWaitingForBits ) );
			#if( configSUPPORT_STATIC_ALLOCATION == 1 )
			{	//打上非静态创建标记
				pxEventBits->ucStaticallyAllocated = pdFALSE;
			}
			#endif
			traceEVENT_GROUP_CREATE( pxEventBits );
		}
		else
		{
			traceEVENT_GROUP_CREATE_FAILED();
		}
		return pxEventBits;
	}

#endif

//同步事件组
EventBits_t xEventGroupSync( EventGroupHandle_t xEventGroup, const EventBits_t uxBitsToSet, const EventBits_t uxBitsToWaitFor, TickType_t xTicksToWait )
{
EventBits_t uxOriginalBitValue, uxReturn;
EventGroup_t *pxEventBits = xEventGroup;
BaseType_t xAlreadyYielded;
BaseType_t xTimeoutOccurred = pdFALSE;
	configASSERT( ( uxBitsToWaitFor & eventEVENT_BITS_CONTROL_BYTES ) == 0 );
	configASSERT( uxBitsToWaitFor != 0 );
	#if ( ( INCLUDE_xTaskGetSchedulerState == 1 ) || ( configUSE_TIMERS == 1 ) )
	{
		configASSERT( !( ( xTaskGetSchedulerState() == taskSCHEDULER_SUSPENDED ) && ( xTicksToWait != 0 ) ) );
	}
	#endif

	vTaskSuspendAll();//挂起所有任务
	{	//获取原始事件位的位值集
		uxOriginalBitValue = pxEventBits->uxEventBits;
		( void ) xEventGroupSetBits( xEventGroup, uxBitsToSet );//为事件组设置新的事件位
		if( ( ( uxOriginalBitValue | uxBitsToSet ) & uxBitsToWaitFor ) == uxBitsToWaitFor )
		{	//所有等待事件都已经出现了
			uxReturn = ( uxOriginalBitValue | uxBitsToSet );
			//清空等待事件
			pxEventBits->uxEventBits &= ~uxBitsToWaitFor;
			xTicksToWait = 0;
		}
		else
		{	//存在等待时间未出现,且指定延迟
			if( xTicksToWait != ( TickType_t ) 0 )
			{
				traceEVENT_GROUP_SYNC_BLOCK( xEventGroup, uxBitsToSet, uxBitsToWaitFor );
				//当前任务加入到事件组中,为其配置等待事件值,指定延时
				vTaskPlaceOnUnorderedEventList( &( pxEventBits->xTasksWaitingForBits ), ( uxBitsToWaitFor | eventCLEAR_EVENTS_ON_EXIT_BIT | eventWAIT_FOR_ALL_BITS ), xTicksToWait );
				uxReturn = 0;
			}
			else
			{	//无指定块时间,仅仅返回当前事件位值
				uxReturn = pxEventBits->uxEventBits;
				xTimeoutOccurred = pdTRUE;
			}
		}
	}
	xAlreadyYielded = xTaskResumeAll();//恢复挂起任务

	if( xTicksToWait != ( TickType_t ) 0 )
	{	//等待时间存在,那么自己已经加入到了阻塞事件组中
		if( xAlreadyYielded == pdFALSE )
		{	//为调度,现在手动调度
			portYIELD_WITHIN_API();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
		//重置事件组的值
		uxReturn = uxTaskResetEventItemValue();

		if( ( uxReturn & eventUNBLOCKED_DUE_TO_BIT_SET ) == ( EventBits_t ) 0 )
		{	//不是未阻塞态
			taskENTER_CRITICAL();
			{
				uxReturn = pxEventBits->uxEventBits;
				if( ( uxReturn & uxBitsToWaitFor ) == uxBitsToWaitFor )
				{	//上文出现调度,说明是阻塞超时了,这里再次确认事件满足条件
					pxEventBits->uxEventBits &= ~uxBitsToWaitFor;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			taskEXIT_CRITICAL();
			xTimeoutOccurred = pdTRUE;	//超时了
		}
		else
		{	//任务未阻塞
		}
		//所有控制位清空
		uxReturn &= ~eventEVENT_BITS_CONTROL_BYTES;
	}
	traceEVENT_GROUP_SYNC_END( xEventGroup, uxBitsToSet, uxBitsToWaitFor, xTimeoutOccurred );
	( void ) xTimeoutOccurred;//编译器警告
	return uxReturn;
}

//事件组等待事件
EventBits_t xEventGroupWaitBits( EventGroupHandle_t xEventGroup, const EventBits_t uxBitsToWaitFor, const BaseType_t xClearOnExit, const BaseType_t xWaitForAllBits, TickType_t xTicksToWait )
{
EventGroup_t *pxEventBits = xEventGroup;
EventBits_t uxReturn, uxControlBits = 0;
BaseType_t xWaitConditionMet, xAlreadyYielded;
BaseType_t xTimeoutOccurred = pdFALSE;
	configASSERT( xEventGroup );
	configASSERT( ( uxBitsToWaitFor & eventEVENT_BITS_CONTROL_BYTES ) == 0 );
	configASSERT( uxBitsToWaitFor != 0 );
	#if ( ( INCLUDE_xTaskGetSchedulerState == 1 ) || ( configUSE_TIMERS == 1 ) )
	{
		configASSERT( !( ( xTaskGetSchedulerState() == taskSCHEDULER_SUSPENDED ) && ( xTicksToWait != 0 ) ) );
	}
	#endif

	vTaskSuspendAll();//挂起所有任务
	{	//获取当前事件组出现的实际
		const EventBits_t uxCurrentEventBits = pxEventBits->uxEventBits;
		//检查等待条件是否满足		
		xWaitConditionMet = prvTestWaitCondition( uxCurrentEventBits, uxBitsToWaitFor, xWaitForAllBits );
		if( xWaitConditionMet != pdFALSE )
		{	//等待条件满足,无需阻塞
			uxReturn = uxCurrentEventBits;
			xTicksToWait = ( TickType_t ) 0;//设置0延时
			if( xClearOnExit != pdFALSE )
			{	//如果在退出时需要清除位,那么清除它
				pxEventBits->uxEventBits &= ~uxBitsToWaitFor;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else if( xTicksToWait == ( TickType_t ) 0 )
		{	//如果等待条件没有满足但没有配置等待时间,那么不阻塞
			uxReturn = uxCurrentEventBits;
			xTimeoutOccurred = pdTRUE;
		}
		else
		{	//现在需要阻塞任务,因为等待条件未满足
			if( xClearOnExit != pdFALSE )
			{	//控制位打上标记,表明退出时需要清除等待位
				uxControlBits |= eventCLEAR_EVENTS_ON_EXIT_BIT;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
			if( xWaitForAllBits != pdFALSE )
			{	//如果是等待所有位的出现,那么打上标记
				//仅仅全部事件都被满足时才中止阻塞,返回
				uxControlBits |= eventWAIT_FOR_ALL_BITS;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
			//将当前任务加入到等待事件组中,并且配置指定的延时时间
			vTaskPlaceOnUnorderedEventList( &( pxEventBits->xTasksWaitingForBits ), ( uxBitsToWaitFor | uxControlBits ), xTicksToWait );
			uxReturn = 0;//防止编译器警告
			traceEVENT_GROUP_WAIT_BITS_BLOCK( xEventGroup, uxBitsToWaitFor );
		}
	}
	xAlreadyYielded = xTaskResumeAll();//恢复所有任务

	if( xTicksToWait != ( TickType_t ) 0 )
	{	//如果等待延时不为零,现在已经阻塞,需要更换任务执行了
		if( xAlreadyYielded == pdFALSE )
		{	//如果没有更换任务,那么手动更换任务执行
			portYIELD_WITHIN_API();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		//程序到达这里,要么是阻塞时间到,要么是等待条件满足,现在要处理
		uxReturn = uxTaskResetEventItemValue();

		if( ( uxReturn & eventUNBLOCKED_DUE_TO_BIT_SET ) == ( EventBits_t ) 0 )
		{	//阻塞态时
			taskENTER_CRITICAL();
			{	//说明是任务超时,因为是从阻塞态出来的
				uxReturn = pxEventBits->uxEventBits;
				//更新一下,因为过了很久的时间了
				if( prvTestWaitCondition( uxReturn, uxBitsToWaitFor, xWaitForAllBits ) != pdFALSE )
				{
					if( xClearOnExit != pdFALSE )
					{
						pxEventBits->uxEventBits &= ~uxBitsToWaitFor;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
				xTimeoutOccurred = pdTRUE;
			}
			taskEXIT_CRITICAL();
		}
		else
		{	//非阻塞态
		}
		//清除事件组控制位
		uxReturn &= ~eventEVENT_BITS_CONTROL_BYTES;
	}
	traceEVENT_GROUP_WAIT_BITS_END( xEventGroup, uxBitsToWaitFor, xTimeoutOccurred );
	( void ) xTimeoutOccurred;//防止编译器警告
	return uxReturn;
}

//事件组清除事件
EventBits_t xEventGroupClearBits( EventGroupHandle_t xEventGroup, const EventBits_t uxBitsToClear )
{
EventGroup_t *pxEventBits = xEventGroup;
EventBits_t uxReturn;
	configASSERT( xEventGroup );
	configASSERT( ( uxBitsToClear & eventEVENT_BITS_CONTROL_BYTES ) == 0 );

	taskENTER_CRITICAL();
	{
		traceEVENT_GROUP_CLEAR_BITS( xEventGroup, uxBitsToClear );
		uxReturn = pxEventBits->uxEventBits;//保留之前的事件
		pxEventBits->uxEventBits &= ~uxBitsToClear;//清除指定的事件
	}
	taskEXIT_CRITICAL();
	return uxReturn;//返回之前的事件
}


//中断环境下事件组清除事件
#if ( ( configUSE_TRACE_FACILITY == 1 ) && ( INCLUDE_xTimerPendFunctionCall == 1 ) && ( configUSE_TIMERS == 1 ) )
	BaseType_t xEventGroupClearBitsFromISR( EventGroupHandle_t xEventGroup, const EventBits_t uxBitsToClear )
	{
		BaseType_t xReturn;
		traceEVENT_GROUP_CLEAR_BITS_FROM_ISR( xEventGroup, uxBitsToClear );
		//中断环境下将 这个事件组信息丢到定时器队列中 让定时器去处理？
		xReturn = xTimerPendFunctionCallFromISR( vEventGroupClearBitsCallback, ( void * ) xEventGroup, ( uint32_t ) uxBitsToClear, NULL );
		return xReturn;
	}

#endif

//中断环境下事件组获取事件
EventBits_t xEventGroupGetBitsFromISR( EventGroupHandle_t xEventGroup )
{
UBaseType_t uxSavedInterruptStatus;
EventGroup_t const * const pxEventBits = xEventGroup;
EventBits_t uxReturn;
	//获取中断状态
	uxSavedInterruptStatus = portSET_INTERRUPT_MASK_FROM_ISR();
	{	//获取事件
		uxReturn = pxEventBits->uxEventBits;
	}
	//清除中断状态
	portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );
	return uxReturn;
}

//事件组设置事件
EventBits_t xEventGroupSetBits( EventGroupHandle_t xEventGroup, const EventBits_t uxBitsToSet )
{
ListItem_t *pxListItem, *pxNext;
ListItem_t const *pxListEnd;
List_t const * pxList;
EventBits_t uxBitsToClear = 0, uxBitsWaitedFor, uxControlBits;
EventGroup_t *pxEventBits = xEventGroup;
BaseType_t xMatchFound = pdFALSE;
	configASSERT( xEventGroup );
	configASSERT( ( uxBitsToSet & eventEVENT_BITS_CONTROL_BYTES ) == 0 );
	//获取事件组任务集的首和尾
	pxList = &( pxEventBits->xTasksWaitingForBits );
	pxListEnd = listGET_END_MARKER( pxList ); 
	vTaskSuspendAll();//挂起全部任务
	{
		traceEVENT_GROUP_SET_BITS( xEventGroup, uxBitsToSet );
		pxListItem = listGET_HEAD_ENTRY( pxList );//获取第一个任务
		//事件组配置新的要设置的事件
		pxEventBits->uxEventBits |= uxBitsToSet;
		while( pxListItem != pxListEnd )
		{	//循环为每一个事件处理
			pxNext = listGET_NEXT( pxListItem );
			//获取该项等待的事件
			uxBitsWaitedFor = listGET_LIST_ITEM_VALUE( pxListItem );
			xMatchFound = pdFALSE;
			//获取等待事件对应的控制
			uxControlBits = uxBitsWaitedFor & eventEVENT_BITS_CONTROL_BYTES;
			//等待事件清除控制标记
			uxBitsWaitedFor &= ~eventEVENT_BITS_CONTROL_BYTES;
			if( ( uxControlBits & eventWAIT_FOR_ALL_BITS ) == ( EventBits_t ) 0 )
			{	//如果控制标记没有被设置为等待全部事件的话
				if( ( uxBitsWaitedFor & pxEventBits->uxEventBits ) != ( EventBits_t ) 0 )
				{	//期望事件组与单个任务出现的事件存在交集,匹配到事件
					xMatchFound = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else if( ( uxBitsWaitedFor & pxEventBits->uxEventBits ) == uxBitsWaitedFor )
			{	//等待全部事件,等待到了全部事件
				xMatchFound = pdTRUE;
			}
			else
			{	//未等待到全部事件
			}

			if( xMatchFound != pdFALSE )
			{	//匹配到了事件交叉
				if( ( uxControlBits & eventCLEAR_EVENTS_ON_EXIT_BIT ) != ( EventBits_t ) 0 )
				{	//添加清除位
					uxBitsToClear |= uxBitsWaitedFor;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
				//从事件组中移除任务
				vTaskRemoveFromUnorderedEventList( pxListItem, pxEventBits->uxEventBits | eventUNBLOCKED_DUE_TO_BIT_SET );
			}
			pxListItem = pxNext;//检查下一项
		}

		//清除匹配到的全部事件
		pxEventBits->uxEventBits &= ~uxBitsToClear;
	}
	( void ) xTaskResumeAll();//任务恢复
	return pxEventBits->uxEventBits;
}

//事件组删除
void vEventGroupDelete( EventGroupHandle_t xEventGroup )
{
EventGroup_t *pxEventBits = xEventGroup;
const List_t *pxTasksWaitingForBits = &( pxEventBits->xTasksWaitingForBits );
	vTaskSuspendAll();//挂起任务
	{
		traceEVENT_GROUP_DELETE( xEventGroup );
		while( listCURRENT_LIST_LENGTH( pxTasksWaitingForBits ) > ( UBaseType_t ) 0 )//事件组任务集非空
		{	//一个个移除,一个个的移除,这些任务会被加入到就绪队列中,而不是在事件组里面进行阻塞等待
			configASSERT( pxTasksWaitingForBits->xListEnd.pxNext != ( const ListItem_t * ) &( pxTasksWaitingForBits->xListEnd ) );
			vTaskRemoveFromUnorderedEventList( pxTasksWaitingForBits->xListEnd.pxNext, eventUNBLOCKED_DUE_TO_BIT_SET );
		}
		
		//事件组移除
		#if( ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 0 ) )
		{
			vPortFree( pxEventBits );
		}
		#elif( ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 1 ) )
		{
			if( pxEventBits->ucStaticallyAllocated == ( uint8_t ) pdFALSE )
			{
				vPortFree( pxEventBits );
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		#endif
	}
	( void ) xTaskResumeAll();
}

//为定时器提供回调
void vEventGroupSetBitsCallback( void *pvEventGroup, const uint32_t ulBitsToSet )
{
	( void ) xEventGroupSetBits( pvEventGroup, ( EventBits_t ) ulBitsToSet );
}

//回调
void vEventGroupClearBitsCallback( void *pvEventGroup, const uint32_t ulBitsToClear )
{
	( void ) xEventGroupClearBits( pvEventGroup, ( EventBits_t ) ulBitsToClear ); 
}

//等待条件的测试检查
static BaseType_t prvTestWaitCondition( const EventBits_t uxCurrentEventBits, const EventBits_t uxBitsToWaitFor, const BaseType_t xWaitForAllBits )
{
BaseType_t xWaitConditionMet = pdFALSE;
	if( xWaitForAllBits == pdFALSE )
	{	//如果不是等待全部事件的话,有一个事件出现就满足要求了
		if( ( uxCurrentEventBits & uxBitsToWaitFor ) != ( EventBits_t ) 0 )
		{
			xWaitConditionMet = pdTRUE;
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else
	{	//等待全部事件的话,需要全部事件出现才行
		if( ( uxCurrentEventBits & uxBitsToWaitFor ) == uxBitsToWaitFor )
		{
			xWaitConditionMet = pdTRUE;
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	return xWaitConditionMet;
}

//中断环境下设置事件
#if ( ( configUSE_TRACE_FACILITY == 1 ) && ( INCLUDE_xTimerPendFunctionCall == 1 ) && ( configUSE_TIMERS == 1 ) )
	BaseType_t xEventGroupSetBitsFromISR( EventGroupHandle_t xEventGroup, const EventBits_t uxBitsToSet, BaseType_t *pxHigherPriorityTaskWoken )
	{
	BaseType_t xReturn;
		traceEVENT_GROUP_SET_BITS_FROM_ISR( xEventGroup, uxBitsToSet );
		//丢到定时器去处理事件的设置
		xReturn = xTimerPendFunctionCallFromISR( vEventGroupSetBitsCallback, ( void * ) xEventGroup, ( uint32_t ) uxBitsToSet, pxHigherPriorityTaskWoken );
		return xReturn;
	}

#endif

//获取指定事件组的成员
#if (configUSE_TRACE_FACILITY == 1)
	UBaseType_t uxEventGroupGetNumber( void* xEventGroup )
	{
	UBaseType_t xReturn;
	EventGroup_t const *pxEventBits = ( EventGroup_t * ) xEventGroup;
		if( xEventGroup == NULL )
		{
			xReturn = 0;
		}
		else
		{
			xReturn = pxEventBits->uxEventGroupNumber;
		}

		return xReturn;
	}

#endif

//设置指定事件组的成员
#if ( configUSE_TRACE_FACILITY == 1 )
	void vEventGroupSetNumber( void * xEventGroup, UBaseType_t uxEventGroupNumber )
	{
		( ( EventGroup_t * ) xEventGroup )->uxEventGroupNumber = uxEventGroupNumber; 
	}

#endif


