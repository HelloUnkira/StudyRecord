/*
 * 错误码配置文件
 */

#ifndef PROJDEFS_H
#define PROJDEFS_H

//为其他文件提供声明支持
typedef void (*TaskFunction_t)( void * );

//用于ms转具体滴答数
#ifndef pdMS_TO_TICKS
	#define pdMS_TO_TICKS( xTimeInMs ) ( ( TickType_t ) ( ( ( TickType_t ) ( xTimeInMs ) * ( TickType_t ) configTICK_RATE_HZ ) / ( TickType_t ) 1000 ) )
#endif

//逻辑动作定义
#define pdFALSE			( ( BaseType_t ) 0 )
#define pdTRUE			( ( BaseType_t ) 1 )
#define pdPASS			( pdTRUE )
#define pdFAIL			( pdFALSE )
#define errQUEUE_EMPTY	( ( BaseType_t ) 0 )
#define errQUEUE_FULL	( ( BaseType_t ) 0 )

//错误码定义
#define errCOULD_NOT_ALLOCATE_REQUIRED_MEMORY	( -1 )
#define errQUEUE_BLOCKED						( -4 )
#define errQUEUE_YIELD							( -5 )

//准确性检查宏
#ifndef configUSE_LIST_DATA_INTEGRITY_CHECK_BYTES
	#define configUSE_LIST_DATA_INTEGRITY_CHECK_BYTES 0
#endif

//16位时钟滴答对应的检查码
#if( configUSE_16_BIT_TICKS == 1 )
	#define pdINTEGRITY_CHECK_VALUE 0x5a5a
#else
	#define pdINTEGRITY_CHECK_VALUE 0x5a5a5a5aUL
#endif

//错误码
#define pdFREERTOS_ERRNO_NONE			0	//没有错误
#define	pdFREERTOS_ERRNO_ENOENT			2	//文件或路径不存在
#define	pdFREERTOS_ERRNO_EINTR			4	//中断系统调用
#define	pdFREERTOS_ERRNO_EIO			5	//I/O错误
#define	pdFREERTOS_ERRNO_ENXIO			6	//设备或地址错误
#define	pdFREERTOS_ERRNO_EBADF			9	//文件数量错误
#define	pdFREERTOS_ERRNO_EAGAIN			11	//处理器数量少错误
#define	pdFREERTOS_ERRNO_EWOULDBLOCK	11	//动作阻塞
#define	pdFREERTOS_ERRNO_ENOMEM			12	//内存不足
#define	pdFREERTOS_ERRNO_EACCES			13	//权限缺少
#define	pdFREERTOS_ERRNO_EFAULT			14	//地址错误
#define	pdFREERTOS_ERRNO_EBUSY			16	//挂载设备忙
#define	pdFREERTOS_ERRNO_EEXIST			17	//文件存在
#define	pdFREERTOS_ERRNO_EXDEV			18	//冲突设备链
#define	pdFREERTOS_ERRNO_ENODEV			19	//设备不存在
#define	pdFREERTOS_ERRNO_ENOTDIR		20	//路径不存在
#define	pdFREERTOS_ERRNO_EISDIR			21	//这是一个路径
#define	pdFREERTOS_ERRNO_EINVAL			22	//非法参数
#define	pdFREERTOS_ERRNO_ENOSPC			28	//设备没有空间预留
#define	pdFREERTOS_ERRNO_ESPIPE			29	//非法偏移seek
#define	pdFREERTOS_ERRNO_EROFS			30	//只读文件系统
#define	pdFREERTOS_ERRNO_EUNATCH		42	//协议驱动不存在
#define	pdFREERTOS_ERRNO_EBADE			50	//非法修改
#define	pdFREERTOS_ERRNO_EFTYPE			79	//文件类型或格式不支持
#define	pdFREERTOS_ERRNO_ENMFILE		89	//没有更多文件
#define	pdFREERTOS_ERRNO_ENOTEMPTY		90	//路径非空
#define	pdFREERTOS_ERRNO_ENAMETOOLONG 	91	//文件或路径名过长
#define	pdFREERTOS_ERRNO_EOPNOTSUPP		95	//传输结尾不支持
#define	pdFREERTOS_ERRNO_ENOBUFS		105	//无可用缓冲区
#define	pdFREERTOS_ERRNO_ENOPROTOOPT	109	//无可用协议
#define	pdFREERTOS_ERRNO_EADDRINUSE		112	//地址被使用
#define	pdFREERTOS_ERRNO_ETIMEDOUT		116	//连接超时
#define	pdFREERTOS_ERRNO_EINPROGRESS	119	//连续正在进行
#define	pdFREERTOS_ERRNO_EALREADY		120	//Socket已经准备
#define	pdFREERTOS_ERRNO_EADDRNOTAVAIL 	125	//地址不可用
#define	pdFREERTOS_ERRNO_EISCONN		127	//Socket已经连接
#define	pdFREERTOS_ERRNO_ENOTCONN		128	//Socket未连接
#define	pdFREERTOS_ERRNO_ENOMEDIUM		135	//没有媒体被插入
#define	pdFREERTOS_ERRNO_EILSEQ			138	//无效的UTF-16序列
#define	pdFREERTOS_ERRNO_ECANCELED		140	//动作被取消

//平台是小端还是大端
#define pdFREERTOS_LITTLE_ENDIAN		0
#define pdFREERTOS_BIG_ENDIAN			1

//封装重定义
#define pdLITTLE_ENDIAN					pdFREERTOS_LITTLE_ENDIAN
#define pdBIG_ENDIAN					pdFREERTOS_BIG_ENDIAN

#endif

