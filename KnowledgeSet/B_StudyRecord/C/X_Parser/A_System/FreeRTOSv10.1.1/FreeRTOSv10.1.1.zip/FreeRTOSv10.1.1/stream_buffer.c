/*
 * 流缓冲
 */

#include <stdint.h>
#include <string.h>

//接口重包含,提前定义一下用于屏蔽mpu_wappers.h造成的影响
#define MPU_WRAPPERS_INCLUDED_FROM_API_FILE

#include "FreeRTOS.h"
#include "task.h"
#include "stream_buffer.h"

//需要任务通知才可以使用流缓冲
#if( configUSE_TASK_NOTIFICATIONS != 1 )	
	#error configUSE_TASK_NOTIFICATIONS must be set to 1 to build stream_buffer.c
#endif

//取消重包含,因为已经没必要了
#undef MPU_WRAPPERS_INCLUDED_FROM_API_FILE 

//流缓冲接受完成
#ifndef sbRECEIVE_COMPLETED
	#define sbRECEIVE_COMPLETED( pxStreamBuffer )										\
		vTaskSuspendAll();/*挂起全部任务*/													\
		{	/*流缓冲的数据已经被接收*/																\
			if( ( pxStreamBuffer )->xTaskWaitingToSend != NULL )						\
			{	/*任务接收通知,通知接收任务,流缓冲的接收端 完成了数据的接收任务*/									\
				( void ) xTaskNotify( ( pxStreamBuffer )->xTaskWaitingToSend,			\
									  ( uint32_t ) 0,									\
									  eNoAction );										\
				( pxStreamBuffer )->xTaskWaitingToSend = NULL;							\
			}																			\
		}																				\
		( void ) xTaskResumeAll();/*恢复全部任务*/
#endif

//中断环境下流缓冲接受完成
#ifndef sbRECEIVE_COMPLETED_FROM_ISR
	#define sbRECEIVE_COMPLETED_FROM_ISR( pxStreamBuffer,								\
										  pxHigherPriorityTaskWoken )					\
	{																					\
	UBaseType_t uxSavedInterruptStatus;													\
		/*获取中断状态*/																		\
		uxSavedInterruptStatus = ( UBaseType_t ) portSET_INTERRUPT_MASK_FROM_ISR();		\
		{	/*流缓冲的数据已经被接收*/ 															\
			if( ( pxStreamBuffer )->xTaskWaitingToSend != NULL )						\
			{	/*任务接收通知,通知接收任务,流缓冲的接收端 完成了数据的接收任务*/									\
				( void ) xTaskNotifyFromISR( ( pxStreamBuffer )->xTaskWaitingToSend,	\
											 ( uint32_t ) 0,							\
											 eNoAction,									\
											 pxHigherPriorityTaskWoken );				\
				( pxStreamBuffer )->xTaskWaitingToSend = NULL;							\
			}																			\
		}																				\
		/*中断状态清除*/																		\
		portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );					\
	}
#endif

//流缓冲发送完成
#ifndef sbSEND_COMPLETED
	#define sbSEND_COMPLETED( pxStreamBuffer )											\
		vTaskSuspendAll();																\
		{	/*流缓冲有数据 等待被接受*/															\
			if( ( pxStreamBuffer )->xTaskWaitingToReceive != NULL )						\
			{	/*任务接收通知,通知接收任务,流缓冲的发送端 完成了数据的发送任务*/									\
				( void ) xTaskNotify( ( pxStreamBuffer )->xTaskWaitingToReceive,		\
									  ( uint32_t ) 0,									\
									  eNoAction );										\
				( pxStreamBuffer )->xTaskWaitingToReceive = NULL;						\
			}																			\
		}																				\
		( void ) xTaskResumeAll();
#endif

//中断环境下流缓冲发送完成
#ifndef sbSEND_COMPLETE_FROM_ISR
	#define sbSEND_COMPLETE_FROM_ISR( pxStreamBuffer, pxHigherPriorityTaskWoken )		\
	{																					\
	UBaseType_t uxSavedInterruptStatus;													\
																						\
		uxSavedInterruptStatus = ( UBaseType_t ) portSET_INTERRUPT_MASK_FROM_ISR();		\
		{	/*流缓冲有数据 等待被接受*/															\
			if( ( pxStreamBuffer )->xTaskWaitingToReceive != NULL )						\
			{	/*任务接收通知,通知接收任务,流缓冲的发送端 完成了数据的发送任务*/									\
				( void ) xTaskNotifyFromISR( ( pxStreamBuffer )->xTaskWaitingToReceive,	\
											 ( uint32_t ) 0,							\
											 eNoAction,									\
											 pxHigherPriorityTaskWoken );				\
				( pxStreamBuffer )->xTaskWaitingToReceive = NULL;						\
			}																			\
		}																				\
		portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );					\
	}
#endif

//流缓冲存储消息的长度
#define sbBYTES_TO_STORE_MESSAGE_LENGTH ( sizeof( configMESSAGE_BUFFER_LENGTH_TYPE ) )

//流缓冲是消息缓冲
#define sbFLAGS_IS_MESSAGE_BUFFER		( ( uint8_t ) 1 )
//流缓冲是一个静态缓冲区
#define sbFLAGS_IS_STATICALLY_ALLOCATED ( ( uint8_t ) 2 )


typedef struct StreamBufferDef_t 
{
	volatile size_t xTail;				//流缓冲读的位置
	volatile size_t xHead;				//流缓冲写的位置
	size_t xLength;						//流缓冲的大小
	size_t xTriggerLevelBytes;			//任务因为等待数据造成的阻塞,解除阻塞时流缓冲数据的最小值
	volatile TaskHandle_t xTaskWaitingToReceive; //等待接收数据的任务的句柄
	volatile TaskHandle_t xTaskWaitingToSend;	//等待发送数据的任务的句柄
	uint8_t *pucBuffer;					//缓冲区
	uint8_t ucFlags;

	#if ( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t uxStreamBufferNumber;//流缓冲数量
	#endif
} StreamBuffer_t;


//流缓冲的字节数
static size_t prvBytesInBuffer( const StreamBuffer_t * const pxStreamBuffer ) PRIVILEGED_FUNCTION;

//向流缓冲写字节
static size_t prvWriteBytesToBuffer( StreamBuffer_t * const pxStreamBuffer, const uint8_t *pucData, size_t xCount ) PRIVILEGED_FUNCTION;

//从流缓冲读取消息
static size_t prvReadMessageFromBuffer( StreamBuffer_t *pxStreamBuffer,
										void *pvRxData,
										size_t xBufferLengthBytes,
										size_t xBytesAvailable,
										size_t xBytesToStoreMessageLength ) PRIVILEGED_FUNCTION;

//向流缓冲写入消息
static size_t prvWriteMessageToBuffer(  StreamBuffer_t * const pxStreamBuffer,
										const void * pvTxData,
										size_t xDataLengthBytes,
										size_t xSpace,
										size_t xRequiredSpace ) PRIVILEGED_FUNCTION;

//从流缓冲读字节
static size_t prvReadBytesFromBuffer( StreamBuffer_t *pxStreamBuffer,
									  uint8_t *pucData,
									  size_t xMaxCount,
									  size_t xBytesAvailable ) PRIVILEGED_FUNCTION;

//新的流缓冲初始化
static void prvInitialiseNewStreamBuffer( StreamBuffer_t * const pxStreamBuffer,
										  uint8_t * const pucBuffer,
										  size_t xBufferSizeBytes,
										  size_t xTriggerLevelBytes,
										  uint8_t ucFlags ) PRIVILEGED_FUNCTION;

//流缓冲的创建
#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
	StreamBufferHandle_t xStreamBufferGenericCreate( size_t xBufferSizeBytes, size_t xTriggerLevelBytes, BaseType_t xIsMessageBuffer )
	{
	uint8_t *pucAllocatedMemory;
	uint8_t ucFlags;
		if( xIsMessageBuffer == pdTRUE )
		{	//流缓冲被作为消息缓冲使用,设备标记
			ucFlags = sbFLAGS_IS_MESSAGE_BUFFER;
			configASSERT( xBufferSizeBytes > sbBYTES_TO_STORE_MESSAGE_LENGTH );
		}
		else
		{
			ucFlags = 0;
			configASSERT( xBufferSizeBytes > 0 );
		}
		configASSERT( xTriggerLevelBytes <= xBufferSizeBytes );
		if( xTriggerLevelBytes == ( size_t ) 0 )
		{//防止等待的任务解除阻塞所用
			xTriggerLevelBytes = ( size_t ) 1;
		}
		//为了按照用户的愿望返回空闲的区域,使用增加一个空闲区域保证逻辑上对正
		xBufferSizeBytes++;//动态分配流缓冲
		pucAllocatedMemory = ( uint8_t * ) pvPortMalloc( xBufferSizeBytes + sizeof( StreamBuffer_t ) );
		if( pucAllocatedMemory != NULL )
		{	//初始化一个新的流缓冲
			prvInitialiseNewStreamBuffer( ( StreamBuffer_t * ) pucAllocatedMemory, 
											pucAllocatedMemory + sizeof( StreamBuffer_t ), 
											xBufferSizeBytes,
										    xTriggerLevelBytes,
										    ucFlags );
			traceSTREAM_BUFFER_CREATE( ( ( StreamBuffer_t * ) pucAllocatedMemory ), xIsMessageBuffer );
		}
		else
		{
			traceSTREAM_BUFFER_CREATE_FAILED( xIsMessageBuffer );
		}
		return ( StreamBufferHandle_t ) pucAllocatedMemory;
	}

#endif

//流缓冲的静态创建
#if( configSUPPORT_STATIC_ALLOCATION == 1 )
	StreamBufferHandle_t xStreamBufferGenericCreateStatic( size_t xBufferSizeBytes,
														   size_t xTriggerLevelBytes,
														   BaseType_t xIsMessageBuffer,
														   uint8_t * const pucStreamBufferStorageArea,
														   StaticStreamBuffer_t * const pxStaticStreamBuffer )
	{
	StreamBuffer_t * const pxStreamBuffer = ( StreamBuffer_t * ) pxStaticStreamBuffer; 
	StreamBufferHandle_t xReturn;
	uint8_t ucFlags;
		configASSERT( pucStreamBufferStorageArea );
		configASSERT( pxStaticStreamBuffer );
		configASSERT( xTriggerLevelBytes <= xBufferSizeBytes );
		if( xTriggerLevelBytes == ( size_t ) 0 )
		{	//防止等待的任务解除阻塞所用
			xTriggerLevelBytes = ( size_t ) 1;
		}
		if( xIsMessageBuffer != pdFALSE )
		{	//是消息,还是静态注册
			ucFlags = sbFLAGS_IS_MESSAGE_BUFFER | sbFLAGS_IS_STATICALLY_ALLOCATED;
		}
		else
		{
			ucFlags = sbFLAGS_IS_STATICALLY_ALLOCATED;
		}
		configASSERT( xBufferSizeBytes > sbBYTES_TO_STORE_MESSAGE_LENGTH );
		#if( configASSERT_DEFINED == 1 )
		{	//检查
			volatile size_t xSize = sizeof( StaticStreamBuffer_t );
			configASSERT( xSize == sizeof( StreamBuffer_t ) );
		}
		#endif
		if( ( pucStreamBufferStorageArea != NULL ) && ( pxStaticStreamBuffer != NULL ) )
		{	//初始化流缓冲
			prvInitialiseNewStreamBuffer( pxStreamBuffer,
										  pucStreamBufferStorageArea,
										  xBufferSizeBytes,
										  xTriggerLevelBytes,
										  ucFlags );
			//额外配置为静态分配
			pxStreamBuffer->ucFlags |= sbFLAGS_IS_STATICALLY_ALLOCATED;

			traceSTREAM_BUFFER_CREATE( pxStreamBuffer, xIsMessageBuffer );
			xReturn = ( StreamBufferHandle_t ) pxStaticStreamBuffer;
		}
		else
		{
			xReturn = NULL;
			traceSTREAM_BUFFER_CREATE_STATIC_FAILED( xReturn, xIsMessageBuffer );
		}
		return xReturn;
	}

#endif

//流缓冲的删除
void vStreamBufferDelete( StreamBufferHandle_t xStreamBuffer )
{
StreamBuffer_t * pxStreamBuffer = xStreamBuffer;
	configASSERT( pxStreamBuffer );
	traceSTREAM_BUFFER_DELETE( xStreamBuffer );

	if( ( pxStreamBuffer->ucFlags & sbFLAGS_IS_STATICALLY_ALLOCATED ) == ( uint8_t ) pdFALSE )
	{	//确认是静态分配还是动态分配
		#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
		{
			vPortFree( ( void * ) pxStreamBuffer );
		}
		#else
		{
			configASSERT( xStreamBuffer == ( StreamBufferHandle_t ) ~0 );
		}
		#endif
	}
	else
	{	//清空
		( void ) memset( pxStreamBuffer, 0x00, sizeof( StreamBuffer_t ) );
	}
}

//流缓冲重置
BaseType_t xStreamBufferReset( StreamBufferHandle_t xStreamBuffer )
{
StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
BaseType_t xReturn = pdFAIL;
#if( configUSE_TRACE_FACILITY == 1 )
	UBaseType_t uxStreamBufferNumber;
#endif
	configASSERT( pxStreamBuffer );
	#if( configUSE_TRACE_FACILITY == 1 )
	{
		uxStreamBufferNumber = pxStreamBuffer->uxStreamBufferNumber;
	}
	#endif

	taskENTER_CRITICAL();
	{
		if( pxStreamBuffer->xTaskWaitingToReceive == NULL )
		{
			if( pxStreamBuffer->xTaskWaitingToSend == NULL )
			{	//重新初始化流缓冲即可
				prvInitialiseNewStreamBuffer( pxStreamBuffer,
											  pxStreamBuffer->pucBuffer,
											  pxStreamBuffer->xLength,
											  pxStreamBuffer->xTriggerLevelBytes,
											  pxStreamBuffer->ucFlags );
				xReturn = pdPASS;

				#if( configUSE_TRACE_FACILITY == 1 )
				{
					pxStreamBuffer->uxStreamBufferNumber = uxStreamBufferNumber;
				}
				#endif
				traceSTREAM_BUFFER_RESET( xStreamBuffer );
			}
		}
	}
	taskEXIT_CRITICAL();
	return xReturn;
}

//流缓冲触发层设置
BaseType_t xStreamBufferSetTriggerLevel( StreamBufferHandle_t xStreamBuffer, size_t xTriggerLevel )
{
StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
BaseType_t xReturn;
	configASSERT( pxStreamBuffer );

	if( xTriggerLevel == ( size_t ) 0 )
	{
		xTriggerLevel = ( size_t ) 1;
	}
	//流缓冲TriggerLevel重写
	if( xTriggerLevel <= pxStreamBuffer->xLength )
	{
		pxStreamBuffer->xTriggerLevelBytes = xTriggerLevel;
		xReturn = pdPASS;
	}
	else
	{
		xReturn = pdFALSE;
	}
	return xReturn;
}

//可用流缓冲空间
size_t xStreamBufferSpacesAvailable( StreamBufferHandle_t xStreamBuffer )
{
const StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
size_t xSpace;
	configASSERT( pxStreamBuffer );
	//流缓冲的长度偏移到写入的位置,然后扣除读出的位置,即可完成偏移计算
	xSpace = pxStreamBuffer->xLength + pxStreamBuffer->xTail;
	xSpace -= pxStreamBuffer->xHead;
	xSpace -= ( size_t ) 1;
	if( xSpace >= pxStreamBuffer->xLength )
	{	//去模
		xSpace -= pxStreamBuffer->xLength;
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	return xSpace;
}

//流缓冲可用字节数
size_t xStreamBufferBytesAvailable( StreamBufferHandle_t xStreamBuffer )
{
const StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
size_t xReturn;
	configASSERT( pxStreamBuffer );
	//获取流缓冲可用字节数
	xReturn = prvBytesInBuffer( pxStreamBuffer );
	return xReturn;
}

//流缓冲接收数据从当前任务
size_t xStreamBufferSend( StreamBufferHandle_t xStreamBuffer,
						  const void *pvTxData,
						  size_t xDataLengthBytes,
						  TickType_t xTicksToWait )
{
StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
size_t xReturn, xSpace = 0;
size_t xRequiredSpace = xDataLengthBytes;
TimeOut_t xTimeOut;
	configASSERT( pvTxData );
	configASSERT( pxStreamBuffer );
	if( ( pxStreamBuffer->ucFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( uint8_t ) 0 )
	{	//是消息缓冲的话,计算消息的长度,数据的大小加一个消息头
		xRequiredSpace += sbBYTES_TO_STORE_MESSAGE_LENGTH;
		configASSERT( xRequiredSpace > xDataLengthBytes );
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}

	if( xTicksToWait != ( TickType_t ) 0 )
	{	//设置溢出次数和超时时间
		vTaskSetTimeOutState( &xTimeOut );
		do
		{
			taskENTER_CRITICAL();
			{	//获取流缓冲可用字节数
				xSpace = xStreamBufferSpacesAvailable( pxStreamBuffer );
				if( xSpace < xRequiredSpace )	//空间不够,准备阻塞
				{	//清除当前任务的通知状态为 非 通知接受完成
					( void ) xTaskNotifyStateClear( NULL );
					configASSERT( pxStreamBuffer->xTaskWaitingToSend == NULL );
					//获取当前任务句柄并绑定到 等待发送到流缓冲 的对象
					pxStreamBuffer->xTaskWaitingToSend = xTaskGetCurrentTaskHandle();
				}
				else
				{	//空间足够,啥也不用做,流缓冲随时取走数据
					taskEXIT_CRITICAL();
					break;
				}
			}
			taskEXIT_CRITICAL();
			traceBLOCKING_ON_STREAM_BUFFER_SEND( xStreamBuffer );
			//从上面下来就表明流缓冲空间不够了,当前无法执行拷贝工作
			//将当前任务加到延迟任务中,等待消息通知
			( void ) xTaskNotifyWait( ( uint32_t ) 0, ( uint32_t ) 0, NULL, xTicksToWait );
			//至此为止要么超时溢出了,要么消息通知等到位了,所以重置
			pxStreamBuffer->xTaskWaitingToSend = NULL;
			//当前任务检查超时情况,还未超时就要继续下一次,直到超时(流缓冲数据被接受)
		} while( xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait ) == pdFALSE );
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}

	if( xSpace == ( size_t ) 0 )
	{	//重新检查空间
		xSpace = xStreamBufferSpacesAvailable( pxStreamBuffer );
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	//现在将数据拷贝到流缓冲中
	xReturn = prvWriteMessageToBuffer( pxStreamBuffer, pvTxData, xDataLengthBytes, xSpace, xRequiredSpace );

	if( xReturn > ( size_t ) 0 )
	{	//发送完成时
		traceSTREAM_BUFFER_SEND( xStreamBuffer, xReturn );
		//流缓冲满足预留空间大于要求非阻塞的最小空间时
		if( prvBytesInBuffer( pxStreamBuffer ) >= pxStreamBuffer->xTriggerLevelBytes )
		{	//谁在等待接收流缓冲的数据？流缓冲的发送部分已经完成了,去通知它
			sbSEND_COMPLETED( pxStreamBuffer );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
		traceSTREAM_BUFFER_SEND_FAILED( xStreamBuffer );
	}

	return xReturn;
}

//中断环境下流缓冲接收数据从当前任务
size_t xStreamBufferSendFromISR( StreamBufferHandle_t xStreamBuffer,
								 const void *pvTxData,
								 size_t xDataLengthBytes,
								 BaseType_t * const pxHigherPriorityTaskWoken )
{
StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
size_t xReturn, xSpace;
size_t xRequiredSpace = xDataLengthBytes;
	configASSERT( pvTxData );
	configASSERT( pxStreamBuffer );
	if( ( pxStreamBuffer->ucFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( uint8_t ) 0 )
	{	//如果是消息,确认消息的长度
		xRequiredSpace += sbBYTES_TO_STORE_MESSAGE_LENGTH;
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	xSpace = xStreamBufferSpacesAvailable( pxStreamBuffer );//获取流缓冲可用字节数
	//将数据拷贝到流缓冲的空间中
	xReturn = prvWriteMessageToBuffer( pxStreamBuffer, pvTxData, xDataLengthBytes, xSpace, xRequiredSpace );
	if( xReturn > ( size_t ) 0 )
	{	//流缓冲有足够空间用于满足任务不被阻塞掉
		if( prvBytesInBuffer( pxStreamBuffer ) >= pxStreamBuffer->xTriggerLevelBytes )
		{	//通知接收任务,数据的发送部分已经结束,以高优先级唤醒数据的接受任务
			sbSEND_COMPLETE_FROM_ISR( pxStreamBuffer, pxHigherPriorityTaskWoken );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}

	traceSTREAM_BUFFER_SEND_FROM_ISR( xStreamBuffer, xReturn );

	return xReturn;
}

//写消息到流缓冲中
static size_t prvWriteMessageToBuffer( StreamBuffer_t * const pxStreamBuffer,
									   const void * pvTxData,
									   size_t xDataLengthBytes,
									   size_t xSpace,
									   size_t xRequiredSpace )
{
	BaseType_t xShouldWrite;
	size_t xReturn;
	if( xSpace == ( size_t ) 0 )
	{	//空间不足
		xShouldWrite = pdFALSE;
	}
	else if( ( pxStreamBuffer->ucFlags & sbFLAGS_IS_MESSAGE_BUFFER ) == ( uint8_t ) 0 )
	{	//不是一个消息
		xShouldWrite = pdTRUE;
		xDataLengthBytes = configMIN( xDataLengthBytes, xSpace );
	}
	else if( xSpace >= xRequiredSpace )
	{	//现在是一个流缓冲消息了,空间也足够
		xShouldWrite = pdTRUE;
		//数据的长度写入到流缓冲中开始位置
		( void ) prvWriteBytesToBuffer( pxStreamBuffer, ( const uint8_t * ) &( xDataLengthBytes ), sbBYTES_TO_STORE_MESSAGE_LENGTH );
	}
	else
	{	//虽然是一个流缓冲消息,但是流缓冲的空间不够,无法接受这个消息
		xShouldWrite = pdFALSE;
	}

	if( xShouldWrite != pdFALSE )
	{	//正式写入数据,紧接着数据的长度之后写
		xReturn = prvWriteBytesToBuffer( pxStreamBuffer, ( const uint8_t * ) pvTxData, xDataLengthBytes ); 
	}
	else
	{
		xReturn = 0;
	}

	return xReturn;
}
									   
//流缓冲发送任务到当前任务
size_t xStreamBufferReceive( StreamBufferHandle_t xStreamBuffer,
							 void *pvRxData,
							 size_t xBufferLengthBytes,
							 TickType_t xTicksToWait )
{
StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
size_t xReceivedLength = 0, xBytesAvailable, xBytesToStoreMessageLength;
	configASSERT( pvRxData );
	configASSERT( pxStreamBuffer );
	if( ( pxStreamBuffer->ucFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( uint8_t ) 0 )
	{	//如果是一个消息的话,消息的写入和读取都要附带一个消息头表明消息的长度大小
		xBytesToStoreMessageLength = sbBYTES_TO_STORE_MESSAGE_LENGTH;
	}
	else
	{
		xBytesToStoreMessageLength = 0;
	}

	if( xTicksToWait != ( TickType_t ) 0 )
	{
		taskENTER_CRITICAL();
		{	//获取流缓冲可用字节数
			xBytesAvailable = prvBytesInBuffer( pxStreamBuffer );
			//流缓冲的可用空间 至少要保证多于一个 一个存储消息长度大小的区域
			if( xBytesAvailable <= xBytesToStoreMessageLength )
			{	//空间不足准备阻塞,清除当前任务的通知状态为 非 通知接受完成
				( void ) xTaskNotifyStateClear( NULL );
				configASSERT( pxStreamBuffer->xTaskWaitingToReceive == NULL );
				//当前任务被指定为流缓冲中数据的接受者
				pxStreamBuffer->xTaskWaitingToReceive = xTaskGetCurrentTaskHandle();
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		taskEXIT_CRITICAL();
		if( xBytesAvailable <= xBytesToStoreMessageLength )
		{	
			traceBLOCKING_ON_STREAM_BUFFER_RECEIVE( xStreamBuffer );
			//空间还是不足,只好将当前任务加到延迟任务中,等待消息通知
			( void ) xTaskNotifyWait( ( uint32_t ) 0, ( uint32_t ) 0, NULL, xTicksToWait );
			pxStreamBuffer->xTaskWaitingToReceive = NULL;
			//重新检查一次可用的字节数
			xBytesAvailable = prvBytesInBuffer( pxStreamBuffer );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else
	{	//获取流缓冲空间大小
		xBytesAvailable = prvBytesInBuffer( pxStreamBuffer );
	}

	if( xBytesAvailable > xBytesToStoreMessageLength )
	{	//满足空间时,从流缓冲读取消息数据
		xReceivedLength = prvReadMessageFromBuffer( pxStreamBuffer, pvRxData, xBufferLengthBytes, xBytesAvailable, xBytesToStoreMessageLength );
		if( xReceivedLength != ( size_t ) 0 )
		{	//接受完成了,通知要向流缓冲发送数据的任务,接受完成了现在应该有空间了
			traceSTREAM_BUFFER_RECEIVE( xStreamBuffer, xReceivedLength );
			sbRECEIVE_COMPLETED( pxStreamBuffer );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else
	{
		traceSTREAM_BUFFER_RECEIVE_FAILED( xStreamBuffer );
		mtCOVERAGE_TEST_MARKER();
	}
	return xReceivedLength;
}

//流缓冲中下一个消息的长度
size_t xStreamBufferNextMessageLengthBytes( StreamBufferHandle_t xStreamBuffer )
{
StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
size_t xReturn, xBytesAvailable, xOriginalTail;
configMESSAGE_BUFFER_LENGTH_TYPE xTempReturn;
	configASSERT( pxStreamBuffer );
	if( ( pxStreamBuffer->ucFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( uint8_t ) 0 )
	{	//如果流缓冲是一个消息,获取可用字节数
		xBytesAvailable = prvBytesInBuffer( pxStreamBuffer );
		if( xBytesAvailable > sbBYTES_TO_STORE_MESSAGE_LENGTH )
		{	//当可用字节数大于消息要求的长度是,表明流缓冲存在消息
			xOriginalTail = pxStreamBuffer->xTail;//读取消息的长度即可
			( void ) prvReadBytesFromBuffer( pxStreamBuffer, ( uint8_t * ) &xTempReturn, sbBYTES_TO_STORE_MESSAGE_LENGTH, xBytesAvailable );
			xReturn = ( size_t ) xTempReturn;
			pxStreamBuffer->xTail = xOriginalTail;//读取完之后要手动还原读取的位置
		}
		else
		{
			configASSERT( xBytesAvailable == 0 );
			xReturn = 0;
		}
	}
	else
	{
		xReturn = 0;
	}
	return xReturn;
}

//中断环境下流缓冲发送数据到当前任务
size_t xStreamBufferReceiveFromISR( StreamBufferHandle_t xStreamBuffer,
									void *pvRxData,
									size_t xBufferLengthBytes,
									BaseType_t * const pxHigherPriorityTaskWoken )
{
StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
size_t xReceivedLength = 0, xBytesAvailable, xBytesToStoreMessageLength;
	configASSERT( pvRxData );
	configASSERT( pxStreamBuffer );
	if( ( pxStreamBuffer->ucFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( uint8_t ) 0 )
	{	//检查是否是一个消息
		xBytesToStoreMessageLength = sbBYTES_TO_STORE_MESSAGE_LENGTH;
	}
	else
	{
		xBytesToStoreMessageLength = 0;
	}
	//流缓冲可用字节数
	xBytesAvailable = prvBytesInBuffer( pxStreamBuffer );
	if( xBytesAvailable > xBytesToStoreMessageLength )
	{	//流缓冲有数据可读,现在读取消息
		xReceivedLength = prvReadMessageFromBuffer( pxStreamBuffer, pvRxData, xBufferLengthBytes, xBytesAvailable, xBytesToStoreMessageLength );
		if( xReceivedLength != ( size_t ) 0 )
		{	//通知向流缓冲发送数据的任务,从流缓冲接收数据的任务已经将数据接收完毕了
			sbRECEIVE_COMPLETED_FROM_ISR( pxStreamBuffer, pxHigherPriorityTaskWoken );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	traceSTREAM_BUFFER_RECEIVE_FROM_ISR( xStreamBuffer, xReceivedLength );
	return xReceivedLength;
}

//从流缓冲读取数据
static size_t prvReadMessageFromBuffer( StreamBuffer_t *pxStreamBuffer,
										void *pvRxData,
										size_t xBufferLengthBytes,
										size_t xBytesAvailable,
										size_t xBytesToStoreMessageLength )
{
size_t xOriginalTail, xReceivedLength, xNextMessageLength;
configMESSAGE_BUFFER_LENGTH_TYPE xTempNextMessageLength;
	if( xBytesToStoreMessageLength != ( size_t ) 0 )
	{	//是一个消息的话,读取该消息
		xOriginalTail = pxStreamBuffer->xTail;//定位到流缓冲读取的开始位置
		( void ) prvReadBytesFromBuffer( pxStreamBuffer, ( uint8_t * ) &xTempNextMessageLength, xBytesToStoreMessageLength, xBytesAvailable );
		xNextMessageLength = ( size_t ) xTempNextMessageLength;
		//读取了一部分数据,减少可用字节数
		xBytesAvailable -= xBytesToStoreMessageLength;
		if( xNextMessageLength > xBufferLengthBytes )
		{	//流缓冲给用户提供的数据量 与 用户需求的数据量的差异
			pxStreamBuffer->xTail = xOriginalTail;
			xNextMessageLength = 0;
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else
	{
		xNextMessageLength = xBufferLengthBytes;
	}
	
	//把数据内容读出来
	xReceivedLength = prvReadBytesFromBuffer( pxStreamBuffer, ( uint8_t * ) pvRxData, xNextMessageLength, xBytesAvailable );
	return xReceivedLength;
}

//流缓冲为空检查
BaseType_t xStreamBufferIsEmpty( StreamBufferHandle_t xStreamBuffer )
{
const StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
BaseType_t xReturn;
size_t xTail;
	configASSERT( pxStreamBuffer );
	xTail = pxStreamBuffer->xTail;
	if( pxStreamBuffer->xHead == xTail )
	{	//读取和写入在同一位置,流缓冲为空
		xReturn = pdTRUE;
	}
	else
	{
		xReturn = pdFALSE;
	}

	return xReturn;
}

//流缓冲为满检查
BaseType_t xStreamBufferIsFull( StreamBufferHandle_t xStreamBuffer )
{
BaseType_t xReturn;
size_t xBytesToStoreMessageLength;
const StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
	configASSERT( pxStreamBuffer );
	if( ( pxStreamBuffer->ucFlags & sbFLAGS_IS_MESSAGE_BUFFER ) != ( uint8_t ) 0 )
	{	//消息确认
		xBytesToStoreMessageLength = sbBYTES_TO_STORE_MESSAGE_LENGTH;
	}
	else
	{
		xBytesToStoreMessageLength = 0;
	}
	if( xStreamBufferSpacesAvailable( xStreamBuffer ) <= xBytesToStoreMessageLength )
	{	//检查流缓冲可用空间 是否还能写入数据
		xReturn = pdTRUE;
	}
	else
	{
		xReturn = pdFALSE;
	}

	return xReturn;
}

//中断环境下流缓冲接受数据完成
BaseType_t xStreamBufferSendCompletedFromISR( StreamBufferHandle_t xStreamBuffer, BaseType_t *pxHigherPriorityTaskWoken )
{
StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
BaseType_t xReturn;
UBaseType_t uxSavedInterruptStatus;
	configASSERT( pxStreamBuffer );
	//中断状态获取
	uxSavedInterruptStatus = ( UBaseType_t ) portSET_INTERRUPT_MASK_FROM_ISR();
	{	//等待从流缓冲获取数据的任务存在时
		if( ( pxStreamBuffer )->xTaskWaitingToReceive != NULL )
		{	//通知它,以高优先级唤醒
			( void ) xTaskNotifyFromISR( ( pxStreamBuffer )->xTaskWaitingToReceive,
										 ( uint32_t ) 0,
										 eNoAction,
										 pxHigherPriorityTaskWoken );
			( pxStreamBuffer )->xTaskWaitingToReceive = NULL;
			xReturn = pdTRUE;
		}
		else
		{
			xReturn = pdFALSE;
		}
	}
	portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );

	return xReturn;
}

//中断环境下流缓冲发送数据完成
BaseType_t xStreamBufferReceiveCompletedFromISR( StreamBufferHandle_t xStreamBuffer, BaseType_t *pxHigherPriorityTaskWoken )
{
StreamBuffer_t * const pxStreamBuffer = xStreamBuffer;
BaseType_t xReturn;
UBaseType_t uxSavedInterruptStatus;
	configASSERT( pxStreamBuffer );
	//中断状态获取
	uxSavedInterruptStatus = ( UBaseType_t ) portSET_INTERRUPT_MASK_FROM_ISR();
	{	//如果等待向流缓冲发送数据的任务存在
		if( ( pxStreamBuffer )->xTaskWaitingToSend != NULL )
		{	//通知它,已经有任务从流缓冲中接受完数据了,高优先级唤醒
			( void ) xTaskNotifyFromISR( ( pxStreamBuffer )->xTaskWaitingToSend,
										 ( uint32_t ) 0,
										 eNoAction,
										 pxHigherPriorityTaskWoken );
			( pxStreamBuffer )->xTaskWaitingToSend = NULL;
			xReturn = pdTRUE;
		}
		else
		{
			xReturn = pdFALSE;
		}
	}
	portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );

	return xReturn;
}

//写字节到流缓冲
static size_t prvWriteBytesToBuffer( StreamBuffer_t * const pxStreamBuffer, const uint8_t *pucData, size_t xCount )
{
size_t xNextHead, xFirstLength;
	configASSERT( xCount > ( size_t ) 0 );
	//获取下一个写位置的头
	xNextHead = pxStreamBuffer->xHead;
	//流缓冲最多能写多少？
	xFirstLength = configMIN( pxStreamBuffer->xLength - xNextHead, xCount );
	configASSERT( ( xNextHead + xFirstLength ) <= pxStreamBuffer->xLength );
	//写入到流缓冲的写头
	( void ) memcpy( ( void* ) ( &( pxStreamBuffer->pucBuffer[ xNextHead ] ) ), ( const void * ) pucData, xFirstLength );
	if( xCount > xFirstLength )
	{	//写满了,那么就覆盖到开始位置,类似于循环队列
		configASSERT( ( xCount - xFirstLength ) <= pxStreamBuffer->xLength );
		( void ) memcpy( ( void * ) pxStreamBuffer->pucBuffer, ( const void * ) &( pucData[ xFirstLength ] ), xCount - xFirstLength );
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	xNextHead += xCount;
	if( xNextHead >= pxStreamBuffer->xLength )
	{
		xNextHead -= pxStreamBuffer->xLength;
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	pxStreamBuffer->xHead = xNextHead;
	return xCount;
}

//从流缓冲读字节
static size_t prvReadBytesFromBuffer( StreamBuffer_t *pxStreamBuffer, uint8_t *pucData, size_t xMaxCount, size_t xBytesAvailable )
{
size_t xCount, xFirstLength, xNextTail;
	//查看流缓冲最多还能读多少字节
	xCount = configMIN( xBytesAvailable, xMaxCount );
	if( xCount > ( size_t ) 0 )
	{
		xNextTail = pxStreamBuffer->xTail;
		xFirstLength = configMIN( pxStreamBuffer->xLength - xNextTail, xCount );

		configASSERT( xFirstLength <= xMaxCount );
		configASSERT( ( xNextTail + xFirstLength ) <= pxStreamBuffer->xLength );
		//读数据,一直读到流缓冲末尾
		( void ) memcpy( ( void * ) pucData, ( const void * ) &( pxStreamBuffer->pucBuffer[ xNextTail ] ), xFirstLength ); 
		if( xCount > xFirstLength )
		{	//剩下的数据从流缓冲的开头去读
			configASSERT( xCount <= xMaxCount );
			( void ) memcpy( ( void * ) &( pucData[ xFirstLength ] ), ( void * ) ( pxStreamBuffer->pucBuffer ), xCount - xFirstLength );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
		//定位下一次读取位置
		xNextTail += xCount;

		if( xNextTail >= pxStreamBuffer->xLength )
		{
			xNextTail -= pxStreamBuffer->xLength;
		}
		pxStreamBuffer->xTail = xNextTail;
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	return xCount;
}

//检查流缓冲存在多少有效的字节数
static size_t prvBytesInBuffer( const StreamBuffer_t * const pxStreamBuffer )
{
size_t xCount;
	xCount = pxStreamBuffer->xLength + pxStreamBuffer->xHead;//之所以要加上长度
	xCount -= pxStreamBuffer->xTail;//是因为流缓冲是循环读取,所以可能是读在后,写在前
	if ( xCount >= pxStreamBuffer->xLength )
	{	//计算流缓冲的 读与写之间的差值
		xCount -= pxStreamBuffer->xLength;
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	return xCount;
}

//流缓冲的初始化
static void prvInitialiseNewStreamBuffer( StreamBuffer_t * const pxStreamBuffer,
										  uint8_t * const pucBuffer,
										  size_t xBufferSizeBytes,
										  size_t xTriggerLevelBytes,
										  uint8_t ucFlags )
{
	#if( configASSERT_DEFINED == 1 )
	{
		const BaseType_t xWriteValue = 0x55;//流缓冲以固定值清空
		configASSERT( memset( pucBuffer, ( int ) xWriteValue, xBufferSizeBytes ) == pucBuffer );
	}
	#endif
	//流缓冲以0清空
	( void ) memset( ( void * ) pxStreamBuffer, 0x00, sizeof( StreamBuffer_t ) );
	pxStreamBuffer->pucBuffer = pucBuffer;//为新的流缓冲绑定,利用传入的参数
	pxStreamBuffer->xLength = xBufferSizeBytes;
	pxStreamBuffer->xTriggerLevelBytes = xTriggerLevelBytes;
	pxStreamBuffer->ucFlags = ucFlags;
}


//流缓冲的数量
#if ( configUSE_TRACE_FACILITY == 1 )
	UBaseType_t uxStreamBufferGetStreamBufferNumber( StreamBufferHandle_t xStreamBuffer )
	{
		return xStreamBuffer->uxStreamBufferNumber;
	}
#endif


//设置流缓冲的数量
#if ( configUSE_TRACE_FACILITY == 1 )
	void vStreamBufferSetStreamBufferNumber( StreamBufferHandle_t xStreamBuffer, UBaseType_t uxStreamBufferNumber )
	{
		xStreamBuffer->uxStreamBufferNumber = uxStreamBufferNumber;
	}
#endif 

//流缓冲中数据类型检查,是否是一个消息
#if ( configUSE_TRACE_FACILITY == 1 )
	uint8_t ucStreamBufferGetStreamBufferType( StreamBufferHandle_t xStreamBuffer )
	{
		return ( xStreamBuffer->ucFlags & sbFLAGS_IS_MESSAGE_BUFFER );
	}
#endif



