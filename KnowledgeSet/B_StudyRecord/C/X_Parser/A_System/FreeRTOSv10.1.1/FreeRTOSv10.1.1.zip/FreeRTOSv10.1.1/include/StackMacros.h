/*
 * 栈的溢出检查配置
 */

#ifndef STACK_MACROS_H
#define STACK_MACROS_H

#ifndef _MSC_VER //(Visual Studio 不支持预处理宏警告),版本更新警告,本文件改名字了
	#warning The name of this file has changed to stack_macros.h.  Please update your code accordingly.  This source file (which has the original name) will be removed in future released.
#endif

//配置为1时仅仅检查当前堆栈是否溢出,判断堆栈增长方式,高字节往低字节增长
#if( ( configCHECK_FOR_STACK_OVERFLOW == 1 ) && ( portSTACK_GROWTH < 0 ) )
    //定义一个溢出检查宏
	#define taskCHECK_FOR_STACK_OVERFLOW()																\
	{   /*检查当前栈顶指针与栈最大值指针*/                                                                             \
	    if( pxCurrentTCB->pxTopOfStack <= pxCurrentTCB->pxStack )										\
		{	/*调用堆栈溢出回调钩子*/                  															\
			vApplicationStackOverflowHook( ( TaskHandle_t ) pxCurrentTCB, pxCurrentTCB->pcTaskName );	\
		}																								\
	}
#endif

//配置为1时仅仅检查当前堆栈是否溢出,判断堆栈增长方式
#if( ( configCHECK_FOR_STACK_OVERFLOW == 1 ) && ( portSTACK_GROWTH > 0 ) )
	#define taskCHECK_FOR_STACK_OVERFLOW()																\
	{																									\
		if( pxCurrentTCB->pxTopOfStack >= pxCurrentTCB->pxEndOfStack )									\
		{																								\
			vApplicationStackOverflowHook( ( TaskHandle_t ) pxCurrentTCB, pxCurrentTCB->pcTaskName );	\
		}																								\
	}
#endif 

//配置为>1时检查当前堆栈最后几个字节是否溢出,判断堆栈增长方式
#if( ( configCHECK_FOR_STACK_OVERFLOW > 1 ) && ( portSTACK_GROWTH < 0 ) )
	#define taskCHECK_FOR_STACK_OVERFLOW()																\
	{																									\
		const uint32_t * const pulStack = ( uint32_t * ) pxCurrentTCB->pxStack;							\
		const uint32_t ulCheckValue = ( uint32_t ) 0xa5a5a5a5;											\
		/*检查最后几个位置的堆栈掩码值*/		                        												\
		if( ( pulStack[ 0 ] != ulCheckValue ) ||						        						\
			( pulStack[ 1 ] != ulCheckValue ) ||						        						\
			( pulStack[ 2 ] != ulCheckValue ) ||						        						\
			( pulStack[ 3 ] != ulCheckValue ) )							            					\
		{	/*快要溢出了或者已经溢出了,调用堆栈溢出回调钩子*/           														\
			vApplicationStackOverflowHook( ( TaskHandle_t ) pxCurrentTCB, pxCurrentTCB->pcTaskName );	\
		}																								\
	}

#endif

#if( ( configCHECK_FOR_STACK_OVERFLOW > 1 ) && ( portSTACK_GROWTH > 0 ) )
	#define taskCHECK_FOR_STACK_OVERFLOW()																								\
	{																																	\
	int8_t *pcEndOfStack = ( int8_t * ) pxCurrentTCB->pxEndOfStack;																		\
	static const uint8_t ucExpectedStackBytes[] = {	tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE,		\
													tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE,		\
													tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE,		\
													tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE,		\
													tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE, tskSTACK_FILL_BYTE };	\
																																		\
																																		\
		pcEndOfStack -= sizeof( ucExpectedStackBytes );																					\
		/*直接从堆栈尾清除一部分区域*/                                                     															\
		if( memcmp( ( void * ) pcEndOfStack, ( void * ) ucExpectedStackBytes, sizeof( ucExpectedStackBytes ) ) != 0 )					\
		{																																\
			vApplicationStackOverflowHook( ( TaskHandle_t ) pxCurrentTCB, pxCurrentTCB->pcTaskName );									\
		}																																\
	}

#endif 

//如果上述条件不满足的话,直接重置为空(删除操作)
#ifndef taskCHECK_FOR_STACK_OVERFLOW
	#define taskCHECK_FOR_STACK_OVERFLOW()
#endif
#endif

