/*
 * 协程
 */

#include "FreeRTOS.h"
#include "task.h"
#include "croutine.h"


#if( configUSE_CO_ROUTINES != 0 )

//移除static修饰
#ifdef portREMOVE_STATIC_QUALIFIER
	#define static
#endif

//协程的一些所用到的内核维护资源
static List_t pxReadyCoRoutineLists[ configMAX_CO_ROUTINE_PRIORITIES ];	//协程就绪队列
static List_t xDelayedCoRoutineList1;									//协程延时队列
static List_t xDelayedCoRoutineList2;									//协程延时队列
static List_t * pxDelayedCoRoutineList;									//协程延时队列引用
static List_t * pxOverflowDelayedCoRoutineList;							//协程溢出延时队列引用
static List_t xPendingReadyCoRoutineList;								//协程挂起就绪队列

CRCB_t * pxCurrentCoRoutine = NULL;//当前协程
static UBaseType_t uxTopCoRoutineReadyPriority = 0;//协程最大就绪优先级
static TickType_t xCoRoutineTickCount = 0, xLastTickCount = 0, xPassedTicks = 0;

//协程初始化状态
#define corINITIAL_STATE	( 0 )

//指定协程加入到就绪队列中
#define prvAddCoRoutineToReadyQueue( pxCRCB )																		\
{																													\
	if( pxCRCB->uxPriority > uxTopCoRoutineReadyPriority )															\
	{																												\
		uxTopCoRoutineReadyPriority = pxCRCB->uxPriority;															\
	}																												\
	vListInsertEnd( ( List_t * ) &( pxReadyCoRoutineLists[ pxCRCB->uxPriority ] ), &( pxCRCB->xGenericListItem ) );	\
}

//新的协程的初始化
static void prvInitialiseCoRoutineLists( void );

//释放挂起就绪队列中阻塞的协程,加入到就绪队列中
static void prvCheckPendingReadyList( void );

//延时队列检查,如果滴答重置需要进行延时队列切换
static void prvCheckDelayedList( void );

//创建一个协程
BaseType_t xCoRoutineCreate( crCOROUTINE_CODE pxCoRoutineCode, UBaseType_t uxPriority, UBaseType_t uxIndex )
{
BaseType_t xReturn;
CRCB_t *pxCoRoutine;
	//动态分配协程的空间
	pxCoRoutine = ( CRCB_t * ) pvPortMalloc( sizeof( CRCB_t ) );
	if( pxCoRoutine )
	{
		if( pxCurrentCoRoutine == NULL )
		{	//刚好当前无协程运行
			pxCurrentCoRoutine = pxCoRoutine;
			prvInitialiseCoRoutineLists();
		}
		if( uxPriority >= configMAX_CO_ROUTINE_PRIORITIES )
		{	//确认协程优先级
			uxPriority = configMAX_CO_ROUTINE_PRIORITIES - 1;
		}
		//初始化
		pxCoRoutine->uxState = corINITIAL_STATE;
		pxCoRoutine->uxPriority = uxPriority;
		pxCoRoutine->uxIndex = uxIndex;
		pxCoRoutine->pxCoRoutineFunction = pxCoRoutineCode;
		//初始化协程队列项
		vListInitialiseItem( &( pxCoRoutine->xGenericListItem ) );
		vListInitialiseItem( &( pxCoRoutine->xEventListItem ) );
		//为协程队列项设置所有者
		listSET_LIST_ITEM_OWNER( &( pxCoRoutine->xGenericListItem ), pxCoRoutine );
		listSET_LIST_ITEM_OWNER( &( pxCoRoutine->xEventListItem ), pxCoRoutine );
		//为协程事件组项设置值为协程优先级的补集
		listSET_LIST_ITEM_VALUE( &( pxCoRoutine->xEventListItem ), ( ( TickType_t ) configMAX_CO_ROUTINE_PRIORITIES - ( TickType_t ) uxPriority ) );
		//协程加入到就绪队列中
		prvAddCoRoutineToReadyQueue( pxCoRoutine );
		xReturn = pdPASS;
	}
	else
	{
		xReturn = errCOULD_NOT_ALLOCATE_REQUIRED_MEMORY;
	}
	return xReturn;
}

//协程加入到延时队列中
void vCoRoutineAddToDelayedList( TickType_t xTicksToDelay, List_t *pxEventList )
{
TickType_t xTimeToWake;
	//计算下一次唤醒时间为 当前时间+延时时间
	xTimeToWake = xCoRoutineTickCount + xTicksToDelay;
	//协程从当前队列中移除
	( void ) uxListRemove( ( ListItem_t * ) &( pxCurrentCoRoutine->xGenericListItem ) );
	//设置唤醒时间
	listSET_LIST_ITEM_VALUE( &( pxCurrentCoRoutine->xGenericListItem ), xTimeToWake );
	if( xTimeToWake < xCoRoutineTickCount )
	{	//唤醒时间小于当前时间说明发生了溢出,将其加入到 溢出延时队列中
		vListInsert( ( List_t * ) pxOverflowDelayedCoRoutineList, ( ListItem_t * ) &( pxCurrentCoRoutine->xGenericListItem ) );
	}
	else
	{	//没有溢出直接加入到延迟队列中
		vListInsert( ( List_t * ) pxDelayedCoRoutineList, ( ListItem_t * ) &( pxCurrentCoRoutine->xGenericListItem ) );
	}
	if( pxEventList )
	{	//当前协程事件组加入到指定的事件中
		vListInsert( pxEventList, &( pxCurrentCoRoutine->xEventListItem ) );
	}
}

//挂起就绪队列检查
static void prvCheckPendingReadyList( void )
{	//循环获得每一个协程
	while( listLIST_IS_EMPTY( &xPendingReadyCoRoutineList ) == pdFALSE )
	{
		CRCB_t *pxUnblockedCRCB;
		portDISABLE_INTERRUPTS();
		{	//从首项开始依次获取并移除
			pxUnblockedCRCB = ( CRCB_t * ) listGET_OWNER_OF_HEAD_ENTRY( (&xPendingReadyCoRoutineList) );
			( void ) uxListRemove( &( pxUnblockedCRCB->xEventListItem ) );
		}
		portENABLE_INTERRUPTS();
		( void ) uxListRemove( &( pxUnblockedCRCB->xGenericListItem ) );
		//加入到就绪队列中
		prvAddCoRoutineToReadyQueue( pxUnblockedCRCB );
	}
}

//延迟队列检查
static void prvCheckDelayedList( void )
{
CRCB_t *pxCRCB;
	xPassedTicks = xTaskGetTickCount() - xLastTickCount;//获取需要处理的滴答数
	while( xPassedTicks )
	{	//因为在这段滴答时间内,可能有些延迟的协程可以运行了
		xCoRoutineTickCount++;
		xPassedTicks--;

		if( xCoRoutineTickCount == 0 )
		{	//滴答溢出了
			List_t * pxTemp;
			//那么溢出延迟队列现在变成了延迟队列了,因为达到了溢出条件
			//原来的延迟队列早就被清空了
			pxTemp = pxDelayedCoRoutineList;
			pxDelayedCoRoutineList = pxOverflowDelayedCoRoutineList;
			pxOverflowDelayedCoRoutineList = pxTemp;
		}

		while( listLIST_IS_EMPTY( pxDelayedCoRoutineList ) == pdFALSE )
		{	//循环从延迟队列中检查它的首项是否达到延时条件
			pxCRCB = ( CRCB_t * ) listGET_OWNER_OF_HEAD_ENTRY( pxDelayedCoRoutineList );
			if( xCoRoutineTickCount < listGET_LIST_ITEM_VALUE( &( pxCRCB->xGenericListItem ) ) )
			{	//出现未来的时间,说明该协程还需要继续延时下去
				break;
			}
			//否则就是过期了,那么将其放入到就绪队列中
			portDISABLE_INTERRUPTS();
			{	//从当前延迟队列中移除项
				( void ) uxListRemove( &( pxCRCB->xGenericListItem ) );
				if( pxCRCB->xEventListItem.pxContainer )
				{	//移除
					( void ) uxListRemove( &( pxCRCB->xEventListItem ) );
				}
			}
			portENABLE_INTERRUPTS();
			//加入到就绪队列中
			prvAddCoRoutineToReadyQueue( pxCRCB );
		}
	}
	xLastTickCount = xCoRoutineTickCount;
}

//协程调度
void vCoRoutineSchedule( void )
{	//延迟就绪队列的每一个协程移入到就绪队列中
	prvCheckPendingReadyList();
	//检查延迟项中的那些过期项加入到就绪队列中
	prvCheckDelayedList();
	//如果就绪队列为空的话(没有可运行任务了)
	while( listLIST_IS_EMPTY( &( pxReadyCoRoutineLists[ uxTopCoRoutineReadyPriority ] ) ) )
	{
		if( uxTopCoRoutineReadyPriority == 0 )
		{
			return;
		}
		--uxTopCoRoutineReadyPriority;
	}
	//从当前最高优先级中取出一个协程,使其成为 当前运行协程
	listGET_OWNER_OF_NEXT_ENTRY( pxCurrentCoRoutine, &( pxReadyCoRoutineLists[ uxTopCoRoutineReadyPriority ] ) );
	//运行协程指定的协程主体(任务主体)
	( pxCurrentCoRoutine->pxCoRoutineFunction )( pxCurrentCoRoutine, pxCurrentCoRoutine->uxIndex );

	return;
}

//初始化协程
static void prvInitialiseCoRoutineLists( void )
{
UBaseType_t uxPriority;
	//初始化就绪队列集
	for( uxPriority = 0; uxPriority < configMAX_CO_ROUTINE_PRIORITIES; uxPriority++ )
	{
		vListInitialise( ( List_t * ) &( pxReadyCoRoutineLists[ uxPriority ] ) );
	}
	//初始化俩个延迟队列和挂起就绪队列
	vListInitialise( ( List_t * ) &xDelayedCoRoutineList1 );
	vListInitialise( ( List_t * ) &xDelayedCoRoutineList2 );
	vListInitialise( ( List_t * ) &xPendingReadyCoRoutineList );
	//指定一个为延迟队列,一个为溢出延迟队列
	pxDelayedCoRoutineList = &xDelayedCoRoutineList1;
	pxOverflowDelayedCoRoutineList = &xDelayedCoRoutineList2;
}


//指定事件组移除一个协程
BaseType_t xCoRoutineRemoveFromEventList( const List_t *pxEventList )
{
CRCB_t *pxUnblockedCRCB;
BaseType_t xReturn;
	//获取最近一个 要解除阻塞的 协程
	pxUnblockedCRCB = ( CRCB_t * ) listGET_OWNER_OF_HEAD_ENTRY( pxEventList );
	( void ) uxListRemove( &( pxUnblockedCRCB->xEventListItem ) );//从事件组移除
	//加入到挂起就绪队列中
	vListInsertEnd( ( List_t * ) &( xPendingReadyCoRoutineList ), &( pxUnblockedCRCB->xEventListItem ) );
	if( pxUnblockedCRCB->uxPriority >= pxCurrentCoRoutine->uxPriority )
	{	//检查优先级确定返回值,可用于内核抢占
		xReturn = pdTRUE;
	}
	else
	{
		xReturn = pdFALSE;
	}
	return xReturn;
}

#endif


