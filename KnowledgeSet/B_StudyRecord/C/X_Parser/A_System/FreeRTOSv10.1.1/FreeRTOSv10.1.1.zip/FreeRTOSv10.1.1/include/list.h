/*
 * 数据结构之链表
 */

#ifndef INC_FREERTOS_H  //全局配置需要在它之前存在
	#error FreeRTOS.h must be included before list.h
#endif

#ifndef LIST_H
#define LIST_H

//支持交叉编译器的优化
#ifndef configLIST_VOLATILE
	#define configLIST_VOLATILE
#endif

//C++兼容
#ifdef __cplusplus
extern "C" {
#endif

//字节数据检查配置
#if( configUSE_LIST_DATA_INTEGRITY_CHECK_BYTES == 0 )
	//无需检查,配置为空
	#define listFIRST_LIST_ITEM_INTEGRITY_CHECK_VALUE
	#define listSECOND_LIST_ITEM_INTEGRITY_CHECK_VALUE
	#define listFIRST_LIST_INTEGRITY_CHECK_VALUE
	#define listSECOND_LIST_INTEGRITY_CHECK_VALUE
	#define listSET_FIRST_LIST_ITEM_INTEGRITY_CHECK_VALUE( pxItem )
	#define listSET_SECOND_LIST_ITEM_INTEGRITY_CHECK_VALUE( pxItem )
	#define listSET_LIST_INTEGRITY_CHECK_1_VALUE( pxList )
	#define listSET_LIST_INTEGRITY_CHECK_2_VALUE( pxList )
	#define listTEST_LIST_ITEM_INTEGRITY( pxItem )
	#define listTEST_LIST_INTEGRITY( pxList )
#else
	//宏确定,新增数据成员的的值检查
	#define listFIRST_LIST_ITEM_INTEGRITY_CHECK_VALUE				TickType_t xListItemIntegrityValue1;
	#define listSECOND_LIST_ITEM_INTEGRITY_CHECK_VALUE				TickType_t xListItemIntegrityValue2;
	#define listFIRST_LIST_INTEGRITY_CHECK_VALUE					TickType_t xListIntegrityValue1;
	#define listSECOND_LIST_INTEGRITY_CHECK_VALUE					TickType_t xListIntegrityValue2;

	//配置新成员的值,使用宏初始化成员
	#define listSET_FIRST_LIST_ITEM_INTEGRITY_CHECK_VALUE( pxItem )		( pxItem )->xListItemIntegrityValue1 = pdINTEGRITY_CHECK_VALUE
	#define listSET_SECOND_LIST_ITEM_INTEGRITY_CHECK_VALUE( pxItem )	( pxItem )->xListItemIntegrityValue2 = pdINTEGRITY_CHECK_VALUE
	#define listSET_LIST_INTEGRITY_CHECK_1_VALUE( pxList )		( pxList )->xListIntegrityValue1 = pdINTEGRITY_CHECK_VALUE
	#define listSET_LIST_INTEGRITY_CHECK_2_VALUE( pxList )		( pxList )->xListIntegrityValue2 = pdINTEGRITY_CHECK_VALUE

	//宏检查,查看数据完整性
	#define listTEST_LIST_ITEM_INTEGRITY( pxItem )		configASSERT( ( ( pxItem )->xListItemIntegrityValue1 == pdINTEGRITY_CHECK_VALUE ) && ( ( pxItem )->xListItemIntegrityValue2 == pdINTEGRITY_CHECK_VALUE ) )
	#define listTEST_LIST_INTEGRITY( pxList )			configASSERT( ( ( pxList )->xListIntegrityValue1 == pdINTEGRITY_CHECK_VALUE ) && ( ( pxList )->xListIntegrityValue2 == pdINTEGRITY_CHECK_VALUE ) )
#endif

struct xLIST;//链表的声明,因为定义在后面,之前的声明需要全局开始声明,以让编译器确定内容
struct xLIST_ITEM//链表项
{
	listFIRST_LIST_ITEM_INTEGRITY_CHECK_VALUE			//用于数据检查所用,设置一个自己确定的值
	configLIST_VOLATILE TickType_t xItemValue;			//项的值,多用于升序插入所用
	struct xLIST_ITEM * configLIST_VOLATILE pxNext;		//后一个节点
	struct xLIST_ITEM * configLIST_VOLATILE pxPrevious;	//前一个节点
	void * pvOwner;										//内核的一个对象,通常是程序控制块TCB
	struct xLIST * configLIST_VOLATILE pxContainer;		//可以理解为指向它的老大哥(组长,等)
	listSECOND_LIST_ITEM_INTEGRITY_CHECK_VALUE			//数据检查所用,设置一个自己确定的值
};
typedef struct xLIST_ITEM ListItem_t;					//扩展声明

struct xMINI_LIST_ITEM//迷你链表项
{   //其余见上
	listFIRST_LIST_ITEM_INTEGRITY_CHECK_VALUE
	configLIST_VOLATILE TickType_t xItemValue;
	struct xLIST_ITEM * configLIST_VOLATILE pxNext;
	struct xLIST_ITEM * configLIST_VOLATILE pxPrevious;
};
typedef struct xMINI_LIST_ITEM MiniListItem_t;          //扩展声明

//定义一个链表
typedef struct xLIST
{
	listFIRST_LIST_INTEGRITY_CHECK_VALUE				//数据完整性检查
	volatile UBaseType_t uxNumberOfItems;               //链表项的个数
	ListItem_t * configLIST_VOLATILE pxIndex;			//链表项指针,指向一个双向链表
	MiniListItem_t xListEnd;							//迷你链表项实例,表明链表的结尾处
	listSECOND_LIST_INTEGRITY_CHECK_VALUE				//数据完整性检查
} List_t;

//设置链表项成员(所有者)
#define listSET_LIST_ITEM_OWNER( pxListItem, pxOwner )		( ( pxListItem )->pvOwner = ( void * ) ( pxOwner ) )

//获取链表项成员(所有者)
#define listGET_LIST_ITEM_OWNER( pxListItem )	( ( pxListItem )->pvOwner )

//设置链表项的值(编码)
#define listSET_LIST_ITEM_VALUE( pxListItem, xValue )	( ( pxListItem )->xItemValue = ( xValue ) )

//获取链表项的值(编码)
#define listGET_LIST_ITEM_VALUE( pxListItem )	( ( pxListItem )->xItemValue )

//意思是循环链表,所以xListEnd的结尾是链表的头,获取它的值
#define listGET_ITEM_VALUE_OF_HEAD_ENTRY( pxList )	( ( ( pxList )->xListEnd ).pxNext->xItemValue )

//获取链表的头
#define listGET_HEAD_ENTRY( pxList )	( ( ( pxList )->xListEnd ).pxNext )

//获得当前的链表项的后一个项
#define listGET_NEXT( pxListItem )	( ( pxListItem )->pxNext )

//获取链表尾,一个迷你链表,不含其它实际成员
#define listGET_END_MARKER( pxList )	( ( ListItem_t const * ) ( &( ( pxList )->xListEnd ) ) )

//链表空检查
#define listLIST_IS_EMPTY( pxList )	( ( ( pxList )->uxNumberOfItems == ( UBaseType_t ) 0 ) ? pdTRUE : pdFALSE )

//链表长度检查
#define listCURRENT_LIST_LENGTH( pxList )	( ( pxList )->uxNumberOfItems )

//获取当前链表的下一个对象
#define listGET_OWNER_OF_NEXT_ENTRY( pxTCB, pxList )										\
{																							\
List_t * const pxConstList = ( pxList );													\
    /*获取链表的下一个项*/                                                                           \
	( pxConstList )->pxIndex = ( pxConstList )->pxIndex->pxNext;							\
	if( ( void * ) ( pxConstList )->pxIndex == ( void * ) &( ( pxConstList )->xListEnd ) )	\
	{	/*如果下一个项是结尾时,那返回第一个项,对象指向结尾时调整到开头*/													\
		( pxConstList )->pxIndex = ( pxConstList )->pxIndex->pxNext;						\
	}	/*返回下一个项中的对象*/																		\
	( pxTCB ) = ( pxConstList )->pxIndex->pvOwner;											\
}


//获取链表的首项
#define listGET_OWNER_OF_HEAD_ENTRY( pxList )  ( (&( ( pxList )->xListEnd ))->pxNext->pvOwner )

//确认亲子关系
#define listIS_CONTAINED_WITHIN( pxList, pxListItem ) ( ( ( pxListItem )->pxContainer == ( pxList ) ) ? ( pdTRUE ) : ( pdFALSE ) )

//确认链表项的父亲(管理者)
#define listLIST_ITEM_CONTAINER( pxListItem ) ( ( pxListItem )->pxContainer )

//链表是否初始化
#define listLIST_IS_INITIALISED( pxList ) ( ( pxList )->xListEnd.xItemValue == portMAX_DELAY )

//链表初始化函数
void vListInitialise( List_t * const pxList ) PRIVILEGED_FUNCTION;

//链表项初始化函数
void vListInitialiseItem( ListItem_t * const pxItem ) PRIVILEGED_FUNCTION;

//链表中插入一个链表项
void vListInsert( List_t * const pxList, ListItem_t * const pxNewListItem ) PRIVILEGED_FUNCTION;

//链表项尾插
void vListInsertEnd( List_t * const pxList, ListItem_t * const pxNewListItem ) PRIVILEGED_FUNCTION;

//链表项的移除
UBaseType_t uxListRemove( ListItem_t * const pxItemToRemove ) PRIVILEGED_FUNCTION;

#ifdef __cplusplus
}
#endif

#endif

