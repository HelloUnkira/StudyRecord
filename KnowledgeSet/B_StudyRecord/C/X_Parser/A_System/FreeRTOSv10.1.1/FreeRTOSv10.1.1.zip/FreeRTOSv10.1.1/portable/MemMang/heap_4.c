/*
 * 堆
 */

#include <stdlib.h>

//接口重包含,提前定义一下用于屏蔽mpu_wappers.h造成的影响
#define MPU_WRAPPERS_INCLUDED_FROM_API_FILE

#include "FreeRTOS.h"
#include "task.h"

//取消重包含,因为已经没必要了
#undef MPU_WRAPPERS_INCLUDED_FROM_API_FILE

//必须定义动态内存分配
#if( configSUPPORT_DYNAMIC_ALLOCATION == 0 )
	#error This file must not be used if configSUPPORT_DYNAMIC_ALLOCATION is 0
#endif

//堆的最小尺寸
#define heapMINIMUM_BLOCK_SIZE	( ( size_t ) ( xHeapStructSize << 1 ) )

//一个字节为8位
#define heapBITS_PER_BYTE		( ( size_t ) 8 )

//动态分配堆
#if( configAPPLICATION_ALLOCATED_HEAP == 1 )
	extern uint8_t ucHeap[ configTOTAL_HEAP_SIZE ];	//如果堆是来源于外界
#else
	static uint8_t ucHeap[ configTOTAL_HEAP_SIZE ]; //否则堆来源于本地
#endif

//堆是依照(内存池)分配的空间,即链表串联连续地址空间的资源
typedef struct A_BLOCK_LINK
{
	struct A_BLOCK_LINK *pxNextFreeBlock;	//下一个空闲块
	size_t xBlockSize;						//空闲块的大小
} BlockLink_t;


//释放一个块并加入到链表集中,如果出现连续空间那么就合并它们
static void prvInsertBlockIntoFreeList( BlockLink_t *pxBlockToInsert );

//堆的初始化函数,因为这里是静态定义堆
static void prvHeapInit( void );

//一个堆结构的大小(维护所用),要进行字节对齐
static const size_t xHeapStructSize	= ( sizeof( BlockLink_t ) + ( ( size_t ) ( portBYTE_ALIGNMENT - 1 ) ) ) & ~( ( size_t ) portBYTE_ALIGNMENT_MASK );

//创建一对作为堆的起始位和结束位
static BlockLink_t xStart, *pxEnd = NULL;

//堆的空余空间
static size_t xFreeBytesRemaining = 0U;
static size_t xMinimumEverFreeBytesRemaining = 0U;

//使用标记位去确认空间是否被分配掉
static size_t xBlockAllocatedBit = 0;


//动态分配
void *pvPortMalloc( size_t xWantedSize )
{
BlockLink_t *pxBlock, *pxPreviousBlock, *pxNewBlockLink;
void *pvReturn = NULL;

	vTaskSuspendAll();//挂起所有任务
	{	//分配的尺寸为空
		if( pxEnd == NULL )
		{	//如果未初始化的话就做一次初始化
			prvHeapInit();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		if( ( xWantedSize & xBlockAllocatedBit ) == 0 )
		{
			if( xWantedSize > 0 )
			{	//合法性检查,添加对应的 堆维护部分
				xWantedSize += xHeapStructSize;
				if( ( xWantedSize & portBYTE_ALIGNMENT_MASK ) != 0x00 )
				{	//字节对齐检查
					xWantedSize += ( portBYTE_ALIGNMENT - ( xWantedSize & portBYTE_ALIGNMENT_MASK ) );
					configASSERT( ( xWantedSize & portBYTE_ALIGNMENT_MASK ) == 0 );
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
			//如果期望空间与剩余空间都达到要求值,分配它
			if( ( xWantedSize > 0 ) && ( xWantedSize <= xFreeBytesRemaining ) )
			{	//获取上一个块的位置
				pxPreviousBlock = &xStart;
				pxBlock = xStart.pxNextFreeBlock;//获取它的下一个空闲块的位置
				while( ( pxBlock->xBlockSize < xWantedSize ) && ( pxBlock->pxNextFreeBlock != NULL ) )
				{	//迭代查询,知道能找到一个满足需求的块或者找到末尾
					pxPreviousBlock = pxBlock;
					pxBlock = pxBlock->pxNextFreeBlock;
				}
				
				if( pxBlock != pxEnd )
				{	//如果成功找到了一个块,那么为返回做准备,返回时不能添加堆本身的维护数据
					pvReturn = ( void * ) ( ( ( uint8_t * ) pxPreviousBlock->pxNextFreeBlock ) + xHeapStructSize );
					//更新下一个空闲块的位置
					pxPreviousBlock->pxNextFreeBlock = pxBlock->pxNextFreeBlock;
					if( ( pxBlock->xBlockSize - xWantedSize ) > heapMINIMUM_BLOCK_SIZE )
					{	//堆太大了,分裂它
						pxNewBlockLink = ( void * ) ( ( ( uint8_t * ) pxBlock ) + xWantedSize );
						configASSERT( ( ( ( size_t ) pxNewBlockLink ) & portBYTE_ALIGNMENT_MASK ) == 0 );
						pxNewBlockLink->xBlockSize = pxBlock->xBlockSize - xWantedSize;
						pxBlock->xBlockSize = xWantedSize;
						//把剩余的部分插入到堆集里面
						prvInsertBlockIntoFreeList( pxNewBlockLink );
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					//更新剩余块的大小
					xFreeBytesRemaining -= pxBlock->xBlockSize;

					if( xFreeBytesRemaining < xMinimumEverFreeBytesRemaining )
					{	//如果剩余空间不足,打上标记
						xMinimumEverFreeBytesRemaining = xFreeBytesRemaining;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					//因为块大小是高对齐的,所以低位是空的
					//所以我们用低位做标记记录,这里使用1000 0000 第8位做记录
					pxBlock->xBlockSize |= xBlockAllocatedBit;
					pxBlock->pxNextFreeBlock = NULL;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		traceMALLOC( pvReturn, xWantedSize );
	}
	( void ) xTaskResumeAll();//任务恢复

	#if( configUSE_MALLOC_FAILED_HOOK == 1 )
	{
		if( pvReturn == NULL )
		{	//如果用户提供了 动态内存分配失败 的事件处理
			//执行它重写的回调钩子
			extern void vApplicationMallocFailedHook( void );
			vApplicationMallocFailedHook();
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	#endif

	configASSERT( ( ( ( size_t ) pvReturn ) & ( size_t ) portBYTE_ALIGNMENT_MASK ) == 0 );
	return pvReturn;
}

//动态释放
void vPortFree( void *pv )
{
uint8_t *puc = ( uint8_t * ) pv;
BlockLink_t *pxLink;
	if( pv != NULL )
	{	//区域非空时
		puc -= xHeapStructSize;//偏移到堆的起始位置,而不是数据的起始位置
		pxLink = ( void * ) puc;
		configASSERT( ( pxLink->xBlockSize & xBlockAllocatedBit ) != 0 );
		configASSERT( pxLink->pxNextFreeBlock == NULL );
		if( ( pxLink->xBlockSize & xBlockAllocatedBit ) != 0 )
		{	//该块被打上了非空闲标记
			if( pxLink->pxNextFreeBlock == NULL )
			{	//那就清空对应的标记
				pxLink->xBlockSize &= ~xBlockAllocatedBit;
				vTaskSuspendAll();//挂起全部任务
				{	//剩余空间记录
					xFreeBytesRemaining += pxLink->xBlockSize;
					traceFREE( pv, pxLink->xBlockSize );
					//加入到(内存池)中
					prvInsertBlockIntoFreeList( ( ( BlockLink_t * ) pxLink ) );
				}
				( void ) xTaskResumeAll();//恢复全部任务
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
}


//获得空余空间的大小
size_t xPortGetFreeHeapSize( void )
{
	return xFreeBytesRemaining;
}

//不允许分裂的最小块大小
size_t xPortGetMinimumEverFreeHeapSize( void )
{
	return xMinimumEverFreeBytesRemaining;
}

//块初始化
void vPortInitialiseBlocks( void )
{
}

//堆初始化
static void prvHeapInit( void )
{
BlockLink_t *pxFirstFreeBlock;
uint8_t *pucAlignedHeap;
size_t uxAddress;
size_t xTotalHeapSize = configTOTAL_HEAP_SIZE;
	//选定为堆的起始位置
	uxAddress = ( size_t ) ucHeap;

	if( ( uxAddress & portBYTE_ALIGNMENT_MASK ) != 0 )
	{	//字节对齐
		uxAddress += ( portBYTE_ALIGNMENT - 1 );
		uxAddress &= ~( ( size_t ) portBYTE_ALIGNMENT_MASK );
		xTotalHeapSize -= uxAddress - ( size_t ) ucHeap;
	}

	pucAlignedHeap = ( uint8_t * ) uxAddress;

	//定义开始位置
	xStart.pxNextFreeBlock = ( void * ) pucAlignedHeap;
	xStart.xBlockSize = ( size_t ) 0;

	//定义结束的位置
	uxAddress = ( ( size_t ) pucAlignedHeap ) + xTotalHeapSize;
	uxAddress -= xHeapStructSize;
	uxAddress &= ~( ( size_t ) portBYTE_ALIGNMENT_MASK );
	pxEnd = ( void * ) uxAddress;
	pxEnd->xBlockSize = 0;
	pxEnd->pxNextFreeBlock = NULL;

	pxFirstFreeBlock = ( void * ) pucAlignedHeap;
	pxFirstFreeBlock->xBlockSize = uxAddress - ( size_t ) pxFirstFreeBlock;
	pxFirstFreeBlock->pxNextFreeBlock = pxEnd;

	//初始化剩余空间的大小
	xMinimumEverFreeBytesRemaining = pxFirstFreeBlock->xBlockSize;
	xFreeBytesRemaining = pxFirstFreeBlock->xBlockSize;

	//选定分配位
	xBlockAllocatedBit = ( ( size_t ) 1 ) << ( ( sizeof( size_t ) * heapBITS_PER_BYTE ) - 1 );
}

static void prvInsertBlockIntoFreeList( BlockLink_t *pxBlockToInsert )
{
BlockLink_t *pxIterator;
uint8_t *puc;
	for( pxIterator = &xStart; pxIterator->pxNextFreeBlock < pxBlockToInsert; pxIterator = pxIterator->pxNextFreeBlock )
	{//迭代器,寻找到一个恰好空闲块地址比当前空闲块地址大的
	}
	puc = ( uint8_t * ) pxIterator;
	if( ( puc + pxIterator->xBlockSize ) == ( uint8_t * ) pxBlockToInsert )
	{	//插进去
		pxIterator->xBlockSize += pxBlockToInsert->xBlockSize;
		pxBlockToInsert = pxIterator;
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}

	puc = ( uint8_t * ) pxBlockToInsert;
	//如果是连续的空间的话,注意这里堆头直接无需释放,因为都是空余块,所以默认直接覆盖了
	if( ( puc + pxBlockToInsert->xBlockSize ) == ( uint8_t * ) pxIterator->pxNextFreeBlock )
	{
		if( pxIterator->pxNextFreeBlock != pxEnd )
		{	//现在将俩个块合并成一个块
			pxBlockToInsert->xBlockSize += pxIterator->pxNextFreeBlock->xBlockSize;
			pxBlockToInsert->pxNextFreeBlock = pxIterator->pxNextFreeBlock->pxNextFreeBlock;
		}
		else
		{
			pxBlockToInsert->pxNextFreeBlock = pxEnd;
		}
	}
	else
	{	//即使不能合并,前后的关联关系需要建立
		pxBlockToInsert->pxNextFreeBlock = pxIterator->pxNextFreeBlock;
	}

	if( pxIterator != pxBlockToInsert )
	{	//再进行前项连接
		pxIterator->pxNextFreeBlock = pxBlockToInsert;
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
}



