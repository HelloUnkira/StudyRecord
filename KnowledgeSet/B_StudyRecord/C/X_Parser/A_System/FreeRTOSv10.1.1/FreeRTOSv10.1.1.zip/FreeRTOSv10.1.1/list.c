/*
 * 数据结构之链表
 */


#include <stdlib.h>
#include "FreeRTOS.h"
#include "list.h"

//链表初始化
void vListInitialise( List_t * const pxList )
{   
    //链表默认没有项,所以指向链表尾
	pxList->pxIndex = ( ListItem_t * ) &( pxList->xListEnd );
    //链表尾初始化一个值表明链表被初始化了
	pxList->xListEnd.xItemValue = portMAX_DELAY;
    //链表尾轮番指向自己,所以最后会构建一个双向的循环链表
	pxList->xListEnd.pxNext = ( ListItem_t * ) &( pxList->xListEnd );
    pxList->xListEnd.pxPrevious = ( ListItem_t * ) &( pxList->xListEnd );
    //链表没有成员
	pxList->uxNumberOfItems = ( UBaseType_t ) 0U;
    //安全配置检查,将值设置为自己的地址
	listSET_LIST_INTEGRITY_CHECK_1_VALUE( pxList );
	listSET_LIST_INTEGRITY_CHECK_2_VALUE( pxList );
}

//链表项初始化
void vListInitialiseItem( ListItem_t * const pxItem )
{   
    //现在链表项未加入到链表中,所以不存在父节点
	pxItem->pxContainer = NULL;
    //安全配置检查
	listSET_FIRST_LIST_ITEM_INTEGRITY_CHECK_VALUE( pxItem );
	listSET_SECOND_LIST_ITEM_INTEGRITY_CHECK_VALUE( pxItem );
}

//链表尾插
void vListInsertEnd( List_t * const pxList, ListItem_t * const pxNewListItem )
{
    ListItem_t * const pxIndex = pxList->pxIndex;

    //该动作做安全检查,如果出现错误这里会写入到错误的区域
    listTEST_LIST_INTEGRITY( pxList );
	listTEST_LIST_ITEM_INTEGRITY( pxNewListItem );

    //链表项被尾插入最后,对影响项进行新的更定
	pxNewListItem->pxNext = pxIndex;
	pxNewListItem->pxPrevious = pxIndex->pxPrevious;

    //检查动作
    mtCOVERAGE_TEST_DELAY();

	pxIndex->pxPrevious->pxNext = pxNewListItem;
	pxIndex->pxPrevious = pxNewListItem;

	//如果项的成员进入到链表中,更新对应的父节点
	pxNewListItem->pxContainer = pxList;

	( pxList->uxNumberOfItems )++;
}

//链表项插入
void vListInsert( List_t * const pxList, ListItem_t * const pxNewListItem )
{
    ListItem_t *pxIterator;
    const TickType_t xValueOfInsertion = pxNewListItem->xItemValue;

	//安全检查
	listTEST_LIST_INTEGRITY( pxList );
	listTEST_LIST_ITEM_INTEGRITY( pxNewListItem );

    //最大延迟,直接尾插
	if( xValueOfInsertion == portMAX_DELAY )
	{
		pxIterator = pxList->xListEnd.pxPrevious;
	}
	else
	{
		for( pxIterator = ( ListItem_t * ) &( pxList->xListEnd ); pxIterator->pxNext->xItemValue <= xValueOfInsertion; pxIterator = pxIterator->pxNext ) 
        {//升序排列插入,将它插入到一个值比其大的前面      
		}
	}
    //插入到对应的节点之前,如果是首节点,那么首节点之前,就是最后一个位置
	pxNewListItem->pxNext = pxIterator->pxNext;
	pxNewListItem->pxNext->pxPrevious = pxNewListItem;
	pxNewListItem->pxPrevious = pxIterator;
	pxIterator->pxNext = pxNewListItem;
	//更新它的父亲
	pxNewListItem->pxContainer = pxList;
    //链表已经多了一项
	( pxList->uxNumberOfItems )++;
}

//移除链表的成员
UBaseType_t uxListRemove( ListItem_t * const pxItemToRemove )
{
    //寻找到项的父亲
    List_t * const pxList = pxItemToRemove->pxContainer;
    //将自己从链表中剥离出来
	pxItemToRemove->pxNext->pxPrevious = pxItemToRemove->pxPrevious;
	pxItemToRemove->pxPrevious->pxNext = pxItemToRemove->pxNext;
    //安全检查
    mtCOVERAGE_TEST_DELAY();

    //如果移除的是首项,更新一下指针
    if( pxList->pxIndex == pxItemToRemove )
	{   //自己并没有放弃对原链的关系
		pxList->pxIndex = pxItemToRemove->pxPrevious;
	}
	else
	{   //安全检查
		mtCOVERAGE_TEST_MARKER();
	}
    //清除指向的父节点,父节点项-1
	pxItemToRemove->pxContainer = NULL;
	( pxList->uxNumberOfItems )--;
    //返回父节点现有项
	return pxList->uxNumberOfItems;
}
/*-----------------------------------------------------------*/

