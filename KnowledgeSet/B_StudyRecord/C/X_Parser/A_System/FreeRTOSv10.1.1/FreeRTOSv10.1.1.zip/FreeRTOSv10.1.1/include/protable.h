/*
 * 操作系统对接的平台配置
 */

#ifndef PORTABLE_H
#define PORTABLE_H

//为预处理器提供准确的当前平台的路径支持
//以前需要设置编译器的include路径用以帮助寻找到portmacro.h平台配置文件
//只是保证向后兼容所以未将其移除
#include "deprecated_definitions.h"

//临界区保护未定义时,上述头文件的包括会使portmacro.h平台配置文件不被包括
#ifndef portENTER_CRITICAL
	#include "portmacro.h"
#endif

//检查当前平台使用的是哪一种字节对齐的方式,并配置相对应的掩码
//掩码在用于对任意地址进行字节对齐时很有帮助,只需要&(~mask)即可字节对齐
#if portBYTE_ALIGNMENT == 32
	#define portBYTE_ALIGNMENT_MASK ( 0x001f )
#endif
#if portBYTE_ALIGNMENT == 16
	#define portBYTE_ALIGNMENT_MASK ( 0x000f )
#endif
#if portBYTE_ALIGNMENT == 8
	#define portBYTE_ALIGNMENT_MASK ( 0x0007 )
#endif
#if portBYTE_ALIGNMENT == 4
	#define portBYTE_ALIGNMENT_MASK	( 0x0003 )
#endif
#if portBYTE_ALIGNMENT == 2
	#define portBYTE_ALIGNMENT_MASK	( 0x0001 )
#endif
#if portBYTE_ALIGNMENT == 1
	#define portBYTE_ALIGNMENT_MASK	( 0x0000 )
#endif
//未定义警告
#ifndef portBYTE_ALIGNMENT_MASK
	#error "Invalid portBYTE_ALIGNMENT definition"
#endif

//可配置区域的数量
#ifndef portNUM_CONFIGURABLE_REGIONS
	#define portNUM_CONFIGURABLE_REGIONS 1
#endif

//C++支持
#ifdef __cplusplus
extern "C" {
#endif

//MPU接口层的封装,使用宏定义进行封装
#include "mpu_wrappers.h"

//配置新任务的堆栈,平台封装,调度控制时的现场保护与还原都会使用到堆栈
#if( portUSING_MPU_WRAPPERS == 1 )
	StackType_t *pxPortInitialiseStack( StackType_t *pxTopOfStack, TaskFunction_t pxCode, void *pvParameters, BaseType_t xRunPrivileged ) PRIVILEGED_FUNCTION;
#else
	StackType_t *pxPortInitialiseStack( StackType_t *pxTopOfStack, TaskFunction_t pxCode, void *pvParameters ) PRIVILEGED_FUNCTION;
#endif


//被heap_5.c使用
typedef struct HeapRegion
{   //堆的起始地址,以及堆的大小
	uint8_t *pucStartAddress;
	size_t xSizeInBytes;
} HeapRegion_t;

//多个堆分配,被heap_5.c使用
void vPortDefineHeapRegions( const HeapRegion_t * const pxHeapRegions ) PRIVILEGED_FUNCTION;

//动态分配策略
void *pvPortMalloc( size_t xSize ) PRIVILEGED_FUNCTION;
void vPortFree( void *pv ) PRIVILEGED_FUNCTION;
void vPortInitialiseBlocks( void ) PRIVILEGED_FUNCTION;
size_t xPortGetFreeHeapSize( void ) PRIVILEGED_FUNCTION;
size_t xPortGetMinimumEverFreeHeapSize( void ) PRIVILEGED_FUNCTION;

//如果说操作系统的心脏是调度的话,那么调度的心脏是 时钟滴答中断,配置它
BaseType_t xPortStartScheduler( void ) PRIVILEGED_FUNCTION;

//上面配置的撤销
void vPortEndScheduler( void ) PRIVILEGED_FUNCTION;

//将平台的控制MPU的各个接口配置到指定位置
#if( portUSING_MPU_WRAPPERS == 1 )
	struct xMEMORY_REGION;
	void vPortStoreTaskMPUSettings( xMPU_SETTINGS *xMPUSettings, const struct xMEMORY_REGION * const xRegions, StackType_t *pxBottomOfStack, uint32_t ulStackDepth ) PRIVILEGED_FUNCTION;
#endif

#ifdef __cplusplus
}
#endif

#endif

