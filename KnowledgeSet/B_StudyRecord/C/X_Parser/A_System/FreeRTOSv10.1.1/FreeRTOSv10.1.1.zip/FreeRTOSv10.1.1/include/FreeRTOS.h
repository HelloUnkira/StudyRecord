/*
 * 学习使用,不做其他用途
 * 仅仅用于理解FreeRTOS
 */

#ifndef INC_FREERTOS_H
#define INC_FREERTOS_H

//系统文件
#include <stddef.h>
//系统文件,字长规定
#include <stdint.h> 

#ifdef __cplusplus
extern "C" {	//用于C++向下兼容C
#endif

//应用的裁剪配置文件,用于裁剪下述的和外部的内容
#include "FreeRTOSConfig.h"

//基础工程配置,错误码配置
#include "projdefs.h"

//平台配置,每一个实际的平台都有对应的配置文件
//所以具体根据事件平台的配置来做参考
#include "portable.h"

//可重用库的使用,默认不使用
#ifndef configUSE_NEWLIB_REENTRANT
	#define configUSE_NEWLIB_REENTRANT 0
#endif

//配置可重用库,导入
#if ( configUSE_NEWLIB_REENTRANT == 1 )
	#include <reent.h>
#endif

//下面是纠错检查

//用于检查各个参数的配置情况
#ifndef configMINIMAL_STACK_SIZE    //配置文件中未定义最小堆栈尺寸
	#error Missing definition:  configMINIMAL_STACK_SIZE must be defined in FreeRTOSConfig.h.  configMINIMAL_STACK_SIZE defines the size (in words) of the stack allocated to the idle task.  Refer to the demo project provided for your port for a suitable value.
#endif

#ifndef configMAX_PRIORITIES        //配置文件中未定义最大优先级
	#error Missing definition:  configMAX_PRIORITIES must be defined in FreeRTOSConfig.h.  See the Configuration section of the FreeRTOS API documentation for details.
#endif

#if configMAX_PRIORITIES < 1        //最大优先级定义太小
	#error configMAX_PRIORITIES must be defined to be greater than or equal to 1.
#endif

#ifndef configUSE_PREEMPTION        //未定义抢占
	#error Missing definition:  configUSE_PREEMPTION must be defined in FreeRTOSConfig.h as either 1 or 0.  See the Configuration section of the FreeRTOS API documentation for details.
#endif

#ifndef configUSE_IDLE_HOOK         //未定义空闲钩子(回调)
	#error Missing definition:  configUSE_IDLE_HOOK must be defined in FreeRTOSConfig.h as either 1 or 0.  See the Configuration section of the FreeRTOS API documentation for details.
#endif

#ifndef configUSE_TICK_HOOK         //未定义时钟滴答钩子(回调)
	#error Missing definition:  configUSE_TICK_HOOK must be defined in FreeRTOSConfig.h as either 1 or 0.  See the Configuration section of the FreeRTOS API documentation for details.
#endif

#ifndef configUSE_16_BIT_TICKS      //未定义十六位位长的时钟滴答钩子
	#error Missing definition:  configUSE_16_BIT_TICKS must be defined in FreeRTOSConfig.h as either 1 or 0.  See the Configuration section of the FreeRTOS API documentation for details.
#endif


//下面是一些功能配置
#ifndef configUSE_CO_ROUTINES       //协程开启与关闭
	#define configUSE_CO_ROUTINES 0
#endif
#ifndef INCLUDE_vTaskPrioritySet    //任务优先级设置
	#define INCLUDE_vTaskPrioritySet 0
#endif
#ifndef INCLUDE_uxTaskPriorityGet   //任务优先级获取
	#define INCLUDE_uxTaskPriorityGet 0
#endif
#ifndef INCLUDE_vTaskDelete         //任务删除
	#define INCLUDE_vTaskDelete 0
#endif
#ifndef INCLUDE_vTaskSuspend        //任务挂起
	#define INCLUDE_vTaskSuspend 0
#endif
#ifndef INCLUDE_vTaskDelayUntil     //任务延时的到达
	#define INCLUDE_vTaskDelayUntil 0
#endif
#ifndef INCLUDE_vTaskDelay          //任务延时
	#define INCLUDE_vTaskDelay 0
#endif
                                    //获取空闲任务句柄
#ifndef INCLUDE_xTaskGetIdleTaskHandle
	#define INCLUDE_xTaskGetIdleTaskHandle 0
#endif
#ifndef INCLUDE_xTaskAbortDelay     //延时停止
	#define INCLUDE_xTaskAbortDelay 0
#endif
#ifndef INCLUDE_xQueueGetMutexHolder//队列获取互斥锁所有权
	#define INCLUDE_xQueueGetMutexHolder 0
#endif
                                    //信号量获取互斥锁所有权
#ifndef INCLUDE_xSemaphoreGetMutexHolder
	#define INCLUDE_xSemaphoreGetMutexHolder INCLUDE_xQueueGetMutexHolder
#endif
#ifndef INCLUDE_xTaskGetHandle      //句柄获取
	#define INCLUDE_xTaskGetHandle 0
#endif
                                    //获取堆栈掩码(可能是求堆栈起始或结束位所用)
#ifndef INCLUDE_uxTaskGetStackHighWaterMark
	#define INCLUDE_uxTaskGetStackHighWaterMark 0
#endif
#ifndef INCLUDE_eTaskGetState       //任务状态获取
	#define INCLUDE_eTaskGetState 0
#endif
#ifndef INCLUDE_xTaskResumeFromISR //中断环境下任务恢复
	#define INCLUDE_xTaskResumeFromISR 1
#endif
                                    //定时器挂起(溢出？)功能回调
#ifndef INCLUDE_xTimerPendFunctionCall
	#define INCLUDE_xTimerPendFunctionCall 0
#endif
                                    //获取调度器状态
#ifndef INCLUDE_xTaskGetSchedulerState
	#define INCLUDE_xTaskGetSchedulerState 0
#endif
                                    //获取当前运行的任务句柄
#ifndef INCLUDE_xTaskGetCurrentTaskHandle
	#define INCLUDE_xTaskGetCurrentTaskHandle 0
#endif

#if configUSE_CO_ROUTINES != 0      //协程被默认是使用的话
                                    //需要默认指定协程优先级
	#ifndef configMAX_CO_ROUTINE_PRIORITIES
		#error configMAX_CO_ROUTINE_PRIORITIES must be greater than or equal to 1.
	#endif
#endif
                                    //使用后台守护任务的钩子
#ifndef configUSE_DAEMON_TASK_STARTUP_HOOK
	#define configUSE_DAEMON_TASK_STARTUP_HOOK 0
#endif
                                    //使用APP任务标记
#ifndef configUSE_APPLICATION_TASK_TAG
	#define configUSE_APPLICATION_TASK_TAG 0
#endif
                                    //线程本地存储的地址数量
#ifndef configNUM_THREAD_LOCAL_STORAGE_POINTERS
	#define configNUM_THREAD_LOCAL_STORAGE_POINTERS 0
#endif
#ifndef configUSE_RECURSIVE_MUTEXES //嵌套互斥的使用
	#define configUSE_RECURSIVE_MUTEXES 0
#endif
#ifndef configUSE_MUTEXES           //互斥锁的使用
	#define configUSE_MUTEXES 0
#endif
#ifndef configUSE_TIMERS            //定时器的使用
	#define configUSE_TIMERS 0
#endif
                                    //信号量的使用
#ifndef configUSE_COUNTING_SEMAPHORES
	#define configUSE_COUNTING_SEMAPHORES 0
#endif
                                    //应用接口重选
#ifndef configUSE_ALTERNATIVE_API
	#define configUSE_ALTERNATIVE_API 0
#endif
#ifndef portCRITICAL_NESTING_IN_TCB //临界区嵌入程序控制块
	#define portCRITICAL_NESTING_IN_TCB 0
#endif
#ifndef configMAX_TASK_NAME_LEN     //任务名长度最大值
	#define configMAX_TASK_NAME_LEN 16
#endif
#ifndef configIDLE_SHOULD_YIELD     //空闲时进行任务切换
	#define configIDLE_SHOULD_YIELD		1
#endif
#if configMAX_TASK_NAME_LEN < 1     //任务名字长度
	#error configMAX_TASK_NAME_LEN must be set to a minimum of 1 in FreeRTOSConfig.h
#endif

#ifndef configASSERT                //断言的配置
	#define configASSERT( x )
	#define configASSERT_DEFINED 0
#else
	#define configASSERT_DEFINED 1
#endif

#if configUSE_TIMERS == 1           //定时器使用,以下参数需要定义,但可以不使用(裁剪)
                                    //时钟任务优先级
	#ifndef configTIMER_TASK_PRIORITY
		#error If configUSE_TIMERS is set to 1 then configTIMER_TASK_PRIORITY must also be defined.
	#endif
	#ifndef configTIMER_QUEUE_LENGTH//时钟队列长度
		#error If configUSE_TIMERS is set to 1 then configTIMER_QUEUE_LENGTH must also be defined.
	#endif
                                    //定时器任务堆栈深度
	#ifndef configTIMER_TASK_STACK_DEPTH
		#error If configUSE_TIMERS is set to 1 then configTIMER_TASK_STACK_DEPTH must also be defined.
	#endif
#endif 

//与平台有关的接口,向下兼容
                                    //设置中断掩码,在中断环境下
#ifndef portSET_INTERRUPT_MASK_FROM_ISR
	#define portSET_INTERRUPT_MASK_FROM_ISR() 0
#endif
                                    //配置中断掩码,在中断环境下
#ifndef portCLEAR_INTERRUPT_MASK_FROM_ISR
	#define portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedStatusValue ) ( void ) uxSavedStatusValue
#endif
#ifndef portCLEAN_UP_TCB            //清除程序控制块
	#define portCLEAN_UP_TCB( pxTCB ) ( void ) pxTCB
#endif
#ifndef portPRE_TASK_DELETE_HOOK    //前任务删除钩子
	#define portPRE_TASK_DELETE_HOOK( pvTaskToDelete, pxYieldPending )
#endif
#ifndef portSETUP_TCB               //设置程序控制块
	#define portSETUP_TCB( pxTCB ) ( void ) pxTCB
#endif
#ifndef configQUEUE_REGISTRY_SIZE   //队列注册长度
	#define configQUEUE_REGISTRY_SIZE 0U
#endif
                                    //队列长度
#if ( configQUEUE_REGISTRY_SIZE < 1 )
	#define vQueueAddToRegistry( xQueue, pcName )
	#define vQueueUnregisterQueue( xQueue )
	#define pcQueueGetName( xQueue )
#endif

#ifndef portPOINTER_SIZE_TYPE
	#define portPOINTER_SIZE_TYPE uint32_t
#endif

//宏的裁剪定义
#ifndef traceSTART                  //启动追踪宏
    #define traceSTART()
#endif
#ifndef traceEND                    //关闭追踪宏
	#define traceEND()
#endif
#ifndef traceTASK_SWITCHED_IN       //任务切换追踪开始
	#define traceTASK_SWITCHED_IN()
#endif
#ifndef traceINCREASE_TICK_COUNT    //递减滴答数追踪
	#define traceINCREASE_TICK_COUNT( x )
#endif
#ifndef traceLOW_POWER_IDLE_BEGIN   //低电量空闲任务开始
	#define traceLOW_POWER_IDLE_BEGIN()
#endif
#ifndef	traceLOW_POWER_IDLE_END     //低电量空闲任务结束
	#define traceLOW_POWER_IDLE_END()
#endif

#ifndef traceTASK_SWITCHED_OUT      //任务切换追踪退出
	#define traceTASK_SWITCHED_OUT()
#endif
#ifndef traceTASK_PRIORITY_INHERIT  //优先级继承
	#define traceTASK_PRIORITY_INHERIT( pxTCBOfMutexHolder, uxInheritedPriority )
#endif
                                    //优先级还原
#ifndef traceTASK_PRIORITY_DISINHERIT
	#define traceTASK_PRIORITY_DISINHERIT( pxTCBOfMutexHolder, uxOriginalPriority )
#endif
                                    //读取队列尝试,阻塞？
#ifndef traceBLOCKING_ON_QUEUE_RECEIVE
	#define traceBLOCKING_ON_QUEUE_RECEIVE( pxQueue )
#endif
#ifndef traceBLOCKING_ON_QUEUE_PEEK //读取队列尝试
	#define traceBLOCKING_ON_QUEUE_PEEK( pxQueue )
#endif
#ifndef traceBLOCKING_ON_QUEUE_SEND //读取队列尝试,阻塞？
	#define traceBLOCKING_ON_QUEUE_SEND( pxQueue )
#endif

                                    //栈溢出检查
#ifndef configCHECK_FOR_STACK_OVERFLOW
	#define configCHECK_FOR_STACK_OVERFLOW 0
#endif
                                    //栈高地址记录(栈顶或栈底)
#ifndef configRECORD_STACK_HIGH_ADDRESS
	#define configRECORD_STACK_HIGH_ADDRESS 0
#endif
                                    //C++？
#ifndef configINCLUDE_FREERTOS_TASK_C_ADDITIONS_H
	#define configINCLUDE_FREERTOS_TASK_C_ADDITIONS_H 0
#endif

                                    //任务状态检查最终
#ifndef traceMOVED_TASK_TO_READY_STATE
	#define traceMOVED_TASK_TO_READY_STATE( pxTCB )
#endif
#ifndef tracePOST_MOVED_TASK_TO_READY_STATE
	#define tracePOST_MOVED_TASK_TO_READY_STATE( pxTCB )
#endif
                                    //队列检查
#ifndef traceQUEUE_CREATE
	#define traceQUEUE_CREATE( pxNewQueue )
#endif
#ifndef traceQUEUE_CREATE_FAILED
	#define traceQUEUE_CREATE_FAILED( ucQueueType )
#endif
                                    //互斥锁检查
#ifndef traceCREATE_MUTEX
	#define traceCREATE_MUTEX( pxNewQueue )
#endif
#ifndef traceCREATE_MUTEX_FAILED
	#define traceCREATE_MUTEX_FAILED()
#endif
#ifndef traceGIVE_MUTEX_RECURSIVE
	#define traceGIVE_MUTEX_RECURSIVE( pxMutex )
#endif
#ifndef traceGIVE_MUTEX_RECURSIVE_FAILED
	#define traceGIVE_MUTEX_RECURSIVE_FAILED( pxMutex )
#endif
#ifndef traceTAKE_MUTEX_RECURSIVE
	#define traceTAKE_MUTEX_RECURSIVE( pxMutex )
#endif
#ifndef traceTAKE_MUTEX_RECURSIVE_FAILED
	#define traceTAKE_MUTEX_RECURSIVE_FAILED( pxMutex )
#endif
                                    //信号量检查
#ifndef traceCREATE_COUNTING_SEMAPHORE
	#define traceCREATE_COUNTING_SEMAPHORE()
#endif
#ifndef traceCREATE_COUNTING_SEMAPHORE_FAILED
	#define traceCREATE_COUNTING_SEMAPHORE_FAILED()
#endif
                                    //队列检查
#ifndef traceQUEUE_SEND
	#define traceQUEUE_SEND( pxQueue )
#endif
#ifndef traceQUEUE_SEND_FAILED
	#define traceQUEUE_SEND_FAILED( pxQueue )
#endif
#ifndef traceQUEUE_RECEIVE
	#define traceQUEUE_RECEIVE( pxQueue )
#endif
#ifndef traceQUEUE_PEEK
	#define traceQUEUE_PEEK( pxQueue )
#endif
#ifndef traceQUEUE_PEEK_FAILED
	#define traceQUEUE_PEEK_FAILED( pxQueue )
#endif
#ifndef traceQUEUE_PEEK_FROM_ISR
	#define traceQUEUE_PEEK_FROM_ISR( pxQueue )
#endif
#ifndef traceQUEUE_RECEIVE_FAILED
	#define traceQUEUE_RECEIVE_FAILED( pxQueue )
#endif
#ifndef traceQUEUE_SEND_FROM_ISR
	#define traceQUEUE_SEND_FROM_ISR( pxQueue )
#endif
#ifndef traceQUEUE_SEND_FROM_ISR_FAILED
	#define traceQUEUE_SEND_FROM_ISR_FAILED( pxQueue )
#endif
#ifndef traceQUEUE_RECEIVE_FROM_ISR
	#define traceQUEUE_RECEIVE_FROM_ISR( pxQueue )
#endif
#ifndef traceQUEUE_RECEIVE_FROM_ISR_FAILED
	#define traceQUEUE_RECEIVE_FROM_ISR_FAILED( pxQueue )
#endif
#ifndef traceQUEUE_PEEK_FROM_ISR_FAILED
	#define traceQUEUE_PEEK_FROM_ISR_FAILED( pxQueue )
#endif
#ifndef traceQUEUE_DELETE
	#define traceQUEUE_DELETE( pxQueue )
#endif
                                    //任务检查
#ifndef traceTASK_CREATE
	#define traceTASK_CREATE( pxNewTCB )
#endif
#ifndef traceTASK_CREATE_FAILED
	#define traceTASK_CREATE_FAILED()
#endif
#ifndef traceTASK_DELETE
	#define traceTASK_DELETE( pxTaskToDelete )
#endif
#ifndef traceTASK_DELAY_UNTIL
	#define traceTASK_DELAY_UNTIL( x )
#endif
#ifndef traceTASK_DELAY
	#define traceTASK_DELAY()
#endif
#ifndef traceTASK_PRIORITY_SET
	#define traceTASK_PRIORITY_SET( pxTask, uxNewPriority )
#endif
#ifndef traceTASK_SUSPEND
	#define traceTASK_SUSPEND( pxTaskToSuspend )
#endif
#ifndef traceTASK_RESUME
	#define traceTASK_RESUME( pxTaskToResume )
#endif
#ifndef traceTASK_RESUME_FROM_ISR
	#define traceTASK_RESUME_FROM_ISR( pxTaskToResume )
#endif
#ifndef traceTASK_INCREMENT_TICK
	#define traceTASK_INCREMENT_TICK( xTickCount )
#endif
                                    //定时器检查
#ifndef traceTIMER_CREATE
	#define traceTIMER_CREATE( pxNewTimer )
#endif
#ifndef traceTIMER_CREATE_FAILED
	#define traceTIMER_CREATE_FAILED()
#endif
#ifndef traceTIMER_COMMAND_SEND
	#define traceTIMER_COMMAND_SEND( xTimer, xMessageID, xMessageValueValue, xReturn )
#endif
#ifndef traceTIMER_EXPIRED
	#define traceTIMER_EXPIRED( pxTimer )
#endif
#ifndef traceTIMER_COMMAND_RECEIVED
	#define traceTIMER_COMMAND_RECEIVED( pxTimer, xMessageID, xMessageValue )
#endif
                                    //动态内存分配
#ifndef traceMALLOC
    #define traceMALLOC( pvAddress, uiSize )
#endif
#ifndef traceFREE
    #define traceFREE( pvAddress, uiSize )
#endif
                                    //事件组
#ifndef traceEVENT_GROUP_CREATE
	#define traceEVENT_GROUP_CREATE( xEventGroup )
#endif
#ifndef traceEVENT_GROUP_CREATE_FAILED
	#define traceEVENT_GROUP_CREATE_FAILED()
#endif
#ifndef traceEVENT_GROUP_SYNC_BLOCK
	#define traceEVENT_GROUP_SYNC_BLOCK( xEventGroup, uxBitsToSet, uxBitsToWaitFor )
#endif
#ifndef traceEVENT_GROUP_SYNC_END
	#define traceEVENT_GROUP_SYNC_END( xEventGroup, uxBitsToSet, uxBitsToWaitFor, xTimeoutOccurred ) ( void ) xTimeoutOccurred
#endif
#ifndef traceEVENT_GROUP_WAIT_BITS_BLOCK
	#define traceEVENT_GROUP_WAIT_BITS_BLOCK( xEventGroup, uxBitsToWaitFor )
#endif
#ifndef traceEVENT_GROUP_WAIT_BITS_END
	#define traceEVENT_GROUP_WAIT_BITS_END( xEventGroup, uxBitsToWaitFor, xTimeoutOccurred ) ( void ) xTimeoutOccurred
#endif
#ifndef traceEVENT_GROUP_CLEAR_BITS
	#define traceEVENT_GROUP_CLEAR_BITS( xEventGroup, uxBitsToClear )
#endif
#ifndef traceEVENT_GROUP_CLEAR_BITS_FROM_ISR
	#define traceEVENT_GROUP_CLEAR_BITS_FROM_ISR( xEventGroup, uxBitsToClear )
#endif
#ifndef traceEVENT_GROUP_SET_BITS
	#define traceEVENT_GROUP_SET_BITS( xEventGroup, uxBitsToSet )
#endif
#ifndef traceEVENT_GROUP_SET_BITS_FROM_ISR
	#define traceEVENT_GROUP_SET_BITS_FROM_ISR( xEventGroup, uxBitsToSet )
#endif
#ifndef traceEVENT_GROUP_DELETE
	#define traceEVENT_GROUP_DELETE( xEventGroup )
#endif
                                    //回调挂起
#ifndef tracePEND_FUNC_CALL
	#define tracePEND_FUNC_CALL(xFunctionToPend, pvParameter1, ulParameter2, ret)
#endif
#ifndef tracePEND_FUNC_CALL_FROM_ISR
	#define tracePEND_FUNC_CALL_FROM_ISR(xFunctionToPend, pvParameter1, ulParameter2, ret)
#endif
                                    //队列
#ifndef traceQUEUE_REGISTRY_ADD
	#define traceQUEUE_REGISTRY_ADD(xQueue, pcQueueName)
#endif
                                    //任务通知
#ifndef traceTASK_NOTIFY_TAKE_BLOCK
	#define traceTASK_NOTIFY_TAKE_BLOCK()
#endif
#ifndef traceTASK_NOTIFY_TAKE
	#define traceTASK_NOTIFY_TAKE()
#endif
#ifndef traceTASK_NOTIFY_WAIT_BLOCK
	#define traceTASK_NOTIFY_WAIT_BLOCK()
#endif
#ifndef traceTASK_NOTIFY_WAIT
	#define traceTASK_NOTIFY_WAIT()
#endif
#ifndef traceTASK_NOTIFY
	#define traceTASK_NOTIFY()
#endif
#ifndef traceTASK_NOTIFY_FROM_ISR
	#define traceTASK_NOTIFY_FROM_ISR()
#endif
#ifndef traceTASK_NOTIFY_GIVE_FROM_ISR
	#define traceTASK_NOTIFY_GIVE_FROM_ISR()
#endif
                                    //流缓冲
#ifndef traceSTREAM_BUFFER_CREATE_FAILED
	#define traceSTREAM_BUFFER_CREATE_FAILED( xIsMessageBuffer )
#endif
#ifndef traceSTREAM_BUFFER_CREATE_STATIC_FAILED
	#define traceSTREAM_BUFFER_CREATE_STATIC_FAILED( xReturn, xIsMessageBuffer )
#endif
#ifndef traceSTREAM_BUFFER_CREATE
	#define traceSTREAM_BUFFER_CREATE( pxStreamBuffer, xIsMessageBuffer )
#endif
#ifndef traceSTREAM_BUFFER_DELETE
	#define traceSTREAM_BUFFER_DELETE( xStreamBuffer )
#endif
#ifndef traceSTREAM_BUFFER_RESET
	#define traceSTREAM_BUFFER_RESET( xStreamBuffer )
#endif
#ifndef traceBLOCKING_ON_STREAM_BUFFER_SEND
	#define traceBLOCKING_ON_STREAM_BUFFER_SEND( xStreamBuffer )
#endif
#ifndef traceSTREAM_BUFFER_SEND
	#define traceSTREAM_BUFFER_SEND( xStreamBuffer, xBytesSent )
#endif
#ifndef traceSTREAM_BUFFER_SEND_FAILED
	#define traceSTREAM_BUFFER_SEND_FAILED( xStreamBuffer )
#endif
#ifndef traceSTREAM_BUFFER_SEND_FROM_ISR
	#define traceSTREAM_BUFFER_SEND_FROM_ISR( xStreamBuffer, xBytesSent )
#endif
#ifndef traceBLOCKING_ON_STREAM_BUFFER_RECEIVE
	#define traceBLOCKING_ON_STREAM_BUFFER_RECEIVE( xStreamBuffer )
#endif
#ifndef traceSTREAM_BUFFER_RECEIVE
	#define traceSTREAM_BUFFER_RECEIVE( xStreamBuffer, xReceivedLength )
#endif
#ifndef traceSTREAM_BUFFER_RECEIVE_FAILED
	#define traceSTREAM_BUFFER_RECEIVE_FAILED( xStreamBuffer )
#endif
#ifndef traceSTREAM_BUFFER_RECEIVE_FROM_ISR
	#define traceSTREAM_BUFFER_RECEIVE_FROM_ISR( xStreamBuffer, xReceivedLength )
#endif
                                    //生成运行时钟
#ifndef configGENERATE_RUN_TIME_STATS
	#define configGENERATE_RUN_TIME_STATS 0
#endif
//获取平台支持,因为它涉及到底层
#if ( configGENERATE_RUN_TIME_STATS == 1 )
	#ifndef portCONFIGURE_TIMER_FOR_RUN_TIME_STATS
		#error If configGENERATE_RUN_TIME_STATS is defined then portCONFIGURE_TIMER_FOR_RUN_TIME_STATS must also be defined.  portCONFIGURE_TIMER_FOR_RUN_TIME_STATS should call a port layer function to setup a peripheral timer/counter that can then be used as the run time counter time base.
	#endif
	#ifndef portGET_RUN_TIME_COUNTER_VALUE
		#ifndef portALT_GET_RUN_TIME_COUNTER_VALUE
			#error If configGENERATE_RUN_TIME_STATS is defined then either portGET_RUN_TIME_COUNTER_VALUE or portALT_GET_RUN_TIME_COUNTER_VALUE must also be defined.  See the examples provided and the FreeRTOS web site for more information.
		#endif
    #endif
#endif

#ifndef portCONFIGURE_TIMER_FOR_RUN_TIME_STATS
	#define portCONFIGURE_TIMER_FOR_RUN_TIME_STATS()
#endif
#ifndef configUSE_MALLOC_FAILED_HOOK//内存分配失败的处理
	#define configUSE_MALLOC_FAILED_HOOK 0
#endif
#ifndef portPRIVILEGE_BIT           //优先位设置
	#define portPRIVILEGE_BIT ( ( UBaseType_t ) 0x00 )
#endif
#ifndef portYIELD_WITHIN_API        //任务切换
	#define portYIELD_WITHIN_API portYIELD
#endif
#ifndef portSUPPRESS_TICKS_AND_SLEEP//终止时钟滴答且睡眠
	#define portSUPPRESS_TICKS_AND_SLEEP( xExpectedIdleTime )
#endif
                                    //过期空闲时钟,睡眠之前
#ifndef configEXPECTED_IDLE_TIME_BEFORE_SLEEP
	#define configEXPECTED_IDLE_TIME_BEFORE_SLEEP 2
#endif
#if configEXPECTED_IDLE_TIME_BEFORE_SLEEP < 2
	#error configEXPECTED_IDLE_TIME_BEFORE_SLEEP must not be less than 2
#endif
#ifndef configUSE_TICKLESS_IDLE
	#define configUSE_TICKLESS_IDLE 0
#endif
#ifndef configPRE_SUPPRESS_TICKS_AND_SLEEP_PROCESSING
	#define configPRE_SUPPRESS_TICKS_AND_SLEEP_PROCESSING( x )
#endif
#ifndef configPRE_SLEEP_PROCESSING
	#define configPRE_SLEEP_PROCESSING( x )
#endif
#ifndef configPOST_SLEEP_PROCESSING
	#define configPOST_SLEEP_PROCESSING( x )
#endif

#ifndef configUSE_QUEUE_SETS        //队列设置
	#define configUSE_QUEUE_SETS 0
#endif
#ifndef portTASK_USES_FLOATING_POINT//任务中使用到浮点数指针
	#define portTASK_USES_FLOATING_POINT()
#endif
                                    //平台提供的安全机制
#ifndef portTASK_CALLS_SECURE_FUNCTIONS
	#define portTASK_CALLS_SECURE_FUNCTIONS()
#endif
#ifndef configUSE_TIME_SLICING      //时间片轮转
	#define configUSE_TIME_SLICING 1
#endif
                                    //APP定义的特权函数
#ifndef configINCLUDE_APPLICATION_DEFINED_PRIVILEGED_FUNCTIONS
	#define configINCLUDE_APPLICATION_DEFINED_PRIVILEGED_FUNCTIONS 0
#endif
#ifndef configUSE_STATS_FORMATTING_FUNCTIONS
	#define configUSE_STATS_FORMATTING_FUNCTIONS 0
#endif
                                    //中断优先级禁用断言
#ifndef portASSERT_IF_INTERRUPT_PRIORITY_INVALID
	#define portASSERT_IF_INTERRUPT_PRIORITY_INVALID()
#endif
#ifndef configUSE_TRACE_FACILITY    //安全追踪
	#define configUSE_TRACE_FACILITY 0//遇到该宏表明代码部是用于调试所用
#endif

#ifndef mtCOVERAGE_TEST_MARKER
	#define mtCOVERAGE_TEST_MARKER()
#endif
#ifndef mtCOVERAGE_TEST_DELAY
	#define mtCOVERAGE_TEST_DELAY()
#endif

#ifndef portASSERT_IF_IN_ISR        //中断内断言
	#define portASSERT_IF_IN_ISR()
#endif
                                    //平台优化？
#ifndef configUSE_PORT_OPTIMISED_TASK_SELECTION
	#define configUSE_PORT_OPTIMISED_TASK_SELECTION 0
#endif
                                    //应用层动态内存堆分配
#ifndef configAPPLICATION_ALLOCATED_HEAP
	#define configAPPLICATION_ALLOCATED_HEAP 0
#endif
#ifndef configUSE_TASK_NOTIFICATIONS//任务通知
	#define configUSE_TASK_NOTIFICATIONS 1
#endif
#ifndef configUSE_POSIX_ERRNO       //跨平台错误码
	#define configUSE_POSIX_ERRNO 0
#endif
#ifndef portTICK_TYPE_IS_ATOMIC     //滴答类型为原子级(不可被打断)
	#define portTICK_TYPE_IS_ATOMIC 0
#endif
                                    //静态ALLOC支持(内存分配)
#ifndef configSUPPORT_STATIC_ALLOCATION
	#define configSUPPORT_STATIC_ALLOCATION 0
#endif
                                    //动态ALLOC支持
#ifndef configSUPPORT_DYNAMIC_ALLOCATION
	#define configSUPPORT_DYNAMIC_ALLOCATION 1
#endif
#ifndef configSTACK_DEPTH_TYPE      //堆栈位深,可自配置,在config中
	#define configSTACK_DEPTH_TYPE uint16_t
#endif
                                    //消息缓冲长度
#ifndef configMESSAGE_BUFFER_LENGTH_TYPE
	#define configMESSAGE_BUFFER_LENGTH_TYPE size_t
#endif
#if( configUSE_TICKLESS_IDLE != 0 ) //使用空闲滴答衰减,终止任务挂起是
	#if( INCLUDE_vTaskSuspend != 1 )
		#error INCLUDE_vTaskSuspend must be set to 1 if configUSE_TICKLESS_IDLE is not set to 0
	#endif
#endif
                                    //静态内存分配和动态内存分配不可以都为0
#if( ( configSUPPORT_STATIC_ALLOCATION == 0 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 0 ) )
	#error configSUPPORT_STATIC_ALLOCATION and configSUPPORT_DYNAMIC_ALLOCATION cannot both be 0, but can both be 1.
#endif
                                    //基本互斥锁是嵌套互斥锁的先决条件
#if( ( configUSE_RECURSIVE_MUTEXES == 1 ) && ( configUSE_MUTEXES != 1 ) )
	#error configUSE_MUTEXES must be set to 1 to use recursive mutexes
#endif
#ifndef configINITIAL_TICK_COUNT    //初始化的滴答数
	#define configINITIAL_TICK_COUNT 0
#endif

#if( portTICK_TYPE_IS_ATOMIC == 0 ) //滴答类型不是原子级(指令集的执行怎么都打断不了时,该部分的集合为原子级)
                                    //那么提供临界区保护,要求获得平台的中断控制权限
	#define portTICK_TYPE_ENTER_CRITICAL() portENTER_CRITICAL()
	#define portTICK_TYPE_EXIT_CRITICAL() portEXIT_CRITICAL()
	#define portTICK_TYPE_SET_INTERRUPT_MASK_FROM_ISR() portSET_INTERRUPT_MASK_FROM_ISR()
	#define portTICK_TYPE_CLEAR_INTERRUPT_MASK_FROM_ISR( x ) portCLEAR_INTERRUPT_MASK_FROM_ISR( ( x ) )
#else                               //此时无需保护,因为执行是原子态,可以放心使用
	#define portTICK_TYPE_ENTER_CRITICAL()
	#define portTICK_TYPE_EXIT_CRITICAL()
	#define portTICK_TYPE_SET_INTERRUPT_MASK_FROM_ISR() 0
	#define portTICK_TYPE_CLEAR_INTERRUPT_MASK_FROM_ISR( x ) ( void ) x
#endif

                                    //版本兼容,意味着之后版本中被舍弃或修改的动作
                                    //依然会被认可
#ifndef configENABLE_BACKWARD_COMPATIBILITY
	#define configENABLE_BACKWARD_COMPATIBILITY 1
#endif

#ifndef configPRINTF                //printf打印,未定义时默认为空语句
	#define configPRINTF( X )
#endif
#ifndef configMAX                   //最大值
	#define configMAX( a, b ) ( ( ( a ) > ( b ) ) ? ( a ) : ( b ) )
#endif
#ifndef configMIN                   //最小值
	#define configMIN( a, b ) ( ( ( a ) < ( b ) ) ? ( a ) : ( b ) )
#endif
                                    //兼容配置时
                                    //对某些函数和宏进行重名,那么之后的版本会全部回退到之前
                                    //保证执行的统一与应用层兼容,但是之后的版本动作是不会被回退的
#if configENABLE_BACKWARD_COMPATIBILITY == 1
	#define eTaskStateGet eTaskGetState
	#define portTickType TickType_t
	#define xTaskHandle TaskHandle_t
	#define xQueueHandle QueueHandle_t
	#define xSemaphoreHandle SemaphoreHandle_t
	#define xQueueSetHandle QueueSetHandle_t
	#define xQueueSetMemberHandle QueueSetMemberHandle_t
	#define xTimeOutType TimeOut_t
	#define xMemoryRegion MemoryRegion_t
	#define xTaskParameters TaskParameters_t
	#define xTaskStatusType	TaskStatus_t
	#define xTimerHandle TimerHandle_t
	#define xCoRoutineHandle CoRoutineHandle_t
	#define pdTASK_HOOK_CODE TaskHookFunction_t
	#define portTICK_RATE_MS portTICK_PERIOD_MS
	#define pcTaskGetTaskName pcTaskGetName
	#define pcTimerGetTimerName pcTimerGetName
	#define pcQueueGetQueueName pcQueueGetName
	#define vTaskGetTaskInfo vTaskGetInfo

	#define tmrTIMER_CALLBACK TimerCallbackFunction_t
	#define pdTASK_CODE TaskFunction_t
	#define xListItem ListItem_t
	#define xList List_t

	#define pxContainer pvContainer
#endif                              //这得是多少个版本之前的定义啊
                                    //兼容接口在之前被弃用过,但
#if( configUSE_ALTERNATIVE_API != 0 )
	#error The alternative API was deprecated some time ago, and was removed in FreeRTOS V9.0 0
#endif

#ifndef configUSE_TASK_FPU_SUPPORT  //FPU(浮点运算单元)支持
	#define configUSE_TASK_FPU_SUPPORT 1
#endif

//一些全局自定义项,静态使用

//静态链表
struct xSTATIC_LIST_ITEM            //静态链表项
{
	TickType_t xDummy1;
	void *pvDummy2[ 4 ];
};
typedef struct xSTATIC_LIST_ITEM StaticListItem_t;

struct xSTATIC_MINI_LIST_ITEM       //小的静态链表项
{
	TickType_t xDummy1;
	void *pvDummy2[ 2 ];
};
typedef struct xSTATIC_MINI_LIST_ITEM StaticMiniListItem_t;

typedef struct xSTATIC_LIST         //静态链表
{
	UBaseType_t uxDummy1;
	void *pvDummy2;
	StaticMiniListItem_t xDummy3;
} StaticList_t;

//静态程序控制块TCB
typedef struct xSTATIC_TCB
{
	void				*pxDummy1;
	#if ( portUSING_MPU_WRAPPERS == 1 )
		xMPU_SETTINGS	xDummy2;
	#endif
	StaticListItem_t	xDummy3[ 2 ];
	UBaseType_t			uxDummy5;
	void				*pxDummy6;
	uint8_t				ucDummy7[ configMAX_TASK_NAME_LEN ];
	#if ( ( portSTACK_GROWTH > 0 ) || ( configRECORD_STACK_HIGH_ADDRESS == 1 ) )
		void			*pxDummy8;
	#endif
	#if ( portCRITICAL_NESTING_IN_TCB == 1 )
		UBaseType_t		uxDummy9;
	#endif
	#if ( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t		uxDummy10[ 2 ];
	#endif
	#if ( configUSE_MUTEXES == 1 )
		UBaseType_t		uxDummy12[ 2 ];
	#endif
	#if ( configUSE_APPLICATION_TASK_TAG == 1 )
		void			*pxDummy14;
	#endif
	#if( configNUM_THREAD_LOCAL_STORAGE_POINTERS > 0 )
		void			*pvDummy15[ configNUM_THREAD_LOCAL_STORAGE_POINTERS ];
	#endif
	#if ( configGENERATE_RUN_TIME_STATS == 1 )
		uint32_t		ulDummy16;
	#endif
	#if ( configUSE_NEWLIB_REENTRANT == 1 )
		struct	_reent	xDummy17;
	#endif
	#if ( configUSE_TASK_NOTIFICATIONS == 1 )
		uint32_t 		ulDummy18;
		uint8_t 		ucDummy19;
	#endif
	#if( ( configSUPPORT_STATIC_ALLOCATION == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
		uint8_t			uxDummy20;
	#endif

	#if( INCLUDE_xTaskAbortDelay == 1 )
		uint8_t ucDummy21;
	#endif
	#if ( configUSE_POSIX_ERRNO == 1 )
		int				iDummy22;
	#endif
} StaticTask_t;

//静态队列
typedef struct xSTATIC_QUEUE
{
	void *pvDummy1[ 3 ];

	union
	{
		void *pvDummy2;
		UBaseType_t uxDummy2;
	} u;

	StaticList_t xDummy3[ 2 ];
	UBaseType_t uxDummy4[ 3 ];
	uint8_t ucDummy5[ 2 ];

	#if( ( configSUPPORT_STATIC_ALLOCATION == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
		uint8_t ucDummy6;
	#endif

	#if ( configUSE_QUEUE_SETS == 1 )
		void *pvDummy7;
	#endif

	#if ( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t uxDummy8;
		uint8_t ucDummy9;
	#endif

} StaticQueue_t;
//静态队列也被复用为静态信号量
typedef StaticQueue_t StaticSemaphore_t;

//静态事件组
typedef struct xSTATIC_EVENT_GROUP
{
	TickType_t xDummy1;
	StaticList_t xDummy2;

	#if( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t uxDummy3;
	#endif

	#if( ( configSUPPORT_STATIC_ALLOCATION == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
			uint8_t ucDummy4;
	#endif

} StaticEventGroup_t;

//静态定时器
typedef struct xSTATIC_TIMER
{
	void				*pvDummy1;
	StaticListItem_t	xDummy2;
	TickType_t			xDummy3;
	UBaseType_t			uxDummy4;
	void 				*pvDummy5;
	TaskFunction_t		pvDummy6;
	#if( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t		uxDummy7;
	#endif

	#if( ( configSUPPORT_STATIC_ALLOCATION == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
		uint8_t 		ucDummy8;
	#endif

} StaticTimer_t;

//静态流缓冲
typedef struct xSTATIC_STREAM_BUFFER
{
	size_t uxDummy1[ 4 ];
	void * pvDummy2[ 3 ];
	uint8_t ucDummy3;
	#if ( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t uxDummy4;
	#endif
} StaticStreamBuffer_t;

//静态流缓冲被复用为静态邮箱缓冲
typedef StaticStreamBuffer_t StaticMessageBuffer_t;

#ifdef __cplusplus
}
#endif

#endif

