/*
 * 数据结构之队列
 */

#include <stdlib.h>
#include <string.h>

//接口重包含,提前定义一下用于屏蔽mpu_wappers.h造成的影响
#define MPU_WRAPPERS_INCLUDED_FROM_API_FILE

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

//使用协程
#if ( configUSE_CO_ROUTINES == 1 )
	#include "croutine.h"
#endif

//取消重包含,因为已经没必要了
#undef MPU_WRAPPERS_INCLUDED_FROM_API_FILE


//互斥锁
#define queueUNLOCKED					( ( int8_t ) -1 )
#define queueLOCKED_UNMODIFIED			( ( int8_t ) 0 )

//定义队列配置
#define uxQueueType						pcHead
#define queueQUEUE_IS_MUTEX				NULL

typedef struct QueuePointers
{
	int8_t *pcTail;					//指向队列尾
    int8_t *pcReadFrom;				//已经读到队列的哪一个位置了
} QueuePointers_t;

typedef struct SemaphoreData
{
	TaskHandle_t xMutexHolder;		 //互斥锁所有者
	UBaseType_t uxRecursiveCallCount;//嵌套次数
} SemaphoreData_t;

//信号量本质不做数据的处理
#define queueSEMAPHORE_QUEUE_ITEM_LENGTH ( ( UBaseType_t ) 0 )
#define queueMUTEX_GIVE_BLOCK_TIME		 ( ( TickType_t ) 0U )

//是否开启内核抢占
#if( configUSE_PREEMPTION == 0 )
	#define queueYIELD_IF_USING_PREEMPTION()
#else
	#define queueYIELD_IF_USING_PREEMPTION() portYIELD_WITHIN_API()
#endif

//队列的定义
typedef struct QueueDefinition 
{
	int8_t *pcHead;					//队列的开头
	int8_t *pcWriteTo;				//队列下一个写入地址,一个空闲的区域

	union
	{
		QueuePointers_t xQueue;		//数据作为一个队列还是
		SemaphoreData_t xSemaphore; //数据作为一个信号量,信号量占用队列的空间(它自己本质上算作不使用空间)
	} u;

	List_t xTasksWaitingToSend;		//被阻塞的任务链表,按优先级顺序排列
	List_t xTasksWaitingToReceive;	//阻塞访问该队列的任务,按优先级排序
                                    //队列中等待的消息数量
	volatile UBaseType_t uxMessagesWaiting;
	UBaseType_t uxLength;			//持有项的数量
	UBaseType_t uxItemSize;			//单个持有项的大小

	volatile int8_t cRxLock;		//存在接受项的数量表明锁定,否则是解锁状态
	volatile int8_t cTxLock;		//存在发送项的数量表明锁定,否则是解锁状态

    //如果俩种内存分配方式都存在的话
	#if( ( configSUPPORT_STATIC_ALLOCATION == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
                                    //如果标志为真表明该区域是静态区域,防止被free掉
		uint8_t ucStaticallyAllocated;
    #endif
                                    //如果使用队列集合
	#if ( configUSE_QUEUE_SETS == 1 )
                                    //确认该队列的父亲是谁
		struct QueueDefinition *pxQueueSetContainer;
	#endif
                                    //追踪调试
	#if ( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t uxQueueNumber;
		uint8_t ucQueueType;
	#endif
} xQUEUE;

//重声明,有些为了兼容旧版本,重声明一般是适应新版本
typedef xQUEUE Queue_t;


//为调试所用到的可选项
#if ( configQUEUE_REGISTRY_SIZE > 0 )
	typedef struct QUEUE_REGISTRY_ITEM
	{
		const char *pcQueueName;//队列名
		QueueHandle_t xHandle;  //队列句柄,实际指向一个队列
	} xQueueRegistryItem;

	typedef xQueueRegistryItem QueueRegistryItem_t;

    //开辟一块静态区域保存这些调试项(队列集合),存放在特权数据区
	PRIVILEGED_DATA QueueRegistryItem_t xQueueRegistry[ configQUEUE_REGISTRY_SIZE ];

#endif



static void prvUnlockQueue( Queue_t * const pxQueue ) PRIVILEGED_FUNCTION;
static BaseType_t prvIsQueueEmpty( const Queue_t *pxQueue ) PRIVILEGED_FUNCTION;
static BaseType_t prvIsQueueFull( const Queue_t *pxQueue ) PRIVILEGED_FUNCTION;
static BaseType_t prvCopyDataToQueue( Queue_t * const pxQueue, const void *pvItemToQueue, const BaseType_t xPosition ) PRIVILEGED_FUNCTION;
static void prvCopyDataFromQueue( Queue_t * const pxQueue, void * const pvBuffer ) PRIVILEGED_FUNCTION;
//使用队列集的话,配置队列的父亲
#if ( configUSE_QUEUE_SETS == 1 )
	static BaseType_t prvNotifyQueueSetContainer( const Queue_t * const pxQueue, const BaseType_t xCopyPosition ) PRIVILEGED_FUNCTION;
#endif
static void prvInitialiseNewQueue( const UBaseType_t uxQueueLength, const UBaseType_t uxItemSize, uint8_t *pucQueueStorage, const uint8_t ucQueueType, Queue_t *pxNewQueue ) PRIVILEGED_FUNCTION;
//使用互斥锁的话
#if( configUSE_MUTEXES == 1 )
	static void prvInitialiseMutex( Queue_t *pxNewQueue ) PRIVILEGED_FUNCTION;
#endif
#if( configUSE_MUTEXES == 1 )
	static UBaseType_t prvGetDisinheritPriorityAfterTimeout( const Queue_t * const pxQueue ) PRIVILEGED_FUNCTION;
#endif

//为队列上锁
#define prvLockQueue( pxQueue )								\
	taskENTER_CRITICAL();									\
	{														\
		if( ( pxQueue )->cRxLock == queueUNLOCKED )			\
		{													\
			( pxQueue )->cRxLock = queueLOCKED_UNMODIFIED;	\
		}													\
		if( ( pxQueue )->cTxLock == queueUNLOCKED )			\
		{													\
			( pxQueue )->cTxLock = queueLOCKED_UNMODIFIED;	\
		}													\
	}								\					\
	taskEXIT_CRITICAL()

//通用的队列重置
BaseType_t xQueueGenericReset( QueueHandle_t xQueue, BaseType_t xNewQueue )
{
Queue_t * const pxQueue = xQueue;
    //安全检查
	configASSERT( pxQueue );
    //进入临界区
	taskENTER_CRITICAL();
	{   //初始化队列尾,为队列头进行 数量*大小 的偏移
		pxQueue->u.xQueue.pcTail = pxQueue->pcHead + ( pxQueue->uxLength * pxQueue->uxItemSize ); 
        pxQueue->uxMessagesWaiting = ( UBaseType_t ) 0U;    //当前队列消息等待数
		pxQueue->pcWriteTo = pxQueue->pcHead;               //下一次写入的地方是在,队列头
		//数据的读取方向,是队列的头+(队列项数量-1)*队列项大小==队列的尾,队列的最后一项
		pxQueue->u.xQueue.pcReadFrom = pxQueue->pcHead + ( ( pxQueue->uxLength - 1U ) * pxQueue->uxItemSize ); 
		pxQueue->cRxLock = queueUNLOCKED;                   //未上锁
		pxQueue->cTxLock = queueUNLOCKED;                   //未上锁

		if( xNewQueue == pdFALSE )
		{
			//任务队列(链表)是空的
			if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToSend ) ) == pdFALSE )
			{   //如果任务队列不空,从该任务队列(链表)移除任务
				if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToSend ) ) != pdFALSE )
				{   //移除成功时,使用内核抢占调度
					queueYIELD_IF_USING_PREEMPTION();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{
			//初始化读写阻塞等待队列
			vListInitialise( &( pxQueue->xTasksWaitingToSend ) );
			vListInitialise( &( pxQueue->xTasksWaitingToReceive ) );
		}
	}
	taskEXIT_CRITICAL();
	return pdPASS;
}

//如果支持静态内存分配
#if( configSUPPORT_STATIC_ALLOCATION == 1 )
	QueueHandle_t xQueueGenericCreateStatic( const UBaseType_t uxQueueLength, const UBaseType_t uxItemSize, uint8_t *pucQueueStorage, StaticQueue_t *pxStaticQueue, const uint8_t ucQueueType )
	{
    Queue_t *pxNewQueue;
        //断言检查
		configASSERT( uxQueueLength > ( UBaseType_t ) 0 );
		configASSERT( pxStaticQueue != NULL );
		configASSERT( !( ( pucQueueStorage != NULL ) && ( uxItemSize == 0 ) ) );
		configASSERT( !( ( pucQueueStorage == NULL ) && ( uxItemSize != 0 ) ) );
        //断言检查,特殊检查
		#if( configASSERT_DEFINED == 1 )
		{
		volatile size_t xSize = sizeof( StaticQueue_t );
			configASSERT( xSize == sizeof( Queue_t ) );
			( void ) xSize;
		}
		#endif
		//获取静态队列的地址
		pxNewQueue = ( Queue_t * ) pxStaticQueue;
        //静态队列地址存在时(类似全局变量)
		if( pxNewQueue != NULL )
		{   //如果动态内存分配机制存在时,配置为静态支持
			#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
			{   //防止被不正当的操作去free掉
                pxNewQueue->ucStaticallyAllocated = pdTRUE;
			}
			#endif 
            //初始化这个队列的各个属性,队列项大小,队列项数量等
			prvInitialiseNewQueue( uxQueueLength, uxItemSize, pucQueueStorage, ucQueueType, pxNewQueue );
		}
		else
		{   //错误追踪
			traceQUEUE_CREATE_FAILED( ucQueueType );
			mtCOVERAGE_TEST_MARKER();
		}

		return pxNewQueue;
	}

#endif 

//如果支持动态内存分配
#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
	QueueHandle_t xQueueGenericCreate( const UBaseType_t uxQueueLength, const UBaseType_t uxItemSize, const uint8_t ucQueueType )
	{
    Queue_t *pxNewQueue;
	size_t xQueueSizeInBytes;
	uint8_t *pucQueueStorage;
        //断言检查
		configASSERT( uxQueueLength > ( UBaseType_t ) 0 );
        //是创建多少个项空间的队列呢
		if( uxItemSize == ( UBaseType_t ) 0 )
		{
			xQueueSizeInBytes = ( size_t ) 0;
		}
		else
		{   //计算要的空间是多少
			xQueueSizeInBytes = ( size_t ) ( uxQueueLength * uxItemSize ); 
        }

        //动态分配存储区域,包括队列本身和项空间
		pxNewQueue = ( Queue_t * ) pvPortMalloc( sizeof( Queue_t ) + xQueueSizeInBytes );
		if( pxNewQueue != NULL )
		{   //创建成功时,指针偏移到存储区的地址中
			pucQueueStorage = ( uint8_t * ) pxNewQueue;
			pucQueueStorage += sizeof( Queue_t ); 
            //如果支持静态内存分配,当前是动态内存分配,那么静态标签需要被清除
			#if( configSUPPORT_STATIC_ALLOCATION == 1 )
			{   //如果不清除该标志,该段动态分配的内存无法被回收
				pxNewQueue->ucStaticallyAllocated = pdFALSE;
			}
			#endif
            //初始化新队列
			prvInitialiseNewQueue( uxQueueLength, uxItemSize, pucQueueStorage, ucQueueType, pxNewQueue );
		}
		else
		{
			traceQUEUE_CREATE_FAILED( ucQueueType );
			mtCOVERAGE_TEST_MARKER();
		}

		return pxNewQueue;
	}

#endif

//队列初始化的动作
static void prvInitialiseNewQueue( const UBaseType_t uxQueueLength, const UBaseType_t uxItemSize, uint8_t *pucQueueStorage, const uint8_t ucQueueType, Queue_t *pxNewQueue )
{
	//去除编译器警告所用
	( void ) ucQueueType;

    //如果项大小为0,即暂时无项
	if( uxItemSize == ( UBaseType_t ) 0 )
	{   //自己指向自己
        pxNewQueue->pcHead = ( int8_t * ) pxNewQueue;
	}
	else
	{   //指向存储区域首地址,队列的开头
		pxNewQueue->pcHead = ( int8_t * ) pucQueueStorage;
	}

	//初始化队列项数和项大小
	pxNewQueue->uxLength = uxQueueLength;
	pxNewQueue->uxItemSize = uxItemSize;
    //重置队列
	( void ) xQueueGenericReset( pxNewQueue, pdTRUE );

	#if ( configUSE_TRACE_FACILITY == 1 )
	{   //安全保护参数,配置为一个数
		pxNewQueue->ucQueueType = ucQueueType;
	}
	#endif
	#if( configUSE_QUEUE_SETS == 1 )
	{   //配置队列集,则其父节点为空,因为是初始化
		pxNewQueue->pxQueueSetContainer = NULL;
	}
	#endif
    //队列创建追踪
	traceQUEUE_CREATE( pxNewQueue );
}


//如果使用互斥锁,将一个队列配置为互斥锁
#if( configUSE_MUTEXES == 1 )
	static void prvInitialiseMutex( Queue_t *pxNewQueue )
	{   //队列不为空
		if( pxNewQueue != NULL )
		{   //队列使用信号量,信号量配置锁所有者
		    pxNewQueue->u.xSemaphore.xMutexHolder = NULL;
			pxNewQueue->uxQueueType = queueQUEUE_IS_MUTEX;
            //锁嵌套次数
			pxNewQueue->u.xSemaphore.uxRecursiveCallCount = 0;
            //互斥锁的追踪
			traceCREATE_MUTEX( pxNewQueue );
            //发送空项到队列中
			( void ) xQueueGenericSend( pxNewQueue, NULL, ( TickType_t ) 0U, queueSEND_TO_BACK );
		}
		else
		{
			traceCREATE_MUTEX_FAILED();
		}
	}

#endif

//使用互斥锁且为动态分配时
#if( ( configUSE_MUTEXES == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
	QueueHandle_t xQueueCreateMutex( const uint8_t ucQueueType )
	{   //使用队列去创建一个互斥锁
	QueueHandle_t xNewQueue;
	const UBaseType_t uxMutexLength = ( UBaseType_t ) 1, uxMutexSize = ( UBaseType_t ) 0;
        //动态创建一个空队列
		xNewQueue = xQueueGenericCreate( uxMutexLength, uxMutexSize, ucQueueType );
        //将这个空队列初始化为互斥锁
		prvInitialiseMutex( ( Queue_t * ) xNewQueue );
    	return xNewQueue;
	}

#endif

//使用互斥锁且为静态分配时
#if( ( configUSE_MUTEXES == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 1 ) )
	QueueHandle_t xQueueCreateMutexStatic( const uint8_t ucQueueType, StaticQueue_t *pxStaticQueue )
	{   //使用动态分配的队列去创建一个互斥锁
	QueueHandle_t xNewQueue;
	const UBaseType_t uxMutexLength = ( UBaseType_t ) 1, uxMutexSize = ( UBaseType_t ) 0;
        //防止编译器警告
		( void ) ucQueueType;
        //静态初始化一个空队列
		xNewQueue = xQueueGenericCreateStatic( uxMutexLength, uxMutexSize, NULL, pxStaticQueue, ucQueueType );
        //初始化队列为互斥锁
        prvInitialiseMutex( ( Queue_t * ) xNewQueue );
		return xNewQueue;
	}

#endif

//使用互斥锁且允许获取锁所有者
#if ( ( configUSE_MUTEXES == 1 ) && ( INCLUDE_xSemaphoreGetMutexHolder == 1 ) )
	TaskHandle_t xQueueGetMutexHolder( QueueHandle_t xSemaphore )
	{
	TaskHandle_t pxReturn;
	Queue_t * const pxSemaphore = ( Queue_t * ) xSemaphore;

        taskENTER_CRITICAL();
		{   //如果该队列结构被重用为一个互斥锁
			if( pxSemaphore->uxQueueType == queueQUEUE_IS_MUTEX )
 			{   //获取锁的所有者
 			    pxReturn = pxSemaphore->u.xSemaphore.xMutexHolder;
			}
			else
			{
				pxReturn = NULL;
			}
		}
		taskEXIT_CRITICAL();
		return pxReturn;
	} 
    
#endif

//使用互斥锁且允许获得锁的所有者
#if ( ( configUSE_MUTEXES == 1 ) && ( INCLUDE_xSemaphoreGetMutexHolder == 1 ) )
	TaskHandle_t xQueueGetMutexHolderFromISR( QueueHandle_t xSemaphore )
	{
    TaskHandle_t pxReturn;
		configASSERT( xSemaphore );//信号量断言
		if( ( ( Queue_t * ) xSemaphore )->uxQueueType == queueQUEUE_IS_MUTEX )
		{   //如果是一个互斥锁,获得其所有者
			pxReturn = ( ( Queue_t * ) xSemaphore )->u.xSemaphore.xMutexHolder;
		}
		else
		{
			pxReturn = NULL;
		}
		return pxReturn;
	} 
    
#endif

//使用嵌套互斥锁
#if ( configUSE_RECURSIVE_MUTEXES == 1 )
	BaseType_t xQueueGiveMutexRecursive( QueueHandle_t xMutex )
	{
	BaseType_t xReturn;
	Queue_t * const pxMutex = ( Queue_t * ) xMutex;
        configASSERT( pxMutex );//互斥锁断言

        //如果互斥锁的所有者,是当前任务句柄(程序控制块TCB)
		if( pxMutex->u.xSemaphore.xMutexHolder == xTaskGetCurrentTaskHandle() )
		{   //追踪检查
			traceGIVE_MUTEX_RECURSIVE( pxMutex );
            //嵌套层次降低一次
			( pxMutex->u.xSemaphore.uxRecursiveCallCount )--;
            //如果嵌套层次为0
            if( pxMutex->u.xSemaphore.uxRecursiveCallCount == ( UBaseType_t ) 0 )
			{
                //发送信号到互斥锁
                ( void ) xQueueGenericSend( pxMutex, NULL, queueMUTEX_GIVE_BLOCK_TIME, queueSEND_TO_BACK );
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
			xReturn = pdPASS;
		}
		else
		{   //不是你持有的锁,无权释放,只有持有锁的所有者才能释放锁
			xReturn = pdFAIL;
			traceGIVE_MUTEX_RECURSIVE_FAILED( pxMutex );
		}
		return xReturn;
	}

#endif 

//如果使用嵌套互斥锁
#if ( configUSE_RECURSIVE_MUTEXES == 1 )
	BaseType_t xQueueTakeMutexRecursive( QueueHandle_t xMutex, TickType_t xTicksToWait )
	{
    BaseType_t xReturn;
	Queue_t * const pxMutex = ( Queue_t * ) xMutex;
		configASSERT( pxMutex );//断言与追踪
		traceTAKE_MUTEX_RECURSIVE( pxMutex );
		if( pxMutex->u.xSemaphore.xMutexHolder == xTaskGetCurrentTaskHandle() )
		{   //你是当前锁的持有者,那么直接提升嵌套等级
			( pxMutex->u.xSemaphore.uxRecursiveCallCount )++;
			xReturn = pdPASS;
		}
		else
		{   //你不是锁的持有者,那么得等持有者释放锁
			xReturn = xQueueSemaphoreTake( pxMutex, xTicksToWait );
			if( xReturn != pdFAIL )
			{   //你等到了锁,现在你是持有者了,提升嵌套等级
				( pxMutex->u.xSemaphore.uxRecursiveCallCount )++;
			}
			else
			{
				traceTAKE_MUTEX_RECURSIVE_FAILED( pxMutex );
			}
		}

		return xReturn;
	}

#endif

//使用迭代信号量(计数,嵌套,等等),且是静态分配内存
#if( ( configUSE_COUNTING_SEMAPHORES == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 1 ) )
	QueueHandle_t xQueueCreateCountingSemaphoreStatic( const UBaseType_t uxMaxCount, const UBaseType_t uxInitialCount, StaticQueue_t *pxStaticQueue )
	{
    QueueHandle_t xHandle;
		configASSERT( uxMaxCount != 0 );//断言检查
		configASSERT( uxInitialCount <= uxMaxCount );
        //静态创建一个空队列,作为信号量使用
		xHandle = xQueueGenericCreateStatic( uxMaxCount, queueSEMAPHORE_QUEUE_ITEM_LENGTH, NULL, pxStaticQueue, queueQUEUE_TYPE_COUNTING_SEMAPHORE );
		if( xHandle != NULL )
		{   //初始化计数值
			( ( Queue_t * ) xHandle )->uxMessagesWaiting = uxInitialCount;
			traceCREATE_COUNTING_SEMAPHORE();
		}
		else
		{
			traceCREATE_COUNTING_SEMAPHORE_FAILED();
		}
		return xHandle;
	}

#endif

//使用计数信号量和动态内存分配
#if( ( configUSE_COUNTING_SEMAPHORES == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
	QueueHandle_t xQueueCreateCountingSemaphore( const UBaseType_t uxMaxCount, const UBaseType_t uxInitialCount )
	{
	QueueHandle_t xHandle;
		configASSERT( uxMaxCount != 0 );//断言检查
		configASSERT( uxInitialCount <= uxMaxCount );
        //创建一个空队列重用为信号量
		xHandle = xQueueGenericCreate( uxMaxCount, queueSEMAPHORE_QUEUE_ITEM_LENGTH, queueQUEUE_TYPE_COUNTING_SEMAPHORE );
		if( xHandle != NULL )
		{   //设置计数初始化值
			( ( Queue_t * ) xHandle )->uxMessagesWaiting = uxInitialCount;
			traceCREATE_COUNTING_SEMAPHORE();
		}
		else
		{
			traceCREATE_COUNTING_SEMAPHORE_FAILED();
		}
		return xHandle;
	}

#endif

//队列集合发送项
BaseType_t xQueueGenericSend( QueueHandle_t xQueue, const void * const pvItemToQueue, TickType_t xTicksToWait, const BaseType_t xCopyPosition )
{
BaseType_t xEntryTimeSet = pdFALSE, xYieldRequired;
TimeOut_t xTimeOut;//超时时间
Queue_t * const pxQueue = xQueue;

	configASSERT( pxQueue );//断言检查
	configASSERT( !( ( pvItemToQueue == NULL ) && ( pxQueue->uxItemSize != ( UBaseType_t ) 0U ) ) );
	configASSERT( !( ( xCopyPosition == queueOVERWRITE ) && ( pxQueue->uxLength != 1 ) ) );
    //如果配置为任务可获得调度器状态,且使用定时器
	#if ( ( INCLUDE_xTaskGetSchedulerState == 1 ) || ( configUSE_TIMERS == 1 ) )
	{   //断言检查调度器状态
		configASSERT( !( ( xTaskGetSchedulerState() == taskSCHEDULER_SUSPENDED ) && ( xTicksToWait != 0 ) ) );
	}
	#endif

    for( ;; )
	{   //进入临界区
		taskENTER_CRITICAL();
		{   //等待的消息数小于总项数,且被配置为复用
			if( ( pxQueue->uxMessagesWaiting < pxQueue->uxLength ) || ( xCopyPosition == queueOVERWRITE ) )
			{
				traceQUEUE_SEND( pxQueue );
				#if ( configUSE_QUEUE_SETS == 1 )
				{//如果使用集合的话
				UBaseType_t uxPreviousMessagesWaiting = pxQueue->uxMessagesWaiting;
                    //将数据复制到队列,内容拷贝复制而不是地址复制,拷贝到队列的对应项中
					xYieldRequired = prvCopyDataToQueue( pxQueue, pvItemToQueue, xCopyPosition );
					if( pxQueue->pxQueueSetContainer != NULL )
					{   //配置为重写模式下,上一次消息等待不为0时
						if( ( xCopyPosition == queueOVERWRITE ) && ( uxPreviousMessagesWaiting != ( UBaseType_t ) 0 ) )
						{
							mtCOVERAGE_TEST_MARKER();
						}   //将队列本身发送到队列组的组长
						else if( prvNotifyQueueSetContainer( pxQueue, xCopyPosition ) != pdFALSE )
						{   //内核抢占调度,如果使用的话
							queueYIELD_IF_USING_PREEMPTION();
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else
					{   //改队列没有所有组(孤儿),如果接受等待队列不为空的话
						if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
						{   //如果可以移出一个任务,从事件集中
							if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
							{   //未阻塞的任务块会以更高优先级调度,那么调度会立即执行
							    //内核抢占调度
								queueYIELD_IF_USING_PREEMPTION();
							}
							else
							{
								mtCOVERAGE_TEST_MARKER();
							}
						}
						else if( xYieldRequired != pdFALSE )
						{   //如果调度请求为真,那么调度执行
						    queueYIELD_IF_USING_PREEMPTION();
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
				}
				#else //如果不使用队列集
				{   //数据拷贝到队列的指定项
					xYieldRequired = prvCopyDataToQueue( pxQueue, pvItemToQueue, xCopyPosition );
					if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
					{   //队列非空且可以从事件集移出任务
						if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
						{   //启动调度
							queueYIELD_IF_USING_PREEMPTION();
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else if( xYieldRequired != pdFALSE )
					{   //如果调度请求成立的话
					    queueYIELD_IF_USING_PREEMPTION();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				#endif
				taskEXIT_CRITICAL();
				return pdPASS;
			}
			else//队列满
			{
				if( xTicksToWait == ( TickType_t ) 0 )
				{   //无等待时间,意味着队列过期
					taskEXIT_CRITICAL();
					traceQUEUE_SEND_FAILED( pxQueue );
					return errQUEUE_FULL;
				}
				else if( xEntryTimeSet == pdFALSE )
				{   //有特殊时间约束,任务设置超时时间状态
					vTaskInternalSetTimeOutState( &xTimeOut );
					xEntryTimeSet = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
		taskEXIT_CRITICAL();
		vTaskSuspendAll();//全部任务挂起
		prvLockQueue( pxQueue );队列上锁
        //任务超时检查
		if( xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait ) == pdFALSE )
		{   //队列满检查
			if( prvIsQueueFull( pxQueue ) != pdFALSE )
			{
				traceBLOCKING_ON_QUEUE_SEND( pxQueue );
                //把当前任务,程序控制块(TCB)插入到等待发送链表中
                //加入当前任务到延迟链表
				vTaskPlaceOnEventList( &( pxQueue->xTasksWaitingToSend ), xTicksToWait );
				//队列解锁
				prvUnlockQueue( pxQueue );
				//恢复调度,当前应该不会发送上下文切换(调度),除非被以很高的
				//优先级丢入就绪队列中
				if( xTaskResumeAll() == pdFALSE )
				{
					portYIELD_WITHIN_API();
				}
			}
			else
			{
				//队列解锁,任务调度恢复
				prvUnlockQueue( pxQueue );
				( void ) xTaskResumeAll();
			}
		}
		else
		{
			//已经超时,解锁,恢复调度
			prvUnlockQueue( pxQueue );
			( void ) xTaskResumeAll();
			traceQUEUE_SEND_FAILED( pxQueue );
			return errQUEUE_FULL;
		}
	} 
}

//中断环境下,向队列发送事件
BaseType_t xQueueGenericSendFromISR( QueueHandle_t xQueue, const void * const pvItemToQueue, BaseType_t * const pxHigherPriorityTaskWoken, const BaseType_t xCopyPosition )
{
BaseType_t xReturn;
UBaseType_t uxSavedInterruptStatus;
Queue_t * const pxQueue = xQueue;
	configASSERT( pxQueue );//断言
	configASSERT( !( ( pvItemToQueue == NULL ) && ( pxQueue->uxItemSize != ( UBaseType_t ) 0U ) ) );
	configASSERT( !( ( xCopyPosition == queueOVERWRITE ) && ( pxQueue->uxLength != 1 ) ) );

	//中断优先级合法性检查,保证中断的安全与简单
	portASSERT_IF_INTERRUPT_PRIORITY_INVALID();

	//中断状态获取
	uxSavedInterruptStatus = portSET_INTERRUPT_MASK_FROM_ISR();
	{   //消息接收项是否大于最大负载,是否支持队列的拷贝式重写
		if( ( pxQueue->uxMessagesWaiting < pxQueue->uxLength ) || ( xCopyPosition == queueOVERWRITE ) )
		{   //检查发送锁
		const int8_t cTxLock = pxQueue->cTxLock;
			traceQUEUE_SEND_FROM_ISR( pxQueue );//追踪
            //数据拷贝
			( void ) prvCopyDataToQueue( pxQueue, pvItemToQueue, xCopyPosition );
			if( cTxLock == queueUNLOCKED )
			{   //发送锁解锁
				#if ( configUSE_QUEUE_SETS == 1 )
				{   //使用队列集
					if( pxQueue->pxQueueSetContainer != NULL )
					{   //本队列有一个直接上级
						if( prvNotifyQueueSetContainer( pxQueue, xCopyPosition ) != pdFALSE )
						{   //将本队列加入到队列集中,以一个高优先集提供配置
							if( pxHigherPriorityTaskWoken != NULL )
							{   //反馈给调用者,以高优先级唤醒已经配置好
								*pxHigherPriorityTaskWoken = pdTRUE;
							}
							else
							{
								mtCOVERAGE_TEST_MARKER();
							}
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else
					{   //孤儿队列
						if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
						{   //队列的接受等待数组不为空
							if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
							{   //从事件组中移除本任务,加入就绪队列
								if( pxHigherPriorityTaskWoken != NULL )
								{   //配置高优先级唤醒
									*pxHigherPriorityTaskWoken = pdTRUE;
								}
								else
								{
									mtCOVERAGE_TEST_MARKER();
								}
							}
							else
							{
								mtCOVERAGE_TEST_MARKER();
							}
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
				}
				#else//不用队列集
				{   //队列空检查    
					if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
					{   //任务从等待接受链表中移除后加入就绪队列
						if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
						{   //高优先级唤醒配置
							if( pxHigherPriorityTaskWoken != NULL )
							{
								*pxHigherPriorityTaskWoken = pdTRUE;
							}
							else
							{
								mtCOVERAGE_TEST_MARKER();
							}
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				#endif
			}
			else
			{   //有锁,加锁,因为发送项增加
				pxQueue->cTxLock = ( int8_t ) ( cTxLock + 1 );
			}
			xReturn = pdPASS;
		}
		else
		{   //队列满错误
			traceQUEUE_SEND_FROM_ISR_FAILED( pxQueue );
			xReturn = errQUEUE_FULL;
		}
	}
    //清除中断掩码,从中断中
	portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );
	return xReturn;
}

//从中断获取
BaseType_t xQueueGiveFromISR( QueueHandle_t xQueue, BaseType_t * const pxHigherPriorityTaskWoken )
{
BaseType_t xReturn;
UBaseType_t uxSavedInterruptStatus;
Queue_t * const pxQueue = xQueue;
	configASSERT( pxQueue );//断言检查
	configASSERT( pxQueue->uxItemSize == 0 );
	configASSERT( !( ( pxQueue->uxQueueType == queueQUEUE_IS_MUTEX ) && ( pxQueue->u.xSemaphore.xMutexHolder != NULL ) ) );

    //中断优先级合法检查
	portASSERT_IF_INTERRUPT_PRIORITY_INVALID();
    //中断标志获取
	uxSavedInterruptStatus = portSET_INTERRUPT_MASK_FROM_ISR();
	{   //消息等待项
	const UBaseType_t uxMessagesWaiting = pxQueue->uxMessagesWaiting;
		if( uxMessagesWaiting < pxQueue->uxLength )
		{   //未超出最大限制(未满),获取发送锁
		const int8_t cTxLock = pxQueue->cTxLock;
			traceQUEUE_SEND_FROM_ISR( pxQueue );
            //消息数增加1个
			pxQueue->uxMessagesWaiting = uxMessagesWaiting + ( UBaseType_t ) 1;
			if( cTxLock == queueUNLOCKED )
			{   //如果是解锁态
				#if ( configUSE_QUEUE_SETS == 1 )
				{   //如果配置了队列集
					if( pxQueue->pxQueueSetContainer != NULL )
					{   //如果有上级
						if( prvNotifyQueueSetContainer( pxQueue, queueSEND_TO_BACK ) != pdFALSE )
						{   //将本队列加入到上级队列中,设置高优先级
							if( pxHigherPriorityTaskWoken != NULL )
							{
								*pxHigherPriorityTaskWoken = pdTRUE;
							}
							else
							{
								mtCOVERAGE_TEST_MARKER();
							}
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else
					{   //孤儿队列
						if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
						{  
							if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
							{   //任务移出等待队列,加入就绪队列
							    if( pxHigherPriorityTaskWoken != NULL )
								{   //高优先级唤醒配置
									*pxHigherPriorityTaskWoken = pdTRUE;
								}
								else
								{
									mtCOVERAGE_TEST_MARKER();
								}
							}
							else
							{
								mtCOVERAGE_TEST_MARKER();
							}
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
				}
				#else
				{   //如上
					if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
					{
						if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
						{
							if( pxHigherPriorityTaskWoken != NULL )
							{
								*pxHigherPriorityTaskWoken = pdTRUE;
							}
							else
							{
								mtCOVERAGE_TEST_MARKER();
							}
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				#endif
			}
			else
			{   //项增加1
				pxQueue->cTxLock = ( int8_t ) ( cTxLock + 1 );
			}
			xReturn = pdPASS;
		}
		else
		{
			traceQUEUE_SEND_FROM_ISR_FAILED( pxQueue );
			xReturn = errQUEUE_FULL;
		}
	}
	portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );
	return xReturn;
}

//从队列接收
BaseType_t xQueueReceive( QueueHandle_t xQueue, void * const pvBuffer, TickType_t xTicksToWait )
{
BaseType_t xEntryTimeSet = pdFALSE;
TimeOut_t xTimeOut;
Queue_t * const pxQueue = xQueue;
	configASSERT( ( pxQueue ) );
	configASSERT( !( ( ( pvBuffer ) == NULL ) && ( ( pxQueue )->uxItemSize != ( UBaseType_t ) 0U ) ) );
	#if ( ( INCLUDE_xTaskGetSchedulerState == 1 ) || ( configUSE_TIMERS == 1 ) )
	{
		configASSERT( !( ( xTaskGetSchedulerState() == taskSCHEDULER_SUSPENDED ) && ( xTicksToWait != 0 ) ) );
	}
	#endif

	for( ;; )
	{   //临界区进入
		taskENTER_CRITICAL();
		{
		const UBaseType_t uxMessagesWaiting = pxQueue->uxMessagesWaiting;
			if( uxMessagesWaiting > ( UBaseType_t ) 0 )
   			{   //队列存在数据,拷贝出来
				prvCopyDataFromQueue( pxQueue, pvBuffer );
				traceQUEUE_RECEIVE( pxQueue );//追踪
				//消息-1
				pxQueue->uxMessagesWaiting = uxMessagesWaiting - ( UBaseType_t ) 1;
				if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToSend ) ) == pdFALSE )
				{   //发送等待队列空检查
					if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToSend ) ) != pdFALSE )
					{   //从发送队列取出任务加入就绪队列
					    //任务调度
						queueYIELD_IF_USING_PREEMPTION();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
				taskEXIT_CRITICAL();
				return pdPASS;
			}
			else
			{   //无阻塞时间
				if( xTicksToWait == ( TickType_t ) 0 )
				{   //队列也是空的,也不阻塞,那么只好退出
					taskEXIT_CRITICAL();
					traceQUEUE_RECEIVE_FAILED( pxQueue );
					return errQUEUE_EMPTY;
				}
				else if( xEntryTimeSet == pdFALSE )
				{   //超时状态配置
					vTaskInternalSetTimeOutState( &xTimeOut );
					xEntryTimeSet = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
		taskEXIT_CRITICAL();
		vTaskSuspendAll();//任务全部挂起
		prvLockQueue( pxQueue );//队列加锁
		if( xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait ) == pdFALSE )
		{   //任务超时检查
			if( prvIsQueueEmpty( pxQueue ) != pdFALSE )
			{   //队列非空时
				traceBLOCKING_ON_QUEUE_RECEIVE( pxQueue );//追踪
				//将本任务加入到事件链表,为当前事件在队列中配置延迟
				vTaskPlaceOnEventList( &( pxQueue->xTasksWaitingToReceive ), xTicksToWait );
				prvUnlockQueue( pxQueue );//解锁
				if( xTaskResumeAll() == pdFALSE )
				{   //任务恢复,恢复时一般不会上下文切换(任务调度)
				    //否则本任务会以高优先级加入就绪队列
					portYIELD_WITHIN_API();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				prvUnlockQueue( pxQueue );//解锁
				( void ) xTaskResumeAll();//恢复
			}
		}
		else
		{   //解锁,恢复
			prvUnlockQueue( pxQueue );
			( void ) xTaskResumeAll();
			if( prvIsQueueEmpty( pxQueue ) != pdFALSE )
			{   //队列空检查
				traceQUEUE_RECEIVE_FAILED( pxQueue );
				return errQUEUE_EMPTY;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
	}
}

//获取信号量
BaseType_t xQueueSemaphoreTake( QueueHandle_t xQueue, TickType_t xTicksToWait )
{
BaseType_t xEntryTimeSet = pdFALSE;
TimeOut_t xTimeOut;
Queue_t * const pxQueue = xQueue;
#if( configUSE_MUTEXES == 1 )//互斥锁使用
	BaseType_t xInheritanceOccurred = pdFALSE;
#endif
	configASSERT( ( pxQueue ) );//断言
	configASSERT( pxQueue->uxItemSize == 0 );
	#if ( ( INCLUDE_xTaskGetSchedulerState == 1 ) || ( configUSE_TIMERS == 1 ) )
	{
		configASSERT( !( ( xTaskGetSchedulerState() == taskSCHEDULER_SUSPENDED ) && ( xTicksToWait != 0 ) ) );
	}
	#endif

	for( ;; )
	{   //临界区进入
		taskENTER_CRITICAL();
		{   //信号量的值要为0,因为是队列重用,信号量不具备项空间,但该值也被复用为嵌套层数
    		const UBaseType_t uxSemaphoreCount = pxQueue->uxMessagesWaiting;
			if( uxSemaphoreCount > ( UBaseType_t ) 0 )
			{   //基准值大于0？扣除一次
				traceQUEUE_RECEIVE( pxQueue );
				pxQueue->uxMessagesWaiting = uxSemaphoreCount - ( UBaseType_t ) 1;
				#if ( configUSE_MUTEXES == 1 )
				{   //使用互斥锁？
					if( pxQueue->uxQueueType == queueQUEUE_IS_MUTEX )
					{   //互斥锁类型检查,锁的所有者进行增计数,表明获取一次嵌套
					    pxQueue->u.xSemaphore.xMutexHolder = pvTaskIncrementMutexHeldCount();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				#endif
				if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToSend ) ) == pdFALSE )
				{   //队列非空
					if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToSend ) ) != pdFALSE )
					{   //将一个最高优先级任务从等待发送移除,送入就绪队列中
						queueYIELD_IF_USING_PREEMPTION();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}

				taskEXIT_CRITICAL();
				return pdPASS;
			}
			else
			{
				if( xTicksToWait == ( TickType_t ) 0 )
				{   //延时检查
					#if( configUSE_MUTEXES == 1 )
					{
						configASSERT( xInheritanceOccurred == pdFALSE );
					}
					#endif
                    //信号量是0且没有延迟阻塞了
					taskEXIT_CRITICAL();
					traceQUEUE_RECEIVE_FAILED( pxQueue );
					return errQUEUE_EMPTY;
				}
				else if( xEntryTimeSet == pdFALSE )
				{   //配置任务就绪延迟
					vTaskInternalSetTimeOutState( &xTimeOut );
					xEntryTimeSet = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
		taskEXIT_CRITICAL();
		vTaskSuspendAll();//任务挂起全部
		prvLockQueue( pxQueue );//队列上锁,对本信号量上锁
		if( xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait ) == pdFALSE )
		{   //更新超时状态
			if( prvIsQueueEmpty( pxQueue ) != pdFALSE )
			{   //等待队列非空时
				traceBLOCKING_ON_QUEUE_RECEIVE( pxQueue );
				#if ( configUSE_MUTEXES == 1 )
				{   //使用互斥锁,类型为互斥锁时
					if( pxQueue->uxQueueType == queueQUEUE_IS_MUTEX )
					{
						taskENTER_CRITICAL();
						{   //优先级继承,从信号量的互斥锁类型中的所有者李继承下来
							xInheritanceOccurred = xTaskPriorityInherit( pxQueue->u.xSemaphore.xMutexHolder );
						}
						taskEXIT_CRITICAL();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				#endif
                //当前任务加入等待接收队列中,并为当前任务配置延迟阻塞
				vTaskPlaceOnEventList( &( pxQueue->xTasksWaitingToReceive ), xTicksToWait );
				prvUnlockQueue( pxQueue );//解锁队列
				if( xTaskResumeAll() == pdFALSE )
				{   //恢复全部任务
					portYIELD_WITHIN_API();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				prvUnlockQueue( pxQueue );
				( void ) xTaskResumeAll();
			}
		}
		else
		{   //等待超时了,要回退
			prvUnlockQueue( pxQueue );
			( void ) xTaskResumeAll();
			if( prvIsQueueEmpty( pxQueue ) != pdFALSE )
			{   //等待消息不为0
				#if ( configUSE_MUTEXES == 1 )
				{   //继承完成
					if( xInheritanceOccurred != pdFALSE )
					{
						taskENTER_CRITICAL();
						{   
							UBaseType_t uxHighestWaitingPriority;
                            //返回一个更高优先级任务的优先级
							uxHighestWaitingPriority = prvGetDisinheritPriorityAfterTimeout( pxQueue );
							vTaskPriorityDisinheritAfterTimeout( pxQueue->u.xSemaphore.xMutexHolder, uxHighestWaitingPriority );
						}
						taskEXIT_CRITICAL();
					}
				}
				#endif
				traceQUEUE_RECEIVE_FAILED( pxQueue );
				return errQUEUE_EMPTY;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
	}
}

//队列数据获取
BaseType_t xQueuePeek( QueueHandle_t xQueue, void * const pvBuffer, TickType_t xTicksToWait )
{
BaseType_t xEntryTimeSet = pdFALSE;
TimeOut_t xTimeOut;
int8_t *pcOriginalReadPosition;
Queue_t * const pxQueue = xQueue;
	configASSERT( ( pxQueue ) );//断言检查
	configASSERT( !( ( ( pvBuffer ) == NULL ) && ( ( pxQueue )->uxItemSize != ( UBaseType_t ) 0U ) ) );
	#if ( ( INCLUDE_xTaskGetSchedulerState == 1 ) || ( configUSE_TIMERS == 1 ) )
	{
		configASSERT( !( ( xTaskGetSchedulerState() == taskSCHEDULER_SUSPENDED ) && ( xTicksToWait != 0 ) ) );
	}
	#endif

	for( ;; )
	{
		taskENTER_CRITICAL();
		{   //获取等待消息数
			const UBaseType_t uxMessagesWaiting = pxQueue->uxMessagesWaiting;
			if( uxMessagesWaiting > ( UBaseType_t ) 0 )
			{   //不为0,表明有数据
			    //定位指针将在哪里阅读
				pcOriginalReadPosition = pxQueue->u.xQueue.pcReadFrom;
                //数据拷贝出来
				prvCopyDataFromQueue( pxQueue, pvBuffer );
				traceQUEUE_PEEK( pxQueue );
                //更新queue中的读指针
                pxQueue->u.xQueue.pcReadFrom = pcOriginalReadPosition;
				if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
				{   //等待队列非空时
					if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
					{   //选一个高优先级任务丢入,就绪队列
					    //之后启动任务调度
						queueYIELD_IF_USING_PREEMPTION();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
				taskEXIT_CRITICAL();
				return pdPASS;
			}
			else
			{
				if( xTicksToWait == ( TickType_t ) 0 )
				{   //当前队列为空,没有阻塞,(或者过期),读不了数据,那么退出
					taskEXIT_CRITICAL();
					traceQUEUE_PEEK_FAILED( pxQueue );
					return errQUEUE_EMPTY;
				}
				else if( xEntryTimeSet == pdFALSE )
				{   //设置内部超时时间(默认超时时间)
					vTaskInternalSetTimeOutState( &xTimeOut );
					xEntryTimeSet = pdTRUE;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
		taskEXIT_CRITICAL();
		vTaskSuspendAll();//挂起全部任务
		prvLockQueue( pxQueue );//队列上锁
		if( xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait ) == pdFALSE )
		{   //超时未过期
			if( prvIsQueueEmpty( pxQueue ) != pdFALSE )
			{   //消息不为空
				traceBLOCKING_ON_QUEUE_PEEK( pxQueue );
                //将当前任务加入到等待接受队列中,添加任务延迟时间
				vTaskPlaceOnEventList( &( pxQueue->xTasksWaitingToReceive ), xTicksToWait );
				prvUnlockQueue( pxQueue );//上锁
				if( xTaskResumeAll() == pdFALSE )
				{   //全部任务恢复
					portYIELD_WITHIN_API();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{   //队列有数据,不阻塞
				prvUnlockQueue( pxQueue );
				( void ) xTaskResumeAll();
			}
		}
		else
		{  
			prvUnlockQueue( pxQueue );
			( void ) xTaskResumeAll();
            //队列还是没有数据
			if( prvIsQueueEmpty( pxQueue ) != pdFALSE )
			{   //退出
				traceQUEUE_PEEK_FAILED( pxQueue );
				return errQUEUE_EMPTY;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
	} 
}

//中断环境下队列接受
BaseType_t xQueueReceiveFromISR( QueueHandle_t xQueue, void * const pvBuffer, BaseType_t * const pxHigherPriorityTaskWoken )
{
BaseType_t xReturn;
UBaseType_t uxSavedInterruptStatus;
Queue_t * const pxQueue = xQueue;
	configASSERT( pxQueue );
	configASSERT( !( ( pvBuffer == NULL ) && ( pxQueue->uxItemSize != ( UBaseType_t ) 0U ) ) );
    //高中断优先级检查
	portASSERT_IF_INTERRUPT_PRIORITY_INVALID();
    //当前中断状态获取
	uxSavedInterruptStatus = portSET_INTERRUPT_MASK_FROM_ISR();
	{   //消息等待数
		const UBaseType_t uxMessagesWaiting = pxQueue->uxMessagesWaiting;
        if( uxMessagesWaiting > ( UBaseType_t ) 0 )
		{
			const int8_t cRxLock = pxQueue->cRxLock;
			traceQUEUE_RECEIVE_FROM_ISR( pxQueue );
            //从队列拷贝一个数据
			prvCopyDataFromQueue( pxQueue, pvBuffer );
            //数据接受,等待处理的一次已经完成-1
            pxQueue->uxMessagesWaiting = uxMessagesWaiting - ( UBaseType_t ) 1;
			if( cRxLock == queueUNLOCKED )
			{   //未上锁
				if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToSend ) ) == pdFALSE )
				{   //等待发送队列非空
					if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToSend ) ) != pdFALSE )
					{   //进行等待发送队列中取出最高优先级任务,加入到就绪队列中
						if( pxHigherPriorityTaskWoken != NULL )
						{   //高优先级唤醒
							*pxHigherPriorityTaskWoken = pdTRUE;
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{   //上锁记录表明数据是否被移除
				pxQueue->cRxLock = ( int8_t ) ( cRxLock + 1 );
			}
			xReturn = pdPASS;
		}
		else
		{
			xReturn = pdFAIL;
			traceQUEUE_RECEIVE_FROM_ISR_FAILED( pxQueue );
		}
	}
	portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );

	return xReturn;
}

//中断数据获取
BaseType_t xQueuePeekFromISR( QueueHandle_t xQueue,  void * const pvBuffer )
{
BaseType_t xReturn;
UBaseType_t uxSavedInterruptStatus;
int8_t *pcOriginalReadPosition;
Queue_t * const pxQueue = xQueue;
	configASSERT( pxQueue );
	configASSERT( !( ( pvBuffer == NULL ) && ( pxQueue->uxItemSize != ( UBaseType_t ) 0U ) ) );
	configASSERT( pxQueue->uxItemSize != 0 ); /* Can't peek a semaphore. */
    //中断优先级检查
	portASSERT_IF_INTERRUPT_PRIORITY_INVALID();
    //获取当前中断状态
	uxSavedInterruptStatus = portSET_INTERRUPT_MASK_FROM_ISR();
	{   //检查消息是否存在
		if( pxQueue->uxMessagesWaiting > ( UBaseType_t ) 0 )
		{   //从队列中拷贝数据出来,并更新读的位置
			traceQUEUE_PEEK_FROM_ISR( pxQueue );
            pcOriginalReadPosition = pxQueue->u.xQueue.pcReadFrom;
			prvCopyDataFromQueue( pxQueue, pvBuffer );
			pxQueue->u.xQueue.pcReadFrom = pcOriginalReadPosition;
			xReturn = pdPASS;
		}
		else
		{
			xReturn = pdFAIL;
			traceQUEUE_PEEK_FROM_ISR_FAILED( pxQueue );
		}
	}
	portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedInterruptStatus );

	return xReturn;
}

//队列消息等待数
UBaseType_t uxQueueMessagesWaiting( const QueueHandle_t xQueue )
{
UBaseType_t uxReturn;
	configASSERT( xQueue );
	taskENTER_CRITICAL();
	{
		uxReturn = ( ( Queue_t * ) xQueue )->uxMessagesWaiting;
	}
	taskEXIT_CRITICAL();

	return uxReturn;
} 

//队列空间合法检查
UBaseType_t uxQueueSpacesAvailable( const QueueHandle_t xQueue )
{
UBaseType_t uxReturn;
Queue_t * const pxQueue = xQueue;
	configASSERT( pxQueue );
	taskENTER_CRITICAL();
	{   //uxMessagesWaiting <= uxLength 是硬条件
		uxReturn = pxQueue->uxLength - pxQueue->uxMessagesWaiting;
	}
	taskEXIT_CRITICAL();
	return uxReturn;
}

//中断模式下消息等待数查询
UBaseType_t uxQueueMessagesWaitingFromISR( const QueueHandle_t xQueue )
{
UBaseType_t uxReturn;
Queue_t * const pxQueue = xQueue;
	configASSERT( pxQueue );
	uxReturn = pxQueue->uxMessagesWaiting;
	return uxReturn;
} 

//队列删除
void vQueueDelete( QueueHandle_t xQueue )
{
Queue_t * const pxQueue = xQueue;
	configASSERT( pxQueue );
	traceQUEUE_DELETE( pxQueue );

	#if ( configQUEUE_REGISTRY_SIZE > 0 )
	{   反注册一个队列
		vQueueUnregisterQueue( pxQueue );
	}
	#endif

	#if( ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 0 ) )
	{   //没有静态分配,直接删掉
		vPortFree( pxQueue );
	}
	#elif( ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 1 ) )
	{   //有静态分配策略,要检查检查,是否是静态分配
		if( pxQueue->ucStaticallyAllocated == ( uint8_t ) pdFALSE )
		{
			vPortFree( pxQueue );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	#else
	{   //哈哈删不掉,因为是静态分配的(全局变量)
		( void ) pxQueue;
	}
	#endif
}

//如果使用追踪功能
#if ( configUSE_TRACE_FACILITY == 1 )
	UBaseType_t uxQueueGetQueueNumber( QueueHandle_t xQueue )
	{   //队列数量检查
		return ( ( Queue_t * ) xQueue )->uxQueueNumber;
	}

#endif

#if ( configUSE_TRACE_FACILITY == 1 )
	void vQueueSetQueueNumber( QueueHandle_t xQueue, UBaseType_t uxQueueNumber )
	{   //队列数量检查
		( ( Queue_t * ) xQueue )->uxQueueNumber = uxQueueNumber;
	}

#endif

#if ( configUSE_TRACE_FACILITY == 1 )
	uint8_t ucQueueGetQueueType( QueueHandle_t xQueue )
	{   //队列类型获取
		return ( ( Queue_t * ) xQueue )->ucQueueType;
	}

#endif

//使用互斥锁
#if( configUSE_MUTEXES == 1 )
	static UBaseType_t prvGetDisinheritPriorityAfterTimeout( const Queue_t * const pxQueue )
	{
	UBaseType_t uxHighestPriorityOfWaitingTasks;
		if( listCURRENT_LIST_LENGTH( &( pxQueue->xTasksWaitingToReceive ) ) > 0U )
		{   //获取等待队列中的最大优先级
			uxHighestPriorityOfWaitingTasks = ( UBaseType_t ) configMAX_PRIORITIES - ( UBaseType_t ) listGET_ITEM_VALUE_OF_HEAD_ENTRY( &( pxQueue->xTasksWaitingToReceive ) );
		}
		else
		{   //默认空闲优先级
			uxHighestPriorityOfWaitingTasks = tskIDLE_PRIORITY;
		}
		return uxHighestPriorityOfWaitingTasks;
	}
#endif 

//数据拷贝到队列
static BaseType_t prvCopyDataToQueue( Queue_t * const pxQueue, const void *pvItemToQueue, const BaseType_t xPosition )
{
BaseType_t xReturn = pdFALSE;
UBaseType_t uxMessagesWaiting;
	uxMessagesWaiting = pxQueue->uxMessagesWaiting;
	if( pxQueue->uxItemSize == ( UBaseType_t ) 0 )
	{   //项大小为0,莫得拷贝,(说明队列被复用了)
		#if ( configUSE_MUTEXES == 1 )
		{
			if( pxQueue->uxQueueType == queueQUEUE_IS_MUTEX )
			{   //哟,是一个互斥锁啊,优先级调回去,调回去
				xReturn = xTaskPriorityDisinherit( pxQueue->u.xSemaphore.xMutexHolder );
				pxQueue->u.xSemaphore.xMutexHolder = NULL;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		#endif
	}
	else if( xPosition == queueSEND_TO_BACK )//拷贝到队列尾,从前往后走
	{   //拷贝数据到队列中
		( void ) memcpy( ( void * ) pxQueue->pcWriteTo, pvItemToQueue, ( size_t ) pxQueue->uxItemSize ); 
		pxQueue->pcWriteTo += pxQueue->uxItemSize;//下一次写入的偏移
		if( pxQueue->pcWriteTo >= pxQueue->u.xQueue.pcTail )
		{   //哟,写到末尾去了,跳到开始,还就哪个循环队列
			pxQueue->pcWriteTo = pxQueue->pcHead;
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else//拷贝到队列头,从后往前走
	{   //拷贝数据到队列中
		( void ) memcpy( ( void * ) pxQueue->u.xQueue.pcReadFrom, pvItemToQueue, ( size_t ) pxQueue->uxItemSize );
        pxQueue->u.xQueue.pcReadFrom -= pxQueue->uxItemSize;//下一次读取的偏移,注意要向前偏移
		if( pxQueue->u.xQueue.pcReadFrom < pxQueue->pcHead )
		{   //哟,读到外太空去了,跳到队列尾去
			pxQueue->u.xQueue.pcReadFrom = ( pxQueue->u.xQueue.pcTail - pxQueue->uxItemSize );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}

		if( xPosition == queueOVERWRITE )//重写方式
		{   //重写意味着覆盖,覆盖实际上不加新的数据,只是将原来某一部分数据更新了
			if( uxMessagesWaiting > ( UBaseType_t ) 0 )
			{   //等待消息数扣除一个
				--uxMessagesWaiting;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
    //新加了一个数据
	pxQueue->uxMessagesWaiting = uxMessagesWaiting + ( UBaseType_t ) 1;

	return xReturn;
}

//从队列拷贝数据处理
static void prvCopyDataFromQueue( Queue_t * const pxQueue, void * const pvBuffer )
{
	if( pxQueue->uxItemSize != ( UBaseType_t ) 0 )
	{   //读取偏移直接往后跳
		pxQueue->u.xQueue.pcReadFrom += pxQueue->uxItemSize;
        if( pxQueue->u.xQueue.pcReadFrom >= pxQueue->u.xQueue.pcTail )
            //跳到最后时回到开始
			pxQueue->u.xQueue.pcReadFrom = pxQueue->pcHead;
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
        //拷贝数据
		( void ) memcpy( ( void * ) pvBuffer, ( void * ) pxQueue->u.xQueue.pcReadFrom, ( size_t ) pxQueue->uxItemSize );
    }
}

//队列去锁
static void prvUnlockQueue( Queue_t * const pxQueue )
{
	taskENTER_CRITICAL();
	{
		int8_t cTxLock = pxQueue->cTxLock;
        //写锁大于-1,就是有锁,大于0,那有别的事务未完成
		while( cTxLock > queueLOCKED_UNMODIFIED )
		{   //队列组被使用
			#if ( configUSE_QUEUE_SETS == 1 )
			{   //存在上级
				if( pxQueue->pxQueueSetContainer != NULL )
				{   //将自己写入到上级的队列尾
					if( prvNotifyQueueSetContainer( pxQueue, queueSEND_TO_BACK ) != pdFALSE )
					{   //还就那个调度被挂起,停止任务调度
						vTaskMissedYield();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else//孤儿队列
				{      
					if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
					{   //队列非空
						if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
						{   //从接受等待队列挑一个优先级最高的丢入就绪队列,关闭任务调度
							vTaskMissedYield();
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else
					{
						break;
					}
				}
			}
			#else //无队列组
			{   //如上
				if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
				{
					if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
					{
						vTaskMissedYield();
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					break;
				}
			}
			#endif 
            //锁降一级
			--cTxLock;
		}
		pxQueue->cTxLock = queueUNLOCKED;
	}
	taskEXIT_CRITICAL();
    //至此写锁已经降到0层了
    //再降读锁
	taskENTER_CRITICAL();
	{
		int8_t cRxLock = pxQueue->cRxLock;

		while( cRxLock > queueLOCKED_UNMODIFIED )
		{
			if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToSend ) ) == pdFALSE )
			{   //从等待发送队列,取一个最高优先级线程移出,然后移入就绪队列
				if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToSend ) ) != pdFALSE )
				{
					vTaskMissedYield();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
                //降一层锁,降到不能降为止
				--cRxLock;
			}
			else
			{
				break;
			}
		}

		pxQueue->cRxLock = queueUNLOCKED;
	}
	taskEXIT_CRITICAL();
}
//注意:自此Rx对应Send,Tx对应Receive便一目了然了

//队列为空？
static BaseType_t prvIsQueueEmpty( const Queue_t *pxQueue )
{
BaseType_t xReturn;
	taskENTER_CRITICAL();
	{
		if( pxQueue->uxMessagesWaiting == ( UBaseType_t )  0 )
		{
			xReturn = pdTRUE;
		}
		else
		{
			xReturn = pdFALSE;
		}
	}
	taskEXIT_CRITICAL();
	return xReturn;
}

//中断环境下,队列为空
BaseType_t xQueueIsQueueEmptyFromISR( const QueueHandle_t xQueue )
{
BaseType_t xReturn;
Queue_t * const pxQueue = xQueue;
	configASSERT( pxQueue );
	if( pxQueue->uxMessagesWaiting == ( UBaseType_t ) 0 )
	{
		xReturn = pdTRUE;
	}
	else
	{
		xReturn = pdFALSE;
	}
	return xReturn;
} 

//队列满判断
static BaseType_t prvIsQueueFull( const Queue_t *pxQueue )
{
BaseType_t xReturn;
	taskENTER_CRITICAL();
	{
		if( pxQueue->uxMessagesWaiting == pxQueue->uxLength )
		{
			xReturn = pdTRUE;
		}
		else
		{
			xReturn = pdFALSE;
		}
	}
	taskEXIT_CRITICAL();
	return xReturn;
}

//中断环境下队列满判断
BaseType_t xQueueIsQueueFullFromISR( const QueueHandle_t xQueue )
{
BaseType_t xReturn;
Queue_t * const pxQueue = xQueue;
	configASSERT( pxQueue );
	if( pxQueue->uxMessagesWaiting == pxQueue->uxLength )
	{
		xReturn = pdTRUE;
	}
	else
	{
		xReturn = pdFALSE;
	}

	return xReturn;
} 

//协程的使用
#if ( configUSE_CO_ROUTINES == 1 )
	BaseType_t xQueueCRSend( QueueHandle_t xQueue, const void *pvItemToQueue, TickType_t xTicksToWait )
	{
	BaseType_t xReturn;
	Queue_t * const pxQueue = xQueue;
		portDISABLE_INTERRUPTS();//还就那个直接关中断
		{   //队列满判断
			if( prvIsQueueFull( pxQueue ) != pdFALSE )
			{   //存在延迟
				if( xTicksToWait > ( TickType_t ) 0 )
				{   //让朋友去分担分担这些任务
					vCoRoutineAddToDelayedList( xTicksToWait, &( pxQueue->xTasksWaitingToSend ) );
					portENABLE_INTERRUPTS();//开中断
					return errQUEUE_BLOCKED;
				}
				else
				{   //开中断,这里不能分担是未被阻塞或过期等
					portENABLE_INTERRUPTS();
					return errQUEUE_FULL;
				}
			}
		}
		portENABLE_INTERRUPTS();

		portDISABLE_INTERRUPTS();
		{   //队列不是满的
			if( pxQueue->uxMessagesWaiting < pxQueue->uxLength )
			{   //从队列里面尾部拷贝
				prvCopyDataToQueue( pxQueue, pvItemToQueue, queueSEND_TO_BACK );
				xReturn = pdPASS;
				if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
				{   //接受等待队列不空
					if( xCoRoutineRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
					{   //从等待接受队列移除任务,然后加到协程就绪队列
						xReturn = errQUEUE_YIELD;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				xReturn = errQUEUE_FULL;
			}
		}
		portENABLE_INTERRUPTS();
		return xReturn;
	}

#endif

//使用协程
#if ( configUSE_CO_ROUTINES == 1 )
	BaseType_t xQueueCRReceive( QueueHandle_t xQueue, void *pvBuffer, TickType_t xTicksToWait )
	{
	BaseType_t xReturn;
	Queue_t * const pxQueue = xQueue;
        //中断关闭
		portDISABLE_INTERRUPTS();
		{   //消息为空
			if( pxQueue->uxMessagesWaiting == ( UBaseType_t ) 0 )
			{   //延迟存在
				if( xTicksToWait > ( TickType_t ) 0 )
				{   //将等待接受队列添加延迟丢入到协程延迟队列中
					vCoRoutineAddToDelayedList( xTicksToWait, &( pxQueue->xTasksWaitingToReceive ) );
					portENABLE_INTERRUPTS();//中断使能
					return errQUEUE_BLOCKED;
				}
				else
				{
					portENABLE_INTERRUPTS();
					return errQUEUE_FULL;
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		portENABLE_INTERRUPTS();

		portDISABLE_INTERRUPTS();
		{   //有消息
			if( pxQueue->uxMessagesWaiting > ( UBaseType_t ) 0 )
			{   //调整读指针
				pxQueue->u.xQueue.pcReadFrom += pxQueue->uxItemSize;
				if( pxQueue->u.xQueue.pcReadFrom >= pxQueue->u.xQueue.pcTail )
				{
					pxQueue->u.xQueue.pcReadFrom = pxQueue->pcHead;
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
				--( pxQueue->uxMessagesWaiting );//消息数-1
                //拷贝到外界
				( void ) memcpy( ( void * ) pvBuffer, ( void * ) pxQueue->u.xQueue.pcReadFrom, ( unsigned ) pxQueue->uxItemSize );
				xReturn = pdPASS;
				if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToSend ) ) == pdFALSE )
				{   //发送等待队列非空
					if( xCoRoutineRemoveFromEventList( &( pxQueue->xTasksWaitingToSend ) ) != pdFALSE )
					{   //取高优先级任务,从发送等待队列中,送入协程就绪队列
						xReturn = errQUEUE_YIELD;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				xReturn = pdFAIL;
			}
		}
		portENABLE_INTERRUPTS();

		return xReturn;
	}

#endif 

//中断环境下协程发送
#if ( configUSE_CO_ROUTINES == 1 )
	BaseType_t xQueueCRSendFromISR( QueueHandle_t xQueue, const void *pvItemToQueue, BaseType_t xCoRoutinePreviouslyWoken )
	{
	Queue_t * const pxQueue = xQueue;
		if( pxQueue->uxMessagesWaiting < pxQueue->uxLength )
		{   //消息不满,直接加入到队列的尾部
			prvCopyDataToQueue( pxQueue, pvItemToQueue, queueSEND_TO_BACK );
			if( xCoRoutinePreviouslyWoken == pdFALSE )
			{   //协程唤醒标记？
				if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) == pdFALSE )
				{   //接受等待队列非空
					if( xCoRoutineRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
					{   //取一个送到协程就绪队列中
						return pdTRUE;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
		return xCoRoutinePreviouslyWoken;
	}

#endif 

//中断环境下协程接受
#if ( configUSE_CO_ROUTINES == 1 )
	BaseType_t xQueueCRReceiveFromISR( QueueHandle_t xQueue, void *pvBuffer, BaseType_t *pxCoRoutineWoken )
	{
	BaseType_t xReturn;
	Queue_t * const pxQueue = xQueue;
		if( pxQueue->uxMessagesWaiting > ( UBaseType_t ) 0 )
		{   //存在等待消息数
			pxQueue->u.xQueue.pcReadFrom += pxQueue->uxItemSize;
			if( pxQueue->u.xQueue.pcReadFrom >= pxQueue->u.xQueue.pcTail )
			{   //读取定位
				pxQueue->u.xQueue.pcReadFrom = pxQueue->pcHead;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
            //消息数-1
			--( pxQueue->uxMessagesWaiting );
            //拷贝到外界
			( void ) memcpy( ( void * ) pvBuffer, ( void * ) pxQueue->u.xQueue.pcReadFrom, ( unsigned ) pxQueue->uxItemSize );
			if( ( *pxCoRoutineWoken ) == pdFALSE )
			{   //协程唤醒？
				if( listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToSend ) ) == pdFALSE )
				{   //发送等待队列不为空
					if( xCoRoutineRemoveFromEventList( &( pxQueue->xTasksWaitingToSend ) ) != pdFALSE )
					{   //发送等待队列中取一个送到协程就绪队列中
						*pxCoRoutineWoken = pdTRUE;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}

			xReturn = pdPASS;
		}
		else
		{
			xReturn = pdFAIL;
		}

		return xReturn;
	}

#endif

//队列注册时尺寸大小
#if ( configQUEUE_REGISTRY_SIZE > 0 )
	void vQueueAddToRegistry( QueueHandle_t xQueue, const char *pcQueueName )
	{
	UBaseType_t ux;
		for( ux = ( UBaseType_t ) 0U; ux < ( UBaseType_t ) configQUEUE_REGISTRY_SIZE; ux++ )
		{   //注册尺寸不为0
			if( xQueueRegistry[ ux ].pcQueueName == NULL )
			{   //初始化,利用参数
				xQueueRegistry[ ux ].pcQueueName = pcQueueName;
				xQueueRegistry[ ux ].xHandle = xQueue;
				traceQUEUE_REGISTRY_ADD( xQueue, pcQueueName );
				break;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
	}

#endif 

#if ( configQUEUE_REGISTRY_SIZE > 0 )
	const char *pcQueueGetName( QueueHandle_t xQueue )
	{
	UBaseType_t ux;
	const char *pcReturn = NULL;
		for( ux = ( UBaseType_t ) 0U; ux < ( UBaseType_t ) configQUEUE_REGISTRY_SIZE; ux++ )
		{
			if( xQueueRegistry[ ux ].xHandle == xQueue )
			{   //名字获取
				pcReturn = xQueueRegistry[ ux ].pcQueueName;
				break;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}

		return pcReturn;
	} 
#endif


#if ( configQUEUE_REGISTRY_SIZE > 0 )
	void vQueueUnregisterQueue( QueueHandle_t xQueue )
	{
	UBaseType_t ux;
		for( ux = ( UBaseType_t ) 0U; ux < ( UBaseType_t ) configQUEUE_REGISTRY_SIZE; ux++ )
		{
			if( xQueueRegistry[ ux ].xHandle == xQueue )
			{   //注册的反动作
				xQueueRegistry[ ux ].pcQueueName = NULL;
				xQueueRegistry[ ux ].xHandle = ( QueueHandle_t ) 0;
				break;
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
	}

#endif

//等待消息限制
#if ( configUSE_TIMERS == 1 )
	void vQueueWaitForMessageRestricted( QueueHandle_t xQueue, TickType_t xTicksToWait, const BaseType_t xWaitIndefinitely )
	{
	Queue_t * const pxQueue = xQueue;
		prvLockQueue( pxQueue );//队列上锁
		if( pxQueue->uxMessagesWaiting == ( UBaseType_t ) 0U )
		{   //当前任务加入到接受等待队列尾,当前任务加入到延迟队列中
			vTaskPlaceOnEventListRestricted( &( pxQueue->xTasksWaitingToReceive ), xTicksToWait, xWaitIndefinitely );
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
		prvUnlockQueue( pxQueue );//队列去锁
	}

#endif 

//下面有接口

#if( ( configUSE_QUEUE_SETS == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
	QueueSetHandle_t xQueueCreateSet( const UBaseType_t uxEventQueueLength )
	{
	QueueSetHandle_t pxQueue;
        //使用集合创建队列,使用动态创建
		pxQueue = xQueueGenericCreate( uxEventQueueLength, ( UBaseType_t ) sizeof( Queue_t * ), queueQUEUE_TYPE_SET );
		return pxQueue;
	}
#endif


#if ( configUSE_QUEUE_SETS == 1 )
	BaseType_t xQueueAddToSet( QueueSetMemberHandle_t xQueueOrSemaphore, QueueSetHandle_t xQueueSet )
	{
	BaseType_t xReturn;
		taskENTER_CRITICAL();
		{
			if( ( ( Queue_t * ) xQueueOrSemaphore )->pxQueueSetContainer != NULL )
			{
				xReturn = pdFAIL;
			}
			else if( ( ( Queue_t * ) xQueueOrSemaphore )->uxMessagesWaiting != ( UBaseType_t ) 0 )
			{
				xReturn = pdFAIL;
			}
			else
			{   //信号量(队列)加入到集合中
				( ( Queue_t * ) xQueueOrSemaphore )->pxQueueSetContainer = xQueueSet;
				xReturn = pdPASS;
			}
		}
		taskEXIT_CRITICAL();

		return xReturn;
	}
#endif 

#if ( configUSE_QUEUE_SETS == 1 )
	BaseType_t xQueueRemoveFromSet( QueueSetMemberHandle_t xQueueOrSemaphore, QueueSetHandle_t xQueueSet )
	{
	BaseType_t xReturn;
	Queue_t * const pxQueueOrSemaphore = ( Queue_t * ) xQueueOrSemaphore;

		if( pxQueueOrSemaphore->pxQueueSetContainer != xQueueSet )
		{
			xReturn = pdFAIL;
		}
		else if( pxQueueOrSemaphore->uxMessagesWaiting != ( UBaseType_t ) 0 )
		{
			xReturn = pdFAIL;
		}
		else
		{
			taskENTER_CRITICAL();
			{   //移除
				pxQueueOrSemaphore->pxQueueSetContainer = NULL;
			}
			taskEXIT_CRITICAL();
			xReturn = pdPASS;
		}
		return xReturn;
	}
#endif 


#if ( configUSE_QUEUE_SETS == 1 )
	QueueSetMemberHandle_t xQueueSelectFromSet( QueueSetHandle_t xQueueSet, TickType_t const xTicksToWait )
	{
	QueueSetMemberHandle_t xReturn = NULL;
		( void ) xQueueReceive( ( QueueHandle_t ) xQueueSet, &xReturn, xTicksToWait );
		return xReturn;
	}
#endif


#if ( configUSE_QUEUE_SETS == 1 )
	QueueSetMemberHandle_t xQueueSelectFromSetFromISR( QueueSetHandle_t xQueueSet )
	{
	QueueSetMemberHandle_t xReturn = NULL;
		( void ) xQueueReceiveFromISR( ( QueueHandle_t ) xQueueSet, &xReturn, NULL ); 
		return xReturn;
	}
#endif 

//通知队列设置上级
#if ( configUSE_QUEUE_SETS == 1 )
	static BaseType_t prvNotifyQueueSetContainer( const Queue_t * const pxQueue, const BaseType_t xCopyPosition )
	{
	Queue_t *pxQueueSetContainer = pxQueue->pxQueueSetContainer;
	BaseType_t xReturn = pdFALSE;
		configASSERT( pxQueueSetContainer );//断言检查
		configASSERT( pxQueueSetContainer->uxMessagesWaiting < pxQueueSetContainer->uxLength );
        //如果消息等待数在合理的范围内
		if( pxQueueSetContainer->uxMessagesWaiting < pxQueueSetContainer->uxLength )
		{   //取锁,取写锁
			const int8_t cTxLock = pxQueueSetContainer->cTxLock;
			traceQUEUE_SEND( pxQueueSetContainer );
            //数据拷贝到队列,将自己拷贝到上级的空间
			xReturn = prvCopyDataToQueue( pxQueueSetContainer, &pxQueue, xCopyPosition );
			if( cTxLock == queueUNLOCKED )
			{   //未上锁
				if( listLIST_IS_EMPTY( &( pxQueueSetContainer->xTasksWaitingToReceive ) ) == pdFALSE )
				{   //上级的接受等待队列不为空
					if( xTaskRemoveFromEventList( &( pxQueueSetContainer->xTasksWaitingToReceive ) ) != pdFALSE )
					{   //移出,送入就绪队列
						xReturn = pdTRUE;
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			else
			{   //写锁+1,在解锁时,其他人知道上级被写过多少次了
				pxQueueSetContainer->cTxLock = ( int8_t ) ( cTxLock + 1 );
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
		return xReturn;
	}
#endif












