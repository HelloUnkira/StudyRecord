/*
 * 软件定时器
 */
#include <stdlib.h>

//接口重包含,提前定义一下用于屏蔽mpu_wappers.h造成的影响
#define MPU_WRAPPERS_INCLUDED_FROM_API_FILE

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

//定时器需要宏配置
#if ( INCLUDE_xTimerPendFunctionCall == 1 ) && ( configUSE_TIMERS == 0 )
	#error configUSE_TIMERS must be set to 1 to make the xTimerPendFunctionCall() function available.
#endif

//取消重包含,因为已经没必要了
#undef MPU_WRAPPERS_INCLUDED_FROM_API_FILE

//使用定时器
#if ( configUSE_TIMERS == 1 )
//宏定义,不延迟为0
#define tmrNO_DELAY		( TickType_t ) 0U
//定时器名字,可在FreeRTOSConfig.h中自定义
#ifndef configTIMER_SERVICE_TASK_NAME
	#define configTIMER_SERVICE_TASK_NAME "Tmr Svc"
#endif

//定时器
typedef struct tmrTimerControl
{
	const char				*pcTimerName;		//定时器名字
    ListItem_t				xTimerListItem;		//定时器在链表中的项,定时器链表
	TickType_t				xTimerPeriodInTicks;//定时器速度与频率
	UBaseType_t				uxAutoReload;		//自动重载定时器
	void 					*pvTimerID;			//定时器ID
	TimerCallbackFunction_t	pxCallbackFunction;	//定时器回调
	#if( configUSE_TRACE_FACILITY == 1 )
		UBaseType_t			uxTimerNumber;		//定时器数量,用于追踪使用
	#endif
                                                //静态分配标志位,防止动态释放静态分配的定时器
	#if( ( configSUPPORT_STATIC_ALLOCATION == 1 ) && ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) )
		uint8_t 			ucStaticallyAllocated;
	#endif
} xTIMER;

typedef xTIMER Timer_t;

typedef struct tmrTimerParameters
{
	TickType_t			xMessageValue;		//可选的子集(参数)
	Timer_t *			pxTimer;			//实际应用到的定时器
} TimerParameter_t;

typedef struct tmrCallbackParameters
{
	PendedFunction_t	pxCallbackFunction;	//定时器回调钩子
	void *pvParameter1;						//回调要用到的第一个参数
	uint32_t ulParameter2;					//回调要用到的第二个参数
} CallbackParameters_t;

typedef struct tmrTimerQueueMessage
{
	BaseType_t			xMessageID;			//定时器服务任务接受的消息,ID号
	union
	{
		TimerParameter_t xTimerParameters;
		//如果回调用不到参数的话别使用扩展
		#if ( INCLUDE_xTimerPendFunctionCall == 1 )
			CallbackParameters_t xCallbackParameters;
		#endif
	} u;
} DaemonTaskMessage_t;//守护任务消息

//活跃定时器链表
PRIVILEGED_DATA static List_t xActiveTimerList1;
PRIVILEGED_DATA static List_t xActiveTimerList2;
//当前定时器链表
PRIVILEGED_DATA static List_t *pxCurrentTimerList;
//溢出定时器链表
PRIVILEGED_DATA static List_t *pxOverflowTimerList;
//下述俩个是用于向定时器服务任务提供消息传递所用
PRIVILEGED_DATA static QueueHandle_t xTimerQueue = NULL;
PRIVILEGED_DATA static TaskHandle_t xTimerTaskHandle = NULL;


#if( configSUPPORT_STATIC_ALLOCATION == 1 )//静态定时器
	extern void vApplicationGetTimerTaskMemory( StaticTask_t **ppxTimerTaskTCBBuffer, StackType_t **ppxTimerTaskStackBuffer, uint32_t *pulTimerTaskStackSize );
#endif

//定时器服务任务的初始化
static void prvCheckForValidListAndQueue( void ) PRIVILEGED_FUNCTION;

//定时器守护任务,定时器的实际管理者,与外界依靠xTimerQueue
static void prvTimerTask( void *pvParameters ) PRIVILEGED_FUNCTION;

//守护任务的辅助,解析xTimerQueue中的命令
static void prvProcessReceivedCommands( void ) PRIVILEGED_FUNCTION;

//插入定时器到xActiveTimerList1或xActiveTimerList2,根据是否过期导致的定时器溢出
static BaseType_t prvInsertTimerInActiveList( Timer_t * const pxTimer, const TickType_t xNextExpiryTime, const TickType_t xTimeNow, const TickType_t xCommandTime ) PRIVILEGED_FUNCTION;

//过期处理,如果是重加载定时器,重新加载它。最后调用定时器回调函数
static void prvProcessExpiredTimer( const TickType_t xNextExpireTime, const TickType_t xTimeNow ) PRIVILEGED_FUNCTION;

//定时器溢出,当前定时器链表如果不引用某些定时器后,切换定时器链表
static void prvSwitchTimerLists( void ) PRIVILEGED_FUNCTION;

//获取当前滴答数,如果上次调用到此次调用中间发送溢出,将参数设置为TRUE
static TickType_t prvSampleTimeNow( BaseType_t * const pxTimerListsWereSwitched ) PRIVILEGED_FUNCTION;

//下一个过期定时器获取,如果定时器为空,返回0
static TickType_t prvGetNextExpireTime( BaseType_t * const pxListWasEmpty ) PRIVILEGED_FUNCTION;

//定时器过期或收到命令后处理,否则阻塞计时器服务任务
static void prvProcessTimerOrBlockTask( const TickType_t xNextExpireTime, BaseType_t xListWasEmpty ) PRIVILEGED_FUNCTION;

//初始化一个新的定时器,使用参数传入的值
static void prvInitialiseNewTimer(	const char * const pcTimerName,			
									const TickType_t xTimerPeriodInTicks,
									const UBaseType_t uxAutoReload,
									void * const pvTimerID,
									TimerCallbackFunction_t pxCallbackFunction,
									Timer_t *pxNewTimer ) PRIVILEGED_FUNCTION;

//定时器创建定时器任务
BaseType_t xTimerCreateTimerTask( void )
{
BaseType_t xReturn = pdFAIL;
	//定时器创建与初始化检查
	prvCheckForValidListAndQueue();
	if( xTimerQueue != NULL )
	{   //定时器队列存在
		#if( configSUPPORT_STATIC_ALLOCATION == 1 )
		{   //优先采用静态分配策略,因为定时器
			StaticTask_t *pxTimerTaskTCBBuffer = NULL;  //定时器TCB缓冲区
			StackType_t *pxTimerTaskStackBuffer = NULL; //定时器栈缓冲区
			uint32_t ulTimerTaskStackSize;              //定时器栈大小
            //获取实际缓冲空间,这部分静态空间由用户提供
			vApplicationGetTimerTaskMemory( &pxTimerTaskTCBBuffer, &pxTimerTaskStackBuffer, &ulTimerTaskStackSize );
            //静态创建定时器任务
            xTimerTaskHandle = xTaskCreateStatic(	prvTimerTask,   //定时器任务
													configTIMER_SERVICE_TASK_NAME,  //定时器名字
													ulTimerTaskStackSize,   //定时器使用的堆栈大小
													NULL,
													( ( UBaseType_t ) configTIMER_TASK_PRIORITY ) | portPRIVILEGE_BIT,  //定时器优先级,特权级
													pxTimerTaskStackBuffer, //定时器堆栈缓冲区首地址
													pxTimerTaskTCBBuffer ); //定时器回调缓冲区首地址
			if( xTimerTaskHandle != NULL )
			{   //创建静态定时器任务成功
				xReturn = pdPASS;
			}
		}
		#else   //不存在静态分配策略时,使用动态分配策略
		{   //动态创建定时器任务
			xReturn = xTaskCreate(	prvTimerTask,   //定时器任务
									configTIMER_SERVICE_TASK_NAME,  //定时器名字
									configTIMER_TASK_STACK_DEPTH,   //定时器堆栈大小
									NULL,
									( ( UBaseType_t ) configTIMER_TASK_PRIORITY ) | portPRIVILEGE_BIT,  //定时器优先级,特权级
									&xTimerTaskHandle );    //定时器任务回调
		}
		#endif
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}

	configASSERT( xReturn );
	return xReturn;
}

//动态定时器的创建
#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
	TimerHandle_t xTimerCreate(	const char * const pcTimerName,			    //定时器名字
								const TickType_t xTimerPeriodInTicks,       //定时器频率和速度
								const UBaseType_t uxAutoReload,             //是否重加载
								void * const pvTimerID,                     //定时器ID
								TimerCallbackFunction_t pxCallbackFunction )//定时器过期回调
	{
	Timer_t *pxNewTimer;
        //动态创建一个定时器属性集
		pxNewTimer = ( Timer_t * ) pvPortMalloc( sizeof( Timer_t ) );
		if( pxNewTimer != NULL )
		{   //初始化这个新的动态定时器
			prvInitialiseNewTimer( pcTimerName, xTimerPeriodInTicks, uxAutoReload, pvTimerID, pxCallbackFunction, pxNewTimer );
			#if( configSUPPORT_STATIC_ALLOCATION == 1 )
			{   //支持静态内存分配时,需要打上标记,防止该区域被永久驻留,不被回收
				pxNewTimer->ucStaticallyAllocated = pdFALSE;
			}
			#endif
		}
        //创建成功就不需要继续静态分配了
		return pxNewTimer;
	}
#endif 

//静态定时器的创建
#if( configSUPPORT_STATIC_ALLOCATION == 1 )
	TimerHandle_t xTimerCreateStatic(	const char * const pcTimerName,
										const TickType_t xTimerPeriodInTicks,
										const UBaseType_t uxAutoReload,
										void * const pvTimerID,
										TimerCallbackFunction_t pxCallbackFunction,
										StaticTimer_t *pxTimerBuffer )
	{
	Timer_t *pxNewTimer;
		#if( configASSERT_DEFINED == 1 )
		{   //静态定时器空间的断言检查
			volatile size_t xSize = sizeof( StaticTimer_t );
			configASSERT( xSize == sizeof( Timer_t ) );
			( void ) xSize; //防止编译器warning
		}
		#endif
		configASSERT( pxTimerBuffer );
        //获得传入的为定时器分配的静态缓冲区
		pxNewTimer = ( Timer_t * ) pxTimerBuffer;
		if( pxNewTimer != NULL )
		{   //初始化新创建的定时器
			prvInitialiseNewTimer( pcTimerName, xTimerPeriodInTicks, uxAutoReload, pvTimerID, pxCallbackFunction, pxNewTimer );
			#if( configSUPPORT_DYNAMIC_ALLOCATION == 1 )
			{   //标签打上,防止错误的空间释放
				pxNewTimer->ucStaticallyAllocated = pdTRUE;
			}
			#endif
		}
		return pxNewTimer;
	}
#endif

//初始化新创建的定时器
static void prvInitialiseNewTimer(	const char * const pcTimerName,
									const TickType_t xTimerPeriodInTicks,
									const UBaseType_t uxAutoReload,
									void * const pvTimerID,
									TimerCallbackFunction_t pxCallbackFunction,
									Timer_t *pxNewTimer )
{
	configASSERT( ( xTimerPeriodInTicks > 0 ) );

	if( pxNewTimer != NULL )
	{
		//检查定时器服务任务的初始化
		prvCheckForValidListAndQueue();
        //利用参数进行配置
		pxNewTimer->pcTimerName = pcTimerName;
		pxNewTimer->xTimerPeriodInTicks = xTimerPeriodInTicks;
		pxNewTimer->uxAutoReload = uxAutoReload;
		pxNewTimer->pvTimerID = pvTimerID;
		pxNewTimer->pxCallbackFunction = pxCallbackFunction;
        //初始化新定时器的定时器项链表
		vListInitialiseItem( &( pxNewTimer->xTimerListItem ) );
		traceTIMER_CREATE( pxNewTimer );
	}
}

//定时器通用命令
BaseType_t xTimerGenericCommand( TimerHandle_t xTimer, const BaseType_t xCommandID, const TickType_t xOptionalValue, BaseType_t * const pxHigherPriorityTaskWoken, const TickType_t xTicksToWait )
{
BaseType_t xReturn = pdFAIL;
DaemonTaskMessage_t xMessage;
	configASSERT( xTimer );
	if( xTimerQueue != NULL )//命令的载体存在
	{	//创建一个消息
		xMessage.xMessageID = xCommandID;
		xMessage.u.xTimerParameters.xMessageValue = xOptionalValue;
		xMessage.u.xTimerParameters.pxTimer = xTimer;
		if( xCommandID < tmrFIRST_FROM_ISR_COMMAND )
		{   //非中断环境下的命令
			if( xTaskGetSchedulerState() == taskSCHEDULER_RUNNING )
			{   //调度器正在运行,向定时器队列发送消息,延时,发送到队列尾
				xReturn = xQueueSendToBack( xTimerQueue, &xMessage, xTicksToWait );
			}
			else
			{   //调度器没有运行,可以立刻发送消息,发送到队列尾
				xReturn = xQueueSendToBack( xTimerQueue, &xMessage, tmrNO_DELAY );
			}
		}
		else
		{   //中断环境下,向队列发送消息,发送到队列尾
			xReturn = xQueueSendToBackFromISR( xTimerQueue, &xMessage, pxHigherPriorityTaskWoken );
		}
		traceTIMER_COMMAND_SEND( xTimer, xCommandID, xOptionalValue, xReturn );
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
	return xReturn;
}


TaskHandle_t xTimerGetTimerDaemonTaskHandle( void )
{   //获取守护任务的句柄
	configASSERT( ( xTimerTaskHandle != NULL ) );
	return xTimerTaskHandle;
}

//获取定时器的频率和周期
TickType_t xTimerGetPeriod( TimerHandle_t xTimer )
{
Timer_t *pxTimer = xTimer;
	configASSERT( xTimer );
	return pxTimer->xTimerPeriodInTicks;
}

//获取定时器组中下一个要过期的定时器的过期时间
TickType_t xTimerGetExpiryTime( TimerHandle_t xTimer )
{
Timer_t * pxTimer =  xTimer;
TickType_t xReturn;

	configASSERT( xTimer );
	xReturn = listGET_LIST_ITEM_VALUE( &( pxTimer->xTimerListItem ) );
	return xReturn;
}

//获取定时器名字
const char * pcTimerGetName( TimerHandle_t xTimer )
{
Timer_t *pxTimer = xTimer;
	configASSERT( xTimer );
	return pxTimer->pcTimerName;
}

//定时器过期处理
static void prvProcessExpiredTimer( const TickType_t xNextExpireTime, const TickType_t xTimeNow )
{
BaseType_t xResult;//从当前定时器链表中获取首项
Timer_t * const pxTimer = ( Timer_t * ) listGET_OWNER_OF_HEAD_ENTRY( pxCurrentTimerList ); 
    //首项出链表
	( void ) uxListRemove( &( pxTimer->xTimerListItem ) );
	traceTIMER_EXPIRED( pxTimer );
    //定时器自动重载
	if( pxTimer->uxAutoReload == ( UBaseType_t ) pdTRUE )
	{   //将计时器设置为活跃态并加入到活跃定时器链表
		if( prvInsertTimerInActiveList( pxTimer, ( xNextExpireTime + pxTimer->xTimerPeriodInTicks ), xTimeNow, xNextExpireTime ) != pdFALSE )
		{   //发送定时器通用命令到队里,这里是发送定时器启动命令,以无延迟发送
			xResult = xTimerGenericCommand( pxTimer, tmrCOMMAND_START_DONT_TRACE, xNextExpireTime, NULL, tmrNO_DELAY );
			configASSERT( xResult );
			( void ) xResult;//阻止编译器警告warning
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	else
	{
		mtCOVERAGE_TEST_MARKER();
	}
    //定时器过期回调处理
	pxTimer->pxCallbackFunction( ( TimerHandle_t ) pxTimer );
}

//定时器后台守护任务
static void prvTimerTask( void *pvParameters )
{
TickType_t xNextExpireTime;
BaseType_t xListWasEmpty;
	( void ) pvParameters;  //阻止编译器warning
	#if( configUSE_DAEMON_TASK_STARTUP_HOOK == 1 )
	{   //使用后台任务开始回调钩子
		extern void vApplicationDaemonTaskStartupHook( void );
		//后台任务启动钩子,允许应用层添加内容
		vApplicationDaemonTaskStartupHook();
	}
	#endif

	for( ;; )
	{   //获取定时器下一个过期时间
		xNextExpireTime = prvGetNextExpireTime( &xListWasEmpty );
        //如果定时器过期,处理它,否则我将阻塞自己等待定时器,过期
		prvProcessTimerOrBlockTask( xNextExpireTime, xListWasEmpty );

		//查看xTimerQueue命令、消息队列
		prvProcessReceivedCommands();
	}
}

//非过期阻塞
static void prvProcessTimerOrBlockTask( const TickType_t xNextExpireTime, BaseType_t xListWasEmpty )
{
TickType_t xTimeNow;
BaseType_t xTimerListsWereSwitched;

	vTaskSuspendAll();//挂起所有任务
	{
		//查看当前滴答数,确认时钟链表是否被切换
		xTimeNow = prvSampleTimeNow( &xTimerListsWereSwitched );
		if( xTimerListsWereSwitched == pdFALSE )
		{   //是滴答溢出还是定时器过期？
			if( ( xListWasEmpty == pdFALSE ) && ( xNextExpireTime <= xTimeNow ) )
			{   //定时器过期
				( void ) xTaskResumeAll();//任务恢复
				//处理该过期定时器
				prvProcessExpiredTimer( xNextExpireTime, xTimeNow );
			}
			else    //滴答溢出
			{   
				if( xListWasEmpty != pdFALSE )
				{   //溢出定时器链表是否为空？
					xListWasEmpty = listLIST_IS_EMPTY( pxOverflowTimerList );
				}
                //定时器溢出,将当前任务编排入等待队列尾,当前任务加入延迟队列
				vQueueWaitForMessageRestricted( xTimerQueue, ( xNextExpireTime - xTimeNow ), xListWasEmpty );
				if( xTaskResumeAll() == pdFALSE )
				{   //任务恢复
					//命令在这个注释左右到达时,任务不会切换
					portYIELD_WITHIN_API();
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
		}
		else
		{
			( void ) xTaskResumeAll();
		}
	}
}

//获取下一个过期时间
static TickType_t prvGetNextExpireTime( BaseType_t * const pxListWasEmpty )
{
TickType_t xNextExpireTime;
    //当前链表是否为空,检查
	*pxListWasEmpty = listLIST_IS_EMPTY( pxCurrentTimerList );
	if( *pxListWasEmpty == pdFALSE )
	{   //取当前定时器链表的头定时器,它表明是一个离目前最近过期的定时器,获取它的过期时间
		xNextExpireTime = listGET_ITEM_VALUE_OF_HEAD_ENTRY( pxCurrentTimerList );
	}
	else
	{   //不存在过期
		xNextExpireTime = ( TickType_t ) 0U;
	}
	return xNextExpireTime;
}

//获取当前滴答
static TickType_t prvSampleTimeNow( BaseType_t * const pxTimerListsWereSwitched )
{
TickType_t xTimeNow;//静态变量存储滴答
PRIVILEGED_DATA static TickType_t xLastTime = ( TickType_t ) 0U;
    //获取滴答时间
	xTimeNow = xTaskGetTickCount();

	if( xTimeNow < xLastTime )  //出现滴答溢出时
	{   //更新定时器链表
		prvSwitchTimerLists();
		*pxTimerListsWereSwitched = pdTRUE;
	}
	else
	{
		*pxTimerListsWereSwitched = pdFALSE;
	}
	xLastTime = xTimeNow;
	return xTimeNow;
}

//插入一个定时器到活跃定时器链表中
static BaseType_t prvInsertTimerInActiveList( Timer_t * const pxTimer, const TickType_t xNextExpiryTime, const TickType_t xTimeNow, const TickType_t xCommandTime )
{
BaseType_t xProcessTimerNow = pdFALSE;
	listSET_LIST_ITEM_VALUE( &( pxTimer->xTimerListItem ), xNextExpiryTime );   //获取下一个过期时间,即读定时器链表项中第一个链表
	listSET_LIST_ITEM_OWNER( &( pxTimer->xTimerListItem ), pxTimer );           //配置本定时器是定时器链表项中第一个链表项的上级
	if( xNextExpiryTime <= xTimeNow )
	{   //上一个定时器命令发出时间与现在必须超过一个定时器周期,表明过期的定时器已经被处理了
		if( ( ( TickType_t ) ( xTimeNow - xCommandTime ) ) >= pxTimer->xTimerPeriodInTicks )
		{   //有效
			xProcessTimerNow = pdTRUE;
		}
		else
		{   //这个过期的定时器没处理,丢入到过期定时器链表中
			vListInsert( pxOverflowTimerList, &( pxTimer->xTimerListItem ) );
		}
	}
	else
	{
		if( ( xTimeNow < xCommandTime ) && ( xNextExpiryTime >= xCommandTime ) )
		{
			//命令发出,滴答溢出,过期时间没有,必须立刻处理
			xProcessTimerNow = pdTRUE;
		}
		else
		{   //加入到当前定时器链表
			vListInsert( pxCurrentTimerList, &( pxTimer->xTimerListItem ) );
		}
	}
	return xProcessTimerNow;
}

//对收到的命令进行处理
static void	prvProcessReceivedCommands( void )
{
DaemonTaskMessage_t xMessage;
Timer_t *pxTimer;
BaseType_t xTimerListsWereSwitched, xResult;
TickType_t xTimeNow;
	while( xQueueReceive( xTimerQueue, &xMessage, tmrNO_DELAY ) != pdFAIL )
    {   //从队列取一个消息来处理
		#if ( INCLUDE_xTimerPendFunctionCall == 1 )
		{   //定时器挂起回调
			if( xMessage.xMessageID < ( BaseType_t ) 0 )
			{   //从消息中取出参数
				const CallbackParameters_t * const pxCallback = &( xMessage.u.xCallbackParameters );
				configASSERT( pxCallback );
                //执行命令的回调处理
				pxCallback->pxCallbackFunction( pxCallback->pvParameter1, pxCallback->ulParameter2 );
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
		}
		#endif

		if( xMessage.xMessageID >= ( BaseType_t ) 0 )
		{   //消息有效,获得消息带的定时器
			pxTimer = xMessage.u.xTimerParameters.pxTimer;
			if( listIS_CONTAINED_WITHIN( NULL, &( pxTimer->xTimerListItem ) ) == pdFALSE )
			{   //定时器项的上级存在,那么将该项从链表中移除
				( void ) uxListRemove( &( pxTimer->xTimerListItem ) );
			}
			else
			{
				mtCOVERAGE_TEST_MARKER();
			}
			traceTIMER_COMMAND_RECEIVED( pxTimer, xMessage.xMessageID, xMessage.u.xTimerParameters.xMessageValue );

            //定时器是否过期			
			xTimeNow = prvSampleTimeNow( &xTimerListsWereSwitched );
			switch( xMessage.xMessageID )
			{   //处理消息自带的命令
				case tmrCOMMAND_START :
			    case tmrCOMMAND_START_FROM_ISR :
			    case tmrCOMMAND_RESET :
			    case tmrCOMMAND_RESET_FROM_ISR :
				case tmrCOMMAND_START_DONT_TRACE :
					//启动和重置命令,将定时器重新加入到活跃链表中
					if( prvInsertTimerInActiveList( pxTimer,  xMessage.u.xTimerParameters.xMessageValue + pxTimer->xTimerPeriodInTicks, xTimeNow, xMessage.u.xTimerParameters.xMessageValue ) != pdFALSE )
					{
						//定时器过期回调
						pxTimer->pxCallbackFunction( ( TimerHandle_t ) pxTimer );
						traceTIMER_EXPIRED( pxTimer );
						if( pxTimer->uxAutoReload == ( UBaseType_t ) pdTRUE )
						{   //定时器重加载,发送重启定时器命令xTimerQueue
							xResult = xTimerGenericCommand( pxTimer, tmrCOMMAND_START_DONT_TRACE, xMessage.u.xTimerParameters.xMessageValue + pxTimer->xTimerPeriodInTicks, NULL, tmrNO_DELAY );
							configASSERT( xResult );
							( void ) xResult;//编译器警告
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					else
					{
						mtCOVERAGE_TEST_MARKER();
					}
					break;

				case tmrCOMMAND_STOP :
				case tmrCOMMAND_STOP_FROM_ISR :
                    //编译器已经停止和移除队列,所以不用动它
					break;

				case tmrCOMMAND_CHANGE_PERIOD :
				case tmrCOMMAND_CHANGE_PERIOD_FROM_ISR :
                    //修改定时器的频率和周期
					pxTimer->xTimerPeriodInTicks = xMessage.u.xTimerParameters.xMessageValue;
					configASSERT( ( pxTimer->xTimerPeriodInTicks > 0 ) );
					//以新的周期频率插入到活跃队列中
					( void ) prvInsertTimerInActiveList( pxTimer, ( xTimeNow + pxTimer->xTimerPeriodInTicks ), xTimeNow, xTimeNow );
					break;

				case tmrCOMMAND_DELETE :
					#if( ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 0 ) )
					{   //删除定时器,直接是否
						vPortFree( pxTimer );
					}
					#elif( ( configSUPPORT_DYNAMIC_ALLOCATION == 1 ) && ( configSUPPORT_STATIC_ALLOCATION == 1 ) )
					{   //静态定时器不能被释放
						if( pxTimer->ucStaticallyAllocated == ( uint8_t ) pdFALSE )
						{
							vPortFree( pxTimer );
						}
						else
						{
							mtCOVERAGE_TEST_MARKER();
						}
					}
					#endif
					break;
				default	:
					break;
			}
		}
	}
}

//切换定时器链表
static void prvSwitchTimerLists( void )
{
TickType_t xNextExpireTime, xReloadTime;
List_t *pxTemp;
Timer_t *pxTimer;
BaseType_t xResult;
	//时钟滴答已经溢出,当前的定时器链表中的定时器需要全部处理掉(过期它并处理它)
	while( listLIST_IS_EMPTY( pxCurrentTimerList ) == pdFALSE )
	{	//如果当前定时器链表不为空,取到下一个过期项
		xNextExpireTime = listGET_ITEM_VALUE_OF_HEAD_ENTRY( pxCurrentTimerList );
		//取到该定时器的所有者(定时器实例)
		pxTimer = ( Timer_t * ) listGET_OWNER_OF_HEAD_ENTRY( pxCurrentTimerList );
		//定时器被移出
		( void ) uxListRemove( &( pxTimer->xTimerListItem ) );
		traceTIMER_EXPIRED( pxTimer );
		//执行它的过期回调
		pxTimer->pxCallbackFunction( ( TimerHandle_t ) pxTimer );
		if( pxTimer->uxAutoReload == ( UBaseType_t ) pdTRUE )
		{	//如果是自动重载的话,需要更新下一次过期值
			xReloadTime = ( xNextExpireTime + pxTimer->xTimerPeriodInTicks );
			if( xReloadTime > xNextExpireTime )
			{	//将它重新插入定时器链表,因为重载时间是被算入当前周期内,如果移到下一个滴答周期
				//会导致定时器超时溢出
				listSET_LIST_ITEM_VALUE( &( pxTimer->xTimerListItem ), xReloadTime );
				listSET_LIST_ITEM_OWNER( &( pxTimer->xTimerListItem ), pxTimer );
				vListInsert( pxCurrentTimerList, &( pxTimer->xTimerListItem ) );
			}
			else
			{	//向命令队列发送消息,发送一个启动定时器的消息
				xResult = xTimerGenericCommand( pxTimer, tmrCOMMAND_START_DONT_TRACE, xNextExpireTime, NULL, tmrNO_DELAY );
				configASSERT( xResult );
				( void ) xResult;
			}
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	//当前定时器队列变成过期定时器队列(空),过期溢出的定时器队列现在变成活跃态了
	pxTemp = pxCurrentTimerList;
	pxCurrentTimerList = pxOverflowTimerList;
	pxOverflowTimerList = pxTemp;
}

//检查链表和队列的合法性,在初始化时
static void prvCheckForValidListAndQueue( void )
{
	taskENTER_CRITICAL();
	{	//队列为空(不存在)
		if( xTimerQueue == NULL )
		{	//初始化俩个定时器链表,并将其分别作为current和overflow
			vListInitialise( &xActiveTimerList1 );
			vListInitialise( &xActiveTimerList2 );
			pxCurrentTimerList = &xActiveTimerList1;
			pxOverflowTimerList = &xActiveTimerList2;

			#if( configSUPPORT_STATIC_ALLOCATION == 1 )
			{	//如果支持静态创建队列,那么静态定义队列,然后调用队列的静态函数创建指令容器队列
				static StaticQueue_t xStaticTimerQueue; 
				static uint8_t ucStaticTimerQueueStorage[ ( size_t ) configTIMER_QUEUE_LENGTH * sizeof( DaemonTaskMessage_t ) ];
				
				xTimerQueue = xQueueCreateStatic( ( UBaseType_t ) configTIMER_QUEUE_LENGTH, ( UBaseType_t ) sizeof( DaemonTaskMessage_t ), &( ucStaticTimerQueueStorage[ 0 ] ), &xStaticTimerQueue );
			}
			#else
			{	//否则动态创建定时器的指令容器队列
				xTimerQueue = xQueueCreate( ( UBaseType_t ) configTIMER_QUEUE_LENGTH, sizeof( DaemonTaskMessage_t ) );
			}
			#endif
			#if ( configQUEUE_REGISTRY_SIZE > 0 )
			{	//如果需要将队列注册到集合中
				if( xTimerQueue != NULL )
				{	//将当前队列xTimerQueue加入到队列集合xQueueRegistry中
					vQueueAddToRegistry( xTimerQueue, "TmrQ" );
				}
				else
				{
					mtCOVERAGE_TEST_MARKER();
				}
			}
			#endif
		}
		else
		{
			mtCOVERAGE_TEST_MARKER();
		}
	}
	taskEXIT_CRITICAL();
}

//定时器活跃检查
BaseType_t xTimerIsTimerActive( TimerHandle_t xTimer )
{
BaseType_t xTimerIsInActiveList;
Timer_t *pxTimer = xTimer;

	configASSERT( xTimer );
	taskENTER_CRITICAL();
	{	//定时器链表项,没有父亲,即非活跃态
		if( listIS_CONTAINED_WITHIN( NULL, &( pxTimer->xTimerListItem ) ) == pdTRUE )
		{
			xTimerIsInActiveList = pdFALSE;
		}
		else
		{
			xTimerIsInActiveList = pdTRUE;
		}
	}
	taskEXIT_CRITICAL();
	return xTimerIsInActiveList;
}

//定时器ID获取
void *pvTimerGetTimerID( const TimerHandle_t xTimer )
{
Timer_t * const pxTimer = xTimer;
void *pvReturn;

	configASSERT( xTimer );

	taskENTER_CRITICAL();
	{
		pvReturn = pxTimer->pvTimerID;
	}
	taskEXIT_CRITICAL();

	return pvReturn;
}

void vTimerSetTimerID( TimerHandle_t xTimer, void *pvNewID )
{
Timer_t * const pxTimer = xTimer;

	configASSERT( xTimer );

	taskENTER_CRITICAL();
	{
		pxTimer->pvTimerID = pvNewID;
	}
	taskEXIT_CRITICAL();
}

//定时器挂起回调
#if( INCLUDE_xTimerPendFunctionCall == 1 )
	BaseType_t xTimerPendFunctionCallFromISR( PendedFunction_t xFunctionToPend, void *pvParameter1, uint32_t ulParameter2, BaseType_t *pxHigherPriorityTaskWoken )
	{
	DaemonTaskMessage_t xMessage;
	BaseType_t xReturn;
		//利用参数配置定时器队列消息(打包)
		xMessage.xMessageID = tmrCOMMAND_EXECUTE_CALLBACK_FROM_ISR;
		xMessage.u.xCallbackParameters.pxCallbackFunction = xFunctionToPend;
		xMessage.u.xCallbackParameters.pvParameter1 = pvParameter1;
		xMessage.u.xCallbackParameters.ulParameter2 = ulParameter2;
		//消息以高优先级唤醒丢入到定时器队列中去
		xReturn = xQueueSendFromISR( xTimerQueue, &xMessage, pxHigherPriorityTaskWoken );
		tracePEND_FUNC_CALL_FROM_ISR( xFunctionToPend, pvParameter1, ulParameter2, xReturn );
		return xReturn;
	}
#endif


#if( INCLUDE_xTimerPendFunctionCall == 1 )
	BaseType_t xTimerPendFunctionCall( PendedFunction_t xFunctionToPend, void *pvParameter1, uint32_t ulParameter2, TickType_t xTicksToWait )
	{
	DaemonTaskMessage_t xMessage;
	BaseType_t xReturn;
		configASSERT( xTimerQueue );//打包发送
		xMessage.xMessageID = tmrCOMMAND_EXECUTE_CALLBACK;
		xMessage.u.xCallbackParameters.pxCallbackFunction = xFunctionToPend;
		xMessage.u.xCallbackParameters.pvParameter1 = pvParameter1;
		xMessage.u.xCallbackParameters.ulParameter2 = ulParameter2;
		xReturn = xQueueSendToBack( xTimerQueue, &xMessage, xTicksToWait );
		tracePEND_FUNC_CALL( xFunctionToPend, pvParameter1, ulParameter2, xReturn );
		return xReturn;
	}
#endif 


#if ( configUSE_TRACE_FACILITY == 1 )
	UBaseType_t uxTimerGetTimerNumber( TimerHandle_t xTimer )
	{
		return ( ( Timer_t * ) xTimer )->uxTimerNumber;
	}

#endif


#if ( configUSE_TRACE_FACILITY == 1 )
	void vTimerSetTimerNumber( TimerHandle_t xTimer, UBaseType_t uxTimerNumber )
	{
		( ( Timer_t * ) xTimer )->uxTimerNumber = uxTimerNumber;
	}

#endif


#endif


