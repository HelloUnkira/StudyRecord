/*
 * 堆
 */
#include <stdlib.h>

//接口重包含,提前定义一下用于屏蔽mpu_wappers.h造成的影响
#define MPU_WRAPPERS_INCLUDED_FROM_API_FILE

#include "FreeRTOS.h"
#include "task.h"

//取消重包含,因为已经没必要了
#undef MPU_WRAPPERS_INCLUDED_FROM_API_FILE

//必须定义动态内存分配
#if( configSUPPORT_DYNAMIC_ALLOCATION == 0 )
	#error This file must not be used if configSUPPORT_DYNAMIC_ALLOCATION is 0
#endif

//堆的调整尺寸
#define configADJUSTED_HEAP_SIZE	( configTOTAL_HEAP_SIZE - portBYTE_ALIGNMENT )

//堆的初始化函数,因为这里是静态定义堆

static void prvHeapInit( void );

//动态分配堆
#if( configAPPLICATION_ALLOCATED_HEAP == 1 )
	extern uint8_t ucHeap[ configTOTAL_HEAP_SIZE ];	//如果堆是来源于外界
#else
	static uint8_t ucHeap[ configTOTAL_HEAP_SIZE ]; //否则堆来源于本地
#endif


//堆是依照(内存池)分配的空间,即链表串联连续地址空间的资源
typedef struct A_BLOCK_LINK
{
	struct A_BLOCK_LINK *pxNextFreeBlock;	//下一个空闲块
	size_t xBlockSize;						//空闲块的大小
} BlockLink_t;



//一个堆结构的大小(维护所用),要进行字节对齐
static const uint16_t heapSTRUCT_SIZE	= ( ( sizeof ( BlockLink_t ) + ( portBYTE_ALIGNMENT - 1 ) ) & ~portBYTE_ALIGNMENT_MASK );
#define heapMINIMUM_BLOCK_SIZE	( ( size_t ) ( heapSTRUCT_SIZE * 2 ) )

//创建一对作为堆的起始位和结束位
static BlockLink_t xStart, xEnd;

//堆的空余空间
static size_t xFreeBytesRemaining = configADJUSTED_HEAP_SIZE;


//插入块到内存池中
#define prvInsertBlockIntoFreeList( pxBlockToInsert )								\
{																					\
BlockLink_t *pxIterator;															\
size_t xBlockSize;																	\
	xBlockSize = pxBlockToInsert->xBlockSize;										\
																					\
	for( pxIterator = &xStart; pxIterator->pxNextFreeBlock->xBlockSize < xBlockSize; pxIterator = pxIterator->pxNextFreeBlock )	\
	{																				\
	}																				\
	pxBlockToInsert->pxNextFreeBlock = pxIterator->pxNextFreeBlock;					\
	pxIterator->pxNextFreeBlock = pxBlockToInsert;									\
}

//动态分配
void *pvPortMalloc( size_t xWantedSize )
{
BlockLink_t *pxBlock, *pxPreviousBlock, *pxNewBlockLink;
static BaseType_t xHeapHasBeenInitialised = pdFALSE;
void *pvReturn = NULL;

	vTaskSuspendAll();//挂起所有任务
	{	//分配的尺寸为空
		if( xHeapHasBeenInitialised == pdFALSE )
		{	//如果未初始化的话就做一次初始化
			prvHeapInit();
			xHeapHasBeenInitialised = pdTRUE;
		}


		if( xWantedSize > 0 )
		{	//合法性检查,添加对应的 堆维护部分
			xWantedSize += heapSTRUCT_SIZE;
			if( ( xWantedSize & portBYTE_ALIGNMENT_MASK ) != 0 )
			{	//字节对齐检查
				xWantedSize += ( portBYTE_ALIGNMENT - ( xWantedSize & portBYTE_ALIGNMENT_MASK ) );
			}
		}
		/如果期望空间与剩余空间都达到要求值,分配它
		if( ( xWantedSize > 0 ) && ( xWantedSize < configADJUSTED_HEAP_SIZE ) )
		{//获取上一个块的位置
			pxPreviousBlock = &xStart;
			pxBlock = xStart.pxNextFreeBlock;//获取它的下一个空闲块的位置
			while( ( pxBlock->xBlockSize < xWantedSize ) && ( pxBlock->pxNextFreeBlock != NULL ) )
			{	//迭代查询,知道能找到一个满足需求的块或者找到末尾
				pxPreviousBlock = pxBlock;
				pxBlock = pxBlock->pxNextFreeBlock;
			}
			
			if( pxBlock != &xEnd )
			{	//如果成功找到了一个块,那么为返回做准备,返回时不能添加堆本身的维护数据
				pvReturn = ( void * ) ( ( ( uint8_t * ) pxPreviousBlock->pxNextFreeBlock ) + heapSTRUCT_SIZE );
				//更新下一个空闲块的位置
				pxPreviousBlock->pxNextFreeBlock = pxBlock->pxNextFreeBlock;
				if( ( pxBlock->xBlockSize - xWantedSize ) > heapMINIMUM_BLOCK_SIZE )
				{	//堆太大了,分裂它
					pxNewBlockLink = ( void * ) ( ( ( uint8_t * ) pxBlock ) + xWantedSize );
						
					pxNewBlockLink->xBlockSize = pxBlock->xBlockSize - xWantedSize;
					pxBlock->xBlockSize = xWantedSize;
					//把剩余的部分插入到堆集里面
					prvInsertBlockIntoFreeList( ( pxNewBlockLink ) );
				}

				//更新剩余块的大小
				xFreeBytesRemaining -= pxBlock->xBlockSize;
			}
		}

		traceMALLOC( pvReturn, xWantedSize );
	}
	( void ) xTaskResumeAll();//任务恢复

	#if( configUSE_MALLOC_FAILED_HOOK == 1 )
	{
		if( pvReturn == NULL )
		{	//如果用户提供了 动态内存分配失败 的事件处理
			//执行它重写的回调钩子
			extern void vApplicationMallocFailedHook( void );
			vApplicationMallocFailedHook();
		}
	}
	#endif

	return pvReturn;
}

//动态释放
void vPortFree( void *pv )
{
uint8_t *puc = ( uint8_t * ) pv;
BlockLink_t *pxLink;

	if( pv != NULL )
	{	//区域非空时
		puc -= heapSTRUCT_SIZE;//偏移到堆的起始位置,而不是数据的起始位置

		pxLink = ( void * ) puc;

		vTaskSuspendAll();
		{	//剩余空间加入到(内存池)中
			prvInsertBlockIntoFreeList( ( ( BlockLink_t * ) pxLink ) );
			xFreeBytesRemaining += pxLink->xBlockSize;
			traceFREE( pv, pxLink->xBlockSize );
		}
		( void ) xTaskResumeAll();
	}
}
//获得空余空间的大小
size_t xPortGetFreeHeapSize( void )
{
	return xFreeBytesRemaining;
}


//块初始化
void vPortInitialiseBlocks( void )
{
}
/*-----------------------------------------------------------*/

static void prvHeapInit( void )
{
BlockLink_t *pxFirstFreeBlock;
uint8_t *pucAlignedHeap;

	//选定为堆的起始位置
	pucAlignedHeap = ( uint8_t * ) ( ( ( portPOINTER_SIZE_TYPE ) &ucHeap[ portBYTE_ALIGNMENT ] ) & ( ~( ( portPOINTER_SIZE_TYPE ) portBYTE_ALIGNMENT_MASK ) ) );

	//定义开始位置
	xStart.pxNextFreeBlock = ( void * ) pucAlignedHeap;
	xStart.xBlockSize = ( size_t ) 0;

	//定义结束的位置
	xEnd.xBlockSize = configADJUSTED_HEAP_SIZE;
	xEnd.pxNextFreeBlock = NULL;

	pxFirstFreeBlock = ( void * ) pucAlignedHeap;
	pxFirstFreeBlock->xBlockSize = configADJUSTED_HEAP_SIZE;
	pxFirstFreeBlock->pxNextFreeBlock = &xEnd;
}



