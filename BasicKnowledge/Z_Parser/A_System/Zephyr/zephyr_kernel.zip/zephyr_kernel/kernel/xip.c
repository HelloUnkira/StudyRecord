/*
 * zephyr内核
 */

//风和系统
//本地执行,程序不拷贝入内存直接载入CPU执行

#include <zephyr.h>
#include <kernel.h>
#include <string.h>
#include <linker/linker-defs.h>

//栈金丝雀保护
#ifdef CONFIG_STACK_CANARIES
extern volatile uintptr_t __stack_chk_guard;
#endif

//将数据部分从ROM复制到RAM
void z_data_copy(void)
{
	//数据段拷贝
	(void)memcpy(&__data_ram_start, &__data_rom_start,
				  __data_ram_end - __data_ram_start);
	//静态函数指令拷贝
#ifdef CONFIG_ARCH_HAS_RAMFUNC_SUPPORT
	(void)memcpy(&_ramfunc_ram_start, &_ramfunc_rom_start,
	 (uintptr_t) &_ramfunc_ram_size);
#endif
	//CCM内存区拷贝
#if DT_NODE_HAS_STATUS(DT_CHOSEN(zephyr_ccm), okay)
	(void)memcpy(&__ccm_data_start, &__ccm_data_rom_start,
				  __ccm_data_end - __ccm_data_start);
#endif
	//ITCM高速指令缓冲区拷贝
#if DT_NODE_HAS_STATUS(DT_CHOSEN(zephyr_itcm), okay)
	(void)memcpy(&__itcm_start, &__itcm_rom_start,
	 (uintptr_t) &__itcm_size);
#endif
	//DTCM高速数据缓冲区拷贝
#if DT_NODE_HAS_STATUS(DT_CHOSEN(zephyr_dtcm), okay)
	(void)memcpy(&__dtcm_data_start, &__dtcm_data_rom_start,
				  __dtcm_data_end - __dtcm_data_start);
#endif
	//代码段重入
#ifdef CONFIG_CODE_DATA_RELOCATION
	//位置重拷贝
	extern void data_copy_xip_relocation(void);
	data_copy_xip_relocation();
#endif
	//栈金丝雀保护
#ifdef CONFIG_USERSPACE
#ifdef CONFIG_STACK_CANARIES
	//栈金丝雀检查所有活跃的C函数
	//__stack_chk_guard是应用共享内存段中未初始化的值
	//保留它不要调用任何函数来执行内存复制
	//真正的探测值稍后在z_cstart()中设置
	uintptr_t guard_copy = __stack_chk_guard;
	uint8_t *src = (uint8_t *)&_app_smem_rom_start;
	uint8_t *dst = (uint8_t *)&_app_smem_start;
	uint32_t count = _app_smem_end - _app_smem_start;

	guard_copy = __stack_chk_guard;
	while (count > 0) {
		*(dst++) = *(src++);
		count--;
	}
	__stack_chk_guard = guard_copy;
#else
	(void)memcpy(&_app_smem_start, &_app_smem_rom_start,
		 _app_smem_end - _app_smem_start);
#endif
#endif
}
