/*
 * zephyr内核
 */

//原语,用于在不需要特定于平台的线程时中止线程

#include <kernel.h>
#include <kernel_structs.h>
#include <kernel_internal.h>
#include <kswap.h>
#include <string.h>
#include <toolchain.h>
#include <linker/sections.h>
#include <wait_q.h>
#include <ksched.h>
#include <sys/__assert.h>
#include <syscall_handler.h>
#include <logging/log.h>

LOG_MODULE_DECLARE(os, CONFIG_KERNEL_LOG_LEVEL);

FUNC_NORETURN void z_self_abort(void)
{
	//自中止线程不会自己清理,我们让当前CPU的空闲线程来做这件事
	int key;
	struct _cpu *cpu;

	//锁定本地irq,防止我们在设置时迁移到另一个CPU
	key = arch_irq_lock();
	//获取当前线程的CPU
	cpu = _current_cpu;
	//检查挂起中断体
	__ASSERT(cpu->pending_abort == NULL, "already have a thread to abort");
	//现在需要中止的线程被绑定为当前线程
	cpu->pending_abort = _current;
	//检查线程和CPU当前空闲线程
	LOG_DBG("%p self-aborting, handle on idle thread %p",
			_current, cpu->idle_thread);
	//挂起当前线程
	k_thread_suspend(_current);
	//调度锁
	z_swap_irqlock(key);
	__ASSERT(false, "should never get here");
	CODE_UNREACHABLE;
}

#if !defined(CONFIG_ARCH_HAS_THREAD_ABORT)
//中止一个线程
void z_impl_k_thread_abort(k_tid_t thread)
{
	//线程是当前线程,且不在中断环境下
	if (thread == _current && !arch_is_in_isr()) {
		//线程自退出,该CPU上的空闲线程将做清理工作
		z_self_abort();
	}

	//中止指定线程
	z_thread_single_abort(thread);

	if (!arch_is_in_isr()) {
		//如果我们在ISR就不用这么做,解除调度锁
		z_reschedule_unlocked();
	}
}
#endif
