/*
 * zephyr内核
 */

//编译器堆栈保护(内核部分)
//此模块提供了使用金丝雀来支持编译器堆栈保护的函数
//这个特性是通过配置CONFIG_STACK_CANARIES=y启用的
//启用此特性后,编译器生成的
//代码引用函数__stack_chk_fail和全局变量__stack_chk_guard

#include <toolchain.h> //编译器的具体配置

#include <kernel_structs.h>
#include <toolchain.h>
#include <linker/sections.h>
#include <kernel.h>
#include <app_memory/app_memdomain.h>

//堆栈金丝雀错误处理程序
//当检测到堆栈金丝雀错误时调用这个函数
void _StackCheckHandler(void)
{
	//堆栈金丝雀错误是软件致命的情况;就这样对待它
	z_except_reason(K_ERR_STACK_CHK_FAIL);
	CODE_UNREACHABLE;
}

//GCC编译器生成的金丝雀值代码引用的符号
//在z_cstart()中初始化金丝雀值
#ifdef CONFIG_USERSPACE
K_APP_DMEM(z_libc_partition) uintptr_t __stack_chk_guard;
#else
__noinit uintptr_t __stack_chk_guard;
#endif

//由GCC编译器生成的代码引用
//此例程在检测到堆栈提示错误时调用,指示缓冲区溢出或堆栈损坏问题
FUNC_ALIAS(_StackCheckHandler, __stack_chk_fail, void);


