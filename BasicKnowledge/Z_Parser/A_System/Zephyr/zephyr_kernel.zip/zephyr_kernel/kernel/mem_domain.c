/*
 * zephyr内核
 */

#include <init.h>
#include <kernel.h>
#include <kernel_structs.h>
#include <kernel_internal.h>
#include <sys/__assert.h>
#include <stdbool.h>
#include <spinlock.h>
#include <sys/libc-hooks.h>
#include <logging/log.h>

LOG_MODULE_DECLARE(os, CONFIG_KERNEL_LOG_LEVEL);
//静态全局自旋锁
struct k_spinlock z_mem_domain_lock;
//最大分区数
static uint8_t max_partitions;
//默认内存域
struct k_mem_domain k_mem_domain_default;

#if __ASSERT_ON
static bool check_add_partition(struct k_mem_domain *domain,
								struct k_mem_partition *part)
{
	int i;
	uintptr_t pstart, pend, dstart, dend;
	if (part == NULL) {//空分区
		LOG_ERR("NULL k_mem_partition provided");
		return false;
	}

#ifdef CONFIG_EXECUTE_XOR_WRITE
	//不能禁用执行的平台应始终返回false
	if (K_MEM_PARTITION_IS_EXECUTABLE(part->attr) &&
	    K_MEM_PARTITION_IS_WRITABLE(part->attr)) {
		LOG_ERR("partition is writable and executable <start %lx>",
				part->start);//分区不可以同时可写可执行
		return false;
	}
#endif

	if (part->size == 0) {//分区大小为空
		LOG_ERR("zero sized partition at %p with base 0x%lx",
				part, part->start);
		return false;
	}

	//获取分区的起始位置和结束位置
	pstart = part->start;
	pend = part->start + part->size;

	if (pend <= pstart) {//检查
		LOG_ERR("invalid partition %p, wraparound detected. base 0x%lx size %zu",
				part, part->start, part->size);
		return false;
	}

	//检查这个分区是否与域中已经存在的任何分区重叠
	for (i = 0; i < domain->num_partitions; i++) {
		//从域中遍历所有分区
		struct k_mem_partition *dpart = &domain->partitions[i];
		if (dpart->size == 0) {
			continue;//未使用的分区
		}
		//获取内存域内分区的起始地址和结束地址
		dstart = dpart->start;
		dend = dstart + dpart->size;
		//检查是否出现分区重叠,检查俩个端点,四个位置俩次比较
		if (pend > dstart && dend > pstart) {
			LOG_ERR("partition %p base %lx (size %zu) overlaps existing base %lx (size %zu)",
					part, part->start, part->size, dpart->start, dpart->size);
			return false;
		}
	}
	return true;
}
#endif

//初始化一个内存域
void k_mem_domain_init(struct k_mem_domain *domain, uint8_t num_parts,
					   struct k_mem_partition *parts[])
{
	k_spinlock_key_t key;
	__ASSERT_NO_MSG(domain != NULL);//断言,内存域存在
	__ASSERT(num_parts == 0U || parts != NULL,//分区表不为空,分区表存在
			 "parts array is NULL and num_parts is nonzero");
	__ASSERT(num_parts <= max_partitions,//分区表太小
			 "num_parts of %d exceeds maximum allowable partitions (%d)",
			 num_parts, max_partitions);
	key = k_spin_lock(&z_mem_domain_lock);

	domain->num_partitions = 0U;//初始化内存域参数
	//内存域的分区表初始化为空
	(void)memset(domain->partitions, 0, sizeof(domain->partitions));
	//初始化该内存域内的线程所用链表
	sys_dlist_init(&domain->mem_domain_q);

#ifdef CONFIG_ARCH_MEM_DOMAIN_DATA
	//平台初始化,如果平台需要处理内存域数据
	int ret = arch_mem_domain_init(domain);

	//TODO传播返回值,见#24609
	//这里没有使用断言,因为这是一个内存分配错误
	if (ret != 0) {
		LOG_ERR("architecture-specific initialization failed for domain %p with %d",
				domain, ret);
		k_panic();//系统挂起(内存域出问题,没得玩了)
	}
#endif
	
	if (num_parts != 0U) {//分区表数非0
		uint32_t i;
		for (i = 0U; i < num_parts; i++) {
			//分区表该分区是否可加入内存域断言检查
			__ASSERT(check_add_partition(domain, parts[i]),
					 "invalid partition index %d (%p)", i, parts[i]);
			//将该分区加入到内存域
			domain->partitions[i] = *parts[i];
			domain->num_partitions++;
#ifdef CONFIG_ARCH_MEM_DOMAIN_SYNCHRONOUS_API
			arch_mem_domain_partition_add(domain, i);
#endif
		}
	}
	k_spin_unlock(&z_mem_domain_lock, key);
}

//将该分区加入到内存域
void k_mem_domain_add_partition(struct k_mem_domain *domain,
								struct k_mem_partition *part)
{
	int p_idx;
	k_spinlock_key_t key;
	__ASSERT_NO_MSG(domain != NULL);//断言内存域存在性检查
	//分区表该分区是否可加入内存域断言检查
	__ASSERT(check_add_partition(domain, part),
			 "invalid partition %p", part);
	key = k_spin_lock(&z_mem_domain_lock);
	
	//一个零大小的分区表示它是一个未使用分区(从内存域找一个地方)
	for (p_idx = 0; p_idx < max_partitions; p_idx++) {
		if (domain->partitions[p_idx].size == 0U) {
			break;
		}
	}
	//空间不足检查
	__ASSERT(p_idx < max_partitions, "no free partition slots available");
	//添加分区到内存域
	LOG_DBG("add partition base %lx size %zu to domain %p\n",
			part->start, part->size, domain);
	
	//添加分区到内存域,建立关联绑定
	domain->partitions[p_idx].start = part->start;
	domain->partitions[p_idx].size = part->size;
	domain->partitions[p_idx].attr = part->attr;
	domain->num_partitions++;

#ifdef CONFIG_ARCH_MEM_DOMAIN_SYNCHRONOUS_API
	arch_mem_domain_partition_add(domain, p_idx);
#endif
	k_spin_unlock(&z_mem_domain_lock, key);
}

//将该分区从内存域中移除
void k_mem_domain_remove_partition(struct k_mem_domain *domain,
								   struct k_mem_partition *part)
{
	int p_idx;
	k_spinlock_key_t key;
	__ASSERT_NO_MSG(domain != NULL);//断言内存域存在性检查
	__ASSERT_NO_MSG(part != NULL);//断言分区存在性检查
	key = k_spin_lock(&z_mem_domain_lock);

	//找到一个匹配给定起始和大小的分区
	for (p_idx = 0; p_idx < max_partitions; p_idx++) {
		if (domain->partitions[p_idx].start == part->start &&
		    domain->partitions[p_idx].size == part->size) {
			break;
		}
	}
	//未找到指定分区
	__ASSERT(p_idx < max_partitions, "no matching partition found");
	//确认分区是
	LOG_DBG("remove partition base %lx size %zu from domain %p\n",
			part->start, part->size, domain);
#ifdef CONFIG_ARCH_MEM_DOMAIN_SYNCHRONOUS_API
	arch_mem_domain_partition_remove(domain, p_idx);
#endif

	//一个零大小的分区表示它是一个未使用分区
	domain->partitions[p_idx].size = 0U;
	domain->num_partitions--;
	k_spin_unlock(&z_mem_domain_lock, key);
}

//一个锁定线程加入该内存域
static void add_thread_locked(struct k_mem_domain *domain,
							  k_tid_t thread)
{
	__ASSERT_NO_MSG(domain != NULL);//断言内存域存在性检查
	__ASSERT_NO_MSG(thread != NULL);//断言线程存在性检查
	LOG_DBG("add thread %p to domain %p\n", thread, domain);
	//将该线程追加到内存域尾部
	sys_dlist_append(&domain->mem_domain_q,
					 &thread->mem_domain_info.mem_domain_q_node);
	thread->mem_domain_info.mem_domain = domain;
#ifdef CONFIG_ARCH_MEM_DOMAIN_SYNCHRONOUS_API
	arch_mem_domain_thread_add(thread);
#endif
}

//移除一个锁定线程
static void remove_thread_locked(struct k_thread *thread)
{
	__ASSERT_NO_MSG(thread != NULL);//断言线程存在性检查
	LOG_DBG("remove thread %p from memory domain %p\n",
			thread, thread->mem_domain_info.mem_domain);
	//该线程移除出内存域
	sys_dlist_remove(&thread->mem_domain_info.mem_domain_q_node);
#ifdef CONFIG_ARCH_MEM_DOMAIN_SYNCHRONOUS_API
	arch_mem_domain_thread_remove(thread);
#endif
}

//从线程对象初始化调用
void z_mem_domain_init_thread(struct k_thread *thread)
{
	k_spinlock_key_t key = k_spin_lock(&z_mem_domain_lock);
	//新线程从父线程继承内存域配置
	add_thread_locked(_current->mem_domain_info.mem_domain, thread);
	k_spin_unlock(&z_mem_domain_lock, key);
}

//当线程在拆卸任务期间中止时调用,sched_spinlock被举起
void z_mem_domain_exit_thread(struct k_thread *thread)
{
	k_spinlock_key_t key = k_spin_lock(&z_mem_domain_lock);
	remove_thread_locked(thread);//移除
	k_spin_unlock(&z_mem_domain_lock, key);
}

//内存域添加线程
void k_mem_domain_add_thread(struct k_mem_domain *domain, k_tid_t thread)
{
	k_spinlock_key_t key;

	key = k_spin_lock(&z_mem_domain_lock);
	if (thread->mem_domain_info.mem_domain != domain) {
		remove_thread_locked(thread);//线程移除出原有内存域
		add_thread_locked(domain, thread);//线程加入到新的内存域
	}
	k_spin_unlock(&z_mem_domain_lock, key);
}

//内存域移除线程
void k_mem_domain_remove_thread(k_tid_t thread)
{
	//线程从其他内存域移入到默认内存域(总要有人收留它)
	k_mem_domain_add_thread(&k_mem_domain_default, thread);
}

//摧毁一个内存域
void k_mem_domain_destroy(struct k_mem_domain *domain)
{
	k_spinlock_key_t key;
	sys_dnode_t *node, *next_node;
	__ASSERT_NO_MSG(domain != NULL);//断言内存域存在性检查
	__ASSERT(domain != &k_mem_domain_default,//断言内存域非默认内存域
			 "cannot destroy default domain");
	key = k_spin_lock(&z_mem_domain_lock);


#ifdef CONFIG_ARCH_MEM_DOMAIN_SYNCHRONOUS_API
	arch_mem_domain_destroy(domain);
#endif
	//遍历内存域每一个节点
	SYS_DLIST_FOR_EACH_NODE_SAFE(&domain->mem_domain_q, node, next_node) {
		//找到该节点的所有者
		struct k_thread *thread = CONTAINER_OF(node, struct k_thread, mem_domain_info);
		remove_thread_locked(thread);//移除出当前内存域
		add_thread_locked(&k_mem_domain_default, thread);//加入到默认内存域
	}
	k_spin_unlock(&z_mem_domain_lock, key);
}

//初始化内存域模块
static int init_mem_domain_module(const struct device *arg)
{
	ARG_UNUSED(arg);
	max_partitions = arch_mem_domain_max_partitions_get();
	//max_partitions必须小于或等于CONFIG_MAX_DOMAIN_PARTITIONS
	//否则会遇到数组索引越界错误
	__ASSERT(max_partitions <= CONFIG_MAX_DOMAIN_PARTITIONS, "");
	//初始化默认内存域
	k_mem_domain_init(&k_mem_domain_default, 0, NULL);
#ifdef Z_LIBC_PARTITION_EXISTS
	k_mem_domain_add_partition(&k_mem_domain_default, &z_libc_partition);
#endif
	return 0;
}

SYS_INIT(init_mem_domain_module, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_DEFAULT);
