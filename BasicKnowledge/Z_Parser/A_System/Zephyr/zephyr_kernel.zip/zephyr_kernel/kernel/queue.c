/*
 * zephyr内核
 */

//dynamic-size队列对象

#include <kernel.h>
#include <kernel_structs.h>
#include <debug/object_tracing_common.h>
#include <toolchain.h>
#include <wait_q.h>
#include <ksched.h>
#include <init.h>
#include <syscall_handler.h>
#include <kernel_internal.h>
#include <sys/check.h>

//动态节点
struct alloc_node {
	//单链表节点,只有一个元素
	//高位做下一个节点地址,低位做flag
	sys_sfnode_t node;
	void *data;//动态节点的数据元
};

//摘要对应节点的数据,如果可以,释放该节点
void *z_queue_node_peek(sys_sfnode_t *node, bool needs_free)
{
	void *ret;

	//sys_sfnode_t.next_and_flags && SYS_SFLIST_FLAGS_MASK(0x3UL)
	//可知指针的低俩位是被用作了flag标志所用
	if ((node != NULL) && (sys_sfnode_flags_get(node) != (uint8_t)0)) {
		//如果设置了这个标志,那么这个项目的排队操作在后台
		//执行了一个alloc_node结构体的内存分配,这是
		//放入队列的内容,释放它并传递回数据指针
		struct alloc_node *anode;
		//通过node节点的地址获得它的所有者alloc_node节点的地址(其实==)
		anode = CONTAINER_OF(node, struct alloc_node, node);
		ret = anode->data;
		//如果需要释放,释放该节点
		if (needs_free) {
			k_free(anode);
		}
	} else {
		//数据直接放置在队列中,为链表保留的第一个字
		//用户模式不允许这样做,尽管它可以通过这种方式获取数据
		ret = (void *)node;
	}
	return ret;
}

#ifdef CONFIG_OBJECT_TRACING
//trace所用
struct k_queue *_trace_list_k_queue;

//完成静态定义队列的初始化
static int init_queue_module(const struct device *dev)
{
	ARG_UNUSED(dev);
	Z_STRUCT_SECTION_FOREACH(k_queue, queue) {
		SYS_TRACING_OBJ_INIT(k_queue, queue);
	}
	return 0;
}
SYS_INIT(init_queue_module, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);
#endif

//初始化队列
void z_impl_k_queue_init(struct k_queue *queue)
{
	sys_sflist_init(&queue->data_q);//初始化链表
	queue->lock = (struct k_spinlock) {};//初始化自旋锁
	z_waitq_init(&queue->wait_q);//初始化等待队列
#if defined(CONFIG_POLL)
	sys_dlist_init(&queue->poll_events);//初始化事件推送
#endif

	SYS_TRACING_OBJ_INIT(k_queue, queue);
	z_object_init(queue);//初始化所有者
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_queue_init(struct k_queue *queue)
{
	Z_OOPS(Z_SYSCALL_OBJ_NEVER_INIT(queue, K_OBJ_QUEUE));
	z_impl_k_queue_init(queue);
}
#include <syscalls/k_queue_init_mrsh.c>
#endif

//就绪一个线程
static void prepare_thread_to_run(struct k_thread *thread, void *data)
{
	//设置k_thread.callee_saved.retval = 0
	//    k_thread.base.swap_data = data
	z_thread_return_value_set_with_data(thread, 0, data);
	z_ready_thread(thread);//就绪该线程
}

//推送事件
static inline void handle_poll_events(struct k_queue *queue, uint32_t state)
{
#ifdef CONFIG_POLL
	//将队列的推送事件以指定状态推送
	z_handle_obj_poll_events(&queue->poll_events, state);
#endif
}

//队列取消等待
void z_impl_k_queue_cancel_wait(struct k_queue *queue)
{
	k_spinlock_key_t key = k_spin_lock(&queue->lock);
	struct k_thread *first_pending_thread;
	//获取队列的等待队列中的最高优先级线程
	first_pending_thread = z_unpend_first_thread(&queue->wait_q);
	if (first_pending_thread != NULL) {
		//准备并就绪该线程
		prepare_thread_to_run(first_pending_thread, NULL);
	}
	//推送 线程取消等待 事件
	handle_poll_events(queue, K_POLL_STATE_CANCELLED);
	z_reschedule(&queue->lock, key);//启用重调度(内核抢占)
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_queue_cancel_wait(struct k_queue *queue)
{
	Z_OOPS(Z_SYSCALL_OBJ(queue, K_OBJ_QUEUE));
	z_impl_k_queue_cancel_wait(queue);
}
#include <syscalls/k_queue_cancel_wait_mrsh.c>
#endif

//队列插入项
static int32_t queue_insert(struct k_queue *queue, void *prev, void *data,
							bool alloc, bool is_append)
{
	struct k_thread *first_pending_thread;
	k_spinlock_key_t key = k_spin_lock(&queue->lock);

	if (is_append) {//如果是追加模式,先获得队列的尾项
		prev = sys_sflist_peek_tail(&queue->data_q);
	}
	
	//获取队列的等待队列中的最高优先级线程
	first_pending_thread = z_unpend_first_thread(&queue->wait_q);
	if (first_pending_thread != NULL) {
		//准备并就绪该线程
		prepare_thread_to_run(first_pending_thread, data);
		z_reschedule(&queue->lock, key);//启用重调度(内核抢占)
		return 0;
	}

	//只有在没有线程挂起时才需要实际分配
	if (alloc) {//如果需要动态分配
		struct alloc_node *anode;
		//分配一个anode节点
		anode = z_thread_malloc(sizeof(*anode));
		if (anode == NULL) {
			k_spin_unlock(&queue->lock, key);
			return -ENOMEM;
		}
		//设置anode_node节点的属性
		//初始化anode_node.node项(标记为动态分配)
		anode->data = data;
		sys_sfnode_init(&anode->node, 0x1);
		data = anode;
	} else {
		sys_sfnode_init(data, 0x0);
	}
	//将指定sys_sfnode_t类型的的节点插入到链表中
	sys_sflist_insert(&queue->data_q, prev, data);
	//推送 产生可用数据 事件
	handle_poll_events(queue, K_POLL_STATE_DATA_AVAILABLE);
	z_reschedule(&queue->lock, key);//启用重调度(内核抢占)
	return 0;
}

//队列的多个动作
void k_queue_insert(struct k_queue *queue, void *prev, void *data)
{
	(void)queue_insert(queue, prev, data, false, false);
}

void k_queue_append(struct k_queue *queue, void *data)
{
	(void)queue_insert(queue, NULL, data, false, true);
}

void k_queue_prepend(struct k_queue *queue, void *data)
{
	(void)queue_insert(queue, NULL, data, false, false);
}

int32_t z_impl_k_queue_alloc_append(struct k_queue *queue, void *data)
{
	return queue_insert(queue, NULL, data, true, true);
}

#ifdef CONFIG_USERSPACE
static inline int32_t z_vrfy_k_queue_alloc_append(struct k_queue *queue,
												  void *data)
{
	Z_OOPS(Z_SYSCALL_OBJ(queue, K_OBJ_QUEUE));
	return z_impl_k_queue_alloc_append(queue, data);
}
#include <syscalls/k_queue_alloc_append_mrsh.c>
#endif

int32_t z_impl_k_queue_alloc_prepend(struct k_queue *queue, void *data)
{
	return queue_insert(queue, NULL, data, true, false);

}

#ifdef CONFIG_USERSPACE
static inline int32_t z_vrfy_k_queue_alloc_prepend(struct k_queue *queue,
												   void *data)
{
	Z_OOPS(Z_SYSCALL_OBJ(queue, K_OBJ_QUEUE));
	return z_impl_k_queue_alloc_prepend(queue, data);
}
#include <syscalls/k_queue_alloc_prepend_mrsh.c>
#endif

//队列追加一个链表
int k_queue_append_list(struct k_queue *queue, void *head, void *tail)
{
	//无效的列表头或尾
	CHECKIF(head == NULL || tail == NULL) {
		return -EINVAL;
	}
	k_spinlock_key_t key = k_spin_lock(&queue->lock);
	struct k_thread *thread = NULL;

	//清空原有队列的等待项,因为现在有数据来了
	if (head != NULL) {
		thread = z_unpend_first_thread(&queue->wait_q);
	}

	while ((head != NULL) && (thread != NULL)) {
		//将第一个等待项交付链表的第一个数据元,并就绪该等待项
		prepare_thread_to_run(thread, head);
		head = *(void **)head;//获取下一个数据元
		//获取下一个等待项
		thread = z_unpend_first_thread(&queue->wait_q);
	}

	//如果还存在数据元
	if (head != NULL) {
		//将剩下的数据元加入到队列的数据链表集中
		sys_sflist_append_list(&queue->data_q, head, tail);
	}

	//推送 产生可用数据 事件
	handle_poll_events(queue, K_POLL_STATE_DATA_AVAILABLE);
	z_reschedule(&queue->lock, key);//启用重调度(内核抢占)
	return 0;
}

//将一个数据元链表合并到队列中
int k_queue_merge_slist(struct k_queue *queue, sys_slist_t *list)
{
	int ret;

	//列表不能为空
	CHECKIF(sys_slist_is_empty(list)) {
		return -EINVAL;
	}

	//注意:只要:
	//- list实现保持下一个指针作为节点对象类型的第一个字段
	//- list->tail->next = NULL
	//- sflist实现与slist的区别仅在于在数据指针的低位填充标志字节
	//- source list是一个真正的列表,而不是一个sflist设置了标志
	//将一个数据元链表合并到队列中
	ret = k_queue_append_list(queue, list->head, list->tail);
	CHECKIF(ret != 0) {
		return ret;
	}
	//初始化数据元链表,清空它,因为副本已经存在在队列中
	//不能再让原有的数据元链表存在引用,防止干扰队列中的数据元
	sys_slist_init(list);
	return 0;
}

//获取队列中的数据元
void *z_impl_k_queue_get(struct k_queue *queue, k_timeout_t timeout)
{
	k_spinlock_key_t key = k_spin_lock(&queue->lock);
	void *data;

	//如果等待队列中的数据不为空
	if (likely(!sys_sflist_is_empty(&queue->data_q))) {
		sys_sfnode_t *node;
		//从里面摘出第一个数据元,并清空它在队列中的副本
		node = sys_sflist_get_not_empty(&queue->data_q);
		data = z_queue_node_peek(node, true);
		k_spin_unlock(&queue->lock, key);
		//将该数据元反馈
		return data;
	}

	//队列暂时不存在数据元,如果不等待则直接返回
	if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		k_spin_unlock(&queue->lock, key);
		return NULL;
	}

	//当前队列不存在数据元
	//将当前线程以超时时间timeout挂起到队列的等待队列中
	int ret = z_pend_curr(&queue->lock, key, &queue->wait_q, timeout);

	//如果不是超时返回,说明当前线程获取到了数据元,则将该数据元反馈
	return (ret != 0) ? NULL : _current->base.swap_data;
}

#ifdef CONFIG_USERSPACE
static inline void *z_vrfy_k_queue_get(struct k_queue *queue,
									   k_timeout_t timeout)
{
	Z_OOPS(Z_SYSCALL_OBJ(queue, K_OBJ_QUEUE));
	return z_impl_k_queue_get(queue, timeout);
}
#include <syscalls/k_queue_get_mrsh.c>

static inline int z_vrfy_k_queue_is_empty(struct k_queue *queue)
{
	Z_OOPS(Z_SYSCALL_OBJ(queue, K_OBJ_QUEUE));
	return z_impl_k_queue_is_empty(queue);
}
#include <syscalls/k_queue_is_empty_mrsh.c>

static inline void *z_vrfy_k_queue_peek_head(struct k_queue *queue)
{
	Z_OOPS(Z_SYSCALL_OBJ(queue, K_OBJ_QUEUE));
	return z_impl_k_queue_peek_head(queue);
}
#include <syscalls/k_queue_peek_head_mrsh.c>

static inline void *z_vrfy_k_queue_peek_tail(struct k_queue *queue)
{
	Z_OOPS(Z_SYSCALL_OBJ(queue, K_OBJ_QUEUE));
	return z_impl_k_queue_peek_tail(queue);
}
#include <syscalls/k_queue_peek_tail_mrsh.c>

#endif

