/*
 * zephyr内核
 */

#include <kernel.h>
#include <kernel_structs.h>
#include <toolchain.h>
#include <ksched.h>
#include <wait_q.h>
#include <syscall_handler.h>

//静态的自旋锁
//保护操作不会被并行的执行,并同步执行
static struct k_spinlock lock;

//初始化条件变量
int z_impl_k_condvar_init(struct k_condvar *condvar)
{
	z_waitq_init(&condvar->wait_q);//初始化等待队列
	z_object_init(condvar);//初始化对象(空动作)
	return 0;
}

#ifdef CONFIG_USERSPACE
int z_vrfy_k_condvar_init(struct k_condvar *condvar)
{
	Z_OOPS(Z_SYSCALL_OBJ_INIT(condvar, K_OBJ_CONDVAR));
	return z_impl_k_condvar_init(condvar);
}
#include <syscalls/k_condvar_init_mrsh.c>
#endif

//发送信号向一个条件变量上挂起的线程
int z_impl_k_condvar_signal(struct k_condvar *condvar)
{
	//为静态的条件变量上锁
	k_spinlock_key_t key = k_spin_lock(&lock);
	//利用等待队列获得其所有者集(线程集),找到优先级最大的线程(编号最小)
	struct k_thread *thread = z_unpend_first_thread(&condvar->wait_q);
	if (thread != NULL) {//如果存在这样的一个线程
		//清空返回值k_thread.callee_saved.retval = 0;
		arch_thread_return_value_set(thread, 0);
		z_ready_thread(thread);//就绪该线程
		//启动重调度,thread已经就绪且是等待队列优先级最高的线程
		//它将有很大的几率被执行,这是内核抢占的一种机制
		z_reschedule(&lock, key);
	} else {//不存在,本次动作无效,解锁
		k_spin_unlock(&lock, key);
	}
	return 0;
}

#ifdef CONFIG_USERSPACE
int z_vrfy_k_condvar_signal(struct k_condvar *condvar)
{
	Z_OOPS(Z_SYSCALL_OBJ(condvar, K_OBJ_CONDVAR));
	return z_impl_k_condvar_signal(condvar);
}
#include <syscalls/k_condvar_signal_mrsh.c>
#endif

//解除阻塞所有在条件变量上挂起的线程
int z_impl_k_condvar_broadcast(struct k_condvar *condvar)
{
	struct k_thread *pending_thread;
	k_spinlock_key_t key;
	int woken = 0;
	//静态条件变量上锁
	key = k_spin_lock(&lock);

	//唤醒所有等待写入的线程
	//遍历寻找每一个"最高优先级线程",直到全部找完
	while ((pending_thread = z_unpend_first_thread(&condvar->wait_q)) !=
			NULL) {
		//清空返回值k_thread.callee_saved.retval = 0;
		arch_thread_return_value_set(pending_thread, 0);
		z_ready_thread(pending_thread);//就绪该线程
		woken++;//就绪完成记录解除成功
	}
	//启动重调度,必须等全部线程都解除阻塞
	//thread已经就绪且是等待队列优先级最高的线程(但它会是第一个就绪的)
	//它将有很大的几率被执行(但是当前pending_thread基本上
	//不会是第一个解除阻塞的线程),这里采用了延迟内核抢占
	//以保证所有的线程全部解除阻塞后再进行内核抢占
	z_reschedule(&lock, key);
	return woken;
}

#ifdef CONFIG_USERSPACE
int z_vrfy_k_condvar_broadcast(struct k_condvar *condvar)
{
	Z_OOPS(Z_SYSCALL_OBJ(condvar, K_OBJ_CONDVAR));
	return z_impl_k_condvar_broadcast(condvar);
}
#include <syscalls/k_condvar_broadcast_mrsh.c>
#endif

//等待释放互斥锁的条件变量
int z_impl_k_condvar_wait(struct k_condvar *condvar, struct k_mutex *mutex,
						  k_timeout_t timeout)
{
	k_spinlock_key_t key;
	int ret;

	//静态条件变量上锁
	key = k_spin_lock(&lock);
	k_mutex_unlock(mutex);//解锁指定的互斥锁
	//将当前线程以指定timeout为时间挂起到条件变量的等待队列中
	//并启动调度机制,开启调度
	ret = z_pend_curr(&lock, key, &condvar->wait_q, timeout);
	//回到此处后表明等待结束,挂起结束,调度器在未来某一个时间
	//切换回当前线程,程序继续执行到这里
	k_mutex_lock(mutex, K_FOREVER);//抢占指定的互斥锁
	return ret;
}
#ifdef CONFIG_USERSPACE
int z_vrfy_k_condvar_wait(struct k_condvar *condvar, struct k_mutex *mutex,
			  k_timeout_t timeout)
{
	Z_OOPS(Z_SYSCALL_OBJ(condvar, K_OBJ_CONDVAR));
	Z_OOPS(Z_SYSCALL_OBJ(mutex, K_OBJ_MUTEX));
	return z_impl_k_condvar_wait(condvar, mutex, timeout);
}
#include <syscalls/k_condvar_wait_mrsh.c>
#endif
