/*
 * zephyr内核
 */
 
#include <kernel.h>
#include <ksched.h>
#include <spinlock.h>
#include <sched_priq.h>
#include <wait_q.h>
#include <kswap.h>
#include <kernel_arch_func.h>
#include <syscall_handler.h>
#include <drivers/timer/system_timer.h>
#include <stdbool.h>
#include <kernel_internal.h>
#include <logging/log.h>
#include <sys/atomic.h>

LOG_MODULE_DECLARE(os, CONFIG_KERNEL_LOG_LEVEL);

//自终止线程标记自己为DEAD到最后一次对其堆栈内存进行读写
//的最大时间(即下一次swap()的时间)
//理论上,这可以针对每个平台进行调优
//但在实践中,这个保守的值应该是安全的
#define THREAD_ABORT_DELAY_US 500

//优先队列的一系列操作集
//根据实际情况去使用对应的以宏定义的抽象
#if defined(CONFIG_SCHED_DUMB)
//使用虚拟
#define _priq_run_add		z_priq_dumb_add
#define _priq_run_remove	z_priq_dumb_remove

#if defined(CONFIG_SCHED_CPU_MASK)
#define _priq_run_best	_priq_dumb_mask_best
#else
#define _priq_run_best	z_priq_dumb_best
#endif

//如果配置可扩展属性,使用红黑树
#elif defined(CONFIG_SCHED_SCALABLE)
#define _priq_run_add		z_priq_rb_add
#define _priq_run_remove	z_priq_rb_remove
#define _priq_run_best		z_priq_rb_best
//如果配置多等待队列,使用优先位图队列集
#elif defined(CONFIG_SCHED_MULTIQ)
#define _priq_run_add		z_priq_mq_add
#define _priq_run_remove	z_priq_mq_remove
#define _priq_run_best		z_priq_mq_best
#endif

//如果等待队列配置可扩展属性,使用红黑树
#if defined(CONFIG_WAITQ_SCALABLE)
#define z_priq_wait_add		z_priq_rb_add
#define _priq_wait_remove	z_priq_rb_remove
#define _priq_wait_best		z_priq_rb_best
//如果配置(虚拟?)等待队列,使用普通链表模式
#elif defined(CONFIG_WAITQ_DUMB)
#define z_priq_wait_add		z_priq_dumb_add
#define _priq_wait_remove	z_priq_dumb_remove
#define _priq_wait_best		z_priq_dumb_best
#endif

//唯一的结构z_kernel实例
struct z_kernel _kernel;
//调度锁
static struct k_spinlock sched_spinlock;


static void update_cache(int);

//宏定义的滚动锁,单次使用
#define LOCKED(lck) for (k_spinlock_key_t __i = {},	\
						 __key = k_spin_lock(lck);	\
						!__i.key;                   \
						k_spin_unlock(lck, __key), __i.key = 1)

//判断线程是否可抢占模式
static inline int is_preempt(struct k_thread *thread)
{
#ifdef CONFIG_PREEMPT_ENABLED
	//抢占值的最高限制,防止多重抢占的不可控性
	return thread->base.preempt <= _PREEMPT_THRESHOLD;
#else
	return 0;
#endif
}

//判断线程是否是元中断优先级别
static inline int is_metairq(struct k_thread *thread)
{
#if CONFIG_NUM_METAIRQ_PRIORITIES > 0
	return (thread->base.prio - K_HIGHEST_THREAD_PRIO)
				< CONFIG_NUM_METAIRQ_PRIORITIES;
#else
	return 0;
#endif
}

#if CONFIG_ASSERT
//判断线程是否是一个虚拟线程
static inline bool is_thread_dummy(struct k_thread *thread)
{
	return (thread->base.thread_state & _THREAD_DUMMY) != 0U;
}
#endif

//检查线程1的优先级是否高于线程2的优先级
bool z_is_t1_higher_prio_than_t2(struct k_thread *thread_1,
				 struct k_thread *thread_2)
{
	//优先级值越小,优先级越高,如果是直接<直接判断
	if (thread_1->base.prio < thread_2->base.prio) {
		return true;
	}

#ifdef CONFIG_SCHED_DEADLINE
	//如果我们假设所有截止日期都在32位模数空间的
	//相同“一半”内(这是一个有文档的API规则)
	//那么队列中最新的截止日期减去最早的截止日期将保证为(2的补码)非负
	//我们可以利用它来比较值,而不必检查当前时间
	if (thread_1->base.prio == thread_2->base.prio) {
		//在优先级相等的情况下通过检查优先中止时间可判断
		//优先级高的先执行,先中止,所以时间会小
		int32_t d1 = thread_1->base.prio_deadline;
		int32_t d2 = thread_2->base.prio_deadline;
		return (d2 - d1) >= 0;
	}
#endif
	return false;
}

//判断线程是否可以有抢占其他线程的资格
static ALWAYS_INLINE bool should_preempt(struct k_thread *thread,
										 int preempt_ok)
{
	//如果软件状态明确允许抢占,抢占是可以的(例如线程k_yield())
	if (preempt_ok != 0) {
		return true;
	}
	//断言当前正在执行的线程需要存在
	__ASSERT(_current != NULL, "");
	//或者如果我们被挂起/挂起/虚拟(...),反正就是没有正常运行
	if (z_is_thread_prevented_from_running(_current)) {
		return true;
	}
	//在ARM的边缘情况下
	//一个线程可以在“同步”交换开始上下文切换之前挂起中断处理程序
	//具有原子交换的平台永远无法达到这个目标
	if (IS_ENABLED(CONFIG_SWAP_NONATOMIC)
	    && z_is_thread_timeout_active(thread)) {
		return true;
	}
	//否则,我们必须运行抢占线程检查或元中断检查
	if (is_preempt(_current) || is_metairq(thread)) {
		return true;
	}
	//如果没有抢占优先级,空闲线程看起来是“合作的”(这是一种API故障)
	//他们必须总是可抢占的
	if (!IS_ENABLED(CONFIG_PREEMPT_ENABLED) &&
	    z_is_idle_thread_object(_current)) {
		return true;//如果没有抢占优先级,空闲线程总是可抢占的
	}
	return false;
}

#ifdef CONFIG_SCHED_CPU_MASK
//优先队列寻找一个最合适运行的线程
static ALWAYS_INLINE struct k_thread *_priq_dumb_mask_best(sys_dlist_t *pq)
{
	//启用掩码后,我们需要准备遍历名单,寻找一个我们可以运行的线程
	struct k_thread *thread;
	//对双向链表进行遍历,获取所有者,去检查每一个线程掩码
	//因为是以优先级为关键字的优先队列,所以找到第一个即可
	SYS_DLIST_FOR_EACH_CONTAINER(pq, thread, base.qnode_dlist) {
		//如果有一个线程与当前线程CPU标号相撞(意味着当前CPU有执行权)
		if ((thread->base.cpu_mask & BIT(_current_cpu->id)) != 0) {
			return thread;//反馈该线程
		}
	}
	return NULL;
}
#endif

//下一个运行线程
static ALWAYS_INLINE struct k_thread *next_up(void)
{
	struct k_thread *thread;
	//如果一个线程自中止,我们需要空闲线程来清理它
	//然后其他线程才能在这个CPU上运行
	if (_current_cpu->pending_abort != NULL) {
		return _current_cpu->idle_thread;
	}
	
	//获取最适合(优先级最高)在当前CPU执行的线程
	thread = _priq_run_best(&_kernel.ready_q.runq);

#if (CONFIG_NUM_METAIRQ_PRIORITIES > 0) && (CONFIG_NUM_COOP_PRIORITIES > 0)
	//MetaIRQs必须总是尝试返回到他们抢占的合作线程
	//而不是现在发生的最高优先级的线程
	//协程被承诺不会被抢占(被非metairq线程)!
	struct k_thread *mirqp = _current_cpu->metairq_preempted;

	if (mirqp != NULL && (thread == NULL || !is_metairq(thread))) {
		//如果该协程曾经被阻止运行,那现在给他运行权限
		if (!z_is_thread_prevented_from_running(mirqp)) {
			thread = mirqp;
		} else {//否则默认当前线程没有协程
			_current_cpu->metairq_preempted = NULL;
		}
	}
#endif

	//如果当前线程被标记为中止,则将其标记为死线程,这样就不会再次调度它
	if (_current->base.thread_state & _THREAD_ABORTING) {
		_current->base.thread_state |= _THREAD_DEAD;
#ifdef CONFIG_SMP
		_current_cpu->swap_ok = true;
#endif
	}

#ifndef CONFIG_SMP
	//在单处理器模式下
	//我们可以将当前线程留在队列中(实际上我们必须这样做
	//否则所有架构的程序集上下文切换代码将负责将其放回z_swap和ISR返回!)
	//这使这个选择变得简单
	return thread ? thread : _current_cpu->idle_thread;
#else
	//在SMP下选择下一个线程的“缓存”机制不起作用
	//所以我们有更多的工作要做来测试_current与从队列的最佳选择
	//在这里上面选择的线程代表“当前最好的线程”
	//关于"queued"的微妙注意:在SMP模式下
	//_current并不存在于队列中,所以这与"ready"并不完全相同
	//它的意思是" _current已经被添加回队列,所以我们不想重新添加它"
	
	//当前线程是否在队列,当前线程是否是活跃的
	int queued = z_is_thread_queued(_current);
	int active = !z_is_thread_prevented_from_running(_current);

	if (thread == NULL) {//没有更好的线程,只好选取空闲线程
		thread = _current_cpu->idle_thread;
	}
	
	//如果当前线程是活跃态
	if (active) {
		//如果当前线程不存在于队列,且当前线程优先级高于选定线程
		if (!queued &&
		    !z_is_t1_higher_prio_than_t2(thread, _current)) {
			thread = _current;//还是当前线程执行
		}

		//如果新选定的线程应该被抢占,那还是当前线程执行
		if (!should_preempt(thread, _current_cpu->swap_ok)) {
			thread = _current;
		}
	}

	//将_current放回队列中
	//线程不是当前线程,且当前线程是活跃态,当前线程不是空闲线程对象
	//当前线程不存在与队列之中
	if (thread != _current && active &&
		!z_is_idle_thread_object(_current) && !queued) {
		//将当前线程加入到内核就绪队列的运行队列中
		_priq_run_add(&_kernel.ready_q.runq, _current);
		z_mark_thread_as_queued(_current);//标记它已经入队列
	}

	//将新的_current从队列中取出
	if (z_is_thread_queued(thread)) {
		//将新线程移除队列中,如果它存在于队列中
		_priq_run_remove(&_kernel.ready_q.runq, thread);
	}
	z_mark_thread_as_not_queued(thread);//标记它已经出队列
	
	//返回下一个选定线程
	return thread;
#endif
}

//将线程移入到优先队列的尾部
static void move_thread_to_end_of_prio_q(struct k_thread *thread)
{
	if (z_is_thread_queued(thread)) {
		//将新线程移除内核就绪队列的运行队列中,如果它存在于队列中
		_priq_run_remove(&_kernel.ready_q.runq, thread);
	}
	//将线程加入到就绪队列的运行队列的尾部
	_priq_run_add(&_kernel.ready_q.runq, thread);
	z_mark_thread_as_queued(thread);//标记为已经入队列
	update_cache(thread == _current);//更新缓冲
}

#ifdef CONFIG_TIMESLICING

static int slice_time;
static int slice_max_prio;

#ifdef CONFIG_SWAP_NONATOMIC
//如果z_swap()不是原子性的,那么计时器中断可能会在_current已经挂起之后
//但是在相应的上下文切换之前尝试把它分段
//将其作为z_time_slice()中的一个noop条件
static struct k_thread *pending_current;
#endif

//重置时间片
void z_reset_time_slice(void)
{
	//将从最后一个宣布的计时开始所经过的时间添加到片计数中
	//因为我们将在FUTURE z_time_slice()调用中看到那些“过期”的计时
	if (slice_time != 0) {
		//当前CPU的时间滴答更新
		_current_cpu->slice_ticks = slice_time + z_clock_elapsed();
		//更新超时过期时间
		z_set_timeout_expiry(slice_time, false);
	}
}

//调度时间分片设置
void k_sched_time_slice_set(int32_t slice, int prio)
{
	LOCKED(&sched_spinlock) {//调度锁
		_current_cpu->slice_ticks = 0;//清空时间片滴答数
		//获取新的时间滴答时间,更新
		slice_time = k_ms_to_ticks_ceil32(slice);
		slice_max_prio = prio;//更新分时最大优先级
		z_reset_time_slice();//重置当前CPU的时间滴答
	}
}

//线程可分时检查
static inline int sliceable(struct k_thread *thread)
{
	//线程是可抢占的,线程不是被运行阻止的
	//线程优先级高于分时最大优先级,线程所有者不是IDLE
	return is_preempt(thread)
		&& !z_is_thread_prevented_from_running(thread)
		&& !z_is_prio_higher(thread->base.prio, slice_max_prio)
		&& !z_is_idle_thread_object(thread);
}

//调用出每个计时器中断
void z_time_slice(int ticks)
{
	//保持sched_spinlock
	//以便在另一个CPU上的活动(比如在错误的时间调用k_thread_abort())
	//不会影响这里做出的决策的正确性
	//还可以防止任何嵌套中断改变线程状态,以避免类似的问题
	//因为这通常会在启用irq的情况下运行
	k_spinlock_key_t key = k_spin_lock(&sched_spinlock);

#ifdef CONFIG_SWAP_NONATOMIC
	//当前线程正在被挂起
	if (pending_current == _current) {
		z_reset_time_slice();//重置时间片
		k_spin_unlock(&sched_spinlock, key);
		return;
	}
	pending_current = NULL;
#endif
	
	//存在分时时间,且当前线程可分时
	if (slice_time && sliceable(_current)) {
		//当前CPU的时间片滴答不足
		if (ticks >= _current_cpu->slice_ticks) {
			//当前线程被移入到优先队列末尾
			move_thread_to_end_of_prio_q(_current);
			z_reset_time_slice();//重置时间片
		} else {
			//当前CPU还有足够的运行时间片,扣除记录即可
			_current_cpu->slice_ticks -= ticks;
		}
	} else {
		//清除当前CPU的分时时间,它已经没有运行时间了
		_current_cpu->slice_ticks = 0;
	}
	k_spin_unlock(&sched_spinlock, key);
}
#endif

//跟踪协程被metairqs抢占,这样我们就可以明确地返回它们,在选择要运行的新线程时调用
static void update_metairq_preempt(struct k_thread *thread)
{
#if (CONFIG_NUM_METAIRQ_PRIORITIES > 0) && (CONFIG_NUM_COOP_PRIORITIES > 0)
	//指定线程是元中断级,当前线程是非元中断级,当前线程不可抢占
	if (is_metairq(thread) && !is_metairq(_current) && !is_preempt(_current)) {
		_current_cpu->metairq_preempted = _current;//记录新抢占
	//如果线程不是元中断级,线程不是空闲对象所有
	} else if (!is_metairq(thread) && !z_is_idle_thread_object(thread)) {
		_current_cpu->metairq_preempted = NULL;//从现有的抢占返回
	}
#endif
}

//更新缓存
static void update_cache(int preempt_ok)
{
#ifndef CONFIG_SMP
	//获取下一个执行线程
	struct k_thread *thread = next_up();
	//该线程是否可以达到抢占条件
	if (should_preempt(thread, preempt_ok)) {
#ifdef CONFIG_TIMESLICING
		//线程不一致才需要更新时间片
		if (thread != _current) {
			z_reset_time_slice();
		}
#endif
		//新线程抢占了当前线程,是否当前线程可以成为合作线程
		update_metairq_preempt(thread);
		//内核就绪队列缓冲更新为新线程
		_kernel.ready_q.cache = thread;
	} else {
		//新线程不达到抢占条件,抢占失败
		_kernel.ready_q.cache = _current;
	}

#else
	//这是工作的方式是CPU记录保持它的“合作交换是OK”标志
	//直到下一次重调度调用或上下文切换
	//它不需要对每个线程进行跟踪
	//因为如果线程因任何原因被抢占
	//调度程序无论如何都会做出相同的决定
	_current_cpu->swap_ok = preempt_ok;
#endif
}

//就绪一个指定的线程
static void ready_thread(struct k_thread *thread)
{
#ifdef KERNEL_COHERENCE
	__ASSERT_NO_MSG(arch_mem_coherent(thread));
#endif
	//如果线程已经在队列中,不要尝试再次将其添加到运行队列中
	if (!z_is_thread_queued(thread) && z_is_thread_ready(thread)) {
		sys_trace_thread_ready(thread);
		//指定的线程加入到内核就绪队列的运行队列
		_priq_run_add(&_kernel.ready_q.runq, thread);
		z_mark_thread_as_queued(thread);//标记它已经入队列
		update_cache(0);//可能无需更新缓冲
#if defined(CONFIG_SMP) &&  defined(CONFIG_SCHED_IPI_SUPPORTED)
		arch_sched_ipi();//平台配置,多处理器所用的处理器间线程迁移
#endif
	}
}

//就绪一个线程
void z_ready_thread(struct k_thread *thread)
{
	LOCKED(&sched_spinlock) {//上调度锁
		ready_thread(thread);
	}
}

//线程加入到就绪队列的尾部
void z_move_thread_to_end_of_prio_q(struct k_thread *thread)
{
	LOCKED(&sched_spinlock) {
		move_thread_to_end_of_prio_q(thread);
	}
}

//对指定线程启动调度
void z_sched_start(struct k_thread *thread)
{
	k_spinlock_key_t key = k_spin_lock(&sched_spinlock);
	//如果线程已经启动就无需再次启动
	if (z_has_thread_started(thread)) {
		k_spin_unlock(&sched_spinlock, key);
		return;
	}
	z_mark_thread_as_started(thread);//标记线程已经启动
	ready_thread(thread);//就绪该线程
	z_reschedule(&sched_spinlock, key);//启用重调度
}

//挂起一个指定线程
void z_impl_k_thread_suspend(struct k_thread *thread)
{
	(void)z_abort_thread_timeout(thread);//中止指定线程的超时
	//上调度锁
	LOCKED(&sched_spinlock) {
		if (z_is_thread_queued(thread)) {//如果线程存在于队列
			//将指定的线程移除出就绪队列的运行队列中
			_priq_run_remove(&_kernel.ready_q.runq, thread);
			z_mark_thread_as_not_queued(thread);//标记该线程出队列
		}
		z_mark_thread_as_suspended(thread);//标记该线程已经挂起
		update_cache(thread == _current);//如果该线程是当前线程,更新缓冲
	}

	if (thread == _current) {
		//如果指定线程是当前线程,启用重调度
		z_reschedule_unlocked();
	}
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_thread_suspend(struct k_thread *thread)
{
	Z_OOPS(Z_SYSCALL_OBJ(thread, K_OBJ_THREAD));
	z_impl_k_thread_suspend(thread);
}
#include <syscalls/k_thread_suspend_mrsh.c>
#endif

//恢复一个线程
void z_impl_k_thread_resume(struct k_thread *thread)
{
	k_spinlock_key_t key = k_spin_lock(&sched_spinlock);

	//如果线程被挂起,则不允许线程被挂起
	if (!z_is_thread_suspended(thread)) {
		k_spin_unlock(&sched_spinlock, key);
		return;
	}
	//标记该线程为未挂起态
	z_mark_thread_as_not_suspended(thread);
	ready_thread(thread);//就绪该线程
	//启用重调度
	z_reschedule(&sched_spinlock, key);
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_thread_resume(struct k_thread *thread)
{
	Z_OOPS(Z_SYSCALL_OBJ(thread, K_OBJ_THREAD));
	z_impl_k_thread_resume(thread);
}
#include <syscalls/k_thread_resume_mrsh.c>
#endif

//获取线程挂起在哪一个等待队列中
static _wait_q_t *pended_on(struct k_thread *thread)
{
	__ASSERT_NO_MSG(thread->base.pended_on);
	return thread->base.pended_on;
}

//中止一个线程
void z_thread_single_abort(struct k_thread *thread)
{
	//初始化一个线程初始函数为空
	void (*fn_abort)(struct k_thread *aborted) = NULL;
	//特权级线程不可被中止,线程是否是自终止的
	__ASSERT(!(thread->base.user_options & K_ESSENTIAL),
			 "essential thread aborted");
	__ASSERT(thread != _current || arch_is_in_isr(),
			 "self-abort detected");

	//阻止此函数中任何进一步的逻辑不止一次运行
	k_spinlock_key_t key = k_spin_lock(&sched_spinlock);
	
	//如果指定线程的状态已经是中止态或死亡态,无需再次中止
	if ((thread->base.thread_state &
	    (_THREAD_ABORTING | _THREAD_DEAD)) != 0) {
		LOG_DBG("Thread %p already dead or on the way out", thread);
		k_spin_unlock(&sched_spinlock, key);
		return;
	}
	//标记它为种植太
	thread->base.thread_state |= _THREAD_ABORTING;
	k_spin_unlock(&sched_spinlock, key);
	//中止该线程的超时等待活动
	(void)z_abort_thread_timeout(thread);
	//中止该线程的调度行为
	if (IS_ENABLED(CONFIG_SMP)) {
		z_sched_abort(thread);
	}
	//上调度锁
	LOCKED(&sched_spinlock) {
		LOG_DBG("Cleanup aborting thread %p", thread);
		struct k_thread *waiter;
		//如果线程是就绪态
		if (z_is_thread_ready(thread)) {
			//该线程存在于就绪队列的运行队列中,移除它
			if (z_is_thread_queued(thread)) {
				_priq_run_remove(&_kernel.ready_q.runq, thread);
				z_mark_thread_as_not_queued(thread);
			}
			update_cache(thread == _current);//更新缓冲
		} else {
			//如果线程是挂起态
			if (z_is_thread_pending(thread)) {
				//将它从导致它挂起的等待队列中移除
				_priq_wait_remove(&pended_on(thread)->waitq, thread);
				z_mark_thread_as_not_pending(thread);//标记非挂起态
				thread->base.pended_on = NULL;//该线程不再挂起于任何地方
			}
		}

		//唤醒所有试图加入这个线程的人
		//k_thread_abort()稍后调用reschedule
		while ((waiter = z_waitq_head(&thread->base.join_waiters)) != NULL) {
			//中止对等待该线程的所有等待者的超时活动
			(void)z_abort_thread_timeout(waiter);
			//将等待者从等待队列中移除
			_priq_wait_remove(&pended_on(waiter)->waitq, waiter);
			z_mark_thread_as_not_pending(waiter);//标记等待者为非挂起态
			waiter->base.pended_on = NULL;//等待者不再挂起于任何地方
			arch_thread_return_value_set(waiter, 0);//设置等待者可运行
			ready_thread(waiter);//就绪等待者
		}

		//如果当前线程是空闲线程,更新缓冲
		if (z_is_idle_thread_object(_current)) {
			update_cache(1);
		}

		//线程被标记为死亡态
		thread->base.thread_state |= _THREAD_DEAD;

		//现在从线程结构读取这个,而不是在我们解锁之后
		//获取线程的中止回调
		fn_abort = thread->fn_abort;

		//保持在自旋锁内,因为这些可能会使用线程对象的内容
		//一旦我们释放了这个自旋锁,线程对象就可以在任何时候被销毁
		sys_trace_thread_abort(thread);
		z_thread_monitor_exit(thread);//退出对该线程的监控

#ifdef CONFIG_USERSPACE
		//将此线程从其内存域中移除,将其从域的线程列表中移除,也可能从特定于平台的任务中移除
		z_mem_domain_exit_thread(thread);

		//撤销线程ID上的权限,以便它可以被回收
		z_thread_perms_all_clear(thread);

		//清除初始化状态,以便该线程对象可以被重用,并在用户线程调用API时触发错误
		z_object_uninit(thread->stack_obj);
		z_object_uninit(thread);
#endif
		//Kernel不应该再查看线程对象,除非另一个线程API被调用
		//如果对象没有损坏,我们将在该对象上捕获其他k_thread_abort(),尽管这是某种程度上未定义的行为
		//此时调用k_thread_create()或释放对象必须是安全的
#if __ASSERT_ON
		//清除断言原子态
		atomic_clear(&thread->base.cookie);
#endif
	}

	if (fn_abort != NULL) {
		//提供给释放或回收的线程对象
		fn_abort(thread);
	}
}

//取消一个线程就绪态
static void unready_thread(struct k_thread *thread)
{
	if (z_is_thread_queued(thread)) {
		//将它移除出就绪队列的运行队列中
		_priq_run_remove(&_kernel.ready_q.runq, thread);
		z_mark_thread_as_not_queued(thread);//标记为出队列
	}
	//如果该线程已经运行,更新缓冲区
	update_cache(thread == _current);
}

//从就绪队列移除一个线程
void z_remove_thread_from_ready_q(struct k_thread *thread)
{
	LOCKED(&sched_spinlock) {
		unready_thread(thread);
	}
}

//线程加入到指定的等待队列
static void add_to_waitq_locked(struct k_thread *thread, _wait_q_t *wait_q)
{
	unready_thread(thread);//对该线程取消就绪
	z_mark_thread_as_pending(thread);//标记其为挂起态
	sys_trace_thread_pend(thread);

	if (wait_q != NULL) {//将该线程加入到等待队列中
		thread->base.pended_on = wait_q;
		z_priq_wait_add(&wait_q->waitq, thread);
	}
}

//线程添加指定的超时时间
static void add_thread_timeout(struct k_thread *thread, k_timeout_t timeout)
{
	//如果超时非永久,添加阻塞超时,加入到超时队列中
	if (!K_TIMEOUT_EQ(timeout, K_FOREVER)) {
		z_add_thread_timeout(thread, timeout);
	}
}

//挂起一个线程到指定的等待队列中,以指定的超时时间
static void pend(struct k_thread *thread, _wait_q_t *wait_q, k_timeout_t timeout)
{
#ifdef KERNEL_COHERENCE
	__ASSERT_NO_MSG(arch_mem_coherent(wait_q));
#endif
	//将线程加入到指定的等待队列中
	LOCKED(&sched_spinlock) {
		add_to_waitq_locked(thread, wait_q);
	}
	//为线程添加指定的超时,线程被加入到超时队列中
	add_thread_timeout(thread, timeout);
}

//挂起一个指定线程到指定的等待队列中,以指定的超时时间
void z_pend_thread(struct k_thread *thread, _wait_q_t *wait_q, k_timeout_t timeout)
{
	__ASSERT_NO_MSG(thread == _current || is_thread_dummy(thread));
	pend(thread, wait_q, timeout);
}

//从等待队列中找到第一个线程
ALWAYS_INLINE struct k_thread *z_find_first_thread_to_unpend(_wait_q_t *wait_q,
															 struct k_thread *from)
{
	ARG_UNUSED(from);
	struct k_thread *ret = NULL;
	//上调度锁
	LOCKED(&sched_spinlock) {
		ret = _priq_wait_best(&wait_q->waitq);
	}

	return ret;
}

//取消一个线程的挂起
static inline void unpend_thread_no_timeout(struct k_thread *thread)
{
	//将其从等待队列中移除
	_priq_wait_remove(&pended_on(thread)->waitq, thread);
	z_mark_thread_as_not_pending(thread);//标记其为非挂起态
	thread->base.pended_on = NULL;//该线程不再挂起于任何地方
}

ALWAYS_INLINE void z_unpend_thread_no_timeout(struct k_thread *thread)
{
	LOCKED(&sched_spinlock) {
		unpend_thread_no_timeout(thread);
	}
}

#ifdef CONFIG_SYS_CLOCK_EXISTS
//*_thread_timeout() APIs的超时处理器
void z_thread_timeout(struct _timeout *timeout)
{
	//上调度锁
	LOCKED(&sched_spinlock) {
		//获得超时器的所有者线程
		struct k_thread *thread = CONTAINER_OF(timeout,
											   struct k_thread, base.timeout);
		//如果该线程是挂起的,取消对它的挂起
		if (thread->base.pended_on != NULL) {
			unpend_thread_no_timeout(thread);
		}
		z_mark_thread_as_started(thread);//标记它为启动态
		z_mark_thread_as_not_suspended(thread);//移除它的挂起态
		ready_thread(thread);//就绪该线程
	}
}
#endif

//挂起当前线程,带中断锁模式
int z_pend_curr_irqlock(uint32_t key, _wait_q_t *wait_q, k_timeout_t timeout)
{
	//挂起当前线程,以指定超时时间挂起到指定的等待队列中
	pend(_current, wait_q, timeout);

#if defined(CONFIG_TIMESLICING) && defined(CONFIG_SWAP_NONATOMIC)
	pending_current = _current;

	int ret = z_swap_irqlock(key);
	LOCKED(&sched_spinlock) {
		if (pending_current == _current) {
			pending_current = NULL;
		}
	}
	return ret;
#else
	return z_swap_irqlock(key);
#endif
}

//挂起当前线程
int z_pend_curr(struct k_spinlock *lock, k_spinlock_key_t key,
				_wait_q_t *wait_q, k_timeout_t timeout)
{
#if defined(CONFIG_TIMESLICING) && defined(CONFIG_SWAP_NONATOMIC)
	pending_current = _current;
#endif
	//挂起当前线程,以指定超时时间挂起到指定的等待队列中
	pend(_current, wait_q, timeout);
	return z_swap(lock, key);
}

//从等待队列解除第一个挂起线程
struct k_thread *z_unpend_first_thread(_wait_q_t *wait_q)
{
	//获得该挂起线程
	struct k_thread *thread = z_unpend1_no_timeout(wait_q);
	//对该线程取消其超时
	if (thread != NULL) {
		(void)z_abort_thread_timeout(thread);
	}
	
	return thread;
}

//解除指定线程的挂起
void z_unpend_thread(struct k_thread *thread)
{
	z_unpend_thread_no_timeout(thread);//将该线程解除挂起
	(void)z_abort_thread_timeout(thread);//将该线程取消超时
}

//设置线程的优先级
bool z_set_prio(struct k_thread *thread, int prio)
{
	//优先级设置实用程序不进行重新调度
	//它只是更改运行队列状态,如果稍后需要重新调度则返回true
	bool need_sched = 0;
	//上调度锁
	LOCKED(&sched_spinlock) {
		//该线程是就绪态,需要调度
		need_sched = z_is_thread_ready(thread);
		if (need_sched) {
			//如果SMP是正在运行的线程,不要在它上重新排队
			if (!IS_ENABLED(CONFIG_SMP) || z_is_thread_queued(thread)) {
				_priq_run_remove(&_kernel.ready_q.runq, thread);
				thread->base.prio = prio;//将其移除后,修改优先级,重新加入
				_priq_run_add(&_kernel.ready_q.runq, thread);
			} else {
				thread->base.prio = prio;
			}
			update_cache(1);//更新缓冲区
		} else {
			thread->base.prio = prio;
		}
	}
	
	sys_trace_thread_priority_set(thread);
	return need_sched;
}

//设置线程优先级
void z_thread_priority_set(struct k_thread *thread, int prio)
{
	bool need_sched = z_set_prio(thread, prio);

#if defined(CONFIG_SMP) && defined(CONFIG_SCHED_IPI_SUPPORTED)
	arch_sched_ipi();
#endif
	//如果需要重调度,且线程没有调度锁,调度它
	if (need_sched && _current->base.sched_locked == 0) {
		z_reschedule_unlocked();
	}
}

//是否需要重调度
static inline int resched(uint32_t key)
{
#ifdef CONFIG_SMP
	_current_cpu->swap_ok = 0;//当前CPU未调度
#endif

	return arch_irq_unlocked(key) && !arch_is_in_isr();
}

//检查下一个就绪线程是否与当前线程相同,如果为true则保存行程
static inline bool need_swap(void)
{
	//SMP的情况将在基于C的z_swap()中处理
#ifdef CONFIG_SMP
	return true;
#else
	struct k_thread *new_thread;
	//检查下一个就绪线程是否与当前线程相同
	new_thread = z_get_next_ready_thread();
	return new_thread != _current;//不是当前线程,需要调度
#endif
}

//带锁调度
void z_reschedule(struct k_spinlock *lock, k_spinlock_key_t key)
{
	//如果具备的调度条件,则调度它
	if (resched(key.key) && need_swap()) {
		z_swap(lock, key);
	} else {//否则为其解自旋锁
		k_spin_unlock(lock, key);
	}
}

//带中断锁调度
void z_reschedule_irqlock(uint32_t key)
{
	//带锁调度
	if (resched(key)) {
		z_swap_irqlock(key);
	} else {
		irq_unlock(key);
	}
}

//调度锁
void k_sched_lock(void)
{
	LOCKED(&sched_spinlock) {
		z_sched_lock();
	}
}

//解调度锁
void k_sched_unlock(void)
{
#ifdef CONFIG_PREEMPT_ENABLED
	//上调度锁
	LOCKED(&sched_spinlock) {
		__ASSERT(_current->base.sched_locked != 0, "");
		__ASSERT(!arch_is_in_isr(), "");
		//当前线程调度锁记录
		++_current->base.sched_locked;
		update_cache(0);//更新缓冲区
	}

	LOG_DBG("scheduler unlocked (%p:%d)",
			_current, _current->base.sched_locked);
	//解调度锁,开启重调度
	z_reschedule_unlocked();
#endif
}

#ifdef CONFIG_SMP
//获取下一个执行线程
struct k_thread *z_get_next_ready_thread(void)
{
	struct k_thread *ret = 0;
	//上调度锁
	LOCKED(&sched_spinlock) {
		ret = next_up();
	}
	return ret;
}
#endif

//只是一个带有跟踪的_current = xxx的包装
//设置指定线程为当前运行线程
static inline void set_current(struct k_thread *new_thread)
{
	z_thread_mark_switched_out();//标记之前的当前线程被切换出去
	_current_cpu->current = new_thread;//设置当前线程为运行线程
}

#ifdef CONFIG_USE_SWITCH
//获取下一个切换句柄
void *z_get_next_switch_handle(void *interrupted)
{
	//检查栈哨兵
	z_check_stack_sentinel();
#ifdef CONFIG_SMP
	//上调度锁
	LOCKED(&sched_spinlock) {
		//获得旧线程
		struct k_thread *old_thread = _current, *new_thread;
		old_thread->switch_handle = NULL;
		new_thread = next_up();//获取新线程
		if (old_thread != new_thread) {
			//旧线程不等于新线程,更新新线程的元中断抢占
			//它会不会让当前线程成为协程
			update_metairq_preempt(new_thread);
			wait_for_switch(new_thread);//等待切换
			arch_cohere_stacks(old_thread, interrupted, new_thread);

#ifdef CONFIG_TIMESLICING
			//重置新线程时间片
			z_reset_time_slice();
#endif
			//还未调度状态,设置当前线程为新线程
			_current_cpu->swap_ok = 0;
			set_current(new_thread);

#ifdef CONFIG_SPIN_VALIDATE
			//改变_current!更新自旋锁bookeeping
			//这样当“错误的”线程试图释放锁时,验证就不会混淆
			z_spin_lock_set_owner(&sched_spinlock);
#endif
		}
		//旧线程的上下文切换句柄更新
		old_thread->switch_handle = interrupted;
	}
#else
	//如果不是多处理器机制,直接设置当前线程上下文句柄
	//更新当前线程为新线程
	_current->switch_handle = interrupted;
	set_current(z_get_next_ready_thread());
#endif
	return _current->switch_handle;
}
#endif

//将一个新线程加入到优先级队列
ALWAYS_INLINE void z_priq_dumb_add(sys_dlist_t *pq, struct k_thread *thread)
{
	struct k_thread *t;
	__ASSERT_NO_MSG(!z_is_idle_thread_object(thread));
	//遍历整个链表获得其所有者
	SYS_DLIST_FOR_EACH_CONTAINER(pq, t, base.qnode_dlist) {
		//将它插入到一个刚好优先级小于它之前
		if (z_is_t1_higher_prio_than_t2(thread, t)) {
			sys_dlist_insert(&t->base.qnode_dlist,
							 &thread->base.qnode_dlist);
			return;
		}
	}
	//找不到一个优先级小于它的,尾插到链表中
	sys_dlist_append(pq, &thread->base.qnode_dlist);
}

//将一个新线程移除出优先级队列
void z_priq_dumb_remove(sys_dlist_t *pq, struct k_thread *thread)
{
#if defined(CONFIG_SWAP_NONATOMIC) && defined(CONFIG_SCHED_DUMB)
	//如果该优先队列是运行队列,且线程是当前线程(需要阻止它的继续运行)
	if (pq == &_kernel.ready_q.runq && thread == _current &&
	    z_is_thread_prevented_from_running(thread)) {
		return;
	}
#endif
	__ASSERT_NO_MSG(!z_is_idle_thread_object(thread));
	//将该线程移除出它的所有者中
	sys_dlist_remove(&thread->base.qnode_dlist);
}

//将一个最好的线程从优先级队列中获取
struct k_thread *z_priq_dumb_best(sys_dlist_t *pq)
{
	struct k_thread *thread = NULL;
	//优先级队列是以优先级排列的,首项便是最好的线程
	sys_dnode_t *n = sys_dlist_peek_head(pq);
	if (n != NULL) {
		//获得该节点的所有者线程
		thread = CONTAINER_OF(n, struct k_thread, base.qnode_dlist);
	}
	return thread;
}

//比较红黑树俩个节点对应的所有者的优先级
bool z_priq_rb_lessthan(struct rbnode *a, struct rbnode *b)
{
	struct k_thread *thread_a, *thread_b;
	//获取俩个节点的所有者
	thread_a = CONTAINER_OF(a, struct k_thread, base.qnode_rb);
	thread_b = CONTAINER_OF(b, struct k_thread, base.qnode_rb);
	//比较其优先级,优先级为>情况为真
	if (z_is_t1_higher_prio_than_t2(thread_a, thread_b)) {
		return true;
	} else if (z_is_t1_higher_prio_than_t2(thread_b, thread_a)) {
		return false;
	} else {
		return thread_a->base.order_key < thread_b->base.order_key
			? 1 : 0;
	}
}

//将一个新线程加入到优先级队列树
void z_priq_rb_add(struct _priq_rb *pq, struct k_thread *thread)
{
	struct k_thread *t;
	__ASSERT_NO_MSG(!z_is_idle_thread_object(thread));
	//记录节点数关键字
	thread->base.order_key = pq->next_order_key++;

	//Renumber at wraparound,这是很小的代码,在实践中几乎不会在真实的系统上被击中
	//但是在非常长时间运行的系统中,priq永远不会完全清空并且包含大量的线程
	//像这样循环所有线程可能是一个延迟故障
	if (!pq->next_order_key) {
		//遍历红黑树所有节点的所有者,更新其关键字
		RB_FOR_EACH_CONTAINER(&pq->tree, t, base.qnode_rb) {
			t->base.order_key = pq->next_order_key++;
		}
	}
	//将线程插入到红黑树中
	rb_insert(&pq->tree, &thread->base.qnode_rb);
}

//将一个新线程移除出优先级队列树
void z_priq_rb_remove(struct _priq_rb *pq, struct k_thread *thread)
{
#if defined(CONFIG_SWAP_NONATOMIC) && defined(CONFIG_SCHED_SCALABLE)
	//如果该优先队列是运行队列,如果该线程是当前线程(中止该线程的运行)
	if (pq == &_kernel.ready_q.runq && thread == _current &&
	    z_is_thread_prevented_from_running(thread)) {
		return;
	}
#endif
	__ASSERT_NO_MSG(!z_is_idle_thread_object(thread));
	//将指定线程从红黑树中移除
	rb_remove(&pq->tree, &thread->base.qnode_rb);
	//更新优先级队列树的根
	if (!pq->tree.root) {
		pq->next_order_key = 0;
	}
}

//将一个最好的线程从优先级队列树中获取
struct k_thread *z_priq_rb_best(struct _priq_rb *pq)
{
	struct k_thread *thread = NULL;
	//关键字最小意味着优先级最高
	struct rbnode *n = rb_get_min(&pq->tree);
	if (n != NULL) {
		//获取该节点的所有者线程
		thread = CONTAINER_OF(n, struct k_thread, base.qnode_rb);
	}
	return thread;
}

#ifdef CONFIG_SCHED_MULTIQ
# if (K_LOWEST_THREAD_PRIO - K_HIGHEST_THREAD_PRIO) > 31
# error Too many priorities for multiqueue scheduler (max 32)
# endif
#endif
//将一个新线程加入到优先级队列集
ALWAYS_INLINE void z_priq_mq_add(struct _priq_mq *pq, struct k_thread *thread)
{
	//计算新线程优先级对应的位
	int priority_bit = thread->base.prio - K_HIGHEST_THREAD_PRIO;
	//加入到对应的位指定的队列中,尾插(因为该队列所有线程优先级一致)
	sys_dlist_append(&pq->queues[priority_bit], &thread->base.qnode_dlist);
	//该位产生了线程,要打上标记
	pq->bitmask |= BIT(priority_bit);
}

//将一个新线程移除出优先级队列集
ALWAYS_INLINE void z_priq_mq_remove(struct _priq_mq *pq, struct k_thread *thread)
{
#if defined(CONFIG_SWAP_NONATOMIC) && defined(CONFIG_SCHED_MULTIQ)
	//如果该优先队列是运行队列,如果该线程是当前线程(中止它的运行)
	if (pq == &_kernel.ready_q.runq && thread == _current &&
		z_is_thread_prevented_from_running(thread)) {
		return;
	}
#endif
	//计算新线程优先级对应的位
	int priority_bit = thread->base.prio - K_HIGHEST_THREAD_PRIO;
	//移除出对应的位指定的队列中
	sys_dlist_remove(&thread->base.qnode_dlist);
	//该队列为空,该优先级位不存在线程,清除标记
	if (sys_dlist_is_empty(&pq->queues[priority_bit])) {
		pq->bitmask &= ~BIT(priority_bit);
	}
}

//将一个最好的线程从优先级队列集中获取
struct k_thread *z_priq_mq_best(struct _priq_mq *pq)
{
	//位图为空,该集合不存在线程
	if (!pq->bitmask) {
		return NULL;
	}
	
	struct k_thread *thread = NULL;
	//获得最高位对应的优先队列
	sys_dlist_t *l = &pq->queues[__builtin_ctz(pq->bitmask)];
	//摘出该队列第一个节点
	sys_dnode_t *n = sys_dlist_peek_head(l);
	if (n != NULL) {
		//如果该节点存在,获取它的所有者线程
		thread = CONTAINER_OF(n, struct k_thread, base.qnode_dlist);
	}
	return thread;
}

//将队列所有线程取消等待
int z_unpend_all(_wait_q_t *wait_q)
{
	int need_sched = 0;
	struct k_thread *thread;
	//滚动获取等待队列中的所有的线程
	while ((thread = z_waitq_head(wait_q)) != NULL) {
		z_unpend_thread(thread);//取消它的阻塞态
		z_ready_thread(thread);//就绪该线程
		need_sched = 1;//记录需要重调度
	}
	return need_sched;
}

//初始化调度
void z_sched_init(void)
{
#ifdef CONFIG_SCHED_DUMB
	//初始化内核就绪队列的运行队列
	sys_dlist_init(&_kernel.ready_q.runq);
#endif

#ifdef CONFIG_SCHED_SCALABLE
	//如果该队列是红黑树实现,额外初始化它的比较回调钩子
	_kernel.ready_q.runq = (struct _priq_rb) {
		.tree = {
			.lessthan_fn = z_priq_rb_lessthan,
		}
	};
#endif

#ifdef CONFIG_SCHED_MULTIQ
	//如果该运行队列是队列集实现,滚动初始化其中的每一个队列
	for (int i = 0; i < ARRAY_SIZE(_kernel.ready_q.runq.queues); i++) {
		sys_dlist_init(&_kernel.ready_q.runq.queues[i]);
	}
#endif

#ifdef CONFIG_TIMESLICING
	//设置调度的时间片片长
	k_sched_time_slice_set(CONFIG_TIMESLICE_SIZE,
						   CONFIG_TIMESLICE_PRIORITY);
#endif
}

//获取线程优先级
int z_impl_k_thread_priority_get(k_tid_t thread)
{
	return thread->base.prio;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_thread_priority_get(k_tid_t thread)
{
	Z_OOPS(Z_SYSCALL_OBJ(thread, K_OBJ_THREAD));
	return z_impl_k_thread_priority_get(thread);
}
#include <syscalls/k_thread_priority_get_mrsh.c>
#endif

//设置一个线程优先级
void z_impl_k_thread_priority_set(k_tid_t tid, int prio)
{
	//使用NULL,因为我们不知道入口点是什么(我们没有跟踪它)
	//空闲也不能改变它的优先级
	Z_ASSERT_VALID_PRIO(prio, NULL);
	__ASSERT(!arch_is_in_isr(), "");
	//获取该线程
	struct k_thread *thread = (struct k_thread *)tid;
	//为该线程设置优先级
	z_thread_priority_set(thread, prio);
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_thread_priority_set(k_tid_t thread, int prio)
{
	Z_OOPS(Z_SYSCALL_OBJ(thread, K_OBJ_THREAD));
	Z_OOPS(Z_SYSCALL_VERIFY_MSG(_is_valid_prio(prio, NULL),
		   "invalid thread priority %d", prio));
	Z_OOPS(Z_SYSCALL_VERIFY_MSG((int8_t)prio >= thread->base.prio,
		   "thread priority may only be downgraded (%d < %d)",
		    prio, thread->base.prio));

	z_impl_k_thread_priority_set(thread, prio);
}
#include <syscalls/k_thread_priority_set_mrsh.c>
#endif

#ifdef CONFIG_SCHED_DEADLINE
//设置线程截止时间线
void z_impl_k_thread_deadline_set(k_tid_t tid, int deadline)
{
	struct k_thread *thread = tid;
	//上调度锁
	LOCKED(&sched_spinlock) {
		//更新线程的截止时间线,以当前时间线为基准
		thread->base.prio_deadline = k_cycle_get_32() + deadline;
		if (z_is_thread_queued(thread)) {
			//截止时间线被更新,需要更新其在优先级队列的顺序
			_priq_run_remove(&_kernel.ready_q.runq, thread);
			_priq_run_add(&_kernel.ready_q.runq, thread);
		}
	}
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_thread_deadline_set(k_tid_t tid, int deadline)
{
	struct k_thread *thread = tid;

	Z_OOPS(Z_SYSCALL_OBJ(thread, K_OBJ_THREAD));
	Z_OOPS(Z_SYSCALL_VERIFY_MSG(deadline > 0,
		   "invalid thread deadline %d", (int)deadline));

	z_impl_k_thread_deadline_set((k_tid_t)thread, deadline);
}
#include <syscalls/k_thread_deadline_set_mrsh.c>
#endif
#endif

//调度
void z_impl_k_yield(void)
{
	__ASSERT(!arch_is_in_isr(), "");
	//当前执行的线程如果不是空闲线程
	if (!z_is_idle_thread_object(_current)) {
		//上调度锁
		LOCKED(&sched_spinlock) {
			//启用多处理器机制时,确认该线程是否在队列中
			//如果当前线程在队列中则需要将其从运行队列移除
			if (!IS_ENABLED(CONFIG_SMP) ||
			    z_is_thread_queued(_current)) {
				_priq_run_remove(&_kernel.ready_q.runq,
						 _current);
			}
			//如果不在队列中将其添加入队列
			_priq_run_add(&_kernel.ready_q.runq, _current);
			z_mark_thread_as_queued(_current);//标记为入队列
			update_cache(1);//刷新缓冲区
		}
	}
	z_swap_unlocked();//启用调度
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_yield(void)
{
	z_impl_k_yield();
}
#include <syscalls/k_yield_mrsh.c>
#endif

//当前线程沉睡滴答数
static int32_t z_tick_sleep(k_ticks_t ticks)
{
#ifdef CONFIG_MULTITHREADING
	uint32_t expected_wakeup_ticks;
	__ASSERT(!arch_is_in_isr(), "");

#ifndef CONFIG_TIMEOUT_64BIT
	LOG_DBG("thread %p for %u ticks", _current, ticks);
#endif

	//等待0毫秒被视为“yield”
	if (ticks == 0) {
		k_yield();
		return 0;
	}
	
	//计算超时时间
	k_timeout_t timeout = Z_TIMEOUT_TICKS(ticks);
	//推演出下一次唤醒的滴答
	expected_wakeup_ticks = ticks + z_tick_get_32();
	//锁定调度机制
	k_spinlock_key_t key = k_spin_lock(&sched_spinlock);
#if defined(CONFIG_TIMESLICING) && defined(CONFIG_SWAP_NONATOMIC)
	//挂起当前线程
	pending_current = _current;
#endif
	unready_thread(_current);//取消当前线程的就绪
	z_add_thread_timeout(_current, timeout);//为当前线程添加超时时间
	z_mark_thread_as_suspended(_current);//标记当前线程已经挂起
	//启用调度
	(void)z_swap(&sched_spinlock, key);
	__ASSERT(!z_is_thread_state_set(_current, _THREAD_SUSPENDED), "");
	//计算唤醒时,当前线程是否沉睡足够的时间,将剩余需要沉睡的时间反馈
	ticks = (k_ticks_t)expected_wakeup_ticks - z_tick_get_32();
	if (ticks > 0) {
		return ticks;
	}
#endif
	return 0;
}

//当前线程沉睡
int32_t z_impl_k_sleep(k_timeout_t timeout)
{
	k_ticks_t ticks;

	__ASSERT(!arch_is_in_isr(), "");
	sys_trace_void(SYS_TRACE_ID_SLEEP);

	//如果指定的超时为永久,直接挂起它
	if (K_TIMEOUT_EQ(timeout, K_FOREVER)) {
		k_thread_suspend(_current);
		return (int32_t) K_TICKS_FOREVER;
	}
	//否则计算超时时间,沉睡它
	ticks = timeout.ticks;
	ticks = z_tick_sleep(ticks);
	sys_trace_end_call(SYS_TRACE_ID_SLEEP);
	//将剩余要沉睡的时间转化成毫秒
	return k_ticks_to_ms_floor64(ticks);
}

#ifdef CONFIG_USERSPACE
static inline int32_t z_vrfy_k_sleep(k_timeout_t timeout)
{
	return z_impl_k_sleep(timeout);
}
#include <syscalls/k_sleep_mrsh.c>
#endif

//微秒级沉睡
int32_t z_impl_k_usleep(int us)
{
	int32_t ticks;
	//将其转化为对应的滴答数,然后沉睡
	ticks = k_us_to_ticks_ceil64(us);
	ticks = z_tick_sleep(ticks);
	return k_ticks_to_us_floor64(ticks);
}

#ifdef CONFIG_USERSPACE
static inline int32_t z_vrfy_k_usleep(int us)
{
	return z_impl_k_usleep(us);
}
#include <syscalls/k_usleep_mrsh.c>
#endif

//唤醒指定的线程
void z_impl_k_wakeup(k_tid_t thread)
{
	//线程如果正在挂起,不唤醒
	if (z_is_thread_pending(thread)) {
		return;
	}

	//中止一个线程的超时等待
	if (z_abort_thread_timeout(thread) < 0) {
		//可能一直在睡觉
		if (thread->base.thread_state != _THREAD_SUSPENDED) {
			return;
		}
	}

	z_mark_thread_as_not_suspended(thread);//标记为非挂起态
	z_ready_thread(thread);//就绪该线程

#if defined(CONFIG_SMP) && defined(CONFIG_SCHED_IPI_SUPPORTED)
	arch_sched_ipi();
#endif
	
	//非中断环境下启用调度
	if (!arch_is_in_isr()) {
		z_reschedule_unlocked();
	}
}

#ifdef CONFIG_TRACE_SCHED_IPI
extern void z_trace_sched_ipi(void);
#endif

#ifdef CONFIG_SMP
void z_sched_ipi(void)
{
	//注意:在向此添加代码时
	//请确保在!CONFIG_SCHED_IPI_SUPPORTED时在适当的位置调用此函数
#ifdef CONFIG_TRACE_SCHED_IPI
	z_trace_sched_ipi();
#endif
}

//中止一个线程
void z_sched_abort(struct k_thread *thread)
{
	k_spinlock_key_t key;
	//如果该线程已经运行,将其从就绪队列中移除
	if (thread == _current) {
		z_remove_thread_from_ready_q(thread);
		return;
	}

	//首先广播一个IPI到其他cpu,以便他们可以停止本地
	//唉,并不是所有的架构都支持这一点
	//如果我们没有它,我们需要等待其他的中断
#ifdef CONFIG_SCHED_IPI_SUPPORTED
	arch_sched_ipi();
#endif

	//等待它被标记为死的CPU运行或因为我们捕获它在队列中空闲
	while ((thread->base.thread_state & _THREAD_DEAD) == 0U) {
		key = k_spin_lock(&sched_spinlock);
		//线程是被阻止运行
		if (z_is_thread_prevented_from_running(thread)) {
			//标记线程状态
			__ASSERT(!z_is_thread_queued(thread), "");
			thread->base.thread_state |= _THREAD_DEAD;
			k_spin_unlock(&sched_spinlock, key);
		//线程是在运行队列中
		} else if (z_is_thread_queued(thread)) {
			//移除出运行队列,标记为出队列,标记线程状态
			_priq_run_remove(&_kernel.ready_q.runq, thread);
			z_mark_thread_as_not_queued(thread);
			thread->base.thread_state |= _THREAD_DEAD;
			k_spin_unlock(&sched_spinlock, key);
		//忙等待100下
		} else {
			k_spin_unlock(&sched_spinlock, key);
			k_busy_wait(100);
		}
	}
}
#endif

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_wakeup(k_tid_t thread)
{
	Z_OOPS(Z_SYSCALL_OBJ(thread, K_OBJ_THREAD));
	z_impl_k_wakeup(thread);
}
#include <syscalls/k_wakeup_mrsh.c>
#endif

//获取内核当前运行线程
k_tid_t z_impl_k_current_get(void)
{
#ifdef CONFIG_SMP
	//在SMP中_current是一个从_current_cpu读取的字段
	//它可以在被读取之前与抢占竞争
	//我们必须在读取时锁定本地中断
	unsigned int k = arch_irq_lock();
#endif

	k_tid_t ret = _current_cpu->current;

#ifdef CONFIG_SMP
	arch_irq_unlock(k);
#endif
	return ret;
}

#ifdef CONFIG_USERSPACE
static inline k_tid_t z_vrfy_k_current_get(void)
{
	return z_impl_k_current_get();
}
#include <syscalls/k_current_get_mrsh.c>
#endif

//当前运行线程是抢占来的?
int z_impl_k_is_preempt_thread(void)
{
	return !arch_is_in_isr() && is_preempt(_current);
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_is_preempt_thread(void)
{
	return z_impl_k_is_preempt_thread();
}
#include <syscalls/k_is_preempt_thread_mrsh.c>
#endif

#ifdef CONFIG_SCHED_CPU_MASK
//现在我们使用一个字节作为掩码
# ifdef CONFIG_SMP
BUILD_ASSERT(CONFIG_MP_NUM_CPUS <= 8, "Too many CPUs for mask word");
# endif

//为线程标记可运行CPU掩码和不可运行CPU掩码
static int cpu_mask_mod(k_tid_t thread, uint32_t enable_mask, uint32_t disable_mask)
{
	int ret = 0;
	LOCKED(&sched_spinlock) {
		//如果线程被阻止运行
		if (z_is_thread_prevented_from_running(thread)) {
			//更新CPU掩码字段
			thread->base.cpu_mask |= enable_mask;
			thread->base.cpu_mask &= ~disable_mask;
		} else {
			ret = -EINVAL;
		}
	}
	return ret;
}

//线程失去任何CPU的使用权,也即清空CPU掩码
int k_thread_cpu_mask_clear(k_tid_t thread)
{
	return cpu_mask_mod(thread, 0, 0xffffffff);
}

//线程获取任何CPU的使用权,也即标满CPU掩码
int k_thread_cpu_mask_enable_all(k_tid_t thread)
{
	return cpu_mask_mod(thread, 0xffffffff, 0);
}

//仅使能线程所需对应CPU
int k_thread_cpu_mask_enable(k_tid_t thread, int cpu)
{
	return cpu_mask_mod(thread, BIT(cpu), 0);
}

//仅去能线程无需对应CPU
int k_thread_cpu_mask_disable(k_tid_t thread, int cpu)
{
	return cpu_mask_mod(thread, 0, BIT(cpu));
}
#endif

//当前线程以指定超时时间休眠等待指定线程退出
int z_impl_k_thread_join(struct k_thread *thread, k_timeout_t timeout)
{
	k_spinlock_key_t key;
	int ret;
	__ASSERT(((arch_is_in_isr() == false) || K_TIMEOUT_EQ(timeout, K_NO_WAIT)), "");
	key = k_spin_lock(&sched_spinlock);
	//如果线程已经阻塞等待或者是当前线程,无需执行
	if ((thread->base.pended_on == &_current->base.join_waiters) ||
	    (thread == _current)) {
		ret = -EDEADLK;
		goto out;
	}

	//线程状态不可为死亡态
	if ((thread->base.thread_state & _THREAD_DEAD) != 0) {
		ret = 0;
		goto out;
	}

	//线程不超时阻塞,直接退出
	if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		ret = -EBUSY;
		goto out;
	}

#if defined(CONFIG_TIMESLICING) && defined(CONFIG_SWAP_NONATOMIC)
	//标记当前线程为挂起
	pending_current = _current;
#endif
	//当前线程加入到指定线程的等待者队列
	add_to_waitq_locked(_current, &thread->base.join_waiters);
	//当前线程加入超时等待
	add_thread_timeout(_current, timeout);
	//启动调度
	return z_swap(&sched_spinlock, key);
out:
	k_spin_unlock(&sched_spinlock, key);
	return ret;
}

#ifdef CONFIG_USERSPACE
//特殊情况:如果线程未初始化,不要出错
//这是因为初始化位对线程对象有双重作用;
//如果为false,则表示线程对象真正未初始化,或者线程因某种原因运行并退出
//在这种情况下返回true,表示我们应该什么都不做,并向调用者返回成功

//检查指定线程的对象
static bool thread_obj_validate(struct k_thread *thread)
{
	struct z_object *ko = z_object_find(thread);
	int ret = z_object_validate(ko, K_OBJ_THREAD, _OBJ_INIT_TRUE);

	switch (ret) {
	case 0:
		return false;
	case -EINVAL:
		return true;
	default:
#ifdef CONFIG_LOG
		z_dump_object_error(ret, thread, ko, K_OBJ_THREAD);
#endif
		Z_OOPS(Z_SYSCALL_VERIFY_MSG(ret, "access denied"));
	}
	CODE_UNREACHABLE;
}

static inline int z_vrfy_k_thread_join(struct k_thread *thread,
									   k_timeout_t timeout)
{
	if (thread_obj_validate(thread)) {
		return 0;
	}

	return z_impl_k_thread_join(thread, timeout);
}
#include <syscalls/k_thread_join_mrsh.c>

static inline void z_vrfy_k_thread_abort(k_tid_t thread)
{
	if (thread_obj_validate(thread)) {
		return;
	}

	Z_OOPS(Z_SYSCALL_VERIFY_MSG(!(thread->base.user_options & K_ESSENTIAL),
				    "aborting essential thread %p", thread));

	z_impl_k_thread_abort((struct k_thread *)thread);
}
#include <syscalls/k_thread_abort_mrsh.c>
#endif
