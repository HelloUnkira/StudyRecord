/*
 * zephyr内核
 */

#include <kernel.h>
#include <kernel_structs.h>
#include <debug/object_tracing_common.h>
#include <toolchain.h>
#include <linker/sections.h>
#include <wait_q.h>
#include <sys/dlist.h>
#include <ksched.h>
#include <init.h>
#include <sys/check.h>

//静态全局自旋锁
static struct k_spinlock lock;

//trace所用,如果使用追踪
#ifdef CONFIG_OBJECT_TRACING
struct k_mem_slab *_trace_list_k_mem_slab;
#endif

//初始化内核内存SLAB分配器内部
//执行任何在构建时未完成的内存SLAB分配器初始化
//目前这只涉及创建每个SLAB的空闲块的列表
static int create_free_list(struct k_mem_slab *slab)
{
	uint32_t j;
	char *p;

	//块必须字对齐
	CHECKIF(((slab->block_size | (uintptr_t)slab->buffer) &
			 (sizeof(void *) - 1)) != 0) {
		return -EINVAL;
	}

	slab->free_list = NULL;//初始化SLAB分配器的空闲链表
	p = slab->buffer;//拿取SLAB分配器缓冲区的地址

	for (j = 0U; j < slab->num_blocks; j++) {
		//buffer被切割成num_blocks个块,每个块的大小为block_size
		//其中每一个块的首个指针大小区域被设置成前一个块的首地址
		//block(0)[NULL]……block(1)[*block(0)]……block(2)[*block(1)]……
		*(char **)p = slab->free_list;
		slab->free_list = p;
		p += slab->block_size;
	}
	return 0;
}

//静态定义内存SLAB分配器的完整初始化
//执行任何在构建时未完成的初始化
static int init_mem_slab_module(const struct device *dev)
{
	int rc = 0;
	ARG_UNUSED(dev);
	
	Z_STRUCT_SECTION_FOREACH(k_mem_slab, slab) {
		//迭代器迭代的静态对象为:
		//_k_mem_slab_list_start[];
		//_k_mem_slab_list_end[];
		rc = create_free_list(slab);//初始化每一个对象
		if (rc < 0) {
			goto out;
		}
		//静态追踪对象初始化,如果需要
		SYS_TRACING_OBJ_INIT(k_mem_slab, slab);
		z_object_init(slab);//初始化其所有者对象
	}
out:
	return rc;
}

SYS_INIT(init_mem_slab_module, PRE_KERNEL_1,
		 CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);

//初始化SLAB分配器,使用外部的缓冲区
int k_mem_slab_init(struct k_mem_slab *slab, void *buffer,
					size_t block_size, uint32_t num_blocks)
{
	int rc = 0;

	slab->num_blocks = num_blocks;//块数量
	slab->block_size = block_size;//块大小
	slab->buffer = buffer;//缓冲区地址
	slab->num_used = 0U;//当前使用数
#ifdef CONFIG_MEM_SLAB_TRACE_MAX_UTILIZATION
	slab->max_used = 0U;//最大使用数
#endif
	//初始化它,分配好块链表
	rc = create_free_list(slab);
	if (rc < 0) {
		goto out;
	}
	//初始化等待队列
	z_waitq_init(&slab->wait_q);
	//初始化追踪对象,如果需要
	SYS_TRACING_OBJ_INIT(k_mem_slab, slab);
	z_object_init(slab);//初始化其所有者对象

out:
	return rc;
}

//从SLAB分配器中分配块
int k_mem_slab_alloc(struct k_mem_slab *slab, void **mem, k_timeout_t timeout)
{
	k_spinlock_key_t key = k_spin_lock(&lock);
	int result;

	if (slab->free_list != NULL) {//如果free_list非空
		*mem = slab->free_list;//直接拿到该链表的首块
		//free_list指向链表的下一块
		slab->free_list = *(char **)(slab->free_list);
		slab->num_used++;//使用块数++
#ifdef CONFIG_MEM_SLAB_TRACE_MAX_UTILIZATION //计算最大使用
		slab->max_used = MAX(slab->num_used, slab->max_used);
#endif
		result = 0;
	} else if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		*mem = NULL;//不要等待空闲块变得可用
		result = -ENOMEM;
	} else {
		//以timeout为超时时间将当前线程挂起到SLAB分配器的等待队列
		result = z_pend_curr(&lock, key, &slab->wait_q, timeout);
		if (result == 0) {
			//如果产生空闲块,则拿到它
			*mem = _current->base.swap_data;
		}
		return result;
	}

	k_spin_unlock(&lock, key);
	return result;
}

//释放块到SLAB分配器中
void k_mem_slab_free(struct k_mem_slab *slab, void **mem)
{
	k_spinlock_key_t key = k_spin_lock(&lock);
	
	//如果空闲链表为空,优先为其等待资源的线程交递
	if (slab->free_list == NULL) {
		//从等待队列获取一个需要块的最高优先级线程
		struct k_thread *pending_thread = z_unpend_first_thread(&slab->wait_q);
		//如果该线程存在
		if (pending_thread != NULL) {
			//设置	k_thread.callee_saved.retval = 0
			//		k_thread.base.swap_data = mem;
			z_thread_return_value_set_with_data(pending_thread, 0, *mem);
			z_ready_thread(pending_thread);
			z_reschedule(&lock, key);
			return;
		}
	}
	//更新关系链,下一个块的首地址开始的指针大小的区域
	//保存前一个块的首地址,这种逆向的实现最终可以实现跳变
	**(char ***) mem = slab->free_list;
	slab->free_list = *(char **) mem;
	slab->num_used--;//扣除使用数
	k_spin_unlock(&lock, key);
}
