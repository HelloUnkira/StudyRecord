/*
 * zephyr内核
 */

#include <kernel.h>
#include <kernel_structs.h>
#include <spinlock.h>
#include <kswap.h>
#include <kernel_internal.h>

//多处理器架构机制
#ifdef CONFIG_SMP
//静态全局原子锁:全局锁和启动标志
static atomic_t global_lock;
static atomic_t start_flag;

//为SMP上全局锁
unsigned int z_smp_global_lock(void)
{
	unsigned int key = arch_irq_lock();//关中断
	//为当前线程计数全局锁
	if (!_current->base.global_lock_count) {
		//锁定全部线程的一个全局锁
		while (!atomic_cas(&global_lock, 0, 1)) {
		}//锁有效计数仅在计数为0下才+1,其他情况死等到底
	}
	//当前线程锁计数(允许当前线程嵌套上锁
	//但全局锁只有一个所有者)
	_current->base.global_lock_count++;
	return key;
}

void z_smp_global_unlock(unsigned int key)
{
	//为当前线程计数全局锁
	if (_current->base.global_lock_count) {
		//当前线程锁计数(允许当前线程嵌套上锁
		//但全局锁只有一个所有者)
		_current->base.global_lock_count--;

		//它的前提是本身有锁
		//这防止别有用心的线程偷偷释放全局锁
		if (!_current->base.global_lock_count) {
			atomic_clear(&global_lock);
		}//仅只有在当前线程自身不上锁的情况下释放全局线程锁
	}
	arch_irq_unlock(key);//开启中断
}

//线程再次请求全局锁
void z_smp_reacquire_global_lock(struct k_thread *thread)
{
	if (thread->base.global_lock_count) {
		arch_irq_lock();
		while (!atomic_cas(&global_lock, 0, 1)) {
		}//锁有效计数仅在计数为0下才+1,其他情况死等到底
	}
}

//在z_swap()中调用,因此假定已经持有锁
//线程请求释放全局锁
void z_smp_release_global_lock(struct k_thread *thread)
{
	//很显然现在该线程是不具备锁的,那么调用者应该持有锁
	//在锁的所有者已知的情况下释放锁
	if (!thread->base.global_lock_count) {
		atomic_clear(&global_lock);
	}
}

#if CONFIG_MP_NUM_CPUS > 1
static FUNC_NORETURN void smp_init_top(void *arg)
{
	atomic_t *cpu_start_flag = arg;
	struct k_thread dummy_thread;

	while (!atomic_get(cpu_start_flag)) {
	}//等待开始调度信号

	//初始化本地的虚拟线程
	z_dummy_thread_init(&dummy_thread);
	smp_timer_init();//对称多处理器定时器初始化
	z_swap_unlocked();//启动调度器

	CODE_UNREACHABLE;
}
#endif

void z_smp_init(void)
{
	//清除开始调度标记
	(void)atomic_clear(&start_flag);

#if defined(CONFIG_SMP) && (CONFIG_MP_NUM_CPUS > 1)
	for (int i = 1; i < CONFIG_MP_NUM_CPUS; i++) {
		//为每一个CPU都挂载当前线程,所有CPU统一执行
		//smp_init_top线程,并且都会阻塞到等待开始调度信号
		//它们都在本地等待锁定(开始调度)
		arch_start_cpu(i, z_interrupt_stacks[i], CONFIG_ISR_STACK_SIZE,
					   smp_init_top, &start_flag);
	}
#endif

	//现在CPU都已经同步了,启用开始调度标记
	(void)atomic_set(&start_flag, 1);
}

//查看CPU状态信息(是否非中断模式,中断未上锁)
bool z_smp_cpu_mobile(void)
{
	unsigned int k = arch_irq_lock();
	bool pinned = arch_is_in_isr() || !arch_irq_unlocked(k);

	arch_irq_unlock(k);
	return !pinned;
}

#endif
