/*
 * zephyr内核
 */

#include <kernel.h>
#include <kernel_structs.h>
#include <spinlock.h>
#include <kswap.h>
#include <syscall_handler.h>
#include <init.h>
#include <ksched.h>

//取出FUTEX锁保护的数据
static struct z_futex_data *k_futex_find_data(struct k_futex *futex)
{
	struct z_object *obj;

	obj = z_object_find(futex);//找到该锁的所有者
	if (obj == NULL || obj->type != K_OBJ_FUTEX) {
		return NULL;
	}
	
	//取出FUTEX锁保护的数据
	return obj->data.futex_data;
}

//唤醒一个/所有线程挂起futex
int z_impl_k_futex_wake(struct k_futex *futex, bool wake_all)
{
	k_spinlock_key_t key;
	unsigned int woken = 0;
	struct k_thread *thread;
	struct z_futex_data *futex_data;
	
	//先获取锁保护的数据
	futex_data = k_futex_find_data(futex);
	if (futex_data == NULL) {
		return -EINVAL;//数据为空,意外
	}

	//为FUTEX锁数据上自旋锁
	key = k_spin_lock(&futex_data->lock);

	do {//先解锁阻塞在FUTEX锁中等待队列里最高优先级线程
		thread = z_unpend_first_thread(&futex_data->wait_q);
		if (thread) {
			z_ready_thread(thread);//就绪它
			//清除k_thread.callee_saved.retval = 0
			arch_thread_return_value_set(thread, 0);
			woken++;//成功解锁一个线程
		}
	//如果wake_all为1,继续解锁剩下的线程,直到thread为空
	} while (thread && wake_all);
	
	//启用内核重调度,阻塞线程中第一个被解除阻塞的线程它的优先级
	//有很大几率比当前线程高,所以在此处执行内核抢占是有必要的
	z_reschedule(&futex_data->lock, key);

	return woken;
}

static inline int z_vrfy_k_futex_wake(struct k_futex *futex, bool wake_all)
{
	if (Z_SYSCALL_MEMORY_WRITE(futex, sizeof(struct k_futex)) != 0) {
		return -EACCES;
	}
	return z_impl_k_futex_wake(futex, wake_all);
}
#include <syscalls/k_futex_wake_mrsh.c>

//在futex上挂起当前线程
int z_impl_k_futex_wait(struct k_futex *futex, int expected,
						k_timeout_t timeout)
{
	int ret;
	k_spinlock_key_t key;
	struct z_futex_data *futex_data;

	//先获取锁保护的数据
	futex_data = k_futex_find_data(futex);
	if (futex_data == NULL) {
		return -EINVAL;//数据为空,意外
	}

	//为FUTEX锁数据上自旋锁
	key = k_spin_lock(&futex_data->lock);

	//FUTEX锁的内部值与预期不一致
	if (atomic_get(&futex->val) != (atomic_val_t)expected) {
		k_spin_unlock(&futex_data->lock, key);//解锁
		return -EAGAIN;//返回
	}

	//以超时时间timeout将当前线程挂起到FUTEX锁的数据区内的等待队列中
	ret = z_pend_curr(&futex_data->lock,key, &futex_data->wait_q, timeout);
	if (ret == -EAGAIN) {
		ret = -ETIMEDOUT;
	}

	return ret;
}

static inline int z_vrfy_k_futex_wait(struct k_futex *futex, int expected,
				      k_timeout_t timeout)
{
	if (Z_SYSCALL_MEMORY_WRITE(futex, sizeof(struct k_futex)) != 0) {
		return -EACCES;
	}
	return z_impl_k_futex_wait(futex, expected, timeout);
}
#include <syscalls/k_futex_wait_mrsh.c>
