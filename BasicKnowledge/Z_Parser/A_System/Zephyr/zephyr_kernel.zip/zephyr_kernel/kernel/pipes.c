/*
 * zephyr内核
 */

//管道

#include <kernel.h>
#include <kernel_structs.h>
#include <debug/object_tracing_common.h>
#include <toolchain.h>
#include <ksched.h>
#include <wait_q.h>
#include <init.h>
#include <syscall_handler.h>
#include <kernel_internal.h>
#include <sys/check.h>

//管道源
struct k_pipe_desc {
	unsigned char *buffer;//传输源/获取者 在缓冲区中的位置
	size_t bytes_to_xfer;//待传输的字节数
#if (CONFIG_NUM_PIPE_ASYNC_MSGS > 0)
	struct k_mem_block *block;//指向内存块的指针
	struct k_mem_block copy_block;//忽视向以前版本兼容
	struct k_sem *sem;//如果是异步传输所使用的信号量
#endif
};

//管道异步传输
struct k_pipe_async {
	struct _thread_base thread;//虚拟线程对象
	struct k_pipe_desc desc;//管消息描述符
};

#ifdef CONFIG_OBJECT_TRACING
//trace所用
struct k_pipe *_trace_list_k_pipe;
#endif

#if (CONFIG_NUM_PIPE_ASYNC_MSGS > 0)
//未使用的异步消息描述符堆栈
K_STACK_DEFINE(pipe_async_msgs, CONFIG_NUM_PIPE_ASYNC_MSGS);

//动态分配一个异步消息描述符
static void pipe_async_alloc(struct k_pipe_async **async)
{
	(void)k_stack_pop(&pipe_async_msgs, (stack_data_t *)async, K_FOREVER);
}

//释放一个异步消息描述符
static void pipe_async_free(struct k_pipe_async *async)
{
	k_stack_push(&pipe_async_msgs, (stack_data_t)async);
}

//完成异步操作
static void pipe_async_finish(struct k_pipe_async *async_desc)
{
	//异步操作在锁定调度器后完成,以防止被调用者调度新线程
	if (async_desc->desc.sem != NULL) {//发送异步传输信号量
		k_sem_give(async_desc->desc.sem);
	}
	pipe_async_free(async_desc);//释放异步传输源
}
#endif

#if (CONFIG_NUM_PIPE_ASYNC_MSGS > 0) || defined(CONFIG_OBJECT_TRACING)
//执行管道对象子系统的运行时初始化
static int init_pipes_module(const struct device *dev)
{
	ARG_UNUSED(dev);
	//异步消息描述符的数组
	static struct k_pipe_async __noinit async_msg[CONFIG_NUM_PIPE_ASYNC_MSGS];
#if (CONFIG_NUM_PIPE_ASYNC_MSGS > 0)
	//创建异步管道消息描述符池
	//虚拟线程需要最小的初始化,因为它永远不会执行
	//_THREAD_DUMMY标志足以区分虚拟线程和真实线程
	//线程不会被添加到内核的已知线程列表中
	//一旦初始化,每个描述符的地址被添加到一个控制访问它们的堆栈

	//先将该占用的全部区域释放到栈中,以便将来使用时获取
	for (int i = 0; i < CONFIG_NUM_PIPE_ASYNC_MSGS; i++) {
		async_msg[i].thread.thread_state = _THREAD_DUMMY;//初始化为虚拟线程
		async_msg[i].thread.swap_data = &async_msg[i].desc;//绑定源
		z_init_thread_timeout(&async_msg[i].thread);//初始化虚拟线程
		//将该部分区域释放到栈缓冲区
		k_stack_push(&pipe_async_msgs, (stack_data_t)&async_msg[i]);
	}
#endif
	//完成静态定义管道的初始化
#ifdef CONFIG_OBJECT_TRACING
	Z_STRUCT_SECTION_FOREACH(k_pipe, pipe) {
		SYS_TRACING_OBJ_INIT(k_pipe, pipe);
	}
#endif
	return 0;
}

SYS_INIT(init_pipes_module, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);
#endif 

//初始化一个管道
void k_pipe_init(struct k_pipe *pipe, unsigned char *buffer, size_t size)
{
	pipe->buffer = buffer;//绑定管道的缓冲区
	pipe->size = size;//缓冲区大小设置
	pipe->bytes_used = 0;//使用空间
	pipe->read_index = 0;//管道读索引
	pipe->write_index = 0;//管道写索引
	pipe->lock = (struct k_spinlock){};//自旋锁初始化
	z_waitq_init(&pipe->wait_q.writers);//初始化写等待队列
	z_waitq_init(&pipe->wait_q.readers);//初始化读等待队列
	SYS_TRACING_OBJ_INIT(k_pipe, pipe);
	pipe->flags = 0;//清空标志
	z_object_init(pipe);//初始化所有者对象
}

//动态创建一个管道并初始化
int z_impl_k_pipe_alloc_init(struct k_pipe *pipe, size_t size)
{
	void *buffer;
	int ret;
	if (size != 0) {//管道有实际传输空间
		buffer = z_thread_malloc(size);//分配一个管道缓冲区
		if (buffer != NULL) {
			k_pipe_init(pipe, buffer, size);//初始化管道
			pipe->flags = K_PIPE_FLAG_ALLOC;//标记为动态分配
			ret = 0;
		} else {
			ret = -ENOMEM;
		}
	} else {
		k_pipe_init(pipe, NULL, 0);//否则初始化一个空管道
		ret = 0;
	}
	return ret;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_pipe_alloc_init(struct k_pipe *pipe, size_t size)
{
	Z_OOPS(Z_SYSCALL_OBJ_NEVER_INIT(pipe, K_OBJ_PIPE));
	return z_impl_k_pipe_alloc_init(pipe, size);
}
#include <syscalls/k_pipe_alloc_init_mrsh.c>
#endif

//清除一个管道
int k_pipe_cleanup(struct k_pipe *pipe)
{
	//如果管道还有等待读或等待写的对象,不可清除管道
	CHECKIF(z_waitq_head(&pipe->wait_q.readers) != NULL ||
			z_waitq_head(&pipe->wait_q.writers) != NULL) {
		return -EAGAIN;
	}

	//如果管道是动态分配
	if ((pipe->flags & K_PIPE_FLAG_ALLOC) != 0) {
		k_free(pipe->buffer);//释放它的缓冲区
		pipe->buffer = NULL;//初始化
		pipe->flags &= ~K_PIPE_FLAG_ALLOC;//清除标记
	}
	return 0;
}

//将字节从src复制到dest
static size_t pipe_xfer(unsigned char *dest, size_t dest_size,
						const unsigned char *src, size_t src_size)
{
	size_t num_bytes = MIN(dest_size, src_size);
	const unsigned char *end = src + num_bytes;
	while (src != end) {
		*dest = *src;
		dest++;
		src++;
	}
	return num_bytes;
}

//数据送入管道中
static size_t pipe_buffer_put(struct k_pipe *pipe,
							  const unsigned char *src, size_t src_size)
{
	size_t bytes_copied;
	size_t run_length;
	size_t num_bytes_written = 0;
	int i;

	//俩次循环是可能存在一次写入,写到末尾还没有写完
	//第二次循环时为了将剩余部分写到开头
	//很显然写动作没有容错检查
	for (i = 0; i < 2; i++) {
		run_length = MIN(pipe->size - pipe->bytes_used,
						 pipe->size - pipe->write_index);
		//数据写入管道缓冲区,从写索引开始
		bytes_copied = pipe_xfer(pipe->buffer + pipe->write_index,
								 run_length,
								 src + num_bytes_written,
								 src_size - num_bytes_written);

		num_bytes_written += bytes_copied;//写入的字节数
		pipe->bytes_used += bytes_copied;//管道被使用的空间
		pipe->write_index += bytes_copied;//更新管道下一次写入的位置
		if (pipe->write_index == pipe->size) {//循环管道
			pipe->write_index = 0;
		}
	}
	return num_bytes_written;
}

//数据从管道中拿出
static size_t pipe_buffer_get(struct k_pipe *pipe,
							  unsigned char *dest, size_t dest_size)
{
	size_t bytes_copied;
	size_t run_length;
	size_t num_bytes_read = 0;
	int i;
	
	//和写入是一致的情况
	for (i = 0; i < 2; i++) {
		run_length = MIN(pipe->bytes_used,
						 pipe->size - pipe->read_index);
		//数据从管道中拿出
		bytes_copied = pipe_xfer(dest + num_bytes_read,
								 dest_size - num_bytes_read,
								 pipe->buffer + pipe->read_index,
								 run_length);

		num_bytes_read += bytes_copied;//读取出的数据
		pipe->bytes_used -= bytes_copied;//管道中被使用掉的数据
		pipe->read_index += bytes_copied;//管道下一次读位置
		if (pipe->read_index == pipe->size) {//循环管道
			pipe->read_index = 0;
		}
	}
	return num_bytes_read;
}

//准备一组读者/作者的工作集合
//准备一个“工作线程”列表,数据将直接复制到/从中
//这个列表很有用,因为它用于……
//1.避免双重复制
//2.最小化中断延迟,因为在复制数据时解除中断
//3.确保超时不会使请求无法满足
//列表中填充了以前挂起的线程,这些线程将在管道调用完成后准备运行
//从管道中读取时需要记住的重要事项……
//1.如果有写入器int wait_q,则管道的缓冲区已满
//2.相反,如果管道的缓冲区没有满,就没有写入器
//3.管道中的可用数据量是管道中使用的字节数(pipe_space)和
//来自等待写入者的所有请求的总和
//4.由于数据首先从管道的缓冲区中读取,所以工作集必须包括写入器
//这些写入器将在之后(尝试)重新填充管道的缓冲区
//向管道写入时需要记住的重要事项…
//1.如果@a wait_q中有读取器,那么管道的缓冲区是空的
//2.相反,如果管道的缓冲区不是空的,则没有读取器
//3.管道中可用的空间量是管道中未使用的
//字节数(pipe_space)和来自等待中的读卡器的所有请求的总和
static bool pipe_xfer_prepare(sys_dlist_t *xfer_list,
							  struct k_thread **waiter,
							  _wait_q_t *wait_q,
							  size_t pipe_space,
							  size_t bytes_to_xfer,
							  size_t min_xfer,
							  k_timeout_t timeout)
{
	struct k_thread  *thread;
	struct k_pipe_desc *desc;
	size_t num_bytes = 0;

	if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {//如果不超时等待
		_WAIT_Q_FOR_EACH(wait_q, thread) {//遍历等待队列
			//将等待队列中的传输源拿取出来
			desc = (struct k_pipe_desc *)thread->base.swap_data;
			//传输数据记录
			num_bytes += desc->bytes_to_xfer;
			//传输数据累计满足当次所需,跳出循环
			if (num_bytes >= bytes_to_xfer) {
				break;
			}
		}

		//当前需要传输数据累加到管道空间小于最小传输限制,意外
		if (num_bytes + pipe_space < min_xfer) {
			return false;
		}
	}
	
	//要么timeout不是K_NO_WAIT(因此线程可能会挂起)
	//要么整个请求都能得到满足,生成工作列表
	sys_dlist_init(xfer_list);//初始化传输链表
	num_bytes = 0;

	while ((thread = z_waitq_head(wait_q)) != NULL) {
		desc = (struct k_pipe_desc *)thread->base.swap_data;
		num_bytes += desc->bytes_to_xfer;

		if (num_bytes > bytes_to_xfer) {
			//这个要求不能完全满足
			//不要从wait_q中删除它
			//不要中止超时(如果适用)
			//不要将其添加到传输链表中
			break;
		}
			//这个要求可以完全满足
			//从wait_q中删除它
			//中止超时
			//把它添加到传输链表中

		z_unpend_thread(thread);//将线程解除挂起但不加入就绪队列
		//将目标线程按优先级顺序(它本来就是优先级排序)加入到传输队列中
		sys_dlist_append(xfer_list, &thread->base.qnode_dlist);
	}

	//最后一个传输者不能被满足传输
	*waiter = (num_bytes > bytes_to_xfer) ? thread : NULL;
	return true;
}

//确定正确的返回代码
//字节Xferred---  No Wait---  Wait
//>=Minimum  ---  0      ---  0
//<Minimum   ---  -EIO   ---  -EAGAIN
//在_pipe_xfer_prepare()中创建“工作集”时,已经检查了“-EIO No Wait”情况
static int pipe_return_code(size_t min_xfer, size_t bytes_remaining,
							size_t bytes_requested)
{
	if (bytes_requested - bytes_remaining >= min_xfer) {
		//至少已满足传输请求的字节的最小数目
		return 0;
	}
	return -EAGAIN;
}

//准备好管道线程
//如果管道线程是一个真正的线程,那么将它添加到就绪队列
//如果它是一个虚拟线程,那么完成异步工作
static void pipe_thread_ready(struct k_thread *thread)
{
#if (CONFIG_NUM_PIPE_ASYNC_MSGS > 0)
	if ((thread->base.thread_state & _THREAD_DUMMY) != 0U) {
		pipe_async_finish((struct k_pipe_async *)thread);
		return;
	}
#endif
	//将该线程加入到就绪队列
	z_ready_thread(thread);
}

//用于向管道发送数据的内部API
int z_pipe_put_internal(struct k_pipe *pipe, struct k_pipe_async *async_desc,
						unsigned char *data, size_t bytes_to_write,
						size_t *bytes_written, size_t min_xfer,
						k_timeout_t timeout)
{
	struct k_thread *reader;
	struct k_pipe_desc *desc;
	sys_dlist_t xfer_list;
	size_t num_bytes_written = 0;
	size_t bytes_copied;

#if (CONFIG_NUM_PIPE_ASYNC_MSGS == 0)
	ARG_UNUSED(async_desc);
#endif

	//参数错误检查,最小传输字节不得小于待传输字节,被写入的位置存在
	CHECKIF((min_xfer > bytes_to_write) || bytes_written == NULL) {
		return -EINVAL;
	}
	k_spinlock_key_t key = k_spin_lock(&pipe->lock);

	//创建一个“工作读取器”列表,数据将直接复制到其中
	if (!pipe_xfer_prepare(&xfer_list, &reader, &pipe->wait_q.readers,
						   pipe->size - pipe->bytes_used, bytes_to_write,
						   min_xfer, timeout)) {
		k_spin_unlock(&pipe->lock, key);
		*bytes_written = 0;
		return -EIO;
	}

	z_sched_lock();//关闭调度器
	k_spin_unlock(&pipe->lock, key);

	//1.'xfer_list'当前包含一个读取线程列表,这些线程的读请求可以由当前调用完成
	//2.'reader'如果不是NULL
	//则指向reader wait_q上的一个线程,该线程可以获得其请求的一些数据
	//3.中断被解锁,但调度器被锁定,以允许传递节拍,但不发生调度
	//4.如果在复制数据时reader超时,不仅我们仍然有一个指向它的指针
	//而且它不能执行,直到这个调用完成,所以将数据复制到它仍然是安全的

	//从传输链表取出第一个线程
	struct k_thread *thread = (struct k_thread *)sys_dlist_get(&xfer_list);
	while (thread != NULL) {
		desc = (struct k_pipe_desc *)thread->base.swap_data;
		//为该线程拷贝数据,从管道中
		bytes_copied = pipe_xfer(desc->buffer, desc->bytes_to_xfer,
								 data + num_bytes_written,
								 bytes_to_write - num_bytes_written);

		num_bytes_written   += bytes_copied;//写入字节数记录
		desc->buffer        += bytes_copied;//定位下一次传输位置
		desc->bytes_to_xfer -= bytes_copied;//待传输的字节数更新

		//线程的读请求已经被满足,就绪它
		z_ready_thread(thread);
		//进行下一个线程的传输
		thread = (struct k_thread *)sys_dlist_get(&xfer_list);
	}

	//将留在wait_q上的所有数据复制到该读者,有可能不会复制任何数据
	if (reader != NULL) {
		desc = (struct k_pipe_desc *)reader->base.swap_data;
		//将剩余的数据传给最后的读者,但读者并不能满足传输需求,因为数据还不够
		bytes_copied = pipe_xfer(desc->buffer, desc->bytes_to_xfer,
								 data + num_bytes_written,
								 bytes_to_write - num_bytes_written);

		num_bytes_written   += bytes_copied;//写入字节数记录
		desc->buffer        += bytes_copied;//定位下一次传输位置
		desc->bytes_to_xfer -= bytes_copied;//待传输的字节数更新
	}

	//尽可能多的数据已经被直接复制到任何等待读取的线程
	//尽可能多地将剩余的数据添加到管道的循环缓冲区中
	num_bytes_written += pipe_buffer_put(pipe, data + num_bytes_written,
										 bytes_to_write - num_bytes_written);

	//数据传输完成,一部分直接分发给等待读取的线程,剩下的数据加入到管道内
	if (num_bytes_written == bytes_to_write) {
		*bytes_written = num_bytes_written;
#if (CONFIG_NUM_PIPE_ASYNC_MSGS > 0)
		if (async_desc != NULL) {//异步传输完成
			pipe_async_finish(async_desc);
		}
#endif
		k_sched_unlock();//解锁
		return 0;
	}

	//数据传输未完成,但不超时阻塞,则速度返回
	if (!K_TIMEOUT_EQ(timeout, K_NO_WAIT) && num_bytes_written >= min_xfer
	    && min_xfer > 0) {
		*bytes_written = num_bytes_written;
#if (CONFIG_NUM_PIPE_ASYNC_MSGS > 0)
		if (async_desc != NULL) {
			pipe_async_finish(async_desc);
		}
#endif
		k_sched_unlock();
		return 0;
	}

	//还有一部分数据没有传输完成,但可以超时阻塞
#if (CONFIG_NUM_PIPE_ASYNC_MSGS > 0)
	if (async_desc != NULL) {
		//在操作写入器wait_q之前,锁定中断并解锁调度器
		k_spinlock_key_t key2 = k_spin_lock(&pipe->lock);
		z_sched_unlock_no_reschedule();//调度器解锁,无锁释放
		//记录异步传输源剩下的数据
		async_desc->desc.buffer = data + num_bytes_written;
		async_desc->desc.bytes_to_xfer = bytes_to_write - num_bytes_written;
		//非超时挂起当前线程到管道的写等待队列中,直到被唤醒
		z_pend_thread((struct k_thread *) &async_desc->thread,
			     &pipe->wait_q.writers, K_FOREVER);
		z_reschedule(&pipe->lock, key2);
		return 0;
	}
#endif

	//同步传输时
	struct k_pipe_desc  pipe_desc;
	//记录同步传输源剩下的数据
	pipe_desc.buffer         = data + num_bytes_written;
	pipe_desc.bytes_to_xfer  = bytes_to_write - num_bytes_written;
	
	if (!K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		_current->base.swap_data = &pipe_desc;
		//在操作写入器wait_q之前,锁定中断并解锁调度器
		k_spinlock_key_t key2 = k_spin_lock(&pipe->lock);
		z_sched_unlock_no_reschedule();//调度器解锁,无锁释放
		//以超时时间timeout挂起当前线程到管道的写等待队列中,直到被唤醒
		(void)z_pend_curr(&pipe->lock, key2,
				 &pipe->wait_q.writers, timeout);
	} else {//如果非超时等待,直接返回
		k_sched_unlock();
	}
	//记录写入数据长度
	*bytes_written = bytes_to_write - pipe_desc.bytes_to_xfer;
	//反馈传输数据结果
	return pipe_return_code(min_xfer, pipe_desc.bytes_to_xfer, bytes_to_write);
}

//从管道获取数据
int z_impl_k_pipe_get(struct k_pipe *pipe, void *data, size_t bytes_to_read,
					  size_t *bytes_read, size_t min_xfer, k_timeout_t timeout)
{
	struct k_thread *writer;
	struct k_pipe_desc *desc;
	sys_dlist_t	xfer_list;
	size_t num_bytes_read = 0;
	size_t bytes_copied;

	//要读取的数据不可小于最少传输数且读取字节空间不可为空
	CHECKIF((min_xfer > bytes_to_read) || bytes_read == NULL) {
		return -EINVAL;
	}
	k_spinlock_key_t key = k_spin_lock(&pipe->lock);

	//创建一个“工作读取器”列表,数据将直接复制到其中
	if (!pipe_xfer_prepare(&xfer_list, &writer, &pipe->wait_q.writers,
						   pipe->bytes_used, bytes_to_read,
						   min_xfer, timeout)) {
		k_spin_unlock(&pipe->lock, key);
		*bytes_read = 0;//错误反馈,读取字节数为0
		return -EIO;
	}

	z_sched_lock();//关闭调度器
	k_spin_unlock(&pipe->lock, key);

	//从管道获取指定长度数据
	num_bytes_read = pipe_buffer_get(pipe, data, bytes_to_read);

	//1.'xfer_list'当前包含一个写线程列表,这些线程可以通过当前调用实现它们的写请求
	//2.'writer'如果不是NULL,则指向写入器wait_q上的一个线程,该线程可以发布它所请求的一些数据
	//3.数据将从每个写入器的缓冲区复制到读取器的缓冲区和/或管道的循环缓冲区
	//4.中断被解锁,但调度器被锁定,以允许传递节拍,但不发生调度
	//5.如果在复制数据时'writer'超时,不仅我们仍然有一个指向它的指针,而且它不能执行
	//直到这个调用完成,所以从它复制数据仍然是安全的

	//获取第一个等待写入到管道的线程
	struct k_thread *thread = (struct k_thread *)sys_dlist_get(&xfer_list);
	//
	while ((thread != NULL) && (num_bytes_read < bytes_to_read)) {
		desc = (struct k_pipe_desc *)thread->base.swap_data;
		//将数据从写线程中拿取出来
		bytes_copied = pipe_xfer((uint8_t *)data + num_bytes_read,
								 bytes_to_read - num_bytes_read,
								 desc->buffer, desc->bytes_to_xfer);

		num_bytes_read       += bytes_copied;//读取字节数量
		desc->buffer         += bytes_copied;//定位下一次传输位置
		desc->bytes_to_xfer  -= bytes_copied;//待传输的字节数更新

		//预计写请求将得到满足
		//但是如果读请求在写请求得到满足之前得到了满足
		//那么写请求必须在稍后写入管道的循环缓冲区时完成
		if (num_bytes_read == bytes_to_read) {
			break;
		}
		//写线程可以就绪了因为它已经完成了数据写入
		pipe_thread_ready(thread);
		//获取下一个等待写入到管道的线程
		thread = (struct k_thread *)sys_dlist_get(&xfer_list);
	}

	//这个写线程的数据量过多,只能获取部分
	if ((writer != NULL) && (num_bytes_read < bytes_to_read)) {
		desc = (struct k_pipe_desc *)writer->base.swap_data;
		bytes_copied = pipe_xfer((uint8_t *)data + num_bytes_read,
								  bytes_to_read - num_bytes_read,
								  desc->buffer, desc->bytes_to_xfer);

		num_bytes_read       += bytes_copied;//读取字节数量
		desc->buffer         += bytes_copied;//定位下一次传输位置
		desc->bytes_to_xfer  -= bytes_copied;//待传输的字节数更新
	}

	//从写入器(如果有的话)复制尽可能多的数据到管道的循环缓冲区
	while (thread != NULL) {
		desc = (struct k_pipe_desc *)thread->base.swap_data;
		bytes_copied = pipe_buffer_put(pipe, desc->buffer,
									   desc->bytes_to_xfer);

		desc->buffer         += bytes_copied;//定位下一次传输位置
		desc->bytes_to_xfer  -= bytes_copied;//待传输的字节数更新

		pipe_thread_ready(thread);//已满足写请求

		thread = (struct k_thread *)sys_dlist_get(&xfer_list);
	}

	//将写者剩下的数据写入环形缓冲区
	if (writer != NULL) {
		desc = (struct k_pipe_desc *)writer->base.swap_data;
		bytes_copied = pipe_buffer_put(pipe, desc->buffer,
									   desc->bytes_to_xfer);

		desc->buffer         += bytes_copied;
		desc->bytes_to_xfer  -= bytes_copied;
	}

	//传输完成
	if (num_bytes_read == bytes_to_read) {
		k_sched_unlock();
		*bytes_read = num_bytes_read;
		return 0;
	}

	//传输未完成,但不超时等待
	if (!K_TIMEOUT_EQ(timeout, K_NO_WAIT)
	    && num_bytes_read >= min_xfer
	    && min_xfer > 0) {
		k_sched_unlock();
		*bytes_read = num_bytes_read;
		return 0;
	}

	//并非所有数据都被读取

	struct k_pipe_desc  pipe_desc;
	//将剩余的数据打包
	pipe_desc.buffer        = (uint8_t *)data + num_bytes_read;
	pipe_desc.bytes_to_xfer = bytes_to_read - num_bytes_read;

	if (!K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		_current->base.swap_data = &pipe_desc;
		k_spinlock_key_t key2 = k_spin_lock(&pipe->lock);
		z_sched_unlock_no_reschedule();//恢复调度器
		//以超时时间timeout将当前线程加入到管道的读等待队列
		(void)z_pend_curr(&pipe->lock, key2,
						  &pipe->wait_q.readers, timeout);
	} else {
		k_sched_unlock();
	}

	//传输字节数
	*bytes_read = bytes_to_read - pipe_desc.bytes_to_xfer;
	//传输结果反馈
	return pipe_return_code(min_xfer, pipe_desc.bytes_to_xfer,
							bytes_to_read);
}

#ifdef CONFIG_USERSPACE
int z_vrfy_k_pipe_get(struct k_pipe *pipe, void *data, size_t bytes_to_read,
					  size_t *bytes_read, size_t min_xfer, k_timeout_t timeout)
{
	Z_OOPS(Z_SYSCALL_OBJ(pipe, K_OBJ_PIPE));
	Z_OOPS(Z_SYSCALL_MEMORY_WRITE(bytes_read, sizeof(*bytes_read)));
	Z_OOPS(Z_SYSCALL_MEMORY_WRITE((void *)data, bytes_to_read));
	return z_impl_k_pipe_get((struct k_pipe *)pipe, (void *)data,
							  bytes_to_read, bytes_read, min_xfer,
							  timeout);
}
#include <syscalls/k_pipe_get_mrsh.c>
#endif

int z_impl_k_pipe_put(struct k_pipe *pipe, void *data, size_t bytes_to_write,
					  size_t *bytes_written, size_t min_xfer,
					  k_timeout_t timeout)
{
	return z_pipe_put_internal(pipe, NULL, data,
							   bytes_to_write, bytes_written,
							   min_xfer, timeout);
}

#ifdef CONFIG_USERSPACE
int z_vrfy_k_pipe_put(struct k_pipe *pipe, void *data, size_t bytes_to_write,
					  size_t *bytes_written, size_t min_xfer,
					  k_timeout_t timeout)
{
	Z_OOPS(Z_SYSCALL_OBJ(pipe, K_OBJ_PIPE));
	Z_OOPS(Z_SYSCALL_MEMORY_WRITE(bytes_written, sizeof(*bytes_written)));
	Z_OOPS(Z_SYSCALL_MEMORY_READ((void *)data, bytes_to_write));
	return z_impl_k_pipe_put((struct k_pipe *)pipe, (void *)data,
							  bytes_to_write, bytes_written, min_xfer,
							  timeout);
}
#include <syscalls/k_pipe_put_mrsh.c>
#endif

#if (CONFIG_NUM_PIPE_ASYNC_MSGS > 0)
//异步写入
void k_pipe_block_put(struct k_pipe *pipe, struct k_mem_block *block,
					  size_t bytes_to_write, struct k_sem *sem)
{
	struct k_pipe_async *async_desc;
	size_t dummy_bytes_written;

	/* For simplicity, always allocate an asynchronous descriptor */
	pipe_async_alloc(&async_desc);

	async_desc->desc.block = &async_desc->desc.copy_block;
	async_desc->desc.copy_block = *block;
	async_desc->desc.sem = sem;
	async_desc->thread.prio = k_thread_priority_get(_current);
#ifdef CONFIG_SMP
	async_desc->thread.is_idle = 0;
#endif

	(void) z_pipe_put_internal(pipe, async_desc, block->data,
							  bytes_to_write, &dummy_bytes_written,
							  bytes_to_write, K_FOREVER);
}
#endif

//当前管道可读字节数
size_t z_impl_k_pipe_read_avail(struct k_pipe *pipe)
{
	size_t res;
	k_spinlock_key_t key;
	if (pipe->buffer == NULL || pipe->size == 0) {
		res = 0;
		goto out;
	}
	key = k_spin_lock(&pipe->lock);

	if (pipe->read_index == pipe->write_index) {
		res = pipe->bytes_used;
	} else if (pipe->read_index < pipe->write_index) {
		res = pipe->write_index - pipe->read_index;
	} else {
		res = pipe->size - (pipe->read_index - pipe->write_index);
	}

	k_spin_unlock(&pipe->lock, key);
out:
	return res;
}

#ifdef CONFIG_USERSPACE
size_t z_vrfy_k_pipe_read_avail(struct k_pipe *pipe)
{
	Z_OOPS(Z_SYSCALL_OBJ(pipe, K_OBJ_PIPE));
	return z_impl_k_pipe_read_avail(pipe);
}
#include <syscalls/k_pipe_read_avail_mrsh.c>
#endif

//当前管道可写字节数
size_t z_impl_k_pipe_write_avail(struct k_pipe *pipe)
{
	size_t res;
	k_spinlock_key_t key;
	if (pipe->buffer == NULL || pipe->size == 0) {
		res = 0;
		goto out;
	}
	key = k_spin_lock(&pipe->lock);

	if (pipe->write_index == pipe->read_index) {
		res = pipe->size - pipe->bytes_used;
	} else if (pipe->write_index < pipe->read_index) {
		res = pipe->read_index - pipe->write_index;
	} else {
		res = pipe->size - (pipe->write_index - pipe->read_index);
	}

	k_spin_unlock(&pipe->lock, key);
out:
	return res;
}

#ifdef CONFIG_USERSPACE
size_t z_vrfy_k_pipe_write_avail(struct k_pipe *pipe)
{
	Z_OOPS(Z_SYSCALL_OBJ(pipe, K_OBJ_PIPE));
	return z_impl_k_pipe_write_avail(pipe);
}
#include <syscalls/k_pipe_write_avail_mrsh.c>
#endif
