/*
 * zephyr内核
 */

//固定大小的线程堆栈对象

#include <kernel.h>
#include <kernel_structs.h>
#include <debug/object_tracing_common.h>
#include <toolchain.h>
#include <ksched.h>
#include <wait_q.h>
#include <sys/check.h>
#include <init.h>
#include <syscall_handler.h>
#include <kernel_internal.h>

#ifdef CONFIG_OBJECT_TRACING
//trace所用
struct k_stack *_trace_list_k_stack;
//静态定义栈的完整初始化
static int init_stack_module(const struct device *dev)
{
	ARG_UNUSED(dev);
	Z_STRUCT_SECTION_FOREACH(k_stack, stack) {
		SYS_TRACING_OBJ_INIT(k_stack, stack);
	}
	return 0;
}
SYS_INIT(init_stack_module, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);
#endif

//初始化一个栈
void k_stack_init(struct k_stack *stack, stack_data_t *buffer,
				  uint32_t num_entries)
{
	z_waitq_init(&stack->wait_q);//初始化等待队列
	stack->lock = (struct k_spinlock) {};//初始化自旋锁
	stack->next = stack->base = buffer;//初始化缓冲区
	stack->top = stack->base + num_entries;//初始化栈顶

	SYS_TRACING_OBJ_INIT(k_stack, stack);
	z_object_init(stack);//初始化栈对象
}

//动态初始化一个栈
int32_t z_impl_k_stack_alloc_init(struct k_stack *stack, uint32_t num_entries)
{
	void *buffer;
	int32_t ret;
	//申请栈缓冲区空间
	buffer = z_thread_malloc(num_entries * sizeof(stack_data_t));
	if (buffer != NULL) {//初始化栈
		k_stack_init(stack, buffer, num_entries);
		stack->flags = K_STACK_FLAG_ALLOC;//标记为动态初始化
		ret = (int32_t)0;
	} else {
		ret = -ENOMEM;
	}
	return ret;
}

#ifdef CONFIG_USERSPACE
static inline int32_t z_vrfy_k_stack_alloc_init(struct k_stack *stack,
												uint32_t num_entries)
{
	Z_OOPS(Z_SYSCALL_OBJ_NEVER_INIT(stack, K_OBJ_STACK));
	Z_OOPS(Z_SYSCALL_VERIFY(num_entries > 0));
	return z_impl_k_stack_alloc_init(stack, num_entries);
}
#include <syscalls/k_stack_alloc_init_mrsh.c>
#endif

//清除一个栈
int k_stack_cleanup(struct k_stack *stack)
{
	//如果还有获取栈资源的等待者,不可清除
	CHECKIF(z_waitq_head(&stack->wait_q) != NULL) {
		return -EAGAIN;
	}
	//如果是动态分配栈的缓冲区
	if ((stack->flags & K_STACK_FLAG_ALLOC) != (uint8_t)0) {
		k_free(stack->base);//释放该缓冲区
		stack->base = NULL;//重置
		stack->flags &= ~K_STACK_FLAG_ALLOC;//去除标记
	}
	return 0;
}

//数据地址推入栈
int z_impl_k_stack_push(struct k_stack *stack, stack_data_t data)
{
	struct k_thread *first_pending_thread;
	int ret = 0;
	k_spinlock_key_t key = k_spin_lock(&stack->lock);
	//空间充裕检查
	CHECKIF(stack->next == stack->top) {
		ret = -ENOMEM;
		goto out;
	}
	
	//获取等待栈数据的最高优先级等待者
	first_pending_thread = z_unpend_first_thread(&stack->wait_q);
	if (first_pending_thread != NULL) {
		z_ready_thread(first_pending_thread);//就绪它
		//直接将新鲜的数据给他
		z_thread_return_value_set_with_data(first_pending_thread,
											0, (void *)data);
		z_reschedule(&stack->lock, key);//启用重调度(内核抢占)
		goto end;
	} else {//否则将数据放入栈的buffer缓冲区
		*(stack->next) = data;
		stack->next++;
		goto out;
	}
	
out:
	k_spin_unlock(&stack->lock, key);
end:
	return ret;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_stack_push(struct k_stack *stack, stack_data_t data)
{
	Z_OOPS(Z_SYSCALL_OBJ(stack, K_OBJ_STACK));
	return z_impl_k_stack_push(stack, data);
}
#include <syscalls/k_stack_push_mrsh.c>
#endif

//从栈中弹出数据地址
int z_impl_k_stack_pop(struct k_stack *stack, stack_data_t *data,
					   k_timeout_t timeout)
{
	k_spinlock_key_t key;
	int result;
	key = k_spin_lock(&stack->lock);

	//如果栈中有数据,直接先拿,拿完走人
	if (likely(stack->next > stack->base)) {
		stack->next--;
		*data = *(stack->next);
		k_spin_unlock(&stack->lock, key);
		return 0;
	}

	//如果栈中没有数据了,且不需超时等待,直接返回忙
	if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		k_spin_unlock(&stack->lock, key);
		return -EBUSY;
	}

	//否则以超时时间timeout挂起当前线程到栈中的等待队列中
	result = z_pend_curr(&stack->lock, key, &stack->wait_q, timeout);
	if (result == -EAGAIN) {
		return -EAGAIN;
	}
	//不管是否产生数据都返回
	*data = (stack_data_t)_current->base.swap_data;
	return 0;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_stack_pop(struct k_stack *stack,
									 stack_data_t *data, k_timeout_t timeout)
{
	Z_OOPS(Z_SYSCALL_OBJ(stack, K_OBJ_STACK));
	Z_OOPS(Z_SYSCALL_MEMORY_WRITE(data, sizeof(stack_data_t)));
	return z_impl_k_stack_pop(stack, data, timeout);
}
#include <syscalls/k_stack_pop_mrsh.c>
#endif
