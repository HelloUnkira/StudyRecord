/*
 * zephyr内核
 */

//邮箱

#include <kernel.h>
#include <kernel_structs.h>
#include <debug/object_tracing_common.h>
#include <toolchain.h>
#include <linker/sections.h>
#include <string.h>
#include <ksched.h>
#include <wait_q.h>
#include <sys/dlist.h>
#include <init.h>

#if (CONFIG_NUM_MBOX_ASYNC_MSGS > 0)

//异步消息描述符类型
struct k_mbox_async {
	struct _thread_base thread;//虚拟线程对象
	struct k_mbox_msg tx_msg;//传输消息描述符
};

//未使用的异步消息描述符堆栈
K_STACK_DEFINE(async_msg_free, CONFIG_NUM_MBOX_ASYNC_MSGS);

//分配一个异步消息描述符
static inline void mbox_async_alloc(struct k_mbox_async **async)
{	//使用栈分配空间,小型的对象使用栈分配是有意义的
	(void)k_stack_pop(&async_msg_free, (stack_data_t *)async, K_FOREVER);
}

//释放一个异步消息描述符
static inline void mbox_async_free(struct k_mbox_async *async)
{
	k_stack_push(&async_msg_free, (stack_data_t)async);
}

#endif

//trace所用,追踪链表
#ifdef CONFIG_OBJECT_TRACING
struct k_mbox *_trace_list_k_mbox;
#endif

#if (CONFIG_NUM_MBOX_ASYNC_MSGS > 0) || defined(CONFIG_OBJECT_TRACING)

//执行邮箱对象子系统的运行时初始化
static int init_mbox_module(const struct device *dev)
{
	ARG_UNUSED(dev);

	//异步消息描述符的数组
	static struct k_mbox_async __noinit async_msg[CONFIG_NUM_MBOX_ASYNC_MSGS];

#if (CONFIG_NUM_MBOX_ASYNC_MSGS > 0)
	//创建异步消息描述符池
	//虚拟线程需要最小的初始化,因为它永远不会执行
	//_THREAD_DUMMY标志足以区分虚拟线程和真实线程
	//线程不会被添加到内核的已知线程列表中
	//一旦初始化,每个描述符的地址被添加到一个控制访问它们的堆栈

	int i;

	for (i = 0; i < CONFIG_NUM_MBOX_ASYNC_MSGS; i++) {
		//为每一个异步消息描述符初始化一个虚拟线程
		z_init_thread_base(&async_msg[i].thread, 0, _THREAD_DUMMY, 0);
		//按顺序将对应的空间释放到栈内,以便后续动态分配使用
		k_stack_push(&async_msg_free, (stack_data_t)&async_msg[i]);
	}
#endif

#ifdef CONFIG_OBJECT_TRACING
	//完成静态定义邮箱的初始化,调试追踪所用
	Z_STRUCT_SECTION_FOREACH(k_mbox, mbox) {
		SYS_TRACING_OBJ_INIT(k_mbox, mbox);
	}
#endif
	return 0;
}

SYS_INIT(init_mbox_module, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);

#endif

//初始化一个邮箱
void k_mbox_init(struct k_mbox *mbox_ptr)
{
	//初始邮箱中的发送等待队列和接收等待队列
	z_waitq_init(&mbox_ptr->tx_msg_queue);
	z_waitq_init(&mbox_ptr->rx_msg_queue);
	//初始化邮箱自旋锁
	mbox_ptr->lock = (struct k_spinlock) {};
	SYS_TRACING_OBJ_INIT(k_mbox, mbox_ptr);
}

//检查发送者和接收者的信息描述符的兼容性
//比较发送者和接收者的消息描述符,看它们是否兼容
//如果是则更新描述符字段以反映匹配已经发生
//参数分别是:发送消息描述符,接收消息描述符
static int mbox_message_match(struct k_mbox_msg *tx_msg,
			       struct k_mbox_msg *rx_msg)
{
	uint32_t temp_info;

	//检查发送者和接收者的处理者释放一致
	if (((tx_msg->tx_target_thread == (k_tid_t)K_ANY) ||
	     (tx_msg->tx_target_thread == rx_msg->tx_target_thread)) &&
	    ((rx_msg->rx_source_thread == (k_tid_t)K_ANY) ||
	     (rx_msg->rx_source_thread == tx_msg->rx_source_thread))) {

		//同步两个描述符的线程标识符字段,为防止(k_tid_t)K_ANY存在
		rx_msg->rx_source_thread = tx_msg->rx_source_thread;
		tx_msg->tx_target_thread = rx_msg->tx_target_thread;

		//交换两个描述符的应用信息字段
		temp_info = rx_msg->info;
		rx_msg->info = tx_msg->info;
		tx_msg->info = temp_info;

		//仅为接收方更新数据大小字段
		//接收消息的尺寸更新到俩者最小值
		if (rx_msg->size > tx_msg->size) {
			rx_msg->size = tx_msg->size;
		}

		//仅为接收方更新数据位置字段
		rx_msg->tx_data = tx_msg->tx_data;
		rx_msg->tx_block = tx_msg->tx_block;
		if (rx_msg->tx_data != NULL) {
			rx_msg->tx_block.data = NULL;
		} else if (rx_msg->tx_block.data != NULL) {
			rx_msg->tx_data = rx_msg->tx_block.data;
		} else {
		}

		//仅为接收者更新同步线程字段
		rx_msg->_syncing_thread = tx_msg->_syncing_thread;

		return 0;
	}
	return -1;
}

//处理收到的消息
//释放任何仍然与消息相关的内存池块,然后通知发送者消息处理已经完成
static void mbox_message_dispose(struct k_mbox_msg *rx_msg)
{
	struct k_thread *sending_thread;
	struct k_mbox_msg *tx_msg;

	//如果消息在收到时被处理,则什么也不做
	if (rx_msg->_syncing_thread == NULL) {
		return;
	}

	if (rx_msg->tx_block.data != NULL) {
		rx_msg->tx_block.data = NULL;
	}

	//恢复发送者信息(因为接收者与发送者是同步的)
	sending_thread = rx_msg->_syncing_thread;
	rx_msg->_syncing_thread = NULL;
	tx_msg = (struct k_mbox_msg *)sending_thread->base.swap_data;

	//更新发送方的数据大小字段
	tx_msg->size = rx_msg->size;

#if (CONFIG_NUM_MBOX_ASYNC_MSGS > 0)
	//异步发送:自由异步消息描述符+虚拟线程对,然后给出信号量(如果需要)
	if ((sending_thread->base.thread_state & _THREAD_DUMMY) != 0U) {
		//发送者线程是虚拟线程
		struct k_sem *async_sem = tx_msg->_async_sem;
		//释放该虚拟线程
		mbox_async_free((struct k_mbox_async *)sending_thread);
		if (async_sem != NULL) {//发送信号量
			k_sem_give(async_sem);
		}
		return;
	}
#endif

	//同步发送:唤醒发送线程
	//设置k_thread.callee_saved.retval = 0;
	arch_thread_return_value_set(sending_thread, 0);
	//标记该线程为未挂起状态
	z_mark_thread_as_not_pending(sending_thread);
	z_ready_thread(sending_thread);//将该线程加入就绪队列
	z_reschedule_unlocked();//无条件开启重调度
}

//发送邮箱信息
//处理同步和异步发送的助手
//参数分别是:邮箱实例,发送消息,等待被接收时间
//(毫秒)(虽然不一定完全处理)(使用K_NO_WAIT立即返回,或使用K_FOREVER等待必要的时间)
//错误返回:
//-ENOMSG如果失败立即
//-EAGAIN如果超时
static int mbox_message_put(struct k_mbox *mbox, struct k_mbox_msg *tx_msg,
			     k_timeout_t timeout)
{
	struct k_thread *sending_thread;
	struct k_thread *receiving_thread;
	struct k_mbox_msg *rx_msg;
	k_spinlock_key_t key;

	//保存发送者id,以便在消息匹配时使用
	tx_msg->rx_source_thread = _current;

	//完成准备发送线程(实际或虚拟)发送
	sending_thread = tx_msg->_syncing_thread;
	sending_thread->base.swap_data = tx_msg;

	key = k_spin_lock(&mbox->lock);//上锁
	//搜索邮箱的rx队列以获得兼容的接收器
	_WAIT_Q_FOR_EACH(&mbox->rx_msg_queue, receiving_thread) {
		rx_msg = (struct k_mbox_msg *)receiving_thread->base.swap_data;
		if (mbox_message_match(tx_msg, rx_msg) == 0) {//取到适配的接收器
			//将接收器从rx队列中取出,也即解除其线程挂起状态
			z_unpend_thread(receiving_thread);
			//设置k_thread.callee_saved.retval = 0;
			arch_thread_return_value_set(receiving_thread, 0);
			//适配的接收线程加入到就绪队列
			z_ready_thread(receiving_thread);

#if (CONFIG_NUM_MBOX_ASYNC_MSGS > 0)
			//异步发送:交换当前线程,如果接收者有优先级,否则让它继续
			//注意:虚拟发送线程(未排队)直到接收方使用消息
			if ((sending_thread->base.thread_state & _THREAD_DUMMY) != 0U) {
				z_reschedule(&mbox->lock, key);//非虚拟线程开启重调度
				return 0;
			}
#endif
			//同步发送:暂停当前线程(未排队),直到接收方使用消息
			return z_pend_curr(&mbox->lock, key, NULL, K_FOREVER);
		}
	}
	
	if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {//没找到匹配的接收器
		k_spin_unlock(&mbox->lock, key);
		return -ENOMSG;
	}

#if (CONFIG_NUM_MBOX_ASYNC_MSGS > 0)
	//异步发送:虚拟线程在发送队列上等待接收方
	if ((sending_thread->base.thread_state & _THREAD_DUMMY) != 0U) {
		z_pend_thread(sending_thread, &mbox->tx_msg_queue, K_FOREVER);
		k_spin_unlock(&mbox->lock, key);
		return 0;
	}
#endif
	//同步发送:发送方在发送队列上等待接收方或超时
	return z_pend_curr(&mbox->lock, key, &mbox->tx_msg_queue, timeout);
}

//消息投送至邮箱,等待对方接收
int k_mbox_put(struct k_mbox *mbox, struct k_mbox_msg *tx_msg,
			   k_timeout_t timeout)
{
	//为同步发送配置内容，然后发送消息
	tx_msg->_syncing_thread = _current;
	return mbox_message_put(mbox, tx_msg, timeout);
}

#if (CONFIG_NUM_MBOX_ASYNC_MSGS > 0)
void k_mbox_async_put(struct k_mbox *mbox, struct k_mbox_msg *tx_msg,
					  struct k_sem *sem)
{
	struct k_mbox_async *async;

	//分配一个异步消息描述符,配置两个部分,然后异步发送消息
	mbox_async_alloc(&async);
	//异步接收者线程(虚拟线程)分配优先级
	async->thread.prio = _current->base.prio;
	//保存异步接收消息
	async->tx_msg = *tx_msg;
	async->tx_msg._syncing_thread = (struct k_thread *)&async->thread;
	async->tx_msg._async_sem = sem;
	//异步消息投递至邮箱
	(void)mbox_message_put(mbox, &async->tx_msg, K_FOREVER);
}
#endif

//从邮箱获取消息
void k_mbox_data_get(struct k_mbox_msg *rx_msg, void *buffer)
{
	if (buffer == NULL) {
		rx_msg->size = 0;
		//处理数据被丢弃的情况
		mbox_message_dispose(rx_msg);
		return;
	}

	//复制消息数据到缓冲区，然后处理消息
	if ((rx_msg->tx_data != NULL) && (rx_msg->size > 0)) {
		(void)memcpy(buffer, rx_msg->tx_data, rx_msg->size);
	}
	mbox_message_dispose(rx_msg);
}

//处理收到的邮箱消息数据的即时消耗
//检查接收到的消息数据是否应保留以备日后检索,或是否应立即使用该数据而将消息销毁
//在下列任何一种情况下,有关资料会立即被使用:
//1)接收者通过提供一个缓冲区来接收数据,请求立即检索
//2)没有要检索的数据(即数据大小为0字节)
static int mbox_message_data_check(struct k_mbox_msg *rx_msg, void *buffer)
{
	if (buffer != NULL) {
		//现在检索数据,然后处理消息
		k_mbox_data_get(rx_msg, buffer);
	} else if (rx_msg->size == 0) {
		//没有数据要获取,所以只需处理消息
		mbox_message_dispose(rx_msg);
	} else {
		//为以后的数据检索保留消息
	}
	return 0;
}

//从邮箱获取消息
int k_mbox_get(struct k_mbox *mbox, struct k_mbox_msg *rx_msg, void *buffer,
			   k_timeout_t timeout)
{
	struct k_thread *sending_thread;
	struct k_mbox_msg *tx_msg;
	k_spinlock_key_t key;
	int result;

	//保存接收者id,以便在消息匹配时使用
	rx_msg->tx_target_thread = _current;

	//搜索邮箱的tx队列以找到兼容的发送方
	key = k_spin_lock(&mbox->lock);

	_WAIT_Q_FOR_EACH(&mbox->tx_msg_queue, sending_thread) {
		tx_msg = (struct k_mbox_msg *)sending_thread->base.swap_data;

		if (mbox_message_match(tx_msg, rx_msg) == 0) {
			//将发件人从邮箱的tx队列中取出
			z_unpend_thread(sending_thread);
			k_spin_unlock(&mbox->lock, key);
			//如果需要,立即使用消息数据
			return mbox_message_data_check(rx_msg, buffer);
		}
	}

	//没有找到匹配的发送者

	if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		//不要等待匹配的发送者出现
		k_spin_unlock(&mbox->lock, key);
		return -ENOMSG;
	}

	//等待,直到出现匹配的发送方或发生超时
	_current->base.swap_data = rx_msg;
	result = z_pend_curr(&mbox->lock, key, &mbox->rx_msg_queue, timeout);

	if (result == 0) {
		//如果需要(被匹配的发送方唤醒),立即使用消息数据
		result = mbox_message_data_check(rx_msg, buffer);
	}
	return result;
}
