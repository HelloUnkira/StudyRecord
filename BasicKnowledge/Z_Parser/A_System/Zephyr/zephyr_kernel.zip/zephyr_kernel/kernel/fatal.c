/*
 * zephyr内核
 */

#include <kernel.h>
#include <kernel_internal.h>
#include <kernel_structs.h>
#include <sys/__assert.h>
#include <arch/cpu.h>
#include <logging/log_ctrl.h>
#include <logging/log.h>
#include <fatal.h>
#include <debug/coredump.h>

LOG_MODULE_DECLARE(os, CONFIG_KERNEL_LOG_LEVEL);

//系统挂起
FUNC_NORETURN __weak void arch_system_halt(unsigned int reason)
{
	ARG_UNUSED(reason);

	//待办事项:如果启用SMP,完全停止系统的最佳方法是什么
	//中断上锁,禁止响应中断
	(void)arch_irq_lock();
	for (;;) {
		//单核处理器的确可以死循环以中止系统
		//但多核处理器的话,该halt顶多只能使单个核死循环
		//其余的核仍然还在运行
	}
}

//错误句柄
__weak void k_sys_fatal_error_handler(unsigned int reason,
									  const z_arch_esf_t *esf)
{
	ARG_UNUSED(esf);

	LOG_PANIC();//打印信息
	LOG_ERR("Halting system");//打印系统错误信息
	arch_system_halt(reason);//挂起系统
	CODE_UNREACHABLE;
}

//获取线程名字
static const char *thread_name_get(struct k_thread *thread)
{
	//获取当前线程名字
	const char *thread_name = thread ? k_thread_name_get(thread) : NULL;

	if (thread_name == NULL || thread_name[0] == '\0') {
		thread_name = "unknown";//如果当前线程名字不存在或为空
	}

	return thread_name;
}

//确认异常原因,转化为字符串
static const char *reason_to_str(unsigned int reason)
{
	switch (reason) {
	case K_ERR_CPU_EXCEPTION:
		return "CPU exception";
	case K_ERR_SPURIOUS_IRQ:
		return "Unhandled interrupt";
	case K_ERR_STACK_CHK_FAIL:
		return "Stack overflow";
	case K_ERR_KERNEL_OOPS:
		return "Kernel oops";
	case K_ERR_KERNEL_PANIC:
		return "Kernel panic";
	default:
		return "Unknown error";
	}
}

//错误悬挂封装
FUNC_NORETURN void k_fatal_halt(unsigned int reason)
{
	arch_system_halt(reason);
}

//获取当前CPU的ID号
static inline int get_cpu(void)
{
#if defined(CONFIG_SMP)
	return arch_curr_cpu()->id;
#else
	return 0;
#endif
}

//致命错误处理
void z_fatal_error(unsigned int reason, const z_arch_esf_t *esf)
{
	//我们不允许这段代码被抢占,但不需要在cpu之间同步,所以使用主层锁是合适的
	unsigned int key = arch_irq_lock();
	//获取当前CPU执行的线程
	struct k_thread *thread = k_current_get();

	//twister查找“ZEPHYR FATAL ERROR”字符串,不要在不更新twister的情况下更改它
	LOG_ERR(">>> ZEPHYR FATAL ERROR %d: %s on CPU %d", reason,
			reason_to_str(reason), get_cpu());

	//FIXME:这似乎不像预期的在所有平台上工作
	//需要一种可靠的方法来确定故障是在处理IRQ或异常时发生的,还是在线程上下文发生的
	//看到# 17656
#if defined(CONFIG_ARCH_HAS_NESTED_EXCEPTION_DETECTION)
	//检查是否是中断嵌套异常,通过检查寄存器标志
	if ((esf != NULL) && arch_is_in_nested_exception(esf)) {
		 LOG_ERR("Fault during interrupt handling\n");
	}
#endif

	//产生致命异常时,当前的中断地址和线程名字
	LOG_ERR("Current thread: %p (%s)", thread, log_strdup(thread_name_get(thread)));

	//核心转储,但实现为空,期望将错误原因,寄存器信息,当前执行线程地址转储
	z_coredump(reason, esf, thread);

	//进入系统层致命异常回调,提供给上层致命原因和寄存器信息
	k_sys_fatal_error_handler(reason, esf);

	//如果系统致命错误处理程序返回,然后杀死错误线程
	//一项政策决定是不绞死这个系统
	//ISRs致命错误策略:无条件恐慌
	//这个策略有一个例外:在ISR退出的时候(代表当前线程)可能会执行堆栈哨兵检查
	//但是在这种情况下线程应该被中止
	//注意k_thread_abort()在某些架构上返回,但在其他架构上不返回;
	//例如ARC, x86_64, Xtensa with ASM2, ARM
	
	if (!IS_ENABLED(CONFIG_TEST)) {//如果不启用测试配置
		__ASSERT(reason != K_ERR_KERNEL_PANIC,
				 "Attempted to recover from a kernel panic condition");
		//FIXME: #17656
#if defined(CONFIG_ARCH_HAS_NESTED_EXCEPTION_DETECTION)
		//检查是否是中断嵌套异常,通过检查寄存器标志
		if ((esf != NULL) && arch_is_in_nested_exception(esf)) {
#if defined(CONFIG_STACK_SENTINEL)
			//尝试从中断异常产生的致命错误中恢复系统
			if (reason != K_ERR_STACK_CHK_FAIL) {
				__ASSERT(0, "Attempted to recover from a fatal error in ISR");
			}
#endif
		}
#endif
	} else {//测试模式
#if defined(CONFIG_ARCH_HAS_NESTED_EXCEPTION_DETECTION)
		if ((esf != NULL) && arch_is_in_nested_exception(esf)) {
			//只有在STACK哨兵检查失败时才中止线程
#if defined(CONFIG_STACK_SENTINEL)
			if (reason != K_ERR_STACK_CHK_FAIL) {
				arch_irq_unlock(key);
				return;//如果STACK哨兵检查成功就在此处返回
			}
#else
			arch_irq_unlock(key);//原语语义保持
			return;//不开启STACK哨兵检查直接返回
#endif
		} else {
			//只有当错误不是由于触发了虚假的ISR处理程序时才中止线程
			if (reason == K_ERR_SPURIOUS_IRQ) {
				arch_irq_unlock(key);
				return;//恢复运行
			}
		}
#endif
	}

	arch_irq_unlock(key);//解锁
	//中止当前线程,由于当前线程被中止,且是被自己中止的,所以不一定会返回
	k_thread_abort(thread);
}
