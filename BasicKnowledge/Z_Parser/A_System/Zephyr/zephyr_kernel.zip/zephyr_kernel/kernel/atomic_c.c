/*
 * zephyr内核
 */

//纯C语言中的原子操作
//这个模块为不支持原生原子操作的处理器提供了原子操作符
//对于中断服务例程和对等处理器执行的操作,原子操作保证是原子的
//(最初来自x86的atomic.c)

#include <toolchain.h>
#include <arch/cpu.h>
#include <spinlock.h>
#include <sys/atomic.h>
#include <kernel_structs.h>

//单个全局自旋锁用于原子操作
//这是回退代码,对性能不敏感,至少通过在SMP上下文中不使用irq_lock()
//我们不会满足于使用全局锁的合法用户
static struct k_spinlock lock;

//对于那些支持用户模式但不支持本地原子操作的cpu
//我们能做的最好的事情就是将原子函数实现为系统调用
//因为在用户模式下,自旋锁是被禁止的
#ifdef CONFIG_USERSPACE
#include <syscall_handler.h>
//查看是否存在系统调用,带z_vrfy_和z_impl_前缀
//的实现(不是所有该前缀都是系统调用)
#define ATOMIC_SYSCALL_HANDLER_TARGET(name)                       \
	static inline atomic_val_t z_vrfy_##name(atomic_t *target)    \
	{                                                             \
		Z_OOPS(Z_SYSCALL_MEMORY_WRITE(target, sizeof(atomic_t))); \
		return z_impl_##name((atomic_t *)target);                 \
	}

#define ATOMIC_SYSCALL_HANDLER_TARGET_VALUE(name)                 \
	static inline atomic_val_t z_vrfy_##name(atomic_t *target,    \
						 atomic_val_t value)                      \
	{								                              \
		Z_OOPS(Z_SYSCALL_MEMORY_WRITE(target, sizeof(atomic_t))); \
		return z_impl_##name((atomic_t *)target, value);          \
	}
//
#else
#define ATOMIC_SYSCALL_HANDLER_TARGET(name)
#define ATOMIC_SYSCALL_HANDLER_TARGET_VALUE(name)
#endif

//原子比较和设置原语
//提供了比较和设置操作符
//如果原始值为<target>等于<oldValue>;然后<newValue>存储在<target>函数返回true
//如果原始值在<target>不等于<oldValue>则存储未完成,函数返回false
//读取<target>的原始值、比较和写入新值(如果发生)都是原子性的
//这与中断和其他处理器对<target>的访问有关
//参数分别是:要测试的目标地址,比较的值,比较的值
bool z_impl_atomic_cas(atomic_t *target, atomic_val_t old_value,
					   atomic_val_t new_value)
{
	k_spinlock_key_t key;
	int ret = false;
	key = k_spin_lock(&lock);//上自旋锁(该锁是全局锁)
	
	if (*target == old_value) {//目标位置是旧值
		*target = new_value;//目标写入了新值
		ret = true;
	}
	
	k_spin_unlock(&lock, key);//解自旋锁(该锁是全局锁)
	return ret;
}

#ifdef CONFIG_USERSPACE
//如上,接口重置
bool z_vrfy_atomic_cas(atomic_t *target, atomic_val_t old_value,
					   atomic_val_t new_value)
{
	Z_OOPS(Z_SYSCALL_MEMORY_WRITE(target, sizeof(atomic_t)));
	return z_impl_atomic_cas((atomic_t *)target, old_value, new_value);
}
#include <syscalls/atomic_cas_mrsh.c>
#endif

//和之前的z_impl_atomic_cas差不多
//但它是用于更新target上保存的地址,target是atomic_t**
bool z_impl_atomic_ptr_cas(atomic_ptr_t *target, void *old_value,
						   void *new_value)
{
	k_spinlock_key_t key;
	int ret = false;
	key = k_spin_lock(&lock);//上自旋锁

	if (*target == old_value) {
		*target = new_value;
		ret = true;
	}

	k_spin_unlock(&lock, key);//解自旋锁
	return ret;
}

#ifdef CONFIG_USERSPACE
//如上,接口重置
static inline bool z_vrfy_atomic_ptr_cas(atomic_ptr_t *target, void *old_value,
										 void *new_value)
{
	Z_OOPS(Z_SYSCALL_MEMORY_WRITE(target, sizeof(atomic_ptr_t)));

	return z_impl_atomic_ptr_cas(target, old_value, new_value);
}
#include <syscalls/atomic_ptr_cas_mrsh.c>
#endif

//原子加法原语
//提供了原子加法操作符
//<value>原子地累加到<target>的值中
//将<target>累加前的值作为结果返回
//参数分别是:目标内存位置,添加的值
atomic_val_t z_impl_atomic_add(atomic_t *target, atomic_val_t value)
{
	k_spinlock_key_t key;
	atomic_val_t ret;
	key = k_spin_lock(&lock);//上自旋锁

	ret = *target;//保留原始值
	*target += value;//累加

	k_spin_unlock(&lock, key);//解自旋锁
	return ret;
}

ATOMIC_SYSCALL_HANDLER_TARGET_VALUE(atomic_add);

//原子减法原语
//这个例程提供了原子减法运算符
//<value>从<target>处的值原子地减去,将结果放在<target>处
//并将扣除之前的<target>值返回
//参数分别是:目标内存位置,扣除的值
atomic_val_t z_impl_atomic_sub(atomic_t *target, atomic_val_t value)
{
	k_spinlock_key_t key;
	atomic_val_t ret;
	key = k_spin_lock(&lock);

	ret = *target;
	*target -= value;

	k_spin_unlock(&lock, key);
	return ret;
}

ATOMIC_SYSCALL_HANDLER_TARGET_VALUE(atomic_sub);

//原子获取原语
//目标内存位置读取
//提供了原子性的get原语,用于原子性地从<target>读取一个值
//它只是做一个普通的负荷,注意<target>期望对齐到4字节边界
atomic_val_t atomic_get(const atomic_t *target)
{
	return *target;
}

void *atomic_ptr_get(const atomic_ptr_t *target)
{
	return *target;
}

//原子的get-and-set原语
//提供了原子集操作符
//<value>被原子地写在<target>,<target>先前的值被返回
atomic_val_t z_impl_atomic_set(atomic_t *target, atomic_val_t value)
{
	k_spinlock_key_t key;
	atomic_val_t ret;
	key = k_spin_lock(&lock);

	ret = *target;
	*target = value;

	k_spin_unlock(&lock, key);
	return ret;
}

ATOMIC_SYSCALL_HANDLER_TARGET_VALUE(atomic_set);

void *z_impl_atomic_ptr_set(atomic_ptr_t *target, void *value)
{
	k_spinlock_key_t key;
	void *ret;
	key = k_spin_lock(&lock);

	ret = *target;
	*target = value;

	k_spin_unlock(&lock, key);
	return ret;
}

#ifdef CONFIG_USERSPACE
static inline void *z_vrfy_atomic_ptr_set(atomic_ptr_t *target, void *value)
{
	Z_OOPS(Z_SYSCALL_MEMORY_WRITE(target, sizeof(atomic_ptr_t)));

	return z_impl_atomic_ptr_set(target, value);
}
#include <syscalls/atomic_ptr_set_mrsh.c>
#endif

//原子按OR原语
//<value>按位原子地与<target>进行或运算
//并将OR之前的值返回
atomic_val_t z_impl_atomic_or(atomic_t *target, atomic_val_t value)
{
	k_spinlock_key_t key;
	atomic_val_t ret;
	key = k_spin_lock(&lock);

	ret = *target;
	*target |= value;

	k_spin_unlock(&lock, key);
	return ret;
}

ATOMIC_SYSCALL_HANDLER_TARGET_VALUE(atomic_or);

//原子位XOR原语
//提供了原子的位XOR操作符
//<value>按位在原子地与<target>进行异或运算
//并将XOR之前的值返回
atomic_val_t z_impl_atomic_xor(atomic_t *target, atomic_val_t value)
{
	k_spinlock_key_t key;
	atomic_val_t ret;
	key = k_spin_lock(&lock);

	ret = *target;
	*target ^= value;

	k_spin_unlock(&lock, key);
	return ret;
}

ATOMIC_SYSCALL_HANDLER_TARGET_VALUE(atomic_xor);

//原子的位AND原语
//提供了原子的位AND操作符
//<value>按位原子地与<target>进行与运算
//并将AND之前的值返回
atomic_val_t z_impl_atomic_and(atomic_t *target, atomic_val_t value)
{
	k_spinlock_key_t key;
	atomic_val_t ret;

	key = k_spin_lock(&lock);

	ret = *target;
	*target &= value;

	k_spin_unlock(&lock, key);

	return ret;
}

ATOMIC_SYSCALL_HANDLER_TARGET_VALUE(atomic_and);

//原子的位NAND原语
//提供了原子的位NAND操作符
//<value>按位原子地与<target>进行与非运算
//并将NAND之前的值返回
atomic_val_t z_impl_atomic_nand(atomic_t *target, atomic_val_t value)
{
	k_spinlock_key_t key;
	atomic_val_t ret;

	key = k_spin_lock(&lock);

	ret = *target;
	*target = ~(*target & value);

	k_spin_unlock(&lock, key);

	return ret;
}

ATOMIC_SYSCALL_HANDLER_TARGET_VALUE(atomic_nand);

#ifdef CONFIG_USERSPACE
#include <syscalls/atomic_add_mrsh.c>
#include <syscalls/atomic_sub_mrsh.c>
#include <syscalls/atomic_set_mrsh.c>
#include <syscalls/atomic_or_mrsh.c>
#include <syscalls/atomic_xor_mrsh.c>
#include <syscalls/atomic_and_mrsh.c>
#include <syscalls/atomic_nand_mrsh.c>
#endif
