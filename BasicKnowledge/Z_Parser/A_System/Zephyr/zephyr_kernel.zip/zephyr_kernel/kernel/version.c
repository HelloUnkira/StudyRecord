/*
 * zephyr内核
 */

#include <zephyr/types.h>
#include "version.h" //MAKE在编译时生成

//返回当前版本的内核版本
//内核版本是一个四字节的值,其格式在文件“kernel_version.h”
uint32_t sys_kernel_version_get(void)
{
	return KERNELVERSION;
}
