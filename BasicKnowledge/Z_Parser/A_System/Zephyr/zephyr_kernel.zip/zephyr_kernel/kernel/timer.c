/*
 * zephyr内核
 */

#include <kernel.h>
#include <debug/object_tracing_common.h>
#include <init.h>
#include <ksched.h>
#include <wait_q.h>
#include <syscall_handler.h>
#include <stdbool.h>
#include <spinlock.h>

//静态全局自旋锁
static struct k_spinlock lock;

#ifdef CONFIG_OBJECT_TRACING
//trace所用
struct k_timer *_trace_list_k_timer;
//完成静态定义计时器的初始化
static int init_timer_module(const struct device *dev)
{
	ARG_UNUSED(dev);
	Z_STRUCT_SECTION_FOREACH(k_timer, timer) {
		SYS_TRACING_OBJ_INIT(k_timer, timer);
	}
	return 0;
}
SYS_INIT(init_timer_module, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);
#endif

//处理内核计时器对象的过期回调
void z_timer_expiration_handler(struct _timeout *t)
{
	//获取超时节点的所有者,为k_timer类型
	struct k_timer *timer = CONTAINER_OF(t, struct k_timer, timeout);
	struct k_thread *thread;

	//如果计时器是周期性的,重新启动它
	//不要添加_TICK_ALIGN,因为我们已经对齐到标记边界
	if (!K_TIMEOUT_EQ(timer->period, K_NO_WAIT) &&
	    !K_TIMEOUT_EQ(timer->period, K_FOREVER)) {
		z_add_timeout(&timer->timeout, z_timer_expiration_handler,
					  timer->period);
	}

	timer->status += 1U;//更新定时器的状态

	if (timer->expiry_fn != NULL) {
		timer->expiry_fn(timer);//调用计时器过期函数
	}

	//获取该定时器等待队列中的第一个等待者
	thread = z_waitq_head(&timer->wait_q);
	if (thread == NULL) {
		return;
	}

	//中断_DO NOT_必须锁在这个特定线程的实例unpending因为:
	//a)这是线程可以从这个挂起队列中移除的唯一地方
	//b)线程可以放在挂起队列上的唯一位置是线程级,这当然不能中断当前上下文
	
	//将该线程取消超时阻塞并就绪它
	z_unpend_thread_no_timeout(thread);
	z_ready_thread(thread);
	arch_thread_return_value_set(thread, 0);
}

//定时器初始化
void k_timer_init(struct k_timer *timer,
				  k_timer_expiry_t expiry_fn,
				  k_timer_stop_t stop_fn)
{
	timer->expiry_fn = expiry_fn;//过期回调
	timer->stop_fn = stop_fn;//中止回调
	timer->status = 0U;//定时器状态
	z_waitq_init(&timer->wait_q);//初始化等待队列
	z_init_timeout(&timer->timeout);//初始化超时实例
	SYS_TRACING_OBJ_INIT(k_timer, timer);
	
	timer->user_data = NULL;//初始化用户数据
	z_object_init(timer);
}

//启动定时器
void z_impl_k_timer_start(struct k_timer *timer, k_timeout_t duration,
						  k_timeout_t period)
{
	//定时器超时时间不可以为永久,永久意味着永远不能超时
	if (K_TIMEOUT_EQ(duration, K_FOREVER)) {
		return;
	}

	//z_add_timeout()总是添加一个传入的tick数算到下一个tick(按照惯例等待“至少只要指定的超时”)
	//但周期间隔总是从内部保证重置计时器ISR,所以不需要围捕,减去一个
	
	//注意duration(!)值得到了相同的向后兼容性处理
	//这是不幸的(即k_timer_start()不像k_sleep()那样对待它的初始睡眠参数)
	//但这是历史的,timer_api测试依赖于此行为

	if (period.ticks != 0 && Z_TICK_ABS(period.ticks) < 0) {
		period.ticks = MAX(period.ticks - 1, 1);
	}
	if (Z_TICK_ABS(duration.ticks) < 0) {
		duration.ticks = MAX(duration.ticks - 1, 0);
	}
	
	//启动前先中止定时器,以保证它是就绪的
	(void)z_abort_timeout(&timer->timeout);
	
	timer->period = period;
	timer->status = 0U;//初始化状态

	//将其加入到超时队列中
	z_add_timeout(&timer->timeout, z_timer_expiration_handler, duration);
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_timer_start(struct k_timer *timer,
										k_timeout_t duration,
										k_timeout_t period)
{
	Z_OOPS(Z_SYSCALL_OBJ(timer, K_OBJ_TIMER));
	z_impl_k_timer_start(timer, duration, period);
}
#include <syscalls/k_timer_start_mrsh.c>
#endif

//中止定时器
void z_impl_k_timer_stop(struct k_timer *timer)
{
	//中止定时器的超时节点,将其从超时队列移除
	int inactive = z_abort_timeout(&timer->timeout) != 0;

	if (inactive) {//如果定时器本身没有运行,无需中止
		return;
	}

	if (timer->stop_fn != NULL) {//先调用中止回调函数
		timer->stop_fn(timer);
	}

	//移除一个挂起项,从定时器的等待队列中
	struct k_thread *pending_thread = z_unpend1_no_timeout(&timer->wait_q);
	//就绪它并开始重调度
	if (pending_thread != NULL) {
		z_ready_thread(pending_thread);
		z_reschedule_unlocked();
	}
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_timer_stop(struct k_timer *timer)
{
	Z_OOPS(Z_SYSCALL_OBJ(timer, K_OBJ_TIMER));
	z_impl_k_timer_stop(timer);
}
#include <syscalls/k_timer_stop_mrsh.c>
#endif

//获取定时器状态
uint32_t z_impl_k_timer_status_get(struct k_timer *timer)
{
	k_spinlock_key_t key = k_spin_lock(&lock);
	uint32_t result = timer->status;
	timer->status = 0U;
	k_spin_unlock(&lock, key);
	return result;
}

#ifdef CONFIG_USERSPACE
static inline uint32_t z_vrfy_k_timer_status_get(struct k_timer *timer)
{
	Z_OOPS(Z_SYSCALL_OBJ(timer, K_OBJ_TIMER));
	return z_impl_k_timer_status_get(timer);
}
#include <syscalls/k_timer_status_get_mrsh.c>
#endif

//异步获取定时器状态
uint32_t z_impl_k_timer_status_sync(struct k_timer *timer)
{
	//断言是否中断环境下
	__ASSERT(!arch_is_in_isr(), "");
	k_spinlock_key_t key = k_spin_lock(&lock);
	uint32_t result = timer->status;

	if (result == 0U) {//定时器状态
		if (!z_is_inactive_timeout(&timer->timeout)) {
			//等待计时器过期或停止
			(void)z_pend_curr(&lock, key, &timer->wait_q, K_FOREVER);
			//获取更新的计时器状态
			key = k_spin_lock(&lock);
			result = timer->status;
		} else {
			//计时器已经停止
		}
	} else {
		//计时器已至少过期一次
	}
	timer->status = 0U;
	k_spin_unlock(&lock, key);
	return result;
}

#ifdef CONFIG_USERSPACE
static inline uint32_t z_vrfy_k_timer_status_sync(struct k_timer *timer)
{
	Z_OOPS(Z_SYSCALL_OBJ(timer, K_OBJ_TIMER));
	return z_impl_k_timer_status_sync(timer);
}
#include <syscalls/k_timer_status_sync_mrsh.c>

static inline k_ticks_t z_vrfy_k_timer_remaining_ticks(struct k_timer *timer)
{
	Z_OOPS(Z_SYSCALL_OBJ(timer, K_OBJ_TIMER));
	return z_impl_k_timer_remaining_ticks(timer);
}
#include <syscalls/k_timer_remaining_ticks_mrsh.c>

static inline k_ticks_t z_vrfy_k_timer_expires_ticks(struct k_timer *timer)
{
	Z_OOPS(Z_SYSCALL_OBJ(timer, K_OBJ_TIMER));
	return z_impl_k_timer_expires_ticks(timer);
}
#include <syscalls/k_timer_expires_ticks_mrsh.c>

static inline void *z_vrfy_k_timer_user_data_get(const struct k_timer *timer)
{
	Z_OOPS(Z_SYSCALL_OBJ(timer, K_OBJ_TIMER));
	return z_impl_k_timer_user_data_get(timer);
}
#include <syscalls/k_timer_user_data_get_mrsh.c>

static inline void z_vrfy_k_timer_user_data_set(struct k_timer *timer,
						void *user_data)
{
	Z_OOPS(Z_SYSCALL_OBJ(timer, K_OBJ_TIMER));
	z_impl_k_timer_user_data_set(timer, user_data);
}
#include <syscalls/k_timer_user_data_set_mrsh.c>

#endif
