/*
 * zephyr内核
 */

#include <kernel.h>
#include <spinlock.h>
#include <ksched.h>
#include <timeout_q.h>
#include <syscall_handler.h>
#include <drivers/timer/system_timer.h>
#include <sys_clock.h>

#define LOCKED(lck) for (k_spinlock_key_t __i = {},             \
						 __key = k_spin_lock(lck);              \
						 __i.key == 0;                          \
						 k_spin_unlock(lck, __key), __i.key = 1)

//静态全局当前滴答数
static uint64_t curr_tick;

//静态全局初始化一个链表
static sys_dlist_t timeout_list = SYS_DLIST_STATIC_INIT(&timeout_list);

//静态全局的自旋锁
static struct k_spinlock timeout_lock;

//最大等待时间
#define MAX_WAIT (IS_ENABLED(CONFIG_SYSTEM_CLOCK_SLOPPY_IDLE) \
				  ? K_TICKS_FOREVER : INT_MAX)

//当前正在执行的z_clock_announce()中留给处理的周期
//它指明了当次发布,产生了多少个超时过期项,任何比它小的节点都已经超时过期了
static int announce_remaining;

//定时器运行时系统时钟频率
#if defined(CONFIG_TIMER_READS_ITS_FREQUENCY_AT_RUNTIME)
int z_clock_hw_cycles_per_sec = CONFIG_SYS_CLOCK_HW_CYCLES_PER_SEC;

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_z_clock_hw_cycles_per_sec_runtime_get(void)
{
	return z_impl_z_clock_hw_cycles_per_sec_runtime_get();
}
#include <syscalls/z_clock_hw_cycles_per_sec_runtime_get_mrsh.c>
#endif
#endif

//获得第一个超时的节点
static struct _timeout *first(void)
{
	//从超时链表摘取出一个节点
	sys_dnode_t *t = sys_dlist_peek_head(&timeout_list);
	//如果该节点存在,返回该节点的所有者,类型为_timeout
	return t == NULL ? NULL : CONTAINER_OF(t, struct _timeout, node);
}

//获得指定节点的下一个超时的节点
static struct _timeout *next(struct _timeout *t)
{
	sys_dnode_t *n = sys_dlist_peek_next(&timeout_list, &t->node);
	return n == NULL ? NULL : CONTAINER_OF(n, struct _timeout, node);
}

//从超时链表中移除该节点
static void remove_timeout(struct _timeout *t)
{
	if (next(t) != NULL) {
		next(t)->dticks += t->dticks;
	}//移除之前将当前时间累加到下一节点之上
	//移除该节点
	sys_dlist_remove(&t->node);
}

//获取对应处理动作工程中,流过的时间
static int32_t elapsed(void)
{
	return announce_remaining == 0 ? z_clock_elapsed() : 0U;
}

//获取下一个节点超时时间
static int32_t next_timeout(void)
{
	struct _timeout *to = first();//获得第一个超时节点
	int32_t ticks_elapsed = elapsed();
	//计算还有多久的时间
	int32_t ret = to == NULL ? MAX_WAIT : 
						CLAMP(to->dticks - ticks_elapsed, 0, MAX_WAIT);

#ifdef CONFIG_TIMESLICING
	//如果启用时间戳,则需要检查当前线程的时间片
	//因为当前线程可能会更早的过期
	if (_current_cpu->slice_ticks && _current_cpu->slice_ticks < ret) {
		ret = _current_cpu->slice_ticks;
	}
#endif
	return ret;
}

//添加超时
void z_add_timeout(struct _timeout *to, _timeout_func_t fn, k_timeout_t timeout)
{
	//检查,如果超时时间为永久,那就不加入超时链表中
	if (K_TIMEOUT_EQ(timeout, K_FOREVER)) {
		return;
	}
#ifdef KERNEL_COHERENCE
	//内存一致性检查?把所有成员地址读出来?比较连贯?
	__ASSERT_NO_MSG(arch_mem_coherent(to));
#endif
	//获取超时时间(滴答)
	k_ticks_t ticks = timeout.ticks + 1;
	//超时时间合法检查
	if (IS_ENABLED(CONFIG_TIMEOUT_64BIT) && Z_TICK_ABS(ticks) >= 0) {
		//计算实际超时时间(滴答)
		ticks = Z_TICK_ABS(ticks) - (curr_tick + elapsed());
	}
	//断言节点是否被使用
	__ASSERT(!sys_dnode_is_linked(&to->node), "");
	to->fn = fn;//超时回调绑定
	ticks = MAX(1, ticks);//滴答必须>0

	LOCKED(&timeout_lock) {//锁定超时
		struct _timeout *t;

		to->dticks = ticks + elapsed();
		for (t = first(); t != NULL; t = next(t)) {
			if (t->dticks > to->dticks) {
				t->dticks -= to->dticks;
				//按超时时间插入到超时链表中
				sys_dlist_insert(&t->node, &to->node);
				break;
			}
			//超时时间是相对于前一个节点的超时
			to->dticks -= t->dticks;
		}

		//超时时间过长,加入到尾部
		if (t == NULL) {
			sys_dlist_append(&timeout_list, &to->node);
		}

		//出现在第一个,最小超时时间,那么可能该时间并不是有效的超时时间
		if (to == first()) {
#if CONFIG_TIMESLICING
			//这不是理想的,因为它没有计算自上次公告以来经过的时间
			//而slice_ticks是基于这个时间的
			//这意味着下一次公告的剩余时间可能少于slice_ticks
			int32_t next_time = next_timeout();

			if (next_time == 0 ||
			    _current_cpu->slice_ticks != next_time) {
				z_clock_set_timeout(next_time, false);
			}
#else
			z_clock_set_timeout(next_timeout(), false);
#endif
		}
	}
}

//终止指定节点的超时
int z_abort_timeout(struct _timeout *to)
{
	int ret = -EINVAL;
	LOCKED(&timeout_lock) {
		//如果该节点存在于超时链表集中
		if (sys_dnode_is_linked(&to->node)) {
			remove_timeout(to);//移除它
			ret = 0;
		}
	}
	return ret;
}

//必须加锁
//超时剩余时间
static k_ticks_t timeout_rem(const struct _timeout *timeout)
{
	k_ticks_t ticks = 0;
	//如果该节点非活跃状态
	if (z_is_inactive_timeout(timeout)) {
		return 0;
	}
	//遍历该节点,找到它的位置的过程中,重新计算它的实际时间
	for (struct _timeout *t = first(); t != NULL; t = next(t)) {
		ticks += t->dticks;
		if (timeout == t) {
			break;
		}
	}
	return ticks - elapsed();
}

//获取指定节点超时时间
k_ticks_t z_timeout_remaining(const struct _timeout *timeout)
{
	k_ticks_t ticks = 0;
	LOCKED(&timeout_lock) {
		ticks = timeout_rem(timeout);
	}
	return ticks;
}

//获取指定节点过期的时间
k_ticks_t z_timeout_expires(const struct _timeout *timeout)
{
	k_ticks_t ticks = 0;
	LOCKED(&timeout_lock) {//超时是以当前的实际滴答为参考计算的
		ticks = curr_tick + timeout_rem(timeout);
	}
	return ticks;
}

//获取下一个超时过期项
int32_t z_get_next_timeout_expiry(void)
{
	int32_t ret = (int32_t) K_TICKS_FOREVER;
	LOCKED(&timeout_lock) {//获取下一个超时时间
		ret = next_timeout();
	}
	return ret;
}

//设置下一个超时过期项
void z_set_timeout_expiry(int32_t ticks, bool is_idle)
{
	LOCKED(&timeout_lock) {//上锁
		int next_to = next_timeout();//获取下一个超时时间
		bool sooner = (next_to == K_TICKS_FOREVER) || (ticks < next_to);
		bool imminent = next_to <= 1;

		//只有在新的超时时间比我们所拥有的时间更早的时候才设置新的超时
		//另外不要试图在一个超时即将到期时设置一个超时:驱动程序有内部逻辑
		//如果它不被认为是可设置的,它将把超时撞到“下一个”滴答
		//然而SMP不能使用这种优化:我们不知道上下文切换何时发生
		//直到中断退出,所以不能获得时间切片钳折叠
		if (!imminent && (sooner || IS_ENABLED(CONFIG_SMP))) {
			//设置空闲时间滴答
			z_clock_set_timeout(ticks, is_idle);
		}
	}
}

//超时发布
void z_clock_announce(int32_t ticks)
{
#ifdef CONFIG_TIMESLICING
	z_time_slice(ticks);//计算时间戳
#endif

	k_spinlock_key_t key = k_spin_lock(&timeout_lock);

	//指定的一个滴答时间,作为时间发布,该滴答内有多少项超时过期?
	announce_remaining = ticks;
	//检查当前有多少个超时过期项,即小于指定滴答时间
	while (first() != NULL && first()->dticks <= announce_remaining) {
		struct _timeout *t = first();//拿到该节点
		int dt = t->dticks;//更新到现在的时间

		curr_tick += dt;//更新现在的滴答
		announce_remaining -= dt;//更新剩余滴答数
		t->dticks = 0;//重置过期节点
		remove_timeout(t);//从超时链表中移除该节点

		k_spin_unlock(&timeout_lock, key);
		t->fn(t);//执行它的超时过期回调
		key = k_spin_lock(&timeout_lock);
	}

	//更新下一个节点的超时时间
	if (first() != NULL) {
		first()->dticks -= announce_remaining;
	}

	//将剩余超时时间累加到当前滴答中
	curr_tick += announce_remaining;
	announce_remaining = 0;//重置它
	//设置下一个超时过期项
	z_clock_set_timeout(next_timeout(), false);
	k_spin_unlock(&timeout_lock, key);
}

//获取当前滴答数
int64_t z_tick_get(void)
{
	uint64_t t = 0U;

	LOCKED(&timeout_lock) {
		t = curr_tick + z_clock_elapsed();
	}
	return t;
}

//获取当前滴答数(32位版本)
uint32_t z_tick_get_32(void)
{
#ifdef CONFIG_TICKLESS_KERNEL
	return (uint32_t)z_tick_get();
#else
	return (uint32_t)curr_tick;
#endif
}

int64_t z_impl_k_uptime_ticks(void)
{
	return z_tick_get();
}

#ifdef CONFIG_USERSPACE
static inline int64_t z_vrfy_k_uptime_ticks(void)
{
	return z_impl_k_uptime_ticks();
}
#include <syscalls/k_uptime_ticks_mrsh.c>
#endif

//返回超时对象的正常运行时间过期(相对于未锁定的“现在”!)当正确使用时
//应该与传递新超时值的用户同步调用一次,不应该迭代地使用它来调整超时
uint64_t z_timeout_end_calc(k_timeout_t timeout)
{
	k_ticks_t dt;

	if (K_TIMEOUT_EQ(timeout, K_FOREVER)) {
		return UINT64_MAX;
	} else if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		return z_tick_get();
	}

	dt = timeout.ticks;

	if (IS_ENABLED(CONFIG_TIMEOUT_64BIT) && Z_TICK_ABS(dt) >= 0) {
		return Z_TICK_ABS(dt);
	}
	return z_tick_get() + MAX(1, dt);
}
