/*
 * zephyr内核
 */

//用于生成结构成员偏移量定义的宏
//
//这个头文件包含宏,允许内核实现生成绝对符号,其值表示各种内核结构的成员偏移量
//这些绝对符号通常用于汇编源文件,而不是硬编码某些本地头文件中的值
//
//警告:绝对符号可能被外部工具使用——例如,定位数据结构中的特定字段
//因此对这些符号的更改可能需要对相关工具进行修改
//通常重新定位一个结构的成员只需要重新构建一个工具;
//然而将成员移动到另一个结构(或现有结构中的新子结构)可能需要修改工具本身
//同样地,删除、重命名或更改绝对符号的含义可能需要对工具进行修改
//
//宏“GEN_OFFSET_SYM(structure, member)”用于生成单个绝对符号
//绝对符号将出现在从利用GEN_OFFSET_SYM()宏的源文件生成的对象模块中
//表示结构成员偏移量的绝对符号有以下形式:
//				__<structure>_<member>_OFFSET
//宏"GEN_NAMED_OFFSET_SYM(structure, member, name)"也提供创建符号的形式如下:
//				__<structure>_<name>_OFFSET
//此头文件还定义了GEN_ABSOLUTE_SYM宏,以简单地定义一个绝对符号
//而不管该值是表示一个结构体还是偏移量
//下面的示例文件说明了这个文件中可用宏的用法:
//				<示例源文件的起始: offsets.c>
//#include <gen_offset.h>
//包含要为其生成偏移量符号的结构定义
//#include <kernel_structs.h>
//GEN_ABS_SYM_BEGIN (_OffsetAbsSyms)//name参数是任意的
//_kernel_t结构成员偏移量
//GEN_OFFSET_SYM (_kernel_t, nested);
//GEN_OFFSET_SYM (_kernel_t, irq_stack);
//GEN_OFFSET_SYM (_kernel_t, current);
//GEN_OFFSET_SYM (_kernel_t, idle);
//GEN_ABSOLUTE_SYM (___kernel_t_SIZEOF, sizeof(_kernel_t));
//GEN_ABS_SYM_END
//				<示例源文件的结束: offsets.c>
//编译样例偏移量,c得到的偏移量,o中的符号如下:
//$ nm offsets.o
//00000000 A ___kernel_t_nested_OFFSET
//00000004 A ___kernel_t_irq_stack_OFFSET
//00000008 A ___kernel_t_current_OFFSET
//0000000c A ___kernel_t_idle_OFFSET


#ifndef ZEPHYR_KERNEL_INCLUDE_GEN_OFFSET_H_
#define ZEPHYR_KERNEL_INCLUDE_GEN_OFFSET_H_

#include <toolchain.h>
#include <stddef.h>

//GEN_OFFSET_SYM()宏的定义与工具链无关
#define GEN_OFFSET_SYM(S, M) \
	GEN_ABSOLUTE_SYM(__##S##_##M##_##OFFSET, offsetof(S, M))

#define GEN_NAMED_OFFSET_SYM(S, M, N) \
	GEN_ABSOLUTE_SYM(__##S##_##N##_##OFFSET, offsetof(S, M))

#endif

//注:
//对于offsetof的原理也可以简易替换成以下的上层实现
//include <stdlib.h>
//#define offsetof(struct_name, srtuct_member_name, offset)	\
//{															\
//	void* ptr = (void*)malloc(sizeof(struct_name));			\
//	offset = (int)ptr - (int)(&(ptr->srtuct_member_name));	\
//}



