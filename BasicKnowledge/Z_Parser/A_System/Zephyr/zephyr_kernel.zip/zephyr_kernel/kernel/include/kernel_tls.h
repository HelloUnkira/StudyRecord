/*
 * zephyr内核
 */

//内核线程本地存储api
//与线程本地存储相关的内核api

#ifndef ZEPHYR_KERNEL_INCLUDE_KERNEL_TLS_H_
#define ZEPHYR_KERNEL_INCLUDE_KERNEL_TLS_H_

#include <linker/linker-defs.h>

//返回TLS数据/bss区域的总大小
//返回线程本地存储(TLS)数据和bss区域的总大小,如在链接器脚本中定义的
//请注意,这并不包括TLS正常功能所需的任何特定于体系结构的位
static inline size_t z_tls_data_size(void)
{
	return (size_t)__tls_size;
}

//复制TLS数据/bss区域到目的地dest
//将TLS数据复制到目的地,并清除数据区后的TLS bss大小区域
static inline void z_tls_copy(char *dest)
{
	size_t tdata_size = (size_t)__tdata_size;
	size_t tbss_size = (size_t)__tbss_size;
	
	//复制初始化数据(tdata)
	memcpy(dest, __tdata_start, tdata_size);
	
	dest += tdata_size;
	//清除BSS数据(tbss) 
	memset(dest, 0, tbss_size);
}

#endif
