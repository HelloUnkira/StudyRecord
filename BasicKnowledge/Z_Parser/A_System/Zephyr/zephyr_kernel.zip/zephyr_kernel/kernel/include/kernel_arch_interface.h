/*
 * zephyr内核
 */

//在架构层实现的内部内核api
//不是所有特定于体系结构的定义都在这里
//公共函数和宏使用的api定义在include/sys/arch_interface.h中
//对于这里所有的内联函数原型,实现是由arch/ARCH/include/kernel_arch_func.h提供的

#ifndef ZEPHYR_KERNEL_INCLUDE_KERNEL_ARCH_INTERFACE_H_
#define ZEPHYR_KERNEL_INCLUDE_KERNEL_ARCH_INTERFACE_H_

#include <kernel.h>
#include <sys/arch_interface.h>

#ifndef _ASMLANGUAGE

#ifdef __cplusplus
extern "C" {
#endif

//arch-timing体系结构定时api

#ifdef CONFIG_ARCH_HAS_CUSTOM_BUSY_WAIT
//忙等待的特定架构实现,usec_to_wait为等待时间,单位为微秒
void arch_busy_wait(uint32_t usec_to_wait);
#endif


//为创建新线程处理arch特定的逻辑
//stack和arch-specific线程状态变量必须被设置
//以便以后尝试切换到这个线程时会成功
//我们将使用请求的线程和参数作为参数进入z_thread_entry
//在这个函数的实现中
//z_setup_new_thread()必须使用线程的堆栈对象中可用堆栈缓冲区的真正边界来调用
//提供的堆栈指针保证正确对齐CPU和ABI需求
//在堆栈指针和堆栈缓冲区边界之间可能保留空间
//用于初始堆栈指针随机化和线程本地存储
//thread->base中的字段将在调用this时被初始化
//参数分别是:未初始化k_thread实例,堆栈对象,对齐的初始堆栈,线程入口函数
//第1个入口点参数,第2个入口点参数,第3个入口点参数
void arch_new_thread(struct k_thread *thread, k_thread_stack_t *stack,
					 char *stack_ptr, k_thread_entry_t entry,
					 void *p1, void *p2, void *p3);

#ifdef CONFIG_USE_SWITCH
//协同上下文切换
//架构在switch句柄的具体语义上有相当大的余地
//但如果可能的话,最佳实现应该做到以下几点:
//
//1)将所有与上下文切换相关的线程状态推入当前堆栈
//2)在保存所有上下文后,更新switched_from参数以包含当前堆栈指针
//switched_from被用作仅输出的参数,它的当前值被忽略(可以是NULL,见下文)
//3)将堆栈指针设置为switch_to中提供的值
//4)从我们切换到的堆栈中弹出所有线程状态并返回
//
//一些arch可以实现thread->switch句柄作为一个指向线程本身的指针
//并将context保存在thread->arch中的某处
//在这种情况下,在从虚拟线程进行初始上下文切换时
//输出线程的thread->switch句柄是NULL
//不是对switched_进行解引用来获得线程指针
//而是减去___thread_t_switch_handle_OFFSET来获得线程指针
//也就是说这样的方案将具有如下行为(在C伪代码中):
//void arch_switch(void *switch_to, void **switched_from)
//{
//    struct k_thread *new = switch_to;
//    struct k_thread *old = CONTAINER_OF(switched_from,
//                                        struct k_thread,
//                                        switch_handle);
//
//    //保存旧的上下文...
//    *switched_from = old;
//    //重加载新的上下文...
//}
//注意无论底层句柄的表示
//传入的switched_from指针必须通过一个非null值写入所有相关的线程状态已经保存
//内核使用这个同步信号来等待另一个CPU的切换完成
//参数分别是:传入线程的句柄,输出线程的switch句柄存储(该位置可能会被更新)
static inline void arch_switch(void *switch_to, void **switched_from);
#else
//协同上下文切换
//必须在使用提供的密钥锁定中断时调用
//这是老式的上下文切换方法,与SMP不兼容
//新的ARCH接口(SMP或UP)被鼓励实现arch_switch()来代替
int arch_swap(unsigned int key);

//设置指定线程的返回值
//假设指定的thread线程正在挂起
//参数分别是:线程实例,函数返回值
static ALWAYS_INLINE void
arch_thread_return_value_set(struct k_thread *thread, unsigned int value);
#endif

#ifdef CONFIG_ARCH_HAS_CUSTOM_SWAP_TO_MAIN
//自定义逻辑进入主线程上下文在早期引导
//用于架构,在早期引导上下文中设置一个虚拟线程来“切换”是不可行的
//参数分别是:主线程实例,初始堆栈,_main应用程序主函数的入口点
void arch_switch_to_main_thread(struct k_thread *main_thread, char *stack_ptr,
				k_thread_entry_t _main);
#endif

#if defined(CONFIG_FPU) && defined(CONFIG_FPU_SHARING)
//禁用浮点上下文保存
//该函数用于禁用特定线程的浮点上下文信息的保存
//对于ARM架构,禁用浮点保留只能在当前线程中请求,不能在isr中请求
//错误返回:
//-EINVAL如果不能执行浮点禁用
int arch_float_disable(struct k_thread *thread);
#endif

//特定于体系结构的能级管理api

//暂停系统,可选的传播原因代码
FUNC_NORETURN void arch_system_halt(unsigned int reason);

//特定于体系结构的IRQ api

//测试当前上下文是否在中断上下文中
//XXX:这是不一致的处理之间的平台wrt异常上下文见:#17656
//如果在中断上下文中,返回true
static inline bool arch_is_in_isr(void);

//特定于体系内存管理单元特定的内存映射api
#ifdef CONFIG_MMU
//将物理内存映射到虚拟地址空间
//这是一个将页面映射到地址空间的低级接口
//当提供未对齐的地址/大小时的行为是未定义的
//它们被假定为与CONFIG_MMU_PAGE_SIZE对齐
//内核处理虚拟地址空间的所有管理;
//当我们调用这个函数时,我们已经确切地知道这个映射将在哪里建立
//如果页表已经为虚拟内存区域安装了映射,那么这些映射将被覆盖
//如果目标架构支持多个页面大小,目前只会使用最小的页面大小
//这个操作不会访问内存范围本身
//这个API必须安全调用isr或异常处理程序
//对这个API的调用被假定是序列化的,实际上所有的使用都来自kernel/mm.c
//它处理虚拟内存管理
//这个API是基础设施的一部分,仍在开发中,可能会改变
//参数分别是:页面对齐的目的虚拟地址映射,页面对齐的源物理地址
//映射内存区域的页对齐大小(以字节为单位),标志(缓存,访问和控制标志,参见K_MAP_*宏)
//错误返回:
//-ENOTSUP不支持的缓存模式,没有合适的后退,或不支持的标志
//-ENOMEM用于其他分页结构的内存不可用
int arch_mem_map(void *dest, uintptr_t addr, size_t size, uint32_t flags);

//删除指定虚拟地址范围的映射
//这是一个用于从地址空间解除页面映射的底层接口
//当这完成时,相关的页表项将被更新,就像没有对该内存范围进行映射一样
//不需要保留以前的上下文,这个函数必须更新所有活动页表中的映射
//当提供未对齐的地址/大小是未定义的行为
//这些被假定是对齐到CONFIG_MMU_PAGE_SIZE
//当提供一个没有被映射的地址范围时的行为是未定义的
//这个函数不应该要求为分页结构分配内存,也不需要释放任何分页结构
//由于所有包含的条目都未映射而产生的空页表可能仍然存在
//实现必须在必要时使tlb失效
//这个API是基础设施的一部分,仍在开发中,可能会改变
//参数分别是:页面对齐的基础虚拟地址,页面对齐的区域大小
void arch_mem_unmap(void *addr, size_t size);
#endif

//arch-misc其他架构api

//早期引导控制台输出钩子
//此函数的定义是可选的
//如果实现了,printk()的任何调用(或由printk支持
//的CONFIG_LOG_MINIMAL日志调用)都会默认向该函数发送字符
//这对于主串行或控制台驱动程序启动之前的早期启动调试是有用的
//可以在运行时用__printk_hook_install()重写
//这个默认的__weak实现不做任何事情
int arch_printk_char_out(int c);

//特定于体系结构的内核初始化钩子
//这个函数在_Cstart的顶部附近被调用
//用于在启动内核的其他部分之前进行附加的特定于体系结构的设置
//已弃用,大多数平台使用prep_c()函数以更简单的方式做同样的事情
static inline void arch_kernel_init(void);

//什么也不做然后返回,打哈欠
static inline void arch_nop(void);

//arch-coredump特定于架构的核心转储api

//核心转储期间特定于体系结构的处理
//在核心转储期间转储特定于体系结构的信息
//接收一个参数异常堆栈帧(特定于平台)
void arch_coredump_info_dump(const z_arch_esf_t *esf);

//获取体系结构指定的目标代码
uint16_t arch_coredump_tgt_code_get(void);

//特定于arch-tls架构的线程本地存储api

//设置栈中特定于架构的TLS区域
//设置线程本地存储的堆栈区域,区域内的结构是结构特有的
//参数分别是:新的线程实例,堆栈
size_t arch_tls_stack_setup(struct k_thread *new_thread, char *stack_ptr);


//包括特定于平台的内联函数实现
#include <kernel_arch_func.h>

#ifdef __cplusplus
}
#endif

#endif
#endif
