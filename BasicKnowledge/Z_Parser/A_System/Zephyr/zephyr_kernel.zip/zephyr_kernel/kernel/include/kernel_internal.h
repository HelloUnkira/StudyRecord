/*
 * zephyr内核
 */

//独立于体系结构的私有内核api
//包含非特定于体系结构的私有内核api

#ifndef ZEPHYR_KERNEL_INCLUDE_KERNEL_INTERNAL_H_
#define ZEPHYR_KERNEL_INCLUDE_KERNEL_INTERNAL_H_

#include <kernel.h>
#include <kernel_arch_interface.h>
#include <string.h>

#ifndef _ASMLANGUAGE

#ifdef __cplusplus
extern "C" {
#endif

//早期的引导功能

void z_bss_zero(void);//清空BSS段

#ifdef CONFIG_XIP
void z_data_copy(void);
#else
static inline void z_data_copy(void)
{
}
#endif

//内核初始化并启动
FUNC_NORETURN void z_cstart(void);

//注册一个线程项
extern FUNC_NORETURN void z_thread_entry(k_thread_entry_t entry,
										 void *p1, void *p2, void *p3);

//初始化一个线程
extern char *z_setup_new_thread(struct k_thread *new_thread,
								k_thread_stack_t *stack, size_t stack_size,
								k_thread_entry_t entry,
								void *p1, void *p2, void *p3,
								int prio, uint32_t options, const char *name);

//从当前线程的资源池中分配对齐的内存
//线程可以被分配一个资源池,该资源池将用于为特定的内核和驱动程序api分配内存
//以这种方式保留的内存应该用k_free()释放
//如果从ISR调用,k_malloc()系统堆将被使用如果它存在
//参数分别是:需要的内存对齐,内存分配大小
void *z_thread_aligned_alloc(size_t align, size_t size);

//从当前线程的资源池中分配一些内存
//线程可以被分配一个资源池,该资源池将用于为特定的内核和驱动程序api分配内存
//以这种方式保留的内存应该用k_free()释放
//如果从ISR调用,k_malloc()系统堆将被使用如果它存在
static inline void *z_thread_malloc(size_t size)
{
	return z_thread_aligned_alloc(0, size);
}

//设置和清除基本线程标志
extern void z_thread_essential_set(void);
extern void z_thread_essential_clear(void);

//在线程中止时进行清理

#if defined(CONFIG_THREAD_MONITOR)
extern void z_thread_monitor_exit(struct k_thread *thread);
#else
#define z_thread_monitor_exit(thread) \
	do {                              \
	} while (false)
#endif

#ifdef CONFIG_USE_SWITCH
//这是一个传统的arch函数
//但是当使用基于开关的z_swap()时,它是一个由内核提供的简单内联函数
static ALWAYS_INLINE void
arch_thread_return_value_set(struct k_thread *thread, unsigned int value)
{
	thread->swap_retval = value;
}
#endif

static ALWAYS_INLINE void
z_thread_return_value_set_with_data(struct k_thread *thread,
				   unsigned int value,
				   void *data)
{
	arch_thread_return_value_set(thread, value);
	thread->base.swap_data = data;
}

//多CPU架构下初始化
extern void z_smp_init(void);

//多CPU架构下时钟初始化
extern void smp_timer_init(void);

//早期的引导
extern void z_early_boot_rand_get(uint8_t *buf, size_t length);

#if CONFIG_STACK_POINTER_RANDOM
extern int z_stack_adjust_initialized;
#endif

#ifdef CONFIG_BOOT_TIME_MEASUREMENT
extern uint32_t z_timestamp_main; //主任务启动时的时间戳
extern uint32_t z_timestamp_idle; //CPU空闲时的时间戳
#endif

extern struct k_thread z_main_thread;


#ifdef CONFIG_MULTITHREADING
extern struct k_thread z_idle_threads[CONFIG_MP_NUM_CPUS];
#endif
extern K_KERNEL_STACK_ARRAY_DEFINE(z_interrupt_stacks, CONFIG_MP_NUM_CPUS,
								   CONFIG_ISR_STACK_SIZE);

#ifdef CONFIG_GEN_PRIV_STACKS
extern uint8_t *z_priv_stack_find(k_thread_stack_t *stack);
#endif

#ifdef CONFIG_USERSPACE
bool z_stack_is_user_capable(k_thread_stack_t *stack);

//内存域设置钩子,从z_setup_new_thread()调用
void z_mem_domain_init_thread(struct k_thread *thread);

//内存域拆卸钩子,从z_thread_single_abort()调用
void z_mem_domain_exit_thread(struct k_thread *thread);

//这个自旋锁:
//-保护完整的活动k_mem_domain对象及其内容
//-序列化对arch_mem_domain_* api的调用
//如果体系结构代码需要访问k_mem_domain结构或它们在任何其他点包含的分区
//这个自旋锁应该被持有,单处理器系统可以通过锁定中断而侥幸逃脱,但不推荐这样做
extern struct k_spinlock z_mem_domain_lock;
#endif

#ifdef CONFIG_GDBSTUB
struct gdb_ctx;

//应由平台层调用,这是gdbstub主循环,在主机上与gdb同步通信
extern int z_gdb_main_loop(struct gdb_ctx *ctx, bool start);
#endif

#ifdef CONFIG_INSTRUMENT_THREAD_SWITCHING
void z_thread_mark_switched_in(void);
void z_thread_mark_switched_out(void);
#else

//在选择要运行的线程后调用
#define z_thread_mark_switched_in()

//在选择要运行的线程之前调用

#define z_thread_mark_switched_out()

#endif

#ifdef __cplusplus
}
#endif

#endif
#endif
