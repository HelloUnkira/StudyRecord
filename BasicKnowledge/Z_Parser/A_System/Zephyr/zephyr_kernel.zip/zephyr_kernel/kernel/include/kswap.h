/*
 * zephyr内核
 */

#ifndef ZEPHYR_KERNEL_INCLUDE_KSWAP_H_
#define ZEPHYR_KERNEL_INCLUDE_KSWAP_H_

#include <ksched.h>
#include <spinlock.h>
#include <kernel_arch_func.h>

//栈溢出检查
#ifdef CONFIG_STACK_SENTINEL
extern void z_check_stack_sentinel(void);
#else
#define z_check_stack_sentinel()
#endif

//在SMP中,irq_lock()是一个自旋锁
//它在上下文切换时被隐式释放并重新获取,以保留现有的语义
//这意味着无论何时我们要返回到一个线程(通过z_swap()或中断/异常返回!)
//我们都需要将锁状态恢复到线程计数器所期望的状态
void z_smp_reacquire_global_lock(struct k_thread *thread);
void z_smp_release_global_lock(struct k_thread *thread);

//上下文切换和与调度相关的例程
#ifdef CONFIG_USE_SWITCH

//当线程交换时,不可避免地会出现SMP竞争——在arch_switch()完成保存状态之前
//它们的线程记录已经在队列中(并且对其他cpu可见)
//在进入一个新线程之前,我们必须为自旋锁切换,参见arch_switch()上的docs
//未来的SMP架构可能需要栅栏/屏障或缓存失效
//目前的没有,可悲的是,Zephyr还没有一个框架
static inline void wait_for_switch(struct k_thread *thread)
{
#ifdef CONFIG_SMP
	volatile void **shp = (void *)&thread->switch_handle;

	while (*shp == NULL) {
		k_busy_wait(1);
	}
#endif
}

//新的上下文切换方式,arch_switch()是一个低层原语,它不知道调度程序或返回值
//SMP需要,因为调度器需要自旋锁,而我们不希望在每个体系结构程序集中都必须这样做
//注意is_spinlock是一个编译时构造,当这个函数展开时将被优化
static ALWAYS_INLINE unsigned int do_swap(unsigned int key,
										  struct k_spinlock *lock,
										  int is_spinlock)
{
	ARG_UNUSED(lock);
	struct k_thread *new_thread, *old_thread;
	//准备进行线程切换,旧线程是当前线程
	old_thread = _current;
	//栈溢出检查
	z_check_stack_sentinel();
	//如果自旋锁锁住了,需要释放自旋锁
	if (is_spinlock) {
		k_spin_release(lock);
	}

#ifdef CONFIG_SMP
	//将switch句柄置空,参见上面的wait_for_switch()
	//请注意,如果我们不切换,我们将它设置回一个非空值!
	//值本身并不重要,因为根据定义_current正在运行并且没有保存状态
	volatile void **shp = (void *)&old_thread->switch_handle;
	*shp = NULL;
#endif
	//获得下一个要执行的线程,从就绪队列中
	new_thread = z_get_next_ready_thread();

#ifdef CONFIG_SMP
	//无需切换的动作
	if (new_thread == old_thread) {
		*shp = old_thread;
	}
#endif

	if (new_thread != old_thread) {
#ifdef CONFIG_TIMESLICING
		z_reset_time_slice();//重置CPU执行时间片
#endif
		//旧线程上下文切换返回初始化
		old_thread->swap_retval = -EAGAIN;

#ifdef CONFIG_SMP
		//清除切换成功标志
		_current_cpu->swap_ok = 0;
		//初始化新线程的执行者为当前的CPU
		new_thread->base.cpu = arch_curr_cpu()->id;

		if (!is_spinlock) {
			//为新线程释放锁,如果需要
			z_smp_release_global_lock(new_thread);
		}
#endif
		//当前线程标记为切换出
		z_thread_mark_switched_out();
		//等待新线程切换
		wait_for_switch(new_thread);
		arch_cohere_stacks(old_thread, NULL, new_thread);
		//当前CPU的当前执行线程被更新为新线程
		_current_cpu->current = new_thread;
		//线程切换
		arch_switch(new_thread->switch_handle,
					&old_thread->switch_handle);
	}
	
	//去掉繁杂的锁,保持switch原语的语义
	if (is_spinlock) {
		arch_irq_unlock(key);
	} else {
		irq_unlock(key);
	}

	return _current->swap_retval;
}

static inline int z_swap_irqlock(unsigned int key)
{
	return do_swap(key, NULL, 0);
}

static inline int z_swap(struct k_spinlock *lock, k_spinlock_key_t key)
{
	return do_swap(key.key, lock, 1);
}

static inline void z_swap_unlocked(void)
{
	struct k_spinlock lock = {};
	k_spinlock_key_t key = k_spin_lock(&lock);

	(void) z_swap(&lock, key);
}

#else

extern int arch_swap(unsigned int key);

static inline int z_swap_irqlock(unsigned int key)
{
	int ret;
	z_check_stack_sentinel();
	ret = arch_swap(key);
	return ret;
}

//如果!USE_SWITCH,那么自旋锁肯定是退化的,因为我们不能处于SMP中
//k_spin_release()调用仅用于验证处理
static ALWAYS_INLINE int z_swap(struct k_spinlock *lock, k_spinlock_key_t key)
{
	k_spin_release(lock);
	return z_swap_irqlock(key.key);
}

static inline void z_swap_unlocked(void)
{
	(void) z_swap_irqlock(arch_irq_lock());
}

#endif

//设置一个“虚拟”线程,用于早期初始化启动CPU上的第一个线程
//需要设置足够的字段,以便上下文切换代码可以使用它来正确存储状态,这将被丢弃
//虚拟线程的内存可以完全未初始化
static inline void z_dummy_thread_init(struct k_thread *dummy_thread)
{
	dummy_thread->base.thread_state = _THREAD_DUMMY;
#ifdef CONFIG_SCHED_CPU_MASK
	dummy_thread->base.cpu_mask = -1;
#endif
	dummy_thread->base.user_options = K_ESSENTIAL;
#ifdef CONFIG_THREAD_STACK_INFO
	dummy_thread->stack_info.start = 0U;
	dummy_thread->stack_info.size = 0U;
#endif
#ifdef CONFIG_USERSPACE
	dummy_thread->mem_domain_info.mem_domain = &k_mem_domain_default;
#endif

	_current_cpu->current = dummy_thread;
}
#endif
