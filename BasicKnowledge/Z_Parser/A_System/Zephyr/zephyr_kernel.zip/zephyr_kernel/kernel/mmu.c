/*
 * zephyr内核
 */

//管理虚拟地址空间

#include <stdint.h>
#include <kernel_arch_interface.h>
#include <spinlock.h>
#include <logging/log.h>

LOG_MODULE_DECLARE(os, CONFIG_KERNEL_LOG_LEVEL);

//自旋锁来保护这个文件中的所有全局变量,并在arch代码中序列化页表更新
static struct k_spinlock mm_lock;

//总体虚拟内存映射
//当内核启动时,所有内存区域都应该在CONFIG_KERNEL_VM_BASE的开头映射到一个大的虚拟区域
//未使用的虚拟内存(不超过CONFIG_KERNEL_VM_SIZE所规定的上限)可以用于运行时内存映射

// +--------------+ <- CONFIG_KERNEL_VM_BASE
// | 映射所有RAM  |
// +--------------+ <- CONFIG_KERNEL_VM_BASE + CONFIG_KERNEL_RAM_SIZE
// | 可用虚拟内存 |    (mapping_limit)当映射向低地址增长时,映射限制也会增加
// |              |
// |..............| <- (mapping_pos)映射位置 (随着映射的增加向低地址增长)
// | 映射         |
// +--------------+
// | 映射         |
// +--------------+
// | ...          |
// +--------------+
// | 映射         |
// +--------------+ <- CONFIG_KERNEL_VM_BASE + CONFIG_KERNEL_VM_SIZE

//目前我们只有一个映射区域,它们是永久的
//这是在大力发展中,可能会改变
 

//内核内存中内存映射的当前位置
//目前所有内核内存映射都是永久的
//内存映射从地址空间的末尾开始然后向低地址增长
//所有这些都在大力开发中,可能会发生变化
static uint8_t *mapping_pos =
	(uint8_t *)((uintptr_t)CONFIG_KERNEL_VM_BASE +
			    (uintptr_t)CONFIG_KERNEL_VM_SIZE);

//虚拟地址映射下限,下面是所有SRAM的永久身份映射
static uint8_t *mapping_limit =
	(uint8_t *)((uintptr_t)CONFIG_KERNEL_VM_BASE +
				   (size_t)CONFIG_KERNEL_RAM_SIZE);

//内存区地址对齐
size_t k_mem_region_align(uintptr_t *aligned_addr, size_t *aligned_size,
						  uintptr_t phys_addr, size_t size, size_t align)
{
	size_t addr_offset;
	//aligned_addr ~ phys_addr ~ phys_addr + size

	//实际的映射区域必须页面对齐,取整物理地址并适当填充区域大小
	*aligned_addr = ROUND_DOWN(phys_addr, align);//地址向下取整
	//物理地址扣除对齐偏移,获得的可用地址偏移
	addr_offset = phys_addr - *aligned_addr;
	//计算对齐后的空间大小
	*aligned_size = ROUND_UP(size + addr_offset, align);
	//返回对齐后产生的地址偏移
	return addr_offset;
}

//物理地址映射
void z_phys_map(uint8_t **virt_ptr, uintptr_t phys, size_t size, uint32_t flags)
{
	uintptr_t aligned_addr, addr_offset;
	size_t aligned_size;
	int ret;
	k_spinlock_key_t key;
	uint8_t *dest_virt;

	//计算对齐后的物理地址
	addr_offset = k_mem_region_align(&aligned_addr, &aligned_size,
									 phys, size, CONFIG_MMU_PAGE_SIZE);
	//静态全局锁
	key = k_spin_lock(&mm_lock);

	//从地址空间顶部挖出一些未使用的虚拟内存
	if ((mapping_pos - aligned_size) < mapping_limit) {
		LOG_ERR("insufficient kernel virtual address space");
		goto fail;
	}
	//偏移到该部分对齐物理区域之前
	mapping_pos -= aligned_size;
	dest_virt = mapping_pos;

	//打印对应的信息,判断
	LOG_DBG("arch_mem_map(%p, 0x%lx, %zu, %x) offset %lu\n",
			 dest_virt, aligned_addr, aligned_size, flags, addr_offset);
	__ASSERT(dest_virt != NULL, "NULL page memory mapping");
	__ASSERT(aligned_size != 0, "0-length mapping at 0x%lx", aligned_addr);
	__ASSERT((uintptr_t)dest_virt <
			((uintptr_t)dest_virt + (aligned_size - 1)),
			"wraparound for virtual address %p (size %zu)",
			dest_virt, size);
	__ASSERT(aligned_addr < (aligned_addr + (size - 1)),
			"wraparound for physical address 0x%lx (size %zu)",
			aligned_addr, size);

	//地址映射,将虚拟地址与物理地址进行关联映射
	ret = arch_mem_map(dest_virt, aligned_addr, aligned_size, flags);
	k_spin_unlock(&mm_lock, key);

	if (ret == 0) {
		//计算虚拟地址区域(偏移回物理地址?)
		*virt_ptr = dest_virt + addr_offset;
	} else {
		//如果所选的缓存模式或访问标志存在不可逾越的问题且没有安全回退,就会发生这种情况
		LOG_ERR("arch_mem_map() to %p returned %d", dest_virt, ret);
		goto fail;
	}
	return;
fail:
	LOG_ERR("memory mapping 0x%lx (size %zu, flags 0x%x) failed", phys, size, flags);
	k_panic();//内存映射错误,系统终止
}
