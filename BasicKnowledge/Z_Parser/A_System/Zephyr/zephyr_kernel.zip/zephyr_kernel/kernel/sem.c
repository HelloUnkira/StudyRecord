/*
 * zephyr内核
 */

//内核信号量对象
//信号量是“计数”类型,也就是说,如果没有线程挂起
//每个“给出”操作将使内部计数增加1
//'init'调用将计数初始化为'initial_count'
//在多个“give”操作之后,可以执行相同数量的“take”操作
//而调用线程不必挂起信号量,或者调用任务不必轮询

#include <kernel.h>
#include <kernel_structs.h>
#include <debug/object_tracing_common.h>
#include <toolchain.h>
#include <wait_q.h>
#include <sys/dlist.h>
#include <ksched.h>
#include <init.h>
#include <syscall_handler.h>
#include <tracing/tracing.h>
#include <sys/check.h>

//我们使用系统范围的锁来同步信号量
//这与使用每个对象的锁相比有不幸的性能影响(信号量被*非常*广泛地使用)
//但是每个对象锁需要大量额外的RAM
//正确的自旋感知信号量实现应该在对count变量的原子访问上进行自旋
//而不是自旋锁本身
//对未来有用的优化…
static struct k_spinlock lock;

#ifdef CONFIG_OBJECT_TRACING
//trace所用
struct k_sem *_trace_list_k_sem;
//完全初始化静态定义的信号量
static int init_sem_module(const struct device *dev)
{
	ARG_UNUSED(dev);
	Z_STRUCT_SECTION_FOREACH(k_sem, sem) {
		SYS_TRACING_OBJ_INIT(k_sem, sem);
	}
	return 0;
}
SYS_INIT(init_sem_module, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);
#endif

//信号量初始化
int z_impl_k_sem_init(struct k_sem *sem, unsigned int initial_count,
					  unsigned int limit)
{
	//限制不能为零,计数不能大于限制
	CHECKIF(limit == 0U || initial_count > limit) {
		return -EINVAL;
	}

	sem->count = initial_count;//初始化计数
	sem->limit = limit;//计数限制
	sys_trace_semaphore_init(sem);//初始化信号量追踪
	z_waitq_init(&sem->wait_q);//初始化等待队列
#if defined(CONFIG_POLL)
	sys_dlist_init(&sem->poll_events);//初始化推送事件
#endif

	SYS_TRACING_OBJ_INIT(k_sem, sem);
	z_object_init(sem);//初始化信号量所有者
	sys_trace_end_call(SYS_TRACE_ID_SEMA_INIT);//初始化信号量结束追踪
	return 0;
}

#ifdef CONFIG_USERSPACE
int z_vrfy_k_sem_init(struct k_sem *sem, unsigned int initial_count,
					  unsigned int limit)
{
	Z_OOPS(Z_SYSCALL_OBJ_INIT(sem, K_OBJ_SEM));
	return z_impl_k_sem_init(sem, initial_count, limit);
}
#include <syscalls/k_sem_init_mrsh.c>
#endif

//推送 产生可用信号量 事件
static inline void handle_poll_events(struct k_sem *sem)
{
#ifdef CONFIG_POLL
	z_handle_obj_poll_events(&sem->poll_events, K_POLL_STATE_SEM_AVAILABLE);
#else
	ARG_UNUSED(sem);
#endif
}

//发送一个信号量
void z_impl_k_sem_give(struct k_sem *sem)
{
	k_spinlock_key_t key = k_spin_lock(&lock);
	struct k_thread *thread;
	sys_trace_semaphore_give(sem);
	//或许信号量等待队列最高优先级线程
	thread = z_unpend_first_thread(&sem->wait_q);
	if (thread != NULL) {
		//如果存在该线程,就绪它
		arch_thread_return_value_set(thread, 0);
		z_ready_thread(thread);
	} else {//否则累加信号量计数
		sem->count += (sem->count != sem->limit) ? 1U : 0U;
		handle_poll_events(sem);//推送信号量事件
	}
	z_reschedule(&lock, key);//启用重调度(内核抢占)
	
	sys_trace_end_call(SYS_TRACE_ID_SEMA_GIVE);
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_sem_give(struct k_sem *sem)
{
	Z_OOPS(Z_SYSCALL_OBJ(sem, K_OBJ_SEM));
	z_impl_k_sem_give(sem);
}
#include <syscalls/k_sem_give_mrsh.c>
#endif

//抢夺信号量
int z_impl_k_sem_take(struct k_sem *sem, k_timeout_t timeout)
{
	int ret = 0;
	//断言检查,当前是否中断环境下,是否非超时阻塞
	__ASSERT(((arch_is_in_isr() == false) || K_TIMEOUT_EQ(timeout, K_NO_WAIT)), "");
	k_spinlock_key_t key = k_spin_lock(&lock);
	sys_trace_semaphore_take(sem);

	//如果当前计数大于0,表明当前生成了可用的信号
	//并且还有一个隐藏信息(等待队列不存在等待项,当前线程是唯一的抢夺者)
	if (likely(sem->count > 0U)) {
		sem->count--;
		k_spin_unlock(&lock, key);
		ret = 0;
		goto out;
	}
	//当前不存在可用信号量,如果非超时等待
	if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		k_spin_unlock(&lock, key);
		ret = -EBUSY;//信号量还未被生成,且等待队列可能有等待者
		goto out;
	}
	//以超时时间timeout挂起当前线程
	ret = z_pend_curr(&lock, key, &sem->wait_q, timeout);
	
out:
	sys_trace_end_call(SYS_TRACE_ID_SEMA_TAKE);
	return ret;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_sem_take(struct k_sem *sem, k_timeout_t timeout)
{
	Z_OOPS(Z_SYSCALL_OBJ(sem, K_OBJ_SEM));
	return z_impl_k_sem_take((struct k_sem *)sem, timeout);
}
#include <syscalls/k_sem_take_mrsh.c>

static inline void z_vrfy_k_sem_reset(struct k_sem *sem)
{
	Z_OOPS(Z_SYSCALL_OBJ(sem, K_OBJ_SEM));
	z_impl_k_sem_reset(sem);
}
#include <syscalls/k_sem_reset_mrsh.c>

static inline unsigned int z_vrfy_k_sem_count_get(struct k_sem *sem)
{
	Z_OOPS(Z_SYSCALL_OBJ(sem, K_OBJ_SEM));
	return z_impl_k_sem_count_get(sem);
}
#include <syscalls/k_sem_count_get_mrsh.c>

#endif
