/*
 * zephyr内核
 */

#include <kernel.h>
#include <toolchain.h>
#include <linker/sections.h>
#include <drivers/timer/system_timer.h>
#include <wait_q.h>
#include <power/power.h>
#include <stdbool.h>
#include <logging/log.h>
#include <ksched.h>

LOG_MODULE_DECLARE(os, CONFIG_KERNEL_LOG_LEVEL);

#ifdef CONFIG_TICKLESS_IDLE_THRESH
#define IDLE_THRESH CONFIG_TICKLESS_IDLE_THRESH
#else
#define IDLE_THRESH 1
#endif

//在没有有效IPI的情况下,为SMP平台回退空闲旋转环
#if (defined(CONFIG_SMP) && !defined(CONFIG_SCHED_IPI_SUPPORTED))
#define SMP_FALLBACK 1
#else
#define SMP_FALLBACK 0
#endif

#ifdef CONFIG_PM
//用于允许pm_system_suspend()实现控制导致pm操作后退出内核闲置的事件通知
unsigned char pm_idle_exit_notify;
//这些几乎肯定会被重写,并且在任何情况下都不做任何事情
//
#if defined(CONFIG_PM_SLEEP_STATES)
void __attribute__((weak)) pm_system_resume(void)
{
}
#endif
//
#if defined(CONFIG_PM_DEEP_SLEEP_STATES)
void __attribute__((weak)) pm_system_resume_from_deep_sleep(void)
{
}
#endif
#endif 

//表示内核处于无tickless模式
//设置内核数据结构空闲字段为正值或K_FOREVER
#if !SMP_FALLBACK && CONFIG_PM
//进入空闲状态
static enum power_states pm_save_idle(int32_t ticks)
{
	//电源状态默认初始化为活跃态
	static enum power_states pm_state = POWER_STATE_ACTIVE;

	//睡眠状态和深度睡眠状态的电源配置
#if (defined(CONFIG_PM_SLEEP_STATES) || \
	 defined(CONFIG_PM_DEEP_SLEEP_STATES))
	pm_idle_exit_notify = 1U;//电源空闲退出通知

	//调用soc接口的suspend hook函数
	//允许进入低功耗状态
	//如果未进入低功耗状态,该函数返回POWER_STATE_ACTIVE
	//在这种情况下,内核将进行正常的空闲处理
	//此功能输入时中断被禁用
	//如果进入了低功耗状态,钩子函数应该在退出之前启用中断
	//这是因为内核在这些情况下不会执行自己的空闲处理
	//也就是说,不会跳过k_cpu_idle()
	//内核的空闲处理重新启用中断,这对内核的调度逻辑至关重要
	pm_state = pm_system_suspend(ticks);
	//如果返回时电源处于活跃态,空闲退出通知标记
	if (pm_state == POWER_STATE_ACTIVE) {
		pm_idle_exit_notify = 0U;
	}
#endif
	return pm_state;
}
#endif

//空闲状态退出
void z_pm_save_idle_exit(int32_t ticks)
{
#if defined(CONFIG_PM_SLEEP_STATES)
	//一些CPU低功耗状态需要在ISR上通知
	//以便在内核切换任务或进程嵌套中断之前完成任何操作
	//这可以通过调用pm_idle_exit_notification_disable()来禁用
	//或者如果不需要也可以忽略它
	if (pm_idle_exit_notify) {
		//如果产生空闲状态退出标记,恢复系统
		pm_system_resume();
	}
#endif
	//时钟空闲滴答可以退出了
	z_clock_idle_exit();
}

//如果空闲优先级很高,不可以被打断时,需要主动交出CPU
#if K_IDLE_PRIO < 0
#define IDLE_YIELD_IF_COOP() k_yield()
//
#else
#define IDLE_YIELD_IF_COOP() do { } while (false)
#endif

//IDLE线程
void idle(void *p1, void *unused2, void *unused3)
{
	struct _cpu *cpu = p1;//获取当前执行CPU
	ARG_UNUSED(unused2);
	ARG_UNUSED(unused3);

	//如果配置启动时间管理
#ifdef CONFIG_BOOT_TIME_MEASUREMENT
	//记录空转开始时的时间戳
	extern uint32_t z_timestamp_idle;
	z_timestamp_idle = k_cycle_get_32();//更新时间戳
#endif

	while (true) {
		//锁定中断以原子方式检查to_abort是否为非null
		//如果是非null则清除它
		int key = arch_irq_lock();
		struct k_thread *to_abort = cpu->pending_abort;
		//如果当前CPU下存在挂起中止态的线程
		if (to_abort) {
			cpu->pending_abort = NULL;//清掉该线程
			arch_irq_unlock(key);

			//在这里可以安全地解锁中断
			//我们已经自动检查并将cpu->pending_abort保存到一个堆栈变量中
			//如果我们在这里被抢占,而另一个线程中止
			//cpu->pending abort将再次被设置,我们将在下面继续循环迭代时处理它
			LOG_DBG("idle %p aborting thread %p",
					_current, to_abort);
			//根据它的实际情况(干掉这个线程)处理
			z_thread_single_abort(to_abort);

			//我们现在必须调用这个调度程序
			//如果我们到了这里,空闲线程会抢占其他所有线程以中止线程
			//现在我们需要弄清楚下一步要做什么
			//并不一定是没有其他可运行线程的情况
			z_reschedule_unlocked();
			continue;
		}

#if SMP_FALLBACK
		arch_irq_unlock(key);
		k_busy_wait(100);//CPU忙等待100个滴答后
		k_yield();//启动调度
#else
//
#ifdef CONFIG_SYS_CLOCK_EXISTS
		//获取下一个超时滴答
		int32_t ticks = z_get_next_timeout_expiry();
		//CONFIG_TICKLESS_IDLE_THRESH的记录行为是
		//系统不应该进入无tickless_idle_thresh的时间段小于该时间段
		//这似乎……很愚蠢,因为它既不节省电力,也不改善延迟
		//但我们需要尊重这个API……
		
		//设置下一个超时过期时间
		z_set_timeout_expiry((ticks < IDLE_THRESH) ? 1 : ticks, true);
#ifdef CONFIG_PM
		_kernel.idle = ticks;
		//检查电源管理策略,决定我们是要睡觉还是只是无所事事
		if (pm_save_idle(ticks) == POWER_STATE_ACTIVE) {
			k_cpu_idle();//无所事事,安安心心等中断
		}
#else
		k_cpu_idle();//无所事事,安安心心等中断
#endif
#else
		k_cpu_idle();//无所事事,安安心心等中断
#endif
		//是否需要主动交出CPU
		IDLE_YIELD_IF_COOP();
#endif
	}
}
