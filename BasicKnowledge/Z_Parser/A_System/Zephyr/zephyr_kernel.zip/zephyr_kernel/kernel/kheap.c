/*
 * zephyr内核
 */

#include <kernel.h>
#include <ksched.h>
#include <wait_q.h>
#include <init.h>

//初始一块内存区为堆
void k_heap_init(struct k_heap *h, void *mem, size_t bytes)
{
	z_waitq_init(&h->wait_q);//初始化等待队列
	sys_heap_init(&h->heap, mem, bytes);//初始化堆
}

//静态初始化堆
static int statics_init(const struct device *unused)
{
	ARG_UNUSED(unused);
	Z_STRUCT_SECTION_FOREACH(k_heap, h) {
		//指定使用系统初始化阶段提供的空间和堆实例做初始化
		k_heap_init(h, h->heap.init_mem, h->heap.init_bytes);
	}
	return 0;
}

SYS_INIT(statics_init, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);

//字节对齐从堆中分配内存
void *k_heap_aligned_alloc(struct k_heap *h, size_t align, size_t bytes,
						   k_timeout_t timeout)
{
	//计算出结束时器的滴答数
	int64_t now, end = z_timeout_end_calc(timeout);
	void *ret = NULL;
	//为该堆上锁
	k_spinlock_key_t key = k_spin_lock(&h->lock);
	//当前环境不是中断环境或超时等待为不等待断言
	__ASSERT(!arch_is_in_isr() || K_TIMEOUT_EQ(timeout, K_NO_WAIT), "");

	while (ret == NULL) {
		//从系统获取堆空间
		ret = sys_heap_aligned_alloc(&h->heap, align, bytes);
		//获取当前滴答数
		now = z_tick_get();
		//如果成功分配到了堆空间或者超时了就返回
		if ((ret != NULL) || ((end - now) <= 0)) {
			break;
		}
		//如果分配失败,以超时时间挂起当前线程到堆的等待队列中
		(void) z_pend_curr(&h->lock, key, &h->wait_q, K_TICKS(end - now));
		key = k_spin_lock(&h->lock);//上锁
	}

	k_spin_unlock(&h->lock, key);//解锁
	return ret;
}

//释放空间回堆中
void k_heap_free(struct k_heap *h, void *mem)
{
	k_spinlock_key_t key = k_spin_lock(&h->lock);//上锁
	//从系统释放堆
	sys_heap_free(&h->heap, mem);
	//如果堆中还有线程等待空间的分配的话
	if (z_unpend_all(&h->wait_q) != 0) {
		//立刻进行重调度,优先保证需要的线程获取空间
		z_reschedule(&h->lock, key);
	} else {
		k_spin_unlock(&h->lock, key);//解锁
	}
}
