/*
 * zephyr内核
 */

//每线程errno访问器函数
//允许访问当前线程的errno而不涉及上下文切换

#include <kernel.h>
#include <syscall_handler.h>

//再次定义_k_neg_e以便在汇编文件中使用,因为errno.h不是汇编语言安全的
//FIXME:浪费4字节
const int _k_neg_eagain = -EAGAIN;

#ifdef CONFIG_ERRNO

#ifdef CONFIG_ERRNO_IN_TLS
//线程全局错误码
__thread int z_errno_var;
//
#else
#ifdef CONFIG_USERSPACE
int *z_impl_z_errno(void)
{
	//初始化到堆栈中的最低地址,以便线程可以直接读/写它
	return &_current->userspace_local_data->errno_var;
}
static inline int *z_vrfy_z_errno(void)
{
	return z_impl_z_errno();
}
#include <syscalls/z_errno_mrsh.c>
//
#else
int *z_impl_z_errno(void)
{
	return &_current->errno_var;
}
#endif
#endif
#endif
