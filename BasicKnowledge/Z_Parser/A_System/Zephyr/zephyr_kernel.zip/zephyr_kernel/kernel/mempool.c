/*
 * zephyr内核
 */

#include <kernel.h>
#include <string.h>
#include <sys/math_extras.h>
#include <sys/util.h>

//地址对齐的堆分配
static void *z_heap_aligned_alloc(struct k_heap *heap, size_t align, size_t size)
{
	uint8_t *mem;
	struct k_heap **heap_ref;
	//获取对齐空间大小
	size_t excess = MAX(sizeof(struct k_heap *), align);

	//获取一个足够大的块来保存初始(对齐和隐藏)堆指针,以及调用者请求的空间
	if (size_add_overflow(size, excess, &size)) {
		return NULL;//size被重写为size + excess
	}

	//从堆中分配对应空间大小的区域
	mem = k_heap_aligned_alloc(heap, align, size, K_NO_WAIT);
	if (mem == NULL) {
		return NULL;
	}

	//创建大于等于(void *)-1的值,它是标记
	//该标记之前将会保存堆地址,也可能该标记被堆地址恰好覆盖
	memset(mem, 0xff, excess);
	heap_ref = (struct k_heap **)mem;
	*heap_ref = heap;//堆地址保存到mem开始的部分

	//将块的用户区部分的地址返回给调用者
	return mem + excess;
}

void k_free(void *ptr)
{
	struct k_heap **heap_ref;

	if (ptr != NULL) {
		
		for (heap_ref = &((struct k_heap **)ptr)[-1];
			*heap_ref == (struct k_heap *)-1; --heap_ref) {
		}
		//重定向到实际开始位置
		ptr = (uint8_t *)heap_ref;
		//释放这块区域,连带着保存堆地址信息的部分
		k_heap_free(*heap_ref, ptr);
	}
}

#if (CONFIG_HEAP_MEM_POOL_SIZE > 0)

K_HEAP_DEFINE(_system_heap, CONFIG_HEAP_MEM_POOL_SIZE);
#define _SYSTEM_HEAP (&_system_heap)

//内存空间分配
void *k_aligned_alloc(size_t align, size_t size)
{
	//对齐检查,该大小是地址空间的整数倍且为2的次方数
	__ASSERT(align / sizeof(void *) >= 1 && 
			(align % sizeof(void *)) == 0,
			"align must be a multiple of sizeof(void *)");

	__ASSERT((align & (align - 1)) == 0,
			 "align must be a power of 2");

	return z_heap_aligned_alloc(_SYSTEM_HEAP, align, size);
}

//动态内存分配
void *k_calloc(size_t nmemb, size_t size)
{
	void *ret;
	size_t bounds;

	if (size_mul_overflow(nmemb, size, &bounds)) {
		return NULL;//获取区域为bounds = nmemb * size
	}

	ret = k_malloc(bounds);
	if (ret != NULL) {//为该空间清空为0
		(void)memset(ret, 0, bounds);
	}
	return ret;
}

//线程分配系统内存区
void k_thread_system_pool_assign(struct k_thread *thread)
{
	thread->resource_pool = _SYSTEM_HEAP;
}
#else
#define _SYSTEM_HEAP	NULL
#endif

//为线程分配堆空间
void *z_thread_aligned_alloc(size_t align, size_t size)
{
	void *ret;
	struct k_heap *heap;

	if (k_is_in_isr()) {
		//中断环境下不可分配
		heap = _SYSTEM_HEAP;
	} else {
		//否则确认堆地址
		heap = _current->resource_pool;
	}

	if (heap) {//从该堆分配空间
		ret = z_heap_aligned_alloc(heap, align, size);
	} else {
		ret = NULL;
	}

	return ret;
}
