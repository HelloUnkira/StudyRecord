/*
 * zephyr内核
 */

//互斥内核服务
//这个模块包含处理互斥锁和解锁的例程
//互斥锁实现优先级继承算法,提高拥有线程的优先级
//以匹配最高优先级的线程等待互斥锁的优先级
//
//每个有助于优先级继承的互斥锁必须按照获得它的相反顺序被释放
//此外,必须在优先级最近一次“碰撞”之后的某个点获取每个有助于提高所拥有线程优先级的互斥锁
//
//例如,如果线程A有两个互斥锁来提高它的优先级
//那么在线程A的优先级因为拥有第一个互斥锁M1而被挤掉之后,线程A必须获得第二个互斥锁M2
//当释放互斥锁时,线程A必须在释放M1之前释放M2
//未能遵循此嵌套模型可能导致线程以意外的优先级级别运行(过高或过低)

#include <kernel.h>
#include <kernel_structs.h>
#include <toolchain.h>
#include <ksched.h>
#include <wait_q.h>
#include <errno.h>
#include <init.h>
#include <syscall_handler.h>
#include <debug/object_tracing_common.h>
#include <tracing/tracing.h>
#include <sys/check.h>
#include <logging/log.h>

LOG_MODULE_DECLARE(os, CONFIG_KERNEL_LOG_LEVEL);

//我们在这里使用全局自旋锁,因为一些同步是为了保护所有者线程的优先级
//而这些优先级不是单个k_mutex的“一部分”
//应该将API的这些部分移到调度器锁下,这样我们就可以拆分了
static struct k_spinlock lock;

#ifdef CONFIG_OBJECT_TRACING
//trace所用
struct k_mutex *_trace_list_k_mutex;

//完成静态定义互斥锁的初始化
static int init_mutex_module(const struct device *dev)
{
	ARG_UNUSED(dev);
	Z_STRUCT_SECTION_FOREACH(k_mutex, mutex) {
		SYS_TRACING_OBJ_INIT(k_mutex, mutex);
	}
	return 0;
}

SYS_INIT(init_mutex_module, PRE_KERNEL_1, CONFIG_KERNEL_INIT_PRIORITY_OBJECTS);

#endif

//初始化一个互斥锁
int z_impl_k_mutex_init(struct k_mutex *mutex)
{
	mutex->owner = NULL;//互斥锁不存在所有者
	mutex->lock_count = 0U;//锁次数为空
	sys_trace_mutex_init(mutex);//互斥锁追踪定位
	z_waitq_init(&mutex->wait_q);//初始化互斥锁等待队列
	
	SYS_TRACING_OBJ_INIT(k_mutex, mutex);
	z_object_init(mutex);//初始化互斥锁对象
	sys_trace_end_call(SYS_TRACE_ID_MUTEX_INIT);
	return 0;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_mutex_init(struct k_mutex *mutex)
{
	Z_OOPS(Z_SYSCALL_OBJ_INIT(mutex, K_OBJ_MUTEX));
	return z_impl_k_mutex_init(mutex);
}
#include <syscalls/k_mutex_init_mrsh.c>
#endif

//为继承获取新的优先级
static int32_t new_prio_for_inheritance(int32_t target, int32_t limit)
{
	//目标优先级检查是否超出限制
	int new_prio = z_is_prio_higher(target, limit) ? target : limit;
	new_prio = z_get_new_prio_with_ceiling(new_prio);
	return new_prio;
}

//调整互斥锁所有者优先级
static bool adjust_owner_prio(struct k_mutex *mutex, int32_t new_prio)
{
	//如果所有者优先级不等于目标优先级
	if (mutex->owner->base.prio != new_prio) {
		LOG_DBG("%p (ready (y/n): %c) prio changed to %d (was %d)",
				mutex->owner, z_is_thread_ready(mutex->owner) ?
				'y' : 'n', new_prio, mutex->owner->base.prio);
		//调整互斥锁所有者优先级
		return z_set_prio(mutex->owner, new_prio);
	}
	return false;
}

//抢夺互斥锁
int z_impl_k_mutex_lock(struct k_mutex *mutex, k_timeout_t timeout)
{
	int new_prio;
	k_spinlock_key_t key;
	bool resched = false;
	//中断环境断言
	__ASSERT(!arch_is_in_isr(), "mutexes cannot be used inside ISRs");
	//互斥锁抢锁动作追踪定位
	sys_trace_mutex_lock(mutex);
	key = k_spin_lock(&lock);

	//如果互斥锁为被使用或者互斥锁的所有者是当前线程
	if (likely((mutex->lock_count == 0U) || (mutex->owner == _current))) {
		//如果是互斥锁未被使用,则它的源优先级为当前线程优先级
		//因为是它抢到了第一个锁,所以它的初始优先级是需要被记录的
		//因为随着将来其他等待者的需求,它本身的优先级会被调整
		//所以需要先为它记录自己本来的优先级
		mutex->owner_orig_prio = (mutex->lock_count == 0U) ?
								  _current->base.prio :
								  mutex->owner_orig_prio;

		mutex->lock_count++;//互斥锁上锁
		mutex->owner = _current;//互斥锁所有者定位到当前线程

		LOG_DBG("%p took mutex %p, count: %d, orig prio: %d",
				_current, mutex, mutex->lock_count,
				mutex->owner_orig_prio);

		k_spin_unlock(&lock, key);
		//互斥锁抢锁动作结束追踪定位
		sys_trace_end_call(SYS_TRACE_ID_MUTEX_LOCK);
		return 0;
	}

	//如果不延迟等待互斥锁
	if (unlikely(K_TIMEOUT_EQ(timeout, K_NO_WAIT))) {
		k_spin_unlock(&lock, key);//解锁
		//互斥锁抢锁动作结束追踪定位
		sys_trace_end_call(SYS_TRACE_ID_MUTEX_LOCK);
		return -EBUSY;
	}

	//需要延迟等待,获取新优先级
	new_prio = new_prio_for_inheritance(_current->base.prio,
										mutex->owner->base.prio);
	LOG_DBG("adjusting prio up on mutex %p", mutex);

	if (z_is_prio_higher(new_prio, mutex->owner->base.prio)) {
		//调整互斥锁所有者优先级,拉高所有者优先级
		//当前线程拿不到锁只能被迫等待,为了能让自己快速获得锁
		//只能提升所有者优先级,以便它快速使用完锁,然后释放
		resched = adjust_owner_prio(mutex, new_prio);
	}
	
	//将当前线程以timeout延迟挂起到互斥锁的等待队列中
	int got_mutex = z_pend_curr(&lock, key, &mutex->wait_q, timeout);

	LOG_DBG("on mutex %p got_mutex value: %d", mutex, got_mutex);
	LOG_DBG("%p got mutex %p (y/n): %c", _current, mutex,
			got_mutex ? 'y' : 'n');

	if (got_mutex == 0) {
		//互斥锁抢锁动作结束追踪定位
		sys_trace_end_call(SYS_TRACE_ID_MUTEX_LOCK);
		return 0;
	}

	//超时,还未等到互斥锁
	LOG_DBG("%p timeout on mutex %p", _current, mutex);
	key = k_spin_lock(&lock);

	//是不是前面还存在更高优先级的等待者,为了能让自己拿到锁
	//需要让所有者快速释放掉锁,并且让优先级更高的等待者获得锁然后使用掉
	//获取等待队列最高优先级线程,强行拉高锁的持有者为等待者中最高优先级别
	//因为这是等待者最大可以贡献给所有者的优先级
	struct k_thread *waiter = z_waitq_head(&mutex->wait_q);

	//如果它存在,调整优先级
	new_prio = (waiter != NULL) ?
		new_prio_for_inheritance(waiter->base.prio, mutex->owner_orig_prio) :
		mutex->owner_orig_prio;

	LOG_DBG("adjusting prio down on mutex %p", mutex);

	//重新调整互斥锁所有者的优先级,为等待者中最大优先级
	resched = adjust_owner_prio(mutex, new_prio) || resched;

	if (resched) {//启用重调度(内核抢占)
		z_reschedule(&lock, key);
	} else {
		k_spin_unlock(&lock, key);
	}

	//互斥锁抢锁动作结束追踪定位
	sys_trace_end_call(SYS_TRACE_ID_MUTEX_LOCK);
	return -EAGAIN;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_mutex_lock(struct k_mutex *mutex,
				      k_timeout_t timeout)
{
	Z_OOPS(Z_SYSCALL_OBJ(mutex, K_OBJ_MUTEX));
	return z_impl_k_mutex_lock(mutex, timeout);
}
#include <syscalls/k_mutex_lock_mrsh.c>
#endif

//释放互斥锁
int z_impl_k_mutex_unlock(struct k_mutex *mutex)
{
	struct k_thread *new_owner;
	//中断环境断言
	__ASSERT(!arch_is_in_isr(), "mutexes cannot be used inside ISRs");

	CHECKIF(mutex->owner == NULL) {
		return -EINVAL;//如果互斥锁不存在所有者
	}
	
	CHECKIF(mutex->owner != _current) {
		return -EPERM;//当前线程不拥有互斥锁
	}

	//尝试解锁已解锁的互斥锁
	//如果当前线程等于mutex ->owner
	//则mutex->lock_count不能为零,因此不需要进行下溢检查
	//使用assert来捕获未定义的行为
	__ASSERT_NO_MSG(mutex->lock_count > 0U);

	//互斥锁解锁追踪开始
	sys_trace_mutex_unlock(mutex);
	z_sched_lock();//关闭调度器
	LOG_DBG("mutex %p lock_count: %d", mutex, mutex->lock_count);

	//如果我们是线程的所有者
	//并且count大于1,则将count减1,并返回并保持当前线程为线程所有者
	if (mutex->lock_count - 1U != 0U) {
		mutex->lock_count--;
		goto k_mutex_unlock_return;
	}

	//如果需要彻底释放互斥锁
	k_spinlock_key_t key = k_spin_lock(&lock);
	//互斥锁的优先级调整回源所有者优先级
	adjust_owner_prio(mutex, mutex->owner_orig_prio);
	//如果有线程在等互斥锁的释放的话,那就将锁给它
	new_owner = z_unpend_first_thread(&mutex->wait_q);
	//更新互斥锁所有者,现在锁是它的了
	mutex->owner = new_owner;
	LOG_DBG("new owner of mutex %p: %p (prio: %d)",
			mutex, new_owner, new_owner ? new_owner->base.prio : -1000);

	if (new_owner != NULL) {//如果存在该所有者
		//由于等待队列是基于优先级的
		//所以新所有者的优先级已经高于或等于第一个服务者的优先级
		//不需要调整它的优先级
		//这是第一个获取该锁的线程,现在源优先级调整为它的优先级
		mutex->owner_orig_prio = new_owner->base.prio;
		//设置k_thread.callee_saved.retval = 0
		arch_thread_return_value_set(new_owner, 0);
		z_ready_thread(new_owner);//锁的持有者加入到就绪队列
		z_reschedule(&lock, key);//启用重调度(内核抢占)
	} else {//没有线程需要该锁
		mutex->lock_count = 0U;
		k_spin_unlock(&lock, key);
	}

k_mutex_unlock_return:
	k_sched_unlock();
	sys_trace_end_call(SYS_TRACE_ID_MUTEX_UNLOCK);
	return 0;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_mutex_unlock(struct k_mutex *mutex)
{
	Z_OOPS(Z_SYSCALL_OBJ(mutex, K_OBJ_MUTEX));
	return z_impl_k_mutex_unlock(mutex);
}
#include <syscalls/k_mutex_unlock_mrsh.c>
#endif
