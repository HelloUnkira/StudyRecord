/*
 * zephyr内核
 */

#include <string.h>
#include <device.h>
#include <sys/atomic.h>
#include <syscall_handler.h>

//各个核心的初始化项

extern const struct init_entry __init_start[];
extern const struct init_entry __init_PRE_KERNEL_1_start[];
extern const struct init_entry __init_PRE_KERNEL_2_start[];
extern const struct init_entry __init_POST_KERNEL_start[];
extern const struct init_entry __init_APPLICATION_start[];
extern const struct init_entry __init_end[];

#ifdef CONFIG_SMP
extern const struct init_entry __init_SMP_start[];
#endif

extern const struct device __device_start[];
extern const struct device __device_end[];

extern uint32_t __device_init_status_start[];

#ifdef CONFIG_PM_DEVICE
extern uint32_t __device_busy_start[];
extern uint32_t __device_busy_end[];
#define DEVICE_BUSY_SIZE (__device_busy_end - __device_busy_start)
#endif

//在给定的级别上执行所有的init条目初始化函数
//为INIT_ENTRY_DEFINE()宏使用指定的级别创建的每个初始化入口对象调用初始化例程
//链接器脚本将初始化条目对象按照它们需要被调用的顺序放置在内存中
//用符号表示一层从哪里离开,下一层从哪里开始
void z_sys_init_run_level(int32_t level)
{
	static const struct init_entry *levels[] = {
		__init_PRE_KERNEL_1_start,
		__init_PRE_KERNEL_2_start,
		__init_POST_KERNEL_start,
		__init_APPLICATION_start,
#ifdef CONFIG_SMP
		__init_SMP_start,
#endif
		/* End marker */
		__init_end,
	};
	const struct init_entry *entry;

	for (entry = levels[level]; entry < levels[level+1]; entry++) {
		const struct device *dev = entry->dev;

		if (dev != NULL) {
			z_object_init(dev);
		}

		if ((entry->init(dev) != 0) && (dev != NULL)) {
			//初始化失败
			//设置init状态位,这样设备就不会被声明为ready
			sys_bitfield_set_bit((mem_addr_t) __device_init_status_start,
								 (dev - __device_start));
		}
	}
}

const struct device *z_impl_device_get_binding(const char *name)
{
	const struct device *dev;

	//将搜索分成两个循环:在常见的情况下,设备名存储在ROM中(并由用户使用CONFIG_*宏引用)
	//只执行廉价的指针比较,为回退保留字符串比较
	for (dev = __device_start; dev != __device_end; dev++) {
		if (z_device_ready(dev) && (dev->name == name)) {
			return dev;
		}
	}

	for (dev = __device_start; dev != __device_end; dev++) {
		if (z_device_ready(dev) && (strcmp(name, dev->name) == 0)) {
			return dev;
		}
	}

	return NULL;
}

#ifdef CONFIG_USERSPACE
static inline const struct device *z_vrfy_device_get_binding(const char *name)
{
	char name_copy[Z_DEVICE_MAX_NAME_LEN];
	if (z_user_string_copy(name_copy, (char *)name, sizeof(name_copy))
	    != 0) {
		return 0;
	}
	return z_impl_device_get_binding(name_copy);
}
#include <syscalls/device_get_binding_mrsh.c>
#endif

size_t z_device_get_all_static(struct device const **devices)
{
	*devices = __device_start;
	return __device_end - __device_start;
}

bool z_device_ready(const struct device *dev)
{
	//Set bit设备初始化失败
	return !(sys_bitfield_test_bit((mem_addr_t)__device_init_status_start,
								   (dev - __device_start)));
}

#ifdef CONFIG_PM_DEVICE
int device_pm_control_nop(const struct device *unused_device,
						  uint32_t unused_ctrl_command,
						  void *unused_context,
						  device_pm_cb cb,
						  void *unused_arg)
{
	return -ENOTSUP;
}

int device_any_busy_check(void)
{
	int i = 0;
	for (i = 0; i < DEVICE_BUSY_SIZE; i++) {
		if (__device_busy_start[i] != 0U) {
			return -EBUSY;
		}
	}
	return 0;
}

int device_busy_check(const struct device *chk_dev)
{
	if (atomic_test_bit((const atomic_t *)__device_busy_start,
						(chk_dev - __device_start))) {
		return -EBUSY;
	}
	return 0;
}

#endif

void device_busy_set(const struct device *busy_dev)
{
#ifdef CONFIG_PM_DEVICE
	atomic_set_bit((atomic_t *) __device_busy_start,
				   (busy_dev - __device_start));
#else
	ARG_UNUSED(busy_dev);
#endif
}

void device_busy_clear(const struct device *busy_dev)
{
#ifdef CONFIG_PM_DEVICE
	atomic_clear_bit((atomic_t *) __device_busy_start,
					 (busy_dev - __device_start));
#else
	ARG_UNUSED(busy_dev);
#endif
}
