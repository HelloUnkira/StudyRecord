/*
 * zephyr内核
 */

//内核异步事件轮询接口
//这种轮询机制允许同时等待多个事件,这些事件可以是直接触发的
//也可以是由内核对象或其他内核构造触发的

#include <kernel.h>
#include <kernel_structs.h>
#include <kernel_internal.h>
#include <wait_q.h>
#include <ksched.h>
#include <syscall_handler.h>
#include <sys/dlist.h>
#include <sys/util.h>
#include <sys/__assert.h>
#include <stdbool.h>

//单个子系统锁
//在高度竞争的SMP系统上,对每个事件进行锁定会更好
//但这里的原始锁定方案是微妙的(它依赖于释放/重新获取某些区域的锁
//以控制延迟,有时很难确切地看到给定关键部分中的数据),稍后进行同步端口优化
static struct k_spinlock lock;

//轮询模式:无模式,轮询模式,触发模式
enum POLL_MODE { MODE_NONE, MODE_POLL, MODE_TRIGGERED};

static int signal_poller(struct k_poll_event *event, uint32_t state);
static int signal_triggered_work(struct k_poll_event *event, uint32_t status);

//轮询事件初始化
void k_poll_event_init(struct k_poll_event *event, uint32_t type,
					   int mode, void *obj)
{
	__ASSERT(mode == K_POLL_MODE_NOTIFY_ONLY,//断言轮询仅通知模式
			 "only NOTIFY_ONLY mode is supported\n");
	__ASSERT(type < (BIT(_POLL_NUM_TYPES)), "invalid type\n");//断言类型检查
	__ASSERT(obj != NULL, "must provide an object\n");//断言对象要存在

	event->poller = NULL;
	//event->tag未初始化:如果需要，用户将设置它
	event->type = type;
	event->state = K_POLL_STATE_NOT_READY;
	event->mode = mode;
	event->unused = 0U;
	event->obj = obj;
}

//必须在中断锁定的情况下调用
static inline bool is_condition_met(struct k_poll_event *event, uint32_t *state)
{	//检查事件的类型
	switch (event->type) {
	case K_POLL_TYPE_SEM_AVAILABLE:
		if (k_sem_count_get(event->sem) > 0U) {
			//是一个信号量事件,且是生成信号量事件
			*state = K_POLL_STATE_SEM_AVAILABLE;
			return true;
		}
		break;
	case K_POLL_TYPE_DATA_AVAILABLE:
		if (!k_queue_is_empty(event->queue)) {
			//是一个队列数据产生事件,生成可用数据
			*state = K_POLL_STATE_FIFO_DATA_AVAILABLE;
			return true;
		}
		break;
	case K_POLL_TYPE_SIGNAL:
		if (event->signal->signaled != 0U) {
			//生成信号
			*state = K_POLL_STATE_SIGNALED;
			return true;
		}
		break;
	case K_POLL_TYPE_IGNORE:
		//忽略的信号
		break;
	default:
		//服务区外的信号
		__ASSERT(false, "invalid event type (0x%x)\n", event->type);
		break;
	}
	return false;
}

//获取轮询者的所有者(线程)
static struct k_thread *poller_thread(struct z_poller *p)
{
	return p ? CONTAINER_OF(p, struct k_thread, poller) : NULL;
}

//添加事件
static inline void add_event(sys_dlist_t *events, struct k_poll_event *event,
							 struct z_poller *poller)
{
	struct k_poll_event *pending;
	//从事件组获取最后一个事件的副本
	pending = (struct k_poll_event *)sys_dlist_peek_tail(events);

	if ((pending == NULL) || //如果事件不存在或者该事件所有者优先级较低
	    z_is_t1_higher_prio_than_t2(poller_thread(pending->poller),
									poller_thread(poller))) {
		//把新事件追加到事件组的尾部
		sys_dlist_append(events, &event->_node);
		return;
	}

	//否则遍历事件组
	SYS_DLIST_FOR_EACH_CONTAINER(events, pending, _node) {
		if (z_is_t1_higher_prio_than_t2(poller_thread(poller),
										poller_thread(pending->poller))) {
			//将事件插入到一个合适的位置
			sys_dlist_insert(&pending->_node, &event->_node);
			return;
		}
	}
	
	//否则遍历完整个事件组,追加到尾部
	sys_dlist_append(events, &event->_node);
}

//必须在中断锁定的情况下调用
static inline void register_event(struct k_poll_event *event,
								  struct z_poller *poller)
{	//为轮询者注册一个事件
	switch (event->type) {
	case K_POLL_TYPE_SEM_AVAILABLE:
		__ASSERT(event->sem != NULL, "invalid semaphore\n");
		add_event(&event->sem->poll_events, event, poller);
		break;
	case K_POLL_TYPE_DATA_AVAILABLE:
		__ASSERT(event->queue != NULL, "invalid queue\n");
		add_event(&event->queue->poll_events, event, poller);
		break;
	case K_POLL_TYPE_SIGNAL:
		__ASSERT(event->signal != NULL, "invalid poll signal\n");
		add_event(&event->signal->poll_events, event, poller);
		break;
	case K_POLL_TYPE_IGNORE:
		break;//忽略类型的事件追加,因为没有意义
	default:
		__ASSERT(false, "invalid event type\n");
		break;
	}
	//确认该追加事件的所有者
	event->poller = poller;
}

//必须在中断锁定的情况下调用
static inline void clear_event_registration(struct k_poll_event *event)
{
	bool remove = false;
	//清除一个注册的事件
	event->poller = NULL;//解除与所有者的关联
	switch (event->type) {//确认该事件是否是有意义的(无意义的事件不存在事件组中)
	case K_POLL_TYPE_SEM_AVAILABLE:
		__ASSERT(event->sem != NULL, "invalid semaphore\n");
		remove = true;
		break;
	case K_POLL_TYPE_DATA_AVAILABLE:
		__ASSERT(event->queue != NULL, "invalid queue\n");
		remove = true;
		break;
	case K_POLL_TYPE_SIGNAL:
		__ASSERT(event->signal != NULL, "invalid poll signal\n");
		remove = true;
		break;
	case K_POLL_TYPE_IGNORE:
		break;
	default:
		__ASSERT(false, "invalid event type\n");
		break;
	}
	//从事件组中移除该事件
	if (remove && sys_dnode_is_linked(&event->_node)) {
		sys_dlist_remove(&event->_node);
	}
}

//必须在中断锁定的情况下调用
static inline void clear_event_registrations(struct k_poll_event *events,
											 int num_events,
											 k_spinlock_key_t key)
{
	while (num_events--) {//清空注册的事件集
		clear_event_registration(&events[num_events]);
		k_spin_unlock(&lock, key);
		key = k_spin_lock(&lock);
	}
}

//设置事件的就绪状态
static inline void set_event_ready(struct k_poll_event *event, uint32_t state)
{
	event->poller = NULL;
	event->state |= state;
}

//注册事件集
static inline int register_events(struct k_poll_event *events,
								  int num_events,
								  struct z_poller *poller,
								  bool just_check)
{
	int events_registered = 0;

	for (int ii = 0; ii < num_events; ii++) {
		k_spinlock_key_t key;
		uint32_t state;
		key = k_spin_lock(&lock);
		//检查对应事件的合法性
		if (is_condition_met(&events[ii], &state)) {
			//设置该事件有效
			set_event_ready(&events[ii], state);
			poller->is_polling = false;//还未投送该事件
		} else if (!just_check && poller->is_polling) {
			register_event(&events[ii], poller);//事件合法直接注册
			events_registered += 1;//注册成功数量
		}
		k_spin_unlock(&lock, key);
	}

	return events_registered;
}

//信号量的投送者
static int signal_poller(struct k_poll_event *event, uint32_t state)
{
	//获取事件投送者的所有者
	struct k_thread *thread = poller_thread(event->poller);
	__ASSERT(thread != NULL, "poller should have a thread\n");
	//如果线程不是挂起态
	if (!z_is_thread_pending(thread)) {
		return 0;
	}
	//如果线程是超时过期态
	if (z_is_thread_timeout_expired(thread)) {
		return -EAGAIN;
	}
	//取消线程的挂起
	z_unpend_thread(thread);
	//为该线程配置k_thread.callee_saved.retval
	arch_thread_return_value_set(thread,
		state == K_POLL_STATE_CANCELLED ? -EINTR : 0);
	//如果线程不是就绪态
	if (!z_is_thread_ready(thread)) {
		return 0;
	}
	//就绪该线程
	z_ready_thread(thread);
	return 0;
}

//投送事件
int z_impl_k_poll(struct k_poll_event *events, int num_events,
				  k_timeout_t timeout)
{
	int events_registered;
	k_spinlock_key_t key;
	struct z_poller *poller = &_current->poller;//获取当前线程投送者
	poller->is_polling = true;//配置其为正在推送
	poller->mode = MODE_POLL;//设置模式为投送态
	//断言检查是否在中断环境下,事件集是否为空,事件数是否合法
	__ASSERT(!arch_is_in_isr(), "");
	__ASSERT(events != NULL, "NULL events\n");
	__ASSERT(num_events >= 0, "<0 events\n");
	//以当前线程为投送者将事件全部投送
	events_registered = register_events(events, num_events, poller,
										K_TIMEOUT_EQ(timeout, K_NO_WAIT));
	key = k_spin_lock(&lock);

	//如果我们不再轮询,这意味着至少一个事件条件是满足的
	//当循环通过这里的事件或因为一个注册的事件已经改变了其状态
	if (!poller->is_polling) {
		//如果投送完毕,则清除其注册状态
		clear_event_registrations(events, events_registered, key);
		k_spin_unlock(&lock, key);
		return 0;
	}
	//否则如果还在投送
	poller->is_polling = false;
	
	if (K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		k_spin_unlock(&lock, key);//不等状态变迁
		return -EAGAIN;
	}
	//初始化一个临时的等待队列
	_wait_q_t wait_q = Z_WAIT_Q_INIT(&wait_q);
	//将其挂起到这个临时的等待队列中(什么鬼,这也行,自己给自己盖房子?)
	int swap_rc = z_pend_curr(&lock, key, &wait_q, timeout);

	//清除所有事件注册
	//如果在循环中发生了事件,我们已经有了一个触发事件
	//这没问题它们会在事件列表中结束;如果我们超时
	//事件发生在我们在这个循环,也是好的,因为我们已经知道返回代码(eagain)
	//即使他们被添加到列表的事件发生时
	//用户必须首先检查返回代码,这整个事件列表状态无效
	key = k_spin_lock(&lock);
	//清除事件的注册状态,如果事件还在的话
	clear_event_registrations(events, events_registered, key);
	k_spin_unlock(&lock, key);

	return swap_rc;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_poll(struct k_poll_event *events,
								int num_events, k_timeout_t timeout)
{
	int ret;
	k_spinlock_key_t key;
	struct k_poll_event *events_copy = NULL;
	uint32_t bounds;

	//验证事件缓冲区并在已分配的内核端缓冲区中复制它
	if (Z_SYSCALL_VERIFY(num_events >= 0)) {
		ret = -EINVAL;
		goto out;
	}
	//bounds = sizeof(struct k_poll_event) * num_events
	if (Z_SYSCALL_VERIFY_MSG(!u32_mul_overflow(num_events,
							 sizeof(struct k_poll_event),
							 &bounds),
							 "num_events too large")) {
		ret = -EINVAL;
		goto out;
	}
	//申请动态空间
	events_copy = z_thread_malloc(bounds);
	if (!events_copy) {
		ret = -ENOMEM;
		goto out;
	}
	key = k_spin_lock(&lock);
	if (Z_SYSCALL_MEMORY_WRITE(events, bounds)) {
		k_spin_unlock(&lock, key);
		goto oops_free;
	}
	//将整个事件集数据拷贝到
	(void)memcpy(events_copy, events, bounds);
	k_spin_unlock(&lock, key);

	//验证events_copy内部的内容
	for (int i = 0; i < num_events; i++) {
		//获取事件的副本
		struct k_poll_event *e = &events_copy[i];
		if (Z_SYSCALL_VERIFY(e->mode == K_POLL_MODE_NOTIFY_ONLY)) {
			ret = -EINVAL;//事件如果是只读通知模式
			goto out_free;
		}

		switch (e->type) {//检查事件的类型合法性
		case K_POLL_TYPE_IGNORE:
			break;
		case K_POLL_TYPE_SIGNAL:
			Z_OOPS(Z_SYSCALL_OBJ(e->signal, K_OBJ_POLL_SIGNAL));
			break;
		case K_POLL_TYPE_SEM_AVAILABLE:
			Z_OOPS(Z_SYSCALL_OBJ(e->sem, K_OBJ_SEM));
			break;
		case K_POLL_TYPE_DATA_AVAILABLE:
			Z_OOPS(Z_SYSCALL_OBJ(e->queue, K_OBJ_QUEUE));
			break;
		default:
			ret = -EINVAL;
			goto out_free;
		}
	}
	//事件投送
	ret = k_poll(events_copy, num_events, timeout);
	//将投送完后的事件反拷贝到用户层
	(void)memcpy((void *)events, events_copy, bounds);
out_free:
	k_free(events_copy);//释放内存空间
out://返回
	return ret;
oops_free:
	k_free(events_copy);
	Z_OOPS(1);
}
#include <syscalls/k_poll_mrsh.c>
#endif

//必须在中断锁定的情况下调用
//信号投送事件
static int signal_poll_event(struct k_poll_event *event, uint32_t state)
{
	//获取事件投送者
	struct z_poller *poller = event->poller;
	int retcode = 0;

	if (poller) {//投诉者存在
		if (poller->mode == MODE_POLL) {//它支持投送
			retcode = signal_poller(event, state);//信号投送
		} else if (poller->mode == MODE_TRIGGERED) {//它支持触发
			//信号投送给触发的工作者
			retcode = signal_triggered_work(event, state);
		}
		//清除投送状态
		poller->is_polling = false;
		if (retcode < 0) {
			return retcode;
		}
	}
	//设置该事件有效(因为它可能已经被投送了)
	set_event_ready(event, state);
	return retcode;
}

//对象投送事件句柄
void z_handle_obj_poll_events(sys_dlist_t *events, uint32_t state)
{
	struct k_poll_event *poll_event;//获取一个投送事件
	poll_event = (struct k_poll_event *)sys_dlist_get(events);
	if (poll_event != NULL) {//将该事件投送出去
		(void) signal_poll_event(poll_event, state);
	}
}

//初始化投送信号
void z_impl_k_poll_signal_init(struct k_poll_signal *signal)
{
	sys_dlist_init(&signal->poll_events);//初始化投送事件集
	signal->signaled = 0U;//当前为空
	//signal->result是单一的
	z_object_init(signal);//初始化投送信号对象
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_poll_signal_init(struct k_poll_signal *signal)
{
	Z_OOPS(Z_SYSCALL_OBJ_INIT(signal, K_OBJ_POLL_SIGNAL));
	z_impl_k_poll_signal_init(signal);
}
#include <syscalls/k_poll_signal_init_mrsh.c>
#endif

//投送信号检查
void z_impl_k_poll_signal_check(struct k_poll_signal *signal,
								unsigned int *signaled, int *result)
{
	*signaled = signal->signaled;
	*result = signal->result;
}

#ifdef CONFIG_USERSPACE
void z_vrfy_k_poll_signal_check(struct k_poll_signal *signal,
								unsigned int *signaled, int *result)
{
	Z_OOPS(Z_SYSCALL_OBJ(signal, K_OBJ_POLL_SIGNAL));
	Z_OOPS(Z_SYSCALL_MEMORY_WRITE(signaled, sizeof(unsigned int)));
	Z_OOPS(Z_SYSCALL_MEMORY_WRITE(result, sizeof(int)));
	z_impl_k_poll_signal_check(signal, signaled, result);
}
#include <syscalls/k_poll_signal_check_mrsh.c>
#endif

//拉起投送信号
int z_impl_k_poll_signal_raise(struct k_poll_signal *signal, int result)
{
	k_spinlock_key_t key = k_spin_lock(&lock);
	struct k_poll_event *poll_event;
	signal->result = result;//初始化信号
	signal->signaled = 1U;
	//获取该信号的投送事件
	poll_event = (struct k_poll_event *)sys_dlist_get(&signal->poll_events);
	if (poll_event == NULL) {
		k_spin_unlock(&lock, key);
		return 0;
	}
	//将其投送为信号
	int rc = signal_poll_event(poll_event, K_POLL_STATE_SIGNALED);
	z_reschedule(&lock, key);//重调度
	return rc;
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_poll_signal_raise(struct k_poll_signal *signal,
											 int result)
{
	Z_OOPS(Z_SYSCALL_OBJ(signal, K_OBJ_POLL_SIGNAL));
	return z_impl_k_poll_signal_raise(signal, result);
}
#include <syscalls/k_poll_signal_raise_mrsh.c>

static inline void z_vrfy_k_poll_signal_reset(struct k_poll_signal *signal)
{
	Z_OOPS(Z_SYSCALL_OBJ(signal, K_OBJ_POLL_SIGNAL));
	z_impl_k_poll_signal_reset(signal);
}
#include <syscalls/k_poll_signal_reset_mrsh.c>

#endif

//触发工作句柄
static void triggered_work_handler(struct k_work *work)
{
	//获取投送的工作者
	struct k_work_poll *twork = CONTAINER_OF(work, struct k_work_poll, work);
	//如果没有设置回调,则k_work_poll_submit_to_queue()已经清除了事件注册
	if (twork->poller.mode != MODE_NONE) {//如果不是空模式
		k_spinlock_key_t key;
		key = k_spin_lock(&lock);
		//清除投送工作者注册的投送事件
		clear_event_registrations(twork->events, twork->num_events, key);
		k_spin_unlock(&lock, key);
	}

	//删除工作所有权并执行真正的处理程序
	twork->workq = NULL;
	twork->real_handler(work);//执行投送工作者的回调
}

//触发工作过期句柄
static void triggered_work_expiration_handler(struct _timeout *timeout)
{
	//获取投送的工作者
	struct k_work_poll *twork = CONTAINER_OF(timeout, struct k_work_poll, timeout);
	twork->poller.is_polling = false;//清除投送状态
	twork->poll_result = -EAGAIN;//设置投送结果
	//该工作项加入到工作队列
	k_work_submit_to_queue(twork->workq, &twork->work);
}

//信号投送工作
static int signal_triggered_work(struct k_poll_event *event, uint32_t status)
{
	//获取信号的投送者,获取投送的工作者
	struct z_poller *poller = event->poller;
	struct k_work_poll *twork = CONTAINER_OF(poller, struct k_work_poll, poller);
	//如果该投送者还在投送,且它的工作队列非空
	if (poller->is_polling && twork->workq != NULL) {
		struct k_work_q *work_q = twork->workq;//获取工作队列
		z_abort_timeout(&twork->timeout);//中止它的超时挂起
		twork->poll_result = 0;//设置投送结果
		//该信号的工作项加入到工作队列
		k_work_submit_to_queue(work_q, &twork->work);
	}
	return 0;
}

//触发工作取消
static int triggered_work_cancel(struct k_work_poll *work,
								 k_spinlock_key_t key)
{
	//检查工作是否等待事件(该工作的投送者还在投送,或投送者为空模式)
	if (work->poller.is_polling && work->poller.mode != MODE_NONE) {
		//删除与工作关联的超时
		z_abort_timeout(&work->timeout);
		//在我们清理登记时,如果事件发生,防止工作执行
		work->poller.mode = MODE_NONE;
		//清除注册的投送事件集
		clear_event_registrations(work->events, work->num_events, key);
		work->workq = NULL;//清除该工作的工作队列
		return 0;
	}

	//如果我们到达这里,工作要么在k_work_poll_submit_to_queue()中注册
	//要么执行,要么挂起,只有在最后一种情况下,我们才有机会取消它
	//但不幸的是,没有公共API执行这个任务
	return -EINVAL;
}

//初始化工作投送
void k_work_poll_init(struct k_work_poll *work,
					  k_work_handler_t handler)
{
	*work = (struct k_work_poll) {};//清空
	k_work_init(&work->work, triggered_work_handler);//初始化
	work->real_handler = handler;//设置事件回调
	z_init_timeout(&work->timeout);//初始化超时
}

//投送的工作提交到队列中
int k_work_poll_submit_to_queue(struct k_work_q *work_q,
								struct k_work_poll *work,
								struct k_poll_event *events,
								int num_events,
								k_timeout_t timeout)
{
	int events_registered;
	k_spinlock_key_t key;
	//断言检查工作队列非空,投送工作项非空,投送事件集非空,投送事件数
	__ASSERT(work_q != NULL, "NULL work_q\n");
	__ASSERT(work != NULL, "NULL work\n");
	__ASSERT(events != NULL, "NULL events\n");
	__ASSERT(num_events > 0, "zero events\n");
	//如果可能的话,接管这项工作
	key = k_spin_lock(&lock);
	if (work->workq != NULL) {//工作队列存在
		if (work->workq == work_q) {//该工作项隶属于该工作队列
			int retval;
			//触发工作取消
			retval = triggered_work_cancel(work, key);
			if (retval < 0) {
				k_spin_unlock(&lock, key);
				return retval;
			}
		} else {
			k_spin_unlock(&lock, key);
			return -EADDRINUSE;
		}
	}
	
	//配置该工作的投送相关信息
	work->poller.is_polling = true;
	work->workq = work_q;
	work->poller.mode = MODE_NONE;
	k_spin_unlock(&lock, key);

	//保存事件列表
	work->events = events;
	work->num_events = num_events;
	work->poll_result = -EINPROGRESS;//清除投送结果
	//注册该投送事件集
	events_registered = register_events(events, num_events,
										&work->poller, false);
	key = k_spin_lock(&lock);
	//如果还在投送且可以超时
	if (work->poller.is_polling && !K_TIMEOUT_EQ(timeout, K_NO_WAIT)) {
		//还有一些工作没有投送完吗?
		__ASSERT(num_events == events_registered,
				 "Some events were not registered!\n");

		//如果请求这样的操作,设置超时
		if (!K_TIMEOUT_EQ(timeout, K_FOREVER)) {
			//将其加入到超时等待之中
			z_add_timeout(&work->timeout,
						  triggered_work_expiration_handler,
						  timeout);
		}

		//从现在开始,任何事件都会导致提交工作
		work->poller.mode = MODE_TRIGGERED;
		k_spin_unlock(&lock, key);
		return 0;
	}

	//指定了K_NO_WAIT超时,或者至少有一个事件在注册时准备好了,或者注册后状态改变了
	//希望没有设置轮询器模式,所以工作没有提交到工作队列

	//如果轮询器仍在轮询，没有观察事件发生
	//这意味着我们到达这里是因为K_NO_WAIT超时“过期”
	if (work->poller.is_polling) {
		work->poller.is_polling = false;
		work->poll_result = -EAGAIN;
	} else {
		work->poll_result = 0;
	}

	//清除注册
	clear_event_registrations(events, events_registered, key);
	k_spin_unlock(&lock, key);

	//投送工作推入工作队列之中
	k_work_submit_to_queue(work_q, &work->work);
	return 0;
}

//工作投送取消
int k_work_poll_cancel(struct k_work_poll *work)
{
	k_spinlock_key_t key;
	int retval;
	if (work == NULL || work->workq == NULL) {
		return -EINVAL;
	}
	key = k_spin_lock(&lock);
	
	//检查是否提交了工作
	retval = triggered_work_cancel(work, key);
	
	k_spin_unlock(&lock, key);
	return retval;
}
