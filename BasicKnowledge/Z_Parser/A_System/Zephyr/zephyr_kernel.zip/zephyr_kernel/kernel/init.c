/*
 * zephyr内核
 */

//内核初始化模块
//这个模块包含用于初始化内核的例程

#include <zephyr.h>
#include <offsets_short.h>
#include <kernel.h>
#include <sys/printk.h>
#include <debug/stack.h>
#include <random/rand32.h>
#include <linker/sections.h>
#include <toolchain.h>
#include <kernel_structs.h>
#include <device.h>
#include <init.h>
#include <linker/linker-defs.h>
#include <ksched.h>
#include <string.h>
#include <sys/dlist.h>
#include <kernel_internal.h>
#include <kswap.h>
#include <drivers/entropy.h>
#include <logging/log_ctrl.h>
#include <tracing/tracing.h>
#include <stdbool.h>
#include <debug/gcov.h>
#include <kswap.h>
#include <logging/log.h>

LOG_MODULE_REGISTER(os, CONFIG_KERNEL_LOG_LEVEL);

//开机时间测量项
#ifdef CONFIG_BOOT_TIME_MEASUREMENT
uint32_t __noinit z_timestamp_main;  //主任务开始时的时间戳
uint32_t __noinit z_timestamp_idle;  //CPU空闲时的时间戳
#endif

//初始化/主线程和空闲线程
K_THREAD_STACK_DEFINE(z_main_stack, CONFIG_MAIN_STACK_SIZE);
struct k_thread z_main_thread;

#ifdef CONFIG_MULTITHREADING
//如果开启多线程模式,每一个CPU(即使只有一个)都会在本地获得一个空闲线程
struct k_thread z_idle_threads[CONFIG_MP_NUM_CPUS];
static K_KERNEL_STACK_ARRAY_DEFINE(z_idle_stacks, CONFIG_MP_NUM_CPUS,
                                   CONFIG_IDLE_STACK_SIZE);
#endif

//中断堆栈的存储空间
//注意:这个区域在内核初始化时用作系统堆栈,因为内核还没有建立自己的堆栈区域
//这个区域的双重用途是安全的,因为在内核上下文切换到init线程之前,中断是禁用的
K_KERNEL_STACK_ARRAY_DEFINE(z_interrupt_stacks, CONFIG_MP_NUM_CPUS,
                            CONFIG_ISR_STACK_SIZE);

//超时队列初始化
#ifdef CONFIG_SYS_CLOCK_EXISTS
	#define initialize_timeouts() do { \
		sys_dlist_init(&_timeout_q); \
	} while (false)
#else
	#define initialize_timeouts() do { } while ((0))
#endif

//空闲线程声明
extern void idle(void *unused1, void *unused2, void *unused3);

//这段代码在引导过程的早期就被调用了,以至于代码覆盖不能正常工作
//此外,并不是所有的平台都调用这段代码,有些像x86这样的程序集是经过优化的

//这个例程清除BSS区域,所有字节都是0
void z_bss_zero(void)
{
	(void)memset(__bss_start, 0, __bss_end - __bss_start);
	
#if DT_NODE_HAS_STATUS(DT_CHOSEN(zephyr_ccm), okay)
	(void)memset(&__ccm_bss_start, 0,
				((uint32_t) &__ccm_bss_end - (uint32_t) &__ccm_bss_start));
#endif

#if DT_NODE_HAS_STATUS(DT_CHOSEN(zephyr_dtcm), okay)
	(void)memset(&__dtcm_bss_start, 0,
				((uint32_t) &__dtcm_bss_end - (uint32_t) &__dtcm_bss_start));
#endif

#ifdef CONFIG_CODE_DATA_RELOCATION
	extern void bss_zeroing_relocation(void);

	bss_zeroing_relocation();
#endif

#ifdef CONFIG_COVERAGE_GCOV
	(void)memset(&__gcov_bss_start, 0,
				((uintptr_t) &__gcov_bss_end - (uintptr_t) &__gcov_bss_start));
#endif
}

//栈金丝雀保护
#ifdef CONFIG_STACK_CANARIES
extern volatile uintptr_t __stack_chk_guard;
#endif 

bool z_sys_post_kernel;
extern void boot_banner(void);

//内核后台线程的主线
//这个例程通过调用剩余的init函数来完成内核初始化,然后调用应用程序的main()例程
static void bg_thread_main(void *unused1, void *unused2, void *unused3)
{
	ARG_UNUSED(unused1);
	ARG_UNUSED(unused2);
	ARG_UNUSED(unused3);

	z_sys_post_kernel = true;
	
	//初始化内核层线程
	z_sys_init_run_level(_SYS_INIT_LEVEL_POST_KERNEL);
#if CONFIG_STACK_POINTER_RANDOM
	z_stack_adjust_initialized = 1;
#endif

	boot_banner();//boot屏障

#ifdef CONFIG_CPLUSPLUS
	//处理.ctors和.init_array段
	extern void __do_global_ctors_aux(void);
	extern void __do_init_array_aux(void);
	__do_global_ctors_aux();
	__do_init_array_aux();
#endif

	//应用程序启动前的最终初始化级别
	z_sys_init_run_level(_SYS_INIT_LEVEL_APPLICATION);

	//初始化系统静态配置的线程(如果有的话)
	z_init_static_threads();

#ifdef KERNEL_COHERENCE
	__ASSERT_NO_MSG(arch_mem_coherent(_kernel));
#endif

#ifdef CONFIG_SMP
	z_smp_init();//多CPU需要用到的初始化
	z_sys_init_run_level(_SYS_INIT_LEVEL_SMP);
#endif

#ifdef CONFIG_BOOT_TIME_MEASUREMENT
	//记录主函数启动的时间戳
	z_timestamp_main = k_cycle_get_32();
#endif

	extern void main(void);
	//启用系统主函数
	main();

	//标记必不可缺,因为main()没有更多的工作要做
	//去除用户主线程的特权级别
	z_main_thread.base.user_options &= ~K_ESSENTIAL;

#ifdef CONFIG_COVERAGE_DUMP
	gcov_coverage_dump();//main()退出后转储覆盖数据
#endif
}

void __weak main(void)
{
	//NOP默认main(),如果应用程序不提供
	arch_nop();
}

#if defined(CONFIG_MULTITHREADING)
//初始化指定CPU的空闲线程
static void init_idle_thread(int i)
{
	//获取空闲线程的实例和堆栈空间
	struct k_thread *thread = &z_idle_threads[i];
	k_thread_stack_t *stack = z_idle_stacks[i];

#ifdef CONFIG_THREAD_NAME
	char tname[8];//空闲线程名字
	snprintk(tname, 8, "idle %02d", i);
#else
	char *tname = NULL;
#endif

	//初始化空闲线程实例
	z_setup_new_thread(thread, stack, CONFIG_IDLE_STACK_SIZE, 
					   idle, &_kernel.cpus[i], NULL, NULL, 
					   K_LOWEST_THREAD_PRIO, K_ESSENTIAL,
					   tname);
	z_mark_thread_as_started(thread);//标记为启动

#ifdef CONFIG_SMP
	thread->base.is_idle = 1U;
#endif
}

//初始化内核数据结构
//这个例程初始化各种内核数据结构,包括初始化和空闲线程以及任何特定于体系结构的初始化
//注意“_kernel”的所有字段在入口时都被设置为零,这可能是它们中许多需要的所有初始化
//返回主线程的初始堆栈指针
static char *prepare_multithreading(void)
{
	char *stack_ptr;
	uint32_t opt;

	//_kernel.Ready_q全为零
	z_sched_init();

#ifndef CONFIG_SMP
	//用主线程填充缓存,因为:
	//-缓存不能为NULL
	//-主线程将首先运行
	//-没有其他线程初始化,因此他们的优先级字段包含垃圾,这将阻止缓存加载算法按预期工作
	_kernel.ready_q.cache = &z_main_thread;
#endif

	opt = K_ESSENTIAL;
#if defined(CONFIG_FPU) && defined(CONFIG_FPU_SHARING)
	opt |= K_FP_REGS;//在主线程中启用FPU
#endif

	//初始化一个主线程
	stack_ptr = z_setup_new_thread(&z_main_thread, z_main_stack,
								   CONFIG_MAIN_STACK_SIZE, bg_thread_main,
								   NULL, NULL, NULL,
								   CONFIG_MAIN_THREAD_PRIORITY,
								   opt, "main");
	z_mark_thread_as_started(&z_main_thread);//标记主线程为启动
	z_ready_thread(&z_main_thread);//就绪主线程

	//初始化每一个CPU的空闲线程,每CPU变量值,中断堆栈区
	for (int i = 0; i < CONFIG_MP_NUM_CPUS; i++) {
		init_idle_thread(i);
		_kernel.cpus[i].idle_thread = &z_idle_threads[i];
		_kernel.cpus[i].id = i;
		_kernel.cpus[i].irq_stack =
			(Z_KERNEL_STACK_BUFFER(z_interrupt_stacks[i]) +
			 K_KERNEL_STACK_SIZEOF(z_interrupt_stacks[i]));
	}

	//初始化超时队列
	initialize_timeouts();
	return stack_ptr;
}

//切换至主线程
static FUNC_NORETURN void switch_to_main_thread(char *stack_ptr)
{
#ifdef CONFIG_ARCH_HAS_CUSTOM_SWAP_TO_MAIN
	arch_switch_to_main_thread(&z_main_thread, stack_ptr, bg_thread_main);
#else
	ARG_UNUSED(stack_ptr);
	//上下文切换到主任务(入口函数是_main()):
	//当前的假线程不是在等待队列或准备队列上,所以它永远不会被重新调度
	z_swap_unlocked();
#endif
	CODE_UNREACHABLE;
}
#endif

#if defined(CONFIG_ENTROPY_HAS_DRIVER) || defined(CONFIG_TEST_RANDOM_GENERATOR)
void z_early_boot_rand_get(uint8_t *buf, size_t length)
{
	int n = sizeof(uint32_t);
#ifdef CONFIG_ENTROPY_HAS_DRIVER
	const struct device *entropy = device_get_binding(DT_CHOSEN_ZEPHYR_ENTROPY_LABEL);
	int rc;

	if (entropy == NULL) {
		goto sys_rand_fallback;
	}

	//尝试看看驱动程序是否提供了特定于isr的API
	rc = entropy_get_entropy_isr(entropy, buf, length, ENTROPY_BUSYWAIT);
	if (rc == -ENOTSUP) {
		//驱动程序不提供特定于ISR的API，假设它可以从ISR上下文调用
		rc = entropy_get_entropy(entropy, buf, length);
	}

	if (rc >= 0) {
		return;
	}

	//陷入僵局以备后路

sys_rand_fallback:
#endif

	//FIXME:这假设sys_rand32_get()不会使用任何同步原语,如信号量或互斥
	//在引导过程中使用它们还为时过早
	//理想情况下,只有熵设备可用的路径应该被构建,这只是那些没有HWRNG熵驱动的设备的后备方案

	while (length > 0) {
		uint32_t rndbits;
		uint8_t *p_rndbits = (uint8_t *)&rndbits;

		rndbits = sys_rand32_get();

		if (length < sizeof(uint32_t)) {
			n = length;
		}

		for (int i = 0; i < n; i++) {
			*buf = *p_rndbits;
			buf++;
			p_rndbits++;
		}

		length -= n;
	}
}
#endif

//初始化内核
//这个例程在系统准备运行C代码时被调用,处理器必须以32位模式运行,BSS必须被清除/置零
FUNC_NORETURN void z_cstart(void)
{
	//gcov钩需要得到报道报告
	gcov_static_init();
	//内核日志初始化
	LOG_CORE_INIT();
	//执行任何特定于体系结构的初始化
	arch_kernel_init();

#if defined(CONFIG_MULTITHREADING)
	//注意:即使CONFIG_ARCH_HAS_CUSTOM_SWAP_TO_MAIN=y
	//prepare_multithreading()中的z_ready_thread()调用也需要一个虚拟线程
	struct k_thread dummy_thread;

	z_dummy_thread_init(&dummy_thread);
#endif

	//执行基本硬件初始化
	z_sys_init_run_level(_SYS_INIT_LEVEL_PRE_KERNEL_1);
	z_sys_init_run_level(_SYS_INIT_LEVEL_PRE_KERNEL_2);

#ifdef CONFIG_STACK_CANARIES
	uintptr_t stack_guard;
	//栈金丝雀保护
	z_early_boot_rand_get((uint8_t *)&stack_guard, sizeof(stack_guard));
	__stack_chk_guard = stack_guard;
	__stack_chk_guard <<= 8;
#endif

#ifdef CONFIG_THREAD_RUNTIME_STATS_USE_TIMING_FUNCTIONS
	timing_init();//初始化定时器(维护线程状态)
	timing_start();//启动定时器
#endif

#ifdef CONFIG_MULTITHREADING
	//切换至主线程
	switch_to_main_thread(prepare_multithreading());
#else
#ifdef ARCH_SWITCH_TO_MAIN_NO_MULTITHREADING
	//在没有多线程的情况下，自定义特定于arch的例程切换到main()
	ARCH_SWITCH_TO_MAIN_NO_MULTITHREADING(bg_thread_main,
										  NULL, NULL, NULL);
#else
	bg_thread_main(NULL, NULL, NULL);

	//我们已经把覆盖数据丢了
	irq_lock();
	while (true) {
	}
#endif
#endif 

	//编译器不能知道上面的例程不会返回并发出警告
	//除非我们显式地告诉它控件永远不会走这么远
	CODE_UNREACHABLE;
}
