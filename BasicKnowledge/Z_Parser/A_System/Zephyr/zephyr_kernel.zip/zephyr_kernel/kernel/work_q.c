/*
 * zephyr内核
 */

//工作队列

#include <kernel_structs.h>
#include <wait_q.h>
#include <spinlock.h>
#include <errno.h>
#include <stdbool.h>
#include <sys/check.h>

//工作队列线程名字
#define WORKQUEUE_THREAD_NAME	"workqueue"

//如果系统时钟存在,申请全局自旋锁
#ifdef CONFIG_SYS_CLOCK_EXISTS
static struct k_spinlock lock;
#endif

//工作队列线程体
extern void z_work_q_main(void *work_q_ptr, void *p2, void *p3);

//开始工作队列
void k_work_q_start(struct k_work_q *work_q, k_thread_stack_t *stack,
					size_t stack_size, int prio)
{
	k_queue_init(&work_q->queue);//初始化队列
	//创建工作队列线程
	(void)k_thread_create(&work_q->thread, stack, stack_size, z_work_q_main,
						   work_q, NULL, NULL, prio, 0, K_NO_WAIT);
	//设置工作队列线程名字
	k_thread_name_set(&work_q->thread, WORKQUEUE_THREAD_NAME);
}

#ifdef CONFIG_SYS_CLOCK_EXISTS
static void work_timeout(struct _timeout *t)
{	//求出延迟工作项,如果有
	struct k_delayed_work *w = CONTAINER_OF(t, struct k_delayed_work, timeout);
	//提交工作到工作队列
	k_work_submit_to_queue(w->work_q, &w->work);
}

//工作取消
static int work_cancel(struct k_delayed_work *work)
{
	//当前延迟的工作项是挂起态?
	if (k_work_pending(&work->work)) {
		//如果已经提交，则从队列中删除
		if (!k_queue_remove(&work->work_q->queue, &work->work)) {
			return -EINVAL;
		}
	} else {
		//中止该项目的倒计时
		int err = z_abort_timeout(&work->timeout);
		if (err) {
			return -EALREADY;
		}
	}
	//脱离工作队列
	work->work_q = NULL;
	//清除挂起状态
	atomic_clear_bit(work->work.flags, K_WORK_STATE_PENDING);
	return 0;
}

//延迟工作项提交到工作队列
int k_delayed_work_submit_to_queue(struct k_work_q *work_q,
								   struct k_delayed_work *work,
								   k_timeout_t delay)
{
	k_spinlock_key_t key = k_spin_lock(&lock);
	int err = 0;

	//工作不能在多个队列中处于活动状态
	if (work->work_q != NULL && work->work_q != work_q) {
		err = -EADDRINUSE;
		goto done;
	}

	//如果工作已经提交,则取消
	if (work->work_q == work_q) {
		err = work_cancel(work);
		//-EALREADY可能表示工作已经完成,所以这可能是一个重复的工作
		//它还可能表明工作处理程序仍在执行
		//但它既没有推迟也没有未决,所以可以重新安排
		if (err == -EALREADY) {
			err = 0;
		} else if (err < 0) {
			goto done;
		}
	}

	//附加工作队列,以便超时回调可以提交它
	work->work_q = work_q;

	//如果没有延迟,直接提交工作,注意这是一个阻塞操作,所以先释放锁
	if (K_TIMEOUT_EQ(delay, K_NO_WAIT)) {
		k_spin_unlock(&lock, key);
		k_work_submit_to_queue(work_q, &work->work);
		return 0;
	}

	//否则为当前的工作项添加超时机制,等待结束后执行work_timeout
	//直到执行该回调时,才进行工作的提交
	z_add_timeout(&work->timeout, work_timeout, delay);

done:
	k_spin_unlock(&lock, key);
	return err;
}

//一项延迟工作的取消
int k_delayed_work_cancel(struct k_delayed_work *work)
{
	k_spinlock_key_t key = k_spin_lock(&lock);
	int ret = -EINVAL;

	if (work->work_q != NULL) {
		ret = work_cancel(work);
	}

	k_spin_unlock(&lock, key);
	return ret;
}

//一项延迟工作的挂起
bool k_delayed_work_pending(struct k_delayed_work *work)
{
	return !z_is_inactive_timeout(&work->timeout) ||
	       k_work_pending(&work->work);
}

#endif /* CONFIG_SYS_CLOCK_EXISTS */
