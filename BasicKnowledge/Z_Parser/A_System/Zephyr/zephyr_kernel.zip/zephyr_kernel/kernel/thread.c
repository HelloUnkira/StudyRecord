/*
 * zephyr内核
 */

//内核线程支持
//这个模块提供了通用线程支持

#include <kernel.h>
#include <spinlock.h>
#include <sys/math_extras.h>
#include <sys_clock.h>
#include <ksched.h>
#include <wait_q.h>
#include <syscall_handler.h>
#include <kernel_internal.h>
#include <kswap.h>
#include <init.h>
#include <tracing/tracing.h>
#include <string.h>
#include <stdbool.h>
#include <irq_offload.h>
#include <sys/check.h>
#include <random/rand32.h>
#include <sys/atomic.h>
#include <logging/log.h>

//操作系统内核层
LOG_MODULE_DECLARE(os, CONFIG_KERNEL_LOG_LEVEL);

//配置线程运行时状态
#ifdef CONFIG_THREAD_RUNTIME_STATS
k_thread_runtime_stats_t threads_runtime_stats;
#endif

//这个锁保护活动线程的链表
//即初始的_kernel.threads指针和由thread->next_thread(直到NULL)组成的链表
#ifdef CONFIG_THREAD_MONITOR
static struct k_spinlock z_thread_monitor_lock;
#endif

//遍历线程的通配迭代器
#define _FOREACH_STATIC_THREAD(thread_data) \
	Z_STRUCT_SECTION_FOREACH(_static_thread_data, thread_data)

//广播式遍历线程,并让用户选择性将数据载入到线程中(为用户访问加锁)
void k_thread_foreach(k_thread_user_cb_t user_cb, void *user_data)
{
#if defined(CONFIG_THREAD_MONITOR)
	struct k_thread *thread;
	k_spinlock_key_t key;
	//用户回调不可为空,否则处理无效
	__ASSERT(user_cb != NULL, "user_cb can not be NULL");
	//需要锁来确保_kernel.threads没有被user_cb直接或间接修改
	//间接的方法是通过调用user_cb中的k_thread_create和k_thread_abort
	key = k_spin_lock(&z_thread_monitor_lock);
	//遍历内核所有线程
	for (thread = _kernel.threads; thread; thread = thread->next_thread) {
		user_cb(thread, user_data);//为回调广播所有线程描述符
	}
	k_spin_unlock(&z_thread_monitor_lock, key);
#endif
}

//广播式遍历线程,并让用户选择性将数据载入到线程中(用户访问线程描述符不加锁)
void k_thread_foreach_unlocked(k_thread_user_cb_t user_cb, void *user_data)
{
#if defined(CONFIG_THREAD_MONITOR)
	struct k_thread *thread;
	k_spinlock_key_t key;
	//用户回调不可为空,否则处理无效
	__ASSERT(user_cb != NULL, "user_cb can not be NULL");
	key = k_spin_lock(&z_thread_monitor_lock);
	//遍历内核所有线程
	for (thread = _kernel.threads; thread; thread = thread->next_thread) {
		k_spin_unlock(&z_thread_monitor_lock, key);
		user_cb(thread, user_data);//为回调广播所有线程描述符
		key = k_spin_lock(&z_thread_monitor_lock);
		//仅在对thread访问时上锁,用户使用thread时不锁定
	}
	k_spin_unlock(&z_thread_monitor_lock, key);
#endif
}

//当前上下文是否是中断环境下
bool k_is_in_isr(void)
{
	return arch_is_in_isr();
}

//这个函数将当前线程标记为系统操作的关键
//这个线程引发的异常将被视为致命的系统错误
void z_thread_essential_set(void)
{
	_current->base.user_options |= K_ESSENTIAL;
}

//这个函数将当前线程标记为对系统操作不重要
//这个线程引发的异常可以恢复
//(这是一个线程的默认标记)
void z_thread_essential_clear(void)
{
	_current->base.user_options &= ~K_ESSENTIAL;
}

//这个例程指示当前线程是否是一个基本的系统线程
bool z_is_thread_essential(void)
{
	return (_current->base.user_options & K_ESSENTIAL) == K_ESSENTIAL;
}

#ifdef CONFIG_SYS_CLOCK_EXISTS
//系统忙等待
void z_impl_k_busy_wait(uint32_t usec_to_wait)
{
	if (usec_to_wait == 0) {
		return;//等待时间为0,无需等待
	}

	//如果需要直接使用程序去实现忙等待
#if !defined(CONFIG_ARCH_HAS_CUSTOM_BUSY_WAIT)
	//获取参考点
	uint32_t start_cycles = k_cycle_get_32();

	//计算等待周期(使用64位数学来防止* / 计算时溢出)
	uint32_t cycles_to_wait = (uint32_t)(
		(uint64_t)usec_to_wait *
		(uint64_t)sys_clock_hw_cycles_per_sec() /
		(uint64_t)USEC_PER_SEC
	);

	for (;;) {
		uint32_t current_cycles = k_cycle_get_32();
		//这将处理无符号32位值的翻转
		//很显然,忙等待就是一个死等状态,CPU当前也是一定被占用的(是否可打断)
		if ((current_cycles - start_cycles) >= cycles_to_wait) {
			break;//仅到达一个等待周期后,退出死等
		}
	}
#else
	//如果平台层提供忙等待支持,则无需手动忙等待
	//也许硬件层有更多好的想法
	arch_busy_wait(usec_to_wait);
#endif
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_busy_wait(uint32_t usec_to_wait)
{
	z_impl_k_busy_wait(usec_to_wait);
}
#include <syscalls/k_busy_wait_mrsh.c>
#endif
#endif

#ifdef CONFIG_THREAD_CUSTOM_DATA
//配置特殊线程参数,如果需要配置
void z_impl_k_thread_custom_data_set(void *value)
{	
	_current->custom_data = value;
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_thread_custom_data_set(void *data)
{
	z_impl_k_thread_custom_data_set(data);
}
#include <syscalls/k_thread_custom_data_set_mrsh.c>
#endif

//获取特殊线程参数,如果需要获取
void *z_impl_k_thread_custom_data_get(void)
{	
	return _current->custom_data;
}

#ifdef CONFIG_USERSPACE
static inline void *z_vrfy_k_thread_custom_data_get(void)
{
	return z_impl_k_thread_custom_data_get();
}
#include <syscalls/k_thread_custom_data_get_mrsh.c>
#endif
#endif

#if defined(CONFIG_THREAD_MONITOR)
//从内核的活动线程链表中删除一个线程(仅解除引用)
void z_thread_monitor_exit(struct k_thread *thread)
{
	//为系统上线程(动作集)锁
	k_spinlock_key_t key = k_spin_lock(&z_thread_monitor_lock);

	//如果该线程是内核活动线程集的首项
	if (thread == _kernel.threads) {//直接更新引用
		_kernel.threads = _kernel.threads->next_thread;
	} else {//否则迭代寻找
		struct k_thread *prev_thread;
		prev_thread = _kernel.threads;
		//迭代整个集合,要么遇到目标线程,要么遇到结尾
		while ((prev_thread != NULL) &&
			(thread != prev_thread->next_thread)) {
			prev_thread = prev_thread->next_thread;
		}
		if (prev_thread != NULL) {
			prev_thread->next_thread = thread->next_thread;
		}
	}
	k_spin_unlock(&z_thread_monitor_lock, key);
}
#endif

//设置线程名字
int z_impl_k_thread_name_set(struct k_thread *thread, const char *value)
{
#ifdef CONFIG_THREAD_NAME
	if (thread == NULL) {//如果不提供指定线程
		thread = _current;//默认设置当前线程
	}
	
	//字符串拷贝数据(线程名字)
	strncpy(thread->name, value, CONFIG_THREAD_MAX_NAME_LEN);
	thread->name[CONFIG_THREAD_MAX_NAME_LEN - 1] = '\0';//字符串结尾标志
	sys_trace_thread_name_set(thread);
	return 0;
#else
	ARG_UNUSED(thread);
	ARG_UNUSED(value);
	return -ENOSYS;
#endif
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_thread_name_set(struct k_thread *t, const char *str)
{
#ifdef CONFIG_THREAD_NAME
	size_t len;
	int err;

	if (t != NULL) {
		if (Z_SYSCALL_OBJ(t, K_OBJ_THREAD) != 0) {
			return -EINVAL;
		}
	}

	len = z_user_string_nlen(str, CONFIG_THREAD_MAX_NAME_LEN, &err);
	if (err != 0) {
		return -EFAULT;
	}
	if (Z_SYSCALL_MEMORY_READ(str, len) != 0) {
		return -EFAULT;
	}

	return z_impl_k_thread_name_set(t, str);
#else
	return -ENOSYS;
#endif
}
#include <syscalls/k_thread_name_set_mrsh.c>
#endif

//获取线程名字
const char *k_thread_name_get(struct k_thread *thread)
{
#ifdef CONFIG_THREAD_NAME
	return (const char *)thread->name;
#else
	ARG_UNUSED(thread);
	return NULL;
#endif
}

//获取线程名字
int z_impl_k_thread_name_copy(k_tid_t thread_id, char *buf, size_t size)
{
#ifdef CONFIG_THREAD_NAME
	strncpy(buf, thread_id->name, size);
	return 0;
#else
	ARG_UNUSED(thread_id);
	ARG_UNUSED(buf);
	ARG_UNUSED(size);
	return -ENOSYS;
#endif
}

//线程几种特殊状态转化为人类友好的可读字符串
const char *k_thread_state_str(k_tid_t thread_id)
{
	switch (thread_id->base.thread_state) {
	case 0:
		return "";
		break;
	case _THREAD_DUMMY:
		return "dummy";
		break;
	case _THREAD_PENDING:
		return "pending";
		break;
	case _THREAD_PRESTART:
		return "prestart";
		break;
	case _THREAD_DEAD:
		return "dead";
		break;
	case _THREAD_SUSPENDED:
		return "suspended";
		break;
	case _THREAD_ABORTING:
		return "aborting";
		break;
	case _THREAD_QUEUED:
		return "queued";
		break;
	}
	return "unknown";
}

#ifdef CONFIG_USERSPACE
//线程名字拷贝
static inline int z_vrfy_k_thread_name_copy(k_tid_t thread, char *buf, size_t size)
{
#ifdef CONFIG_THREAD_NAME
	size_t len;
	//获取线程所有者对象
	struct z_object *ko = z_object_find(thread);

	//特殊情况:我们允许读取初始化线程的名称,即使我们没有对它们的权限
	if (thread == NULL || ko->type != K_OBJ_THREAD ||
	    (ko->flags & K_OBJ_FLAG_INITIALIZED) == 0) {
		return -EINVAL;
	}
	if (Z_SYSCALL_MEMORY_WRITE(buf, size) != 0) {
		return -EFAULT;
	}
	len = strlen(thread->name);
	if (len + 1 > size) {
		return -ENOSPC;
	}

	//拷贝数据(线程名字)
	return z_user_to_copy((void *)buf, thread->name, len + 1);
#else
	ARG_UNUSED(thread);
	ARG_UNUSED(buf);
	ARG_UNUSED(size);
	return -ENOSYS;
#endif
}
#include <syscalls/k_thread_name_copy_mrsh.c>
#endif

#ifdef CONFIG_STACK_SENTINEL
//检查堆栈哨兵是否仍然存在
//当线程初始化时,堆栈哨兵特性将一个魔术值写入线程堆栈的最低4个字节
//这个值在几个地方被检查:
//1)在k_yield()中,如果当前线程没有被交换出去
//2)服务一个非嵌套中断之后
//3)在z_swap()中,检查输出线程中的哨兵
//Item 2需要arch/code中的支持
//如果检查失败,线程将通过系统致命错误处理程序适当终止
void z_check_stack_sentinel(void)
{
	uint32_t *stack;
	//虚拟线程检查
	if ((_current->base.thread_state & _THREAD_DUMMY) != 0) {
		return;
	}
	//获取栈哨兵地址
	stack = (uint32_t *)_current->stack_info.start;
	if (*stack != STACK_SENTINEL) {
		//保存它,以便进一步检查不会触发相同的错误
		*stack = STACK_SENTINEL;
		//栈溢出异常,中止线程
		z_except_reason(K_ERR_STACK_CHK_FAIL);
	}
}
#endif

#ifdef CONFIG_MULTITHREADING
void z_impl_k_thread_start(struct k_thread *thread)
{
	z_sched_start(thread);
}

#ifdef CONFIG_USERSPACE
static inline void z_vrfy_k_thread_start(struct k_thread *thread)
{
	Z_OOPS(Z_SYSCALL_OBJ(thread, K_OBJ_THREAD));
	return z_impl_k_thread_start(thread);
}
#include <syscalls/k_thread_start_mrsh.c>
#endif
#endif

#ifdef CONFIG_MULTITHREADING
//新线程加入调度
static void schedule_new_thread(struct k_thread *thread, k_timeout_t delay)
{
#ifdef CONFIG_SYS_CLOCK_EXISTS
	//如果该线程是非等待
	if (K_TIMEOUT_EQ(delay, K_NO_WAIT)) {
		k_thread_start(thread);//启动该线程
	} else {//否则加入到延时队列
		z_add_thread_timeout(thread, delay);
	}
#else //不存在系统时钟,无法延时,只能立刻启动
	ARG_UNUSED(delay);
	k_thread_start(thread);
#endif
}
#endif

#if CONFIG_STACK_POINTER_RANDOM
int z_stack_adjust_initialized;
//获取一个随机偏移
static size_t random_offset(size_t stack_size)
{
	size_t random_val;

	if (!z_stack_adjust_initialized) {
		//如果是启动阶段,则获取启动阶段的时候诞生的随机数
		z_early_boot_rand_get((uint8_t *)&random_val, sizeof(random_val));
	} else {//获取范围内的随机数
		sys_rand_get((uint8_t *)&random_val, sizeof(random_val));
	}
	//这里不需要担心大小的对齐,需要arch_new_thread()来完成
	//FIXME:这不是获得一个范围内的随机数的最佳方法
	//利用随机数种子获得一个随机的偏移量
	const size_t fuzz = random_val % CONFIG_STACK_POINTER_RANDOM;
	//并对该随机的偏移量进行地址合法性检查
	if (unlikely(fuzz * 2 > stack_size)) {
		return 0;
	}
	return fuzz;
}
#if defined(CONFIG_STACK_GROWS_UP) //这是非常罕见的
#error "Stack pointer randomization not implemented for upward growing stacks"
#endif
#endif

//设置线程栈,通过给定的一个缓冲区
static char *setup_thread_stack(struct k_thread *new_thread,
								k_thread_stack_t *stack, size_t stack_size)
{
	size_t stack_obj_size, stack_buf_size;
	char *stack_ptr, *stack_buf_start;
	size_t delta = 0;

	//计算出栈对象大小,栈缓冲起始地址,栈大小
#ifdef CONFIG_USERSPACE
	if (z_stack_is_user_capable(stack)) {
		stack_obj_size = Z_THREAD_STACK_SIZE_ADJUST(stack_size);
		stack_buf_start = Z_THREAD_STACK_BUFFER(stack);
		stack_buf_size = stack_obj_size - K_THREAD_STACK_RESERVED;
	} else
#endif
	{ 	//对象不能承载用户模式线程
		stack_obj_size = Z_KERNEL_STACK_SIZE_ADJUST(stack_size);
		stack_buf_start = Z_KERNEL_STACK_BUFFER(stack);
		stack_buf_size = stack_obj_size - K_KERNEL_STACK_RESERVED;
	}

	//在堆栈对象的高端的初始堆栈指针
	//可能在此函数中稍后通过TLS或随机偏移量减少
	stack_ptr = (char *)stack + stack_obj_size;
	//栈的信息调试检查
	LOG_DBG("stack %p for thread %p: obj_size=%zu buf_start=%p "
			" buf_size %zu stack_ptr=%p",
			stack, new_thread, stack_obj_size, stack_buf_start,
			stack_buf_size, stack_ptr);
	
	//初始化栈,如果需要
#ifdef CONFIG_INIT_STACKS
	memset(stack_buf_start, 0xaa, stack_buf_size);
#endif
	//配置栈哨兵,如果需要
#ifdef CONFIG_STACK_SENTINEL
	//将堆栈哨兵放置在堆栈区域的最低4字节处
	//我们会定期检查线程是否仍然存在,如果线程不存在就终止它
	*((uint32_t *)stack_buf_start) = STACK_SENTINEL;
#endif

#ifdef CONFIG_THREAD_LOCAL_STORAGE
	//TLS始终是堆栈缓冲区中的最后一个
	delta += arch_tls_stack_setup(new_thread, stack_ptr);
#endif

#ifdef CONFIG_THREAD_USERSPACE_LOCAL_DATA
	size_t tls_size = sizeof(struct _thread_userspace_local_data);
	//在堆栈缓冲区的最高内存上为本地数据预留空间
	delta += tls_size;
	new_thread->userspace_local_data = (struct _thread_userspace_local_data *)
									   (stack_ptr - delta);
#endif

	//获取一个随机偏移,如果需要的话
#if CONFIG_STACK_POINTER_RANDOM
	delta += random_offset(stack_buf_size);
#endif
	delta = ROUND_UP(delta, ARCH_STACK_PTR_ALIGN);
	
#ifdef CONFIG_THREAD_STACK_INFO
	//初始值,平台实现了MPU守卫
	//从堆栈缓冲区“借”内存(不在K_THREAD_STACK_RESERVED中跟踪)将需要适当地更新这个
	//这里跟踪的边界对应于线程可以访问的堆栈对象区域,其中包括TLS
	new_thread->stack_info.start = (uintptr_t)stack_buf_start;
	new_thread->stack_info.size = stack_buf_size;
	new_thread->stack_info.delta = delta;
#endif
	stack_ptr -= delta;

	return stack_ptr;
}

#define THREAD_COOKIE	0x1337C0D3

//提供的stack_size值被假定为K_THREAD_STACK_SIZEOF(stack)的结果
//或者传递给定义了'stack'的K_THREAD_STACK_DEFINE()实例的size值
char *z_setup_new_thread(struct k_thread *new_thread,
						 k_thread_stack_t *stack, size_t stack_size,
						 k_thread_entry_t entry,
						 void *p1, void *p2, void *p3,
						 int prio, uint32_t options, const char *name)
{
	char *stack_ptr;
	//设置k_thread.base.cookie为指定参考值
#if __ASSERT_ON
	atomic_val_t old_val = atomic_set(&new_thread->base.cookie,
									  THREAD_COOKIE);
	//必须是垃圾或0,从来没有设置.在z_thread_single_abort()结束时清除
	__ASSERT(old_val != THREAD_COOKIE,
			 "re-use of active thread object %p detected", new_thread);
#endif
	//检查线程主的优先级是否合法
	Z_ASSERT_VALID_PRIO(prio, entry);

#ifdef CONFIG_USERSPACE
	//参数检查,用户者判断
	__ASSERT((options & K_USER) == 0 || z_stack_is_user_capable(stack),
			  "user thread %p with kernel-only stack %p",
			  new_thread, stack);
	z_object_init(new_thread);//新线程主初始化
	z_object_init(stack);//堆栈初始化
	new_thread->stack_obj = stack;//绑定线程
	new_thread->syscall_frame = NULL;
	//任何给定的线程都可以访问自己
	k_object_access_grant(new_thread, new_thread);
#endif

	//新线程等待队列的初始化
	z_waitq_init(&new_thread->base.join_waiters);
	//初始化各种struct k_thread成员
	z_init_thread_base(&new_thread->base, prio, _THREAD_PRESTART, options);
	//为新线程设置堆栈
	stack_ptr = setup_thread_stack(new_thread, stack, stack_size);

#ifdef KERNEL_COHERENCE
	//检查线程对象是安全的,但是堆栈仍然被缓存!
	__ASSERT_NO_MSG(arch_mem_coherent(new_thread));
	__ASSERT_NO_MSG(!arch_mem_coherent(stack));
#endif

	//平台层线程初始化,绑定堆栈和线程主及其参数
	arch_new_thread(new_thread, stack, stack_ptr, entry, p1, p2, p3);
	//静态线程随后用实际值覆盖它
	new_thread->init_data = NULL;
	new_thread->fn_abort = NULL;

#ifdef CONFIG_USE_SWITCH
	//switch_handle必须为非空,除非出于同步的原因在z_swap()中
	//历史上,一些概念上的USE_SWITCH架构实际上忽略了这个领域
	__ASSERT(new_thread->switch_handle != NULL,
			 "arch layer failed to initialize switch_handle");
#endif

#ifdef CONFIG_THREAD_CUSTOM_DATA
	//初始化自定义数据字段(值对内核是不透明的)
	new_thread->custom_data = NULL;
#endif

#ifdef CONFIG_THREAD_MONITOR
	//新线程绑定其线程主和三个可选参数
	new_thread->entry.pEntry = entry;
	new_thread->entry.parameter1 = p1;
	new_thread->entry.parameter2 = p2;
	new_thread->entry.parameter3 = p3;
	k_spinlock_key_t key = k_spin_lock(&z_thread_monitor_lock);
	//新线程下一个线程为内核首线程
	new_thread->next_thread = _kernel.threads;
	//内核线程集首线程被更新为新线程
	_kernel.threads = new_thread;
	k_spin_unlock(&z_thread_monitor_lock, key);
#endif

#ifdef CONFIG_THREAD_NAME
	if (name != NULL) {//是否需要设置线程名
		strncpy(new_thread->name, name, CONFIG_THREAD_MAX_NAME_LEN - 1);
		//确保NULL终止，如果更长则截断
		new_thread->name[CONFIG_THREAD_MAX_NAME_LEN - 1] = '\0';
	} else {
		new_thread->name[0] = '\0';
	}
#endif

#ifdef CONFIG_SCHED_CPU_MASK
	//初始化每CPU变量同步原语,它对于本地线程组有很大意义
	new_thread->base.cpu_mask = -1;
#endif

#ifdef CONFIG_ARCH_HAS_CUSTOM_SWAP_TO_MAIN
	//如果虚拟线程未被使用,_current可能为空
	if (!_current) {
		new_thread->resource_pool = NULL;
		return stack_ptr;
	}
#endif

#ifdef CONFIG_USERSPACE
	//初始化内存域
	z_mem_domain_init_thread(new_thread);
	//新线程继承当前线程属性
	if ((options & K_INHERIT_PERMS) != 0U) {
		z_thread_perms_inherit(_current, new_thread);
	}
#endif

#ifdef CONFIG_SCHED_DEADLINE
	//调度所用初始化
	new_thread->base.prio_deadline = 0;
#endif

	//初始化资源池
	new_thread->resource_pool = _current->resource_pool;
	sys_trace_thread_create(new_thread);

#ifdef CONFIG_THREAD_RUNTIME_STATS
	//初始化运行时状态
	memset(&new_thread->rt_stats, 0, sizeof(new_thread->rt_stats));
#endif

	return stack_ptr;
}

#ifdef CONFIG_MULTITHREADING
//线程的创建
k_tid_t z_impl_k_thread_create(struct k_thread *new_thread,
							   k_thread_stack_t *stack,
							   size_t stack_size, k_thread_entry_t entry,
							   void *p1, void *p2, void *p3,
							   int prio, uint32_t options, k_timeout_t delay)
{
	//中断环境检查
	__ASSERT(!arch_is_in_isr(), "Threads may not be created in ISRs");

	//特殊情况,仅用于单元测试
#if defined(CONFIG_TEST) && defined(CONFIG_ARCH_HAS_USERSPACE) && !defined(CONFIG_USERSPACE)
	__ASSERT((options & K_USER) == 0,
			  "Platform is capable of user mode, and test thread created with K_USER option,"
			  " but neither CONFIG_TEST_USERSPACE nor CONFIG_USERSPACE is set\n");
#endif

	//创建一个新的线程
	z_setup_new_thread(new_thread, stack, stack_size, entry, p1, p2, p3,
					   prio, options, NULL);
					   
	//如果线程不是永久阻塞,则加入调度器或者延迟加入调度器
	if (!K_TIMEOUT_EQ(delay, K_FOREVER)) {
		schedule_new_thread(new_thread, delay);
	}
	return new_thread;
}


#ifdef CONFIG_USERSPACE
bool z_stack_is_user_capable(k_thread_stack_t *stack)
{
	return z_object_find(stack) != NULL;
}

k_tid_t z_vrfy_k_thread_create(struct k_thread *new_thread,
							   k_thread_stack_t *stack,
							   size_t stack_size, k_thread_entry_t entry,
							   void *p1, void *p2, void *p3,
							   int prio, uint32_t options, k_timeout_t delay)
{
	size_t total_size, stack_obj_size;
	struct z_object *stack_object;
	//线程和堆栈对象*必须*处于未初始化状态
	Z_OOPS(Z_SYSCALL_OBJ_NEVER_INIT(new_thread, K_OBJ_THREAD));
	//不需要检查z_stack_is_user_capable(),如果它不在对象表中,它就不会存在
	stack_object = z_object_find(stack);
	
	Z_OOPS(Z_SYSCALL_VERIFY_MSG(z_obj_validation_check(stack_object, stack,
								K_OBJ_THREAD_STACK_ELEMENT,
								_OBJ_INIT_FALSE) == 0,
								"bad stack object"));

	//通过计算总大小并与对象元数据中的大小值进行比较,验证传入的堆栈大小是正确的
	Z_OOPS(Z_SYSCALL_VERIFY_MSG(!size_add_overflow(K_THREAD_STACK_RESERVED,
						        stack_size, &total_size),
								"stack size overflow (%zu+%zu)",
								stack_size,
								K_THREAD_STACK_RESERVED));

	//测试小于或等于,因为可能已经为对齐约束分配了额外的空间
#ifdef CONFIG_GEN_PRIV_STACKS
	stack_obj_size = stack_object->data.stack_data->size;
#else
	stack_obj_size = stack_object->data.stack_size;
#endif
	Z_OOPS(Z_SYSCALL_VERIFY_MSG(total_size <= stack_obj_size,
								"stack size %zu is too big, max is %zu",
								total_size, stack_obj_size));

	//用户线程只能创建其他用户线程,它们不能被标记为必不可少
	Z_OOPS(Z_SYSCALL_VERIFY(options & K_USER));
	Z_OOPS(Z_SYSCALL_VERIFY(!(options & K_ESSENTIAL)));

	//检验先验论证的有效性;必须与调用者的优先级相同或更低
	Z_OOPS(Z_SYSCALL_VERIFY(_is_valid_prio(prio, NULL)));
	Z_OOPS(Z_SYSCALL_VERIFY(z_is_prio_lower_or_equal(prio, _current->base.prio)));

	//调用系统初始化新线程
	z_setup_new_thread(new_thread, stack, stack_size,
					   entry, p1, p2, p3, prio, options, NULL);

	//如果它不是永久阻塞,则加入调度器或者延迟加入调度器
	if (!K_TIMEOUT_EQ(delay, K_FOREVER)) {
		schedule_new_thread(new_thread, delay);
	}
	return new_thread;
}
#include <syscalls/k_thread_create_mrsh.c>
#endif
#endif

#ifdef CONFIG_MULTITHREADING
#ifdef CONFIG_USERSPACE
static void grant_static_access(void)
{
	Z_STRUCT_SECTION_FOREACH(z_object_assignment, pos) {
		for (int i = 0; pos->objects[i] != NULL; i++) {
			k_object_access_grant(pos->objects[i], pos->thread);
		}
	}
}
#endif

//初始化静态线程
void z_init_static_threads(void)
{
	//迭代初始化整个线程集合
	_FOREACH_STATIC_THREAD(thread_data) {
		//对单个线程实行静态初始化,使用指定的数据集
		z_setup_new_thread(thread_data->init_thread,
						   thread_data->init_stack,
						   thread_data->init_stack_size,
					   	   thread_data->init_entry,
						   thread_data->init_p1,
						   thread_data->init_p2,
						   thread_data->init_p3,
						   thread_data->init_prio,
						   thread_data->init_options,
						   thread_data->init_name);
		//它的回响是针对本身
		thread_data->init_thread->init_data = thread_data;
	}

#ifdef CONFIG_USERSPACE
	grant_static_access();
#endif

	//非遗留静态线程可以立即启动或在之前指定的延迟之后启动
	//即使调度器被锁定,滴答仍然可以被传递和处理
	//使用一个预定锁来阻止它们在全部启动之前运行
	//注意,使用遗留API定义的静态线程有一个K_FOREVER延迟
	k_sched_lock();
	_FOREACH_STATIC_THREAD(thread_data) {
		//迭代整个已经初始化的线程集合,根据延时适时加入调度器或挂起(不加入)
		if (thread_data->init_delay != K_TICKS_FOREVER) {
			schedule_new_thread(thread_data->init_thread,
					    K_MSEC(thread_data->init_delay));
		}
	}
	k_sched_unlock();
}
#endif

//初始化k_thread.base集合
void z_init_thread_base(struct _thread_base *thread_base, int priority,
						uint32_t initial_state, unsigned int options)
{
	//k_q_node在列表中第一次插入时进行初始化
	//用户选项记录
	thread_base->user_options = (uint8_t)options;
	//初始化线程状态
	thread_base->thread_state = (uint8_t)initial_state;
	//初始化优先级
	thread_base->prio = priority;
	//初始化调度锁
	thread_base->sched_locked = 0U;
#ifdef CONFIG_SMP
	//多处理器模式,确认是否空闲态的标记初始化
	thread_base->is_idle = 0;
#endif

	//初始化线程超时时间,swap_data不需要初始化
	z_init_thread_timeout(thread_base);
}

//初始化用户模式下的线程主
FUNC_NORETURN void k_thread_user_mode_enter(k_thread_entry_t entry,
											void *p1, void *p2, void *p3)
{
	_current->base.user_options |= K_USER;//当前线程模式被标记为用户模式
	z_thread_essential_clear();//清除线程的特权标记
	
#ifdef CONFIG_THREAD_MONITOR
	_current->entry.pEntry = entry;//初始化线程主
	_current->entry.parameter1 = p1;//可选参数1
	_current->entry.parameter2 = p2;//可选参数2
	_current->entry.parameter3 = p3;//可选参数3
#endif

#ifdef CONFIG_USERSPACE
	//断言检查当前线程的对象主体
	__ASSERT(z_stack_is_user_capable(_current->stack_obj),
			 "dropping to user mode with kernel-only stack object");
			 
#ifdef CONFIG_THREAD_USERSPACE_LOCAL_DATA
	//清空当前线程的本地数据集
	memset(_current->userspace_local_data, 0,
	       sizeof(struct _thread_userspace_local_data));
#endif

#ifdef CONFIG_THREAD_LOCAL_STORAGE
	//平台层设置堆栈TLS空间,如果需要
	arch_tls_stack_setup(_current, (char *)(_current->stack_info.start +
						 _current->stack_info.size));
#endif

	//平台层初始化用户模式项
	arch_user_mode_enter(entry, p1, p2, p3);
#else
	//在这种情况下,我们没有重置堆栈
	z_thread_entry(entry, p1, p2, p3);
#endif
}

//之所以在这里定义这些自旋锁断言谓词
//是因为在spinlock.h中使用它们是一个巨大的头信息排序问题
#ifdef CONFIG_SPIN_VALIDATE
//自旋锁合法检查
bool z_spin_lock_valid(struct k_spinlock *l)
{
	uintptr_t thread_cpu = l->thread_cpu;
	//检查线程CPU标号是否是当前线程
	//确认自旋锁内该线程是否为当前线程
	if (thread_cpu) {
		if ((thread_cpu & 3U) == _current_cpu->id) {
			return false;
		}
	}
	return true;
}

bool z_spin_unlock_valid(struct k_spinlock *l)
{
	if (l->thread_cpu != (_current_cpu->id | (uintptr_t)_current)) {
		return false;
	}
	l->thread_cpu = 0;
	return true;
}

//为指定的自旋锁配置其所有者,为当前线程的CPU标号
void z_spin_lock_set_owner(struct k_spinlock *l)
{
	l->thread_cpu = _current_cpu->id | (uintptr_t)_current;
}
#endif

//禁止该线程硬件浮点数功能
int z_impl_k_float_disable(struct k_thread *thread)
{
#if defined(CONFIG_FPU) && defined(CONFIG_FPU_SHARING)
	return arch_float_disable(thread);
#else
	return -ENOSYS;
#endif
}

#ifdef CONFIG_USERSPACE
static inline int z_vrfy_k_float_disable(struct k_thread *thread)
{
	Z_OOPS(Z_SYSCALL_OBJ(thread, K_OBJ_THREAD));
	return z_impl_k_float_disable(thread);
}
#include <syscalls/k_float_disable_mrsh.c>
#endif

#ifdef CONFIG_IRQ_OFFLOAD
//使offload_sem在测试时在外部可见,以便在错误发生时将其发布到外部
K_SEM_DEFINE(offload_sem, 1, 1);

//将指定的流程载入到中断上下文内运行
void irq_offload(irq_offload_routine_t routine, const void *parameter)
{
	k_sem_take(&offload_sem, K_FOREVER);
	arch_irq_offload(routine, parameter);
	k_sem_give(&offload_sem);
}
#endif

#if defined(CONFIG_INIT_STACKS) && defined(CONFIG_THREAD_STACK_INFO)
#ifdef CONFIG_STACK_GROWS_UP
#error "Unsupported configuration for stack analysis"
#endif

//线程堆栈空间获取
int z_impl_k_thread_stack_space_get(const struct k_thread *thread,
									size_t *unused_ptr)
{
	//线程堆栈起始地址
	const uint8_t *start = (uint8_t *)thread->stack_info.start;
	//堆栈大小的获取
	size_t size = thread->stack_info.size;
	size_t unused = 0;
	const uint8_t *checked_stack = start;
	//将任何局部变量的地址作为堆栈指针的浅界
	//上面的地址保证是可访问的
	//将堆栈指针初始化时定位到开头
	const uint8_t *stack_pointer = (const uint8_t *)&start;

	//如果我们正在分析的堆栈上运行,一些内存管理硬件将产生一个异常
	//如果我们读取未使用的堆栈内存
	//当从用户模式调用时,这永远不会发生
	//因为用户模式将始终在特权提升堆栈上运行此函数
	if ((stack_pointer > start) && (stack_pointer <= (start + size)) &&
	    IS_ENABLED(CONFIG_NO_UNUSED_STACK_INSPECTION)) {
		//TODO:我们可以添加一个arch_ API调用来临时禁用CPU中的堆栈检查
		//但这需要正确管理wrt上下文切换/中断
		return -ENOTSUP;
	}

	if (IS_ENABLED(CONFIG_STACK_SENTINEL)) {
		//为哨兵值保留的堆栈缓冲区的前4个字节,它不会为线程堆栈0xAAAAAAAA
		//FIXME:thread->stack_info.start应该反思这一点!
		checked_stack += 4;
		size -= 4;
	}

	for (size_t i = 0; i < size; i++) {
		if ((checked_stack[i]) == 0xaaU) {
			unused++;//检查未使用的堆栈空间
		} else {
			break;
		}
	}//并将其反馈到上层
	*unused_ptr = unused;
	return 0;
}

#ifdef CONFIG_USERSPACE
int z_vrfy_k_thread_stack_space_get(const struct k_thread *thread,
									size_t *unused_ptr)
{
	size_t unused;
	int ret;

	ret = Z_SYSCALL_OBJ(thread, K_OBJ_THREAD);
	CHECKIF(ret != 0) {
		return ret;
	}
	
	//获取堆栈空间
	ret = z_impl_k_thread_stack_space_get(thread, &unused);
	CHECKIF(ret != 0) {
		return ret;
	}

	//将该数据拷贝到上层
	ret = z_user_to_copy(unused_ptr, &unused, sizeof(size_t));
	CHECKIF(ret != 0) {
		return ret;
	}

	return 0;
}
#include <syscalls/k_thread_stack_space_get_mrsh.c>
#endif
#endif

#ifdef CONFIG_USERSPACE
static inline k_ticks_t z_vrfy_k_thread_timeout_remaining_ticks(struct k_thread *t)
{
	Z_OOPS(Z_SYSCALL_OBJ(t, K_OBJ_THREAD));
	return z_impl_k_thread_timeout_remaining_ticks(t);
}
#include <syscalls/k_thread_timeout_remaining_ticks_mrsh.c>

static inline k_ticks_t z_vrfy_k_thread_timeout_expires_ticks(
						  struct k_thread *t)
{
	Z_OOPS(Z_SYSCALL_OBJ(t, K_OBJ_THREAD));
	return z_impl_k_thread_timeout_expires_ticks(t);
}
#include <syscalls/k_thread_timeout_expires_ticks_mrsh.c>
#endif

#ifdef CONFIG_INSTRUMENT_THREAD_SWITCHING
//更新线程切换进入的标记
void z_thread_mark_switched_in(void)
{
#ifdef CONFIG_TRACING
	sys_trace_thread_switched_in();
#endif

#ifdef CONFIG_THREAD_RUNTIME_STATS
	struct k_thread *thread;
	//获取当前运行线程的描述符
	thread = k_current_get();
	//更新上一次切换进入的时间为当前时间
#ifdef CONFIG_THREAD_RUNTIME_STATS_USE_TIMING_FUNCTIONS
	thread->rt_stats.last_switched_in = timing_counter_get();
#else
	thread->rt_stats.last_switched_in = k_cycle_get_32();
#endif

#endif
}

//更新线程切换出去的标记
void z_thread_mark_switched_out(void)
{
#ifdef CONFIG_THREAD_RUNTIME_STATS
#ifdef CONFIG_THREAD_RUNTIME_STATS_USE_TIMING_FUNCTIONS
	timing_t now;
#else
	uint32_t now;
#endif
	uint64_t diff;
	struct k_thread *thread;
	//获取当前线程描述符
	thread = k_current_get();
	
	if (unlikely(thread->rt_stats.last_switched_in == 0)) {
		return;//线程没有运行过,如何切换出去
	}
	if (unlikely(thread->base.thread_state == _THREAD_DUMMY)) {
		return;//虚拟线程没有stat结构
	}

	//更新当前线程切换的时间
#ifdef CONFIG_THREAD_RUNTIME_STATS_USE_TIMING_FUNCTIONS
	now = timing_counter_get();
	diff = timing_cycles_get(&thread->rt_stats.last_switched_in, &now);
#else
	now = k_cycle_get_32();
	diff = (uint64_t)now - thread->rt_stats.last_switched_in;
	thread->rt_stats.last_switched_in = 0;
#endif

	thread->rt_stats.stats.execution_cycles += diff;

	threads_runtime_stats.execution_cycles += diff;
#endif

#ifdef CONFIG_TRACING
	sys_trace_thread_switched_out();
#endif
}

#ifdef CONFIG_THREAD_RUNTIME_STATS
//指定线程的运行状态获取
int k_thread_runtime_stats_get(k_tid_t thread, k_thread_runtime_stats_t *stats)
{
	if ((thread == NULL) || (stats == NULL)) {
		return -EINVAL;
	}
	//将其拷贝到上层空间
	(void)memcpy(stats, &thread->rt_stats.stats, sizeof(thread->rt_stats.stats));
	return 0;
}

//获取所有线程的运行状态
int k_thread_runtime_stats_all_get(k_thread_runtime_stats_t *stats)
{
	if (stats == NULL) {
		return -EINVAL;
	}

	(void)memcpy(stats, &threads_runtime_stats, sizeof(threads_runtime_stats));

	return 0;
}
#endif

#endif
