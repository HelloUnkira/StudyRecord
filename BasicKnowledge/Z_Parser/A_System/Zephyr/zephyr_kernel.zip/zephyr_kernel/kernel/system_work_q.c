/*
 * zephyr内核
 */

//系统工作队列

#include <kernel.h>
#include <init.h>

K_KERNEL_STACK_DEFINE(sys_work_q_stack, CONFIG_SYSTEM_WORKQUEUE_STACK_SIZE);

//定义一个系统工作队列
struct k_work_q k_sys_work_q;

//初始化系统工作队列
static int k_sys_work_q_init(const struct device *dev)
{
	ARG_UNUSED(dev);

	//启动工作队列
	k_work_q_start(&k_sys_work_q, sys_work_q_stack,
				   K_KERNEL_STACK_SIZEOF(sys_work_q_stack),
				   CONFIG_SYSTEM_WORKQUEUE_PRIORITY);
	//配置工作队列名字
	k_thread_name_set(&k_sys_work_q.thread, "sysworkq");

	return 0;
}

SYS_INIT(k_sys_work_q_init, POST_KERNEL, CONFIG_KERNEL_INIT_PRIORITY_DEFAULT);
