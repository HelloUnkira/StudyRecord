/*
 * zephyr内核架构层
 */

//这个文件的目的是提供基本/最小的内核结构定义
//以便在不包括kernel.h的情况下使用它们
//1.kernel_struct.h不直接或间接依赖于kernel.h
//(也就是说,它不应该包含任何包含kernel.h的头文件)
//2.Kernel.h将隐含kernel_struct.h,这样当包含Kernel.h时
//就不需要显式地包含kernel_struct.h

#ifndef ZEPHYR_KERNEL_INCLUDE_KERNEL_STRUCTS_H_
#define ZEPHYR_KERNEL_INCLUDE_KERNEL_STRUCTS_H_

#if !defined(_ASMLANGUAGE)
#include <sys/atomic.h>
#include <zephyr/types.h>
#include <sched_priq.h>
#include <sys/dlist.h>
#include <sys/util.h>
#include <sys/sys_heap.h>
#endif

//内核优先级数
#define K_NUM_PRIORITIES \
	(CONFIG_NUM_COOP_PRIORITIES + \
	 CONFIG_NUM_PREEMPT_PRIORITIES + 1)

//内核优先级位图
#define K_NUM_PRIO_BITMAPS ((K_NUM_PRIORITIES + 31) >> 5)

//struct k_thread的位掩码定义,thread_state字段
//必须在kerneL_arch_data.h之前,因为可能需要它们已经定义

//状态:common使用低位,arch-specific使用高位
#define _THREAD_DUMMY (BIT(0))//不是真正的线程
#define _THREAD_PENDING (BIT(1))//线程正在等待一个对象
#define _THREAD_PRESTART (BIT(2))//线程尚未启动
#define _THREAD_DEAD (BIT(3))//线程终止
#define _THREAD_SUSPENDED (BIT(4))//线程被挂起
#define _THREAD_ABORTING (BIT(5))//线程被终止
#define _THREAD_QUEUED (BIT(7))//线程存在于就绪队列中

#ifdef CONFIG_STACK_SENTINEL
//堆栈最低字节中的魔法值(堆栈溢出检查)
#define STACK_SENTINEL 0xF0F0F0F0
#endif

//在线程不可抢占的时候的_thread_base.preempt的最小值
#define _NON_PREEMPT_THRESHOLD 0x0080U
//在线程可抢占的时候的_thread_base.preempt的最大值
#define _PREEMPT_THRESHOLD (_NON_PREEMPT_THRESHOLD - 1U)
#if !defined(_ASMLANGUAGE)

struct _ready_q {
#ifndef CONFIG_SMP
	//总是包含下一个要运行的线程:不能为NULL
	struct k_thread *cache;
#endif

#if defined(CONFIG_SCHED_DUMB)
	sys_dlist_t runq;//运行队列(链表)
#elif defined(CONFIG_SCHED_SCALABLE)
	struct _priq_rb runq;//运行队列(红黑树)
#elif defined(CONFIG_SCHED_MULTIQ)
	struct _priq_mq runq;//运行队列(位图队列集,Linux prio_array_t)
#endif
};

typedef struct _ready_q _ready_q_t;

struct _cpu {
	uint32_t nested;//嵌套中断计数
	char *irq_stack;//中断栈指针基地址
	struct k_thread *current;//当前调度线程
	struct k_thread *idle_thread;//每个CPU分配一个空闲线程
	struct k_thread *pending_abort;//如果非空,自中止线程需要清理

#if (CONFIG_NUM_METAIRQ_PRIORITIES > 0) && (CONFIG_NUM_COOP_PRIORITIES > 0)
	struct k_thread *metairq_preempted;//Coop线程被当前metairq抢占，或NULL 
#endif

#ifdef CONFIG_TIMESLICING
	int slice_ticks;//当前时间片中剩余的节拍数
#endif

	uint8_t id;

#ifdef CONFIG_SMP
	uint8_t swap_ok;//当_current允许上下文切换时为True
#endif
};

typedef struct _cpu _cpu_t;

struct z_kernel {
	//同步原语,每CPU变量,每个CPU只负责本地的线程组并执行它们
	struct _cpu cpus[CONFIG_MP_NUM_CPUS];

#ifdef CONFIG_SYS_CLOCK_EXISTS
	sys_dlist_t timeout_q;//超时队列
#endif

#ifdef CONFIG_PM
	int32_t idle;//内核空闲的节拍数
#endif

	//ready queue:可以是大的,保留在小的字段之后
	//因为一些程序集(例如ARC)在偏移量的编码上是有限的
	struct _ready_q ready_q;

#ifdef CONFIG_FPU_SHARING
	//*除了'current_fp'字段外,不存在'current_sse'字段
	//因为不可能将IA-32非整数寄存器划分为由不同线程拥有的两个不同的块
	//换句话说，如果'fxnsave/fxrstor'指令同时保存/恢复X87 FPU和XMM寄存器
	//一个线程不可能只“拥有”XMM寄存器。
	struct k_thread *current_fp;//拥有FP 寄存器的线程
#endif

#if defined(CONFIG_THREAD_MONITOR)
	struct k_thread *threads;//所有线程的单链表
#endif
};

typedef struct z_kernel _kernel_t;

extern struct z_kernel _kernel;

#ifdef CONFIG_SMP

//如果当前上下文可以被抢占并迁移到另一个SMP CPU,则为True
bool z_smp_cpu_mobile(void);

//当前线程的执行者,CPU
#define _current_cpu ({ __ASSERT_NO_MSG(!z_smp_cpu_mobile()); \
			arch_curr_cpu(); })
//当前执行的线程
#define _current k_current_get()
//
#else
//如果只有一个CPU(单核处理器),那么只有cpus[0]存在
#define _current_cpu (&_kernel.cpus[0])
#define _current _kernel.cpus[0].current
#endif

#define _timeout_q _kernel.timeout_q

//内核等待队列记录
#ifdef CONFIG_WAITQ_SCALABLE
//等待队列(红黑树)
typedef struct {
	struct _priq_rb waitq;
} _wait_q_t;
//俩个红黑树节点比较,比较俩个节点的所有者(线程)的权限(线程优先级)
//红黑树是自平衡的排序二叉树,排列时是按k_thread.base.order_key为关键字
extern bool z_priq_rb_lessthan(struct rbnode *a, struct rbnode *b);
//初始化等待队列
#define Z_WAIT_Q_INIT(wait_q) { { { .lessthan_fn = z_priq_rb_lessthan } } }
//
#else
//等待队列(链表)
typedef struct {
	sys_dlist_t waitq;
} _wait_q_t;
//初始化等待队列
#define Z_WAIT_Q_INIT(wait_q) { SYS_DLIST_STATIC_INIT(&(wait_q)->waitq) }
#endif

//内核超时记录
struct _timeout;
//超时回调
typedef void (*_timeout_func_t)(struct _timeout *t);

struct _timeout {
	sys_dnode_t node;//超时节点
	_timeout_func_t fn;//超时回调
#ifdef CONFIG_TIMEOUT_64BIT
	int64_t dticks;//不能使用k_ticks_t的头依赖原因
#else
	int32_t dticks;
#endif
};

#endif
#endif
