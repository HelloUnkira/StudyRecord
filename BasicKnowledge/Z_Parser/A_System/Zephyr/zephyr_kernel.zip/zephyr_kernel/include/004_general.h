/*
 * zephyr底层,list,rbtree
 * 本文件并不存在,只是实现的摘要
 */





//摘要来源于#include <sys/sflist.h>
#ifdef __LP64__
typedef uint64_t unative_t;
#else
typedef uint32_t unative_t;
#endif

struct _sfnode {//单向链表节点
	//这是一个很特殊的设计,因为指针是一个无符号整数
	//但指针又是地址对齐的,所以低地址永远为0
	//该实现是,高位做指针,低位用于做标签
	unative_t next_and_flags;
};

typedef struct _sfnode sys_sfnode_t;

//带头尾节点的单向链表
struct _sflist {
	sys_sfnode_t *head;
	sys_sfnode_t *tail;
};

//带头尾节点的单向链表
typedef struct _sflist sys_sflist_t;

//摘要来源于#include <sys/dlist.h> 
//双向链表(double list)
struct _dnode {
	union {
		struct _dnode *head;//双向链表头
		struct _dnode *next;//双向链表下一节点
	};
	union {
		struct _dnode *tail;//双向链表尾
		struct _dnode *prev;//双向链表上一节点
	};
};

//以头尾节点为中心的双向链表
typedef struct _dnode sys_dlist_t;
//以节点为中心的双向链表
typedef struct _dnode sys_dnode_t;


//上述俩种容器为其系统提供底层数据结构的支持
//基本的增删查改与通化的实现基本一致
//模板化实现在#include <sys/list_gen.h>中
//除去其中某些宏定义的实现,这是沿用Linux中的设计

//一种遍历的实现
#include XXX_TRAVERSE(list_name, list, node) \
	for (node = sys_ ## list_name ## _peek_head(list); node != NULL; \
	     node = sys_ ## list_name ## _peek_next(node))

//一种反向索引的实现(已知当前node地址,container类型,所有者中命名node),求出所有者地址
//其中最为主要的实现是offsetof,它可以求出所有者中任一成员与所有者头地址之间的差值
//这可以简要理解为:malloc(sizeof(container));&container - &container.member;
//但是Linux中的实现是直接使用0地址计算的,也即在0地址上创建该所有者以计算偏移
#define CONTAINER_OF(ptr, container_type, member) \
	((container_type *)(((char *)(ptr)) - offsetof(container_type, member)))

//已知链表地址求所有者
#define XXX_CONTAINER(list_node, container, node) \
	((list_node) ? CONTAINER_OF((list_node), __typeof__(*(container)), node) : NULL)





//摘要来源于#include <sys/rb.h>
//特殊设计,颜色位为指针位的地位,因为指针是地址对齐
//低位无效,所以被复用为颜色位
struct rbnode {
	//它拥有俩个孩子的关联,但不存在父亲的关联,父亲的关联
	//在递归时被动态生成
	struct rbnode *children[2];
};

//比较节点A是否严格小于节点B,如果小于函数返回为真
typedef bool (*rb_lessthan_t)(struct rbnode *a, struct rbnode *b);

struct rbtree {
	struct rbnode *root;//根节点
	rb_lessthan_t lessthan_fn;
	int max_depth;//最大深度
#ifdef CONFIG_MISRA_SANE
	struct rbnode *iter_stack[Z_MAX_RBTREE_DEPTH];
	unsigned char iter_left[Z_MAX_RBTREE_DEPTH];
#endif
};

struct _priq_rb {
	struct rbtree tree;
	int next_order_key;//排序关键字
};

//基本的增删查改与通化的原理一致,因为涉及到对结构的优化
//所以实现的细节部分出入较大,因为它使用STACK做的递归

struct _priq_mq {
	sys_dlist_t queues[32];
	unsigned int bitmask;//以位图的方式确认一个集合
						 //该位为1对应queues[i]存在项
};


















