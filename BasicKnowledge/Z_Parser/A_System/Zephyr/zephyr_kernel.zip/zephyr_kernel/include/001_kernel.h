/*
 * zephyr内核架构层
 */

//从该层可以轻易的熟知
//zephyr内核向上层提供的接口和内核自带的实现
#ifndef ZEPHYR_INCLUDE_KERNEL_H_
#define ZEPHYR_INCLUDE_KERNEL_H_

#if !defined(_ASMLANGUAGE)
//很显然,该部分头文件引用并不包括内核实际功能的引用
//也即,它是无依赖项的内核索引
//所以可以通过从该层去了解内核实现细节
#include <kernel_includes.h>//仅一些定义和编译约束项
#include <errno.h>//错误码
#include <stdbool.h>//C语言并不自带bool类型
#include <toolchain.h>//工具链选择

#ifdef CONFIG_THREAD_RUNTIME_STATS_USE_TIMING_FUNCTIONS
#include <timing/timing.h>//特殊项,调度
#endif

#ifdef __cplusplus
extern "C" {
#endif

//优先级指定,COOP(疑似cooperate,?协程),PREEMPT(内核抢占)
#if defined(CONFIG_COOP_ENABLED) && defined(CONFIG_PREEMPT_ENABLED)
#define _NUM_COOP_PRIO (CONFIG_NUM_COOP_PRIORITIES)
#define _NUM_PREEMPT_PRIO (CONFIG_NUM_PREEMPT_PRIORITIES + 1)
//
#elif defined(CONFIG_COOP_ENABLED)
#define _NUM_COOP_PRIO (CONFIG_NUM_COOP_PRIORITIES + 1)
#define _NUM_PREEMPT_PRIO (0)
//
#elif defined(CONFIG_PREEMPT_ENABLED)
#define _NUM_COOP_PRIO (0)
#define _NUM_PREEMPT_PRIO (CONFIG_NUM_PREEMPT_PRIORITIES + 1)
//
#else
#error "invalid configuration"
#endif

//
#define K_PRIO_COOP(x) (-(_NUM_COOP_PRIO - (x)))
#define K_PRIO_PREEMPT(x) (x)
//
#define K_ANY NULL
#define K_END NULL

//最高线程优先级,依赖COOP和PREEMPT
#if defined(CONFIG_COOP_ENABLED) && defined(CONFIG_PREEMPT_ENABLED)
#define K_HIGHEST_THREAD_PRIO (-CONFIG_NUM_COOP_PRIORITIES)
//
#elif defined(CONFIG_COOP_ENABLED)
#define K_HIGHEST_THREAD_PRIO (-CONFIG_NUM_COOP_PRIORITIES - 1)
//
#elif defined(CONFIG_PREEMPT_ENABLED)
#define K_HIGHEST_THREAD_PRIO 0
//
#else
#error "invalid configuration"
#endif

//最低线程优先级,依赖PREEMPT
#ifdef CONFIG_PREEMPT_ENABLED
#define K_LOWEST_THREAD_PRIO CONFIG_NUM_PREEMPT_PRIORITIES
#else
#define K_LOWEST_THREAD_PRIO -1
#endif

//空闲线程优先级,它是在诸如低功耗,睡眠等模式下使用
//通常来说,一旦其余任务都在睡眠时它才可以执行,所以它的优先级最低
#define K_IDLE_PRIO K_LOWEST_THREAD_PRIO
//
#define K_HIGHEST_APPLICATION_THREAD_PRIO (K_HIGHEST_THREAD_PRIO)
#define K_LOWEST_APPLICATION_THREAD_PRIO (K_LOWEST_THREAD_PRIO - 1)

//追踪,调试所用,猜测
#ifdef CONFIG_OBJECT_TRACING
#define _OBJECT_TRACING_NEXT_PTR(type) struct type *__next;
#define _OBJECT_TRACING_LINKED_FLAG uint8_t __linked;
#define _OBJECT_TRACING_INIT \
	.__next = NULL,	     \
	.__linked = 0,
//
#else
#define _OBJECT_TRACING_INIT
#define _OBJECT_TRACING_NEXT_PTR(type)
#define _OBJECT_TRACING_LINKED_FLAG
#endif

//POOL一般来说关联的是memory_pool(内存池)
#ifdef CONFIG_POLL
#define _POLL_EVENT_OBJ_INIT(obj) \
	.poll_events = SYS_DLIST_STATIC_INIT(&obj.poll_events),
#define _POLL_EVENT sys_dlist_t poll_events
//
#else
#define _POLL_EVENT_OBJ_INIT(obj)
#define _POLL_EVENT
#endif

//内核数据结构声明
struct k_thread;		//线程
struct k_mutex;			//互斥锁
struct k_sem;			//信号量
struct k_msgq;			//消息队列
struct k_mbox;			//邮箱
struct k_pipe;			//管道
struct k_queue;			//队列
struct k_fifo;			//FIFO,先进先出,队列思想
struct k_lifo;			//LIFO,后进先出,堆栈思想
struct k_stack;			//堆栈
struct k_mem_slab;		//SLAB分配器
struct k_mem_pool;		//内存池
struct k_timer;			//定时器
struct k_poll_event;	//事件推送
struct k_poll_signal;	//信号推送
struct k_mem_domain;	//内存域
struct k_mem_partition;	//内存分区
struct k_futex;			//线程同步

//执行上下文类型
enum execution_context_types {
	K_ISR = 0,			//中断环境
	K_COOP_THREAD,		//COOP(?协程)环境
	K_PREEMPT_THREAD,	//内核抢占环境
};

//私有,由k_poll和k_work_poll使用
struct k_work_poll;
typedef int (*_poller_cb_t)(struct k_poll_event *event, uint32_t state);

//用户线程回调
//用户线程需要统一到该接口,并在初始化时将执行域地址(函数名)传入到内核
typedef void (*k_thread_user_cb_t)(const struct k_thread *thread, void *user_data);

//遍历系统中的所有线程,并为每个线程调用user_cb函数,锁定与不锁定
//为了更有效这个函数必须设置选项@option{CONFIG_THREAD_MONITOR}
//
//这个API使用k_spin_lock来保护_kernel.threads链表
//这意味着创建新线程和终止现有线程将被阻塞,直到此API返回
extern void k_thread_foreach(k_thread_user_cb_t user_cb, void *user_data);
//工作原理与k_thread_foreach完全相同,但是在执行user_cb时解锁中断
//此API仅在访问_kernel.threads链表项时使用k_spin_lock
//它在用户回调函数处理期间解锁它
//如果在执行foreach函数时创建了新任务,则添加的新任务不会包含在枚举项中
//如果在此枚举动作期间中止了一个任务,那么这里将出现竞争
//并且有可能将此中止的任务包括在该枚举项中
//如果任务被终止,并且当k_thread_foreach_unlocked正在执行时,它的k_thread结构
//所占用的内存被重用,这甚至可能导致系统行为不稳定
//这个函数可能永远不会返回,因为它会跟随一些@c next task指针,把给定的指针当作
//指向k_thread结构体的指针,而它现在是不同的
//不要重用被k_thread结构的task所占用的内存,如果它在任何上下文中被调用后被中止
extern void k_thread_foreach_unlocked(k_thread_user_cb_t user_cb, void *user_data);

#endif

//线程用户选项,汇编代码可能需要,通用部分使用低位,特定域使用高位

//系统线程不能中止
#define K_ESSENTIAL (BIT(0))

//FPU寄存器通过上下文切换进行管理
//这个选项表示线程使用CPU的浮点寄存器
//这指示内核在调度线程时采取其他步骤来保存和恢复这些寄存器的内容
//如果@option{CONFIG_FPU_SHARING}没有启用,则无效
#if defined(CONFIG_FPU_SHARING)
#define K_FP_REGS (BIT(1))
#endif

//用户模式的线程
#define K_USER (BIT(2))

//指示正在创建的线程应该从创建它的线程继承所有内核对象权限
//如果@option{CONFIG_USERSPACE}没有启用,则无效
#define K_INHERIT_PERMS (BIT(3))

//为线程用户选项的x86位掩码定义
#ifdef CONFIG_X86
#if defined(CONFIG_FPU_SHARING) && defined(CONFIG_SSE)
#define K_SSE_REGS (BIT(7))//线程使用SSEx(以及FP)寄存器
#endif
#endif

#if !defined(_ASMLANGUAGE)
//创建一个线程,初始化一个线程,然后安排它执行,该函数返回一个新线程ID
//线程选项是特定于体系结构的,可以包括K_ESSENTIAL,K_FP_REGS和K_SSE_REGS
//可以使用“|”(逻辑OR操作符)分隔多个选项
//传递给这个函数的堆栈对象必须最初使用这些宏中的任何一个来定义,以便可移植:
//K_THREAD_STACK_DEFINE()可以支持用户线程或上级线程的堆栈
//K_KERNEL_STACK_DEFINE()适用于可能只支持supervisor线程的堆栈
//如果启用了CONFIG_USERSPACE,这些堆栈使用的内存就更少
//stack_size参数有约束,它必须是:
//传递给K_THREAD_STACK_DEFINE()或K_KERNEL_STACK_DEFINE()的原始大小值
//K_THREAD_STACK_SIZEOF(stack)的返回值,如果堆栈是用K_THREAD_STACK_DEFINE()定义的
//K_KERNEL_STACK_SIZEOF(stack)的返回值,如果堆栈是用K_KERNEL_STACK_DEFINE()定义的
//参数分别是:线程实体,堆栈空间,堆栈大小,线程执行域(自定义k_thread_entry_t类型线程函数名)
//按顺序三个传入线程执行域的参数,优先级,线程选项,调度延迟时间(K_NO_WAIT,调度不延迟)
__syscall k_tid_t k_thread_create(struct k_thread *new_thread,//线程结构体,未初始化
								  k_thread_stack_t *stack,//堆栈空间
								  size_t stack_size,//堆栈大小
								  k_thread_entry_t entry,//线程体
								  void *p1, void *p2, void *p3,//线程体所用到的三个参数
								  int prio, uint32_t options, k_timeout_t delay);

//将线程的特权永久地下调到用户模式
//这允许管理线程作为用户线程被重用
//此函数不返回,但控制将转移到提供的入口点,就像这是一个新的用户线程
//具体实现确保堆栈缓冲区的内容被擦除,任何线程本地存储将被恢复到原始状态
//保留内存域成员、资源池分配、内核对象权限、优先级和线程选项
//这个函数的一个常见用途是,一旦所有的supervisor mode-only任务完成后,将主线程作为用户线程重新使用
//参数分别是:线程执行域(自定义k_thread_entry_t类型线程函数名),按顺序三个传入线程执行域的参数
extern FUNC_NORETURN void k_thread_user_mode_enter(k_thread_entry_t entry,
												   void *p1, void *p2, void *p3);

//授予一个线程对一组内核对象的访问权
//这是一个方便的函数,对于提供的线程,授予对其余参数的访问权,这些参数必须是指向内核对象的指针
//线程对象必须初始化(即运行),NULL不应该作为参数传递
//参数分别是:授予对象访问权限的线程,内核对象指针列表
#define k_thread_access_grant(thread, ...) \
	FOR_EACH_FIXED_ARG(k_object_access_grant, (;), thread, __VA_ARGS__)

//为线程分配一个资源内存池
//默认情况下,线程没有分配资源池,除非它们的父线程有资源池,在这种情况下它是继承的
//多个线程可以被分配到同一个内存池
//改变一个线程的资源池不会从之前的资源池迁移分配
//参数分别是:目标线程为资源请求分配内存池,用于资源的堆对象,或NULL(如果线程不再有内存池)
static inline void k_thread_heap_assign(struct k_thread *thread, struct k_heap *heap)
{
	thread->resource_pool = heap;
}

//获取指定线程的堆栈使用信息,用户线程需要对目标线程对象有权限
//某些硬件可能会阻止对当前使用的堆栈缓冲区的检查,如果这个API从管理模式调用
//在当前运行的线程上,在一个平台上选择@option{CONFIG_NO_UNUSED_STACK_INSPECTION},将产生一个错误
//参数分别是:目标线程,输出参数(用目标线程未使用的堆栈空间填充,以字节为单位)
//错误返回:
//-EBADF错误线程对象(仅限用户模式)
//-EPERM线程对象没有权限(仅在用户模式下)
//-ENOTSUP被硬件策略禁止
//-EINVAL线程未初始化或退出(仅用户模式)
//-EFAULT unused_ptr错误的内存地址(仅在用户模式下)
#if defined(CONFIG_INIT_STACKS) && defined(CONFIG_THREAD_STACK_INFO)
__syscall int k_thread_stack_space_get(const struct k_thread *thread, size_t *unused_ptr);
#endif

//指定系统堆作为线程的资源池
//类似于z_thread_resource_pool_assign(),但是线程将使用内核堆绘制内存
//请谨慎使用,因为恶意线程可能对内核堆执行DoS攻击
//参数分别是:为资源请求分配系统堆的目标线程
#if (CONFIG_HEAP_MEM_POOL_SIZE > 0)
void k_thread_system_pool_assign(struct k_thread *thread);
#endif

//休眠直到线程退出
//调用者将被置为睡眠状态,直到目标线程退出
//要么因为被中止,自我退出,要么发生致命错误,如果线程不运行,该API立即返回
//这个API只能从isr调用K_NO_WAIT超时
//参数分别是:等待退出的线程,超时等待线程退出的上限时间
//错误返回:
//-EBUSY返回没有等待
//-EAGAIN等待时间超时
//-EDEADLK目标线程在调用者上加入,或者目标线程是调用者
__syscall int k_thread_join(struct k_thread *thread, k_timeout_t timeout);

//使当前线程处于休眠状态
//这个例程将当前线程置于睡眠状态,持续时间为timeout,指定为k_timeout_t对象
//如果@a timeout设置为K_FOREVER,则线程被挂起
//参数分别是:timeout期望的睡眠时间
//如果请求的时间已经过去,或者线程被k_wakeup调用唤醒,则为0
__syscall int32_t k_sleep(k_timeout_t timeout);

//使当前线程处于休眠状态
//这个例程将当前线程置于睡眠状态,持续时间为ms
//参数分别是:休眠毫秒数
//如果请求的时间已经过去,或者线程被k_wakeup调用唤醒,则为0
static inline int32_t k_msleep(int32_t ms)
{
	return k_sleep(Z_TIMEOUT_MS(ms));
}

//使当前线程以微秒的分辨率进入睡眠状态
//如果没有内核调优,这个函数不可能按预期工作
//特别是,因为睡眠持续时间的下界是滴答的持续时间
//所以必须调整@option{CONFIG_SYS_CLOCK_TICKS_PER_SEC}以实现所需的分辨率
//在尝试使用k_usleep()之前,必须理解这样做的含义,谨慎使用
//参数分别是:睡眠的微秒数
//如果请求的时间已经过去,或者线程被k_wakeup调用唤醒,则为0
__syscall int32_t k_usleep(int32_t us);

//导致当前线程繁忙等待
//这个例程导致当前线程执行usec_to_wait微秒的“do nothing”循环
//用于毫秒分辨率的延迟的时钟可能是倾斜的,相对于用于系统超时的时钟,如k_sleep()
//例如,k_busy_wait(1000)可能比k_sleep(K_MSEC(1))所花的时间稍长或稍短,其偏移量取决于时钟公差
//参数分别是:忙等待的微秒数 
__syscall void k_busy_wait(uint32_t usec_to_wait);

//返回当前线程
//这个例程导致当前线程让与具有相同或更高优先级的另一个线程执行,如果没有其他相同或更高优先级的就绪线程,例程将立即返回
__syscall void k_yield(void);


//唤醒一个正在睡觉的线程
//这个程序会提前唤醒thread
//如果线程当前没有睡眠,那么这个例程没有效果
//参数分别是:要唤醒的线程ID
__syscall void k_wakeup(k_tid_t thread);

//获取当前线程的线程ID
//返回当前线程的ID
__syscall k_tid_t k_current_get(void);

//终止一个线程,这个例程永久停止thread线程的执行
//线程会从它所在的所有内核队列(即就绪队列、超时队列或内核对象等待队列)中移除
//但是,线程当前可能拥有的任何内核资源(例如互斥体或内存块)都不会被释放
//这个例程的调用者负责确保执行所有必要的清理
//参数分别是:要中止的线程ID
__syscall void k_thread_abort(k_tid_t thread);

//启动一个非活动线程
//如果一个线程创建的延迟参数为K_FOREVER,它将不会被添加到调度队列中,直到这个函数被调用
//参数分别是:thread启动线程
__syscall void k_thread_start(k_tid_t thread);


extern k_ticks_t z_timeout_expires(const struct _timeout *timeout);
extern k_ticks_t z_timeout_remaining(const struct _timeout *timeout);
#ifdef CONFIG_SYS_CLOCK_EXISTS
//获得线程唤醒的时间,以系统计时为单位
//这个例程在一个等待线程下一次执行时计算系统正常运行时间,以系统节拍为单位
//如果线程没有等待,则返回当前系统时间
__syscall k_ticks_t k_thread_timeout_expires_ticks(struct k_thread *t);
static inline k_ticks_t z_impl_k_thread_timeout_expires_ticks(struct k_thread *t)
{
	return z_timeout_expires(&t->base.timeout);
}

//获取线程唤醒前的剩余时间,以系统计时为单位
//这个例程计算在等待的线程下一次执行之前剩余的时间,以系统节拍为单位
//如果线程没有等待,则返回0
__syscall k_ticks_t k_thread_timeout_remaining_ticks(struct k_thread *t);
static inline k_ticks_t z_impl_k_thread_timeout_remaining_ticks(struct k_thread *t)
{
	return z_timeout_remaining(&t->base.timeout);
}
#endif

//已超时,不再在_timeout_q上
#define _EXPIRED (-2)

struct _static_thread_data {//内核所用线程管理
	struct k_thread *init_thread;//线程实例
	k_thread_stack_t *init_stack;//堆栈
	unsigned int init_stack_size;//堆栈大小
	k_thread_entry_t init_entry;//线程执行域(用户线程函数名)
	void *init_p1;//传入执行域的参数1
	void *init_p2;//传入执行域的参数2
	void *init_p3;//传入执行域的参数3
	int init_prio;//优先级
	uint32_t init_options;//线程选项
	int32_t init_delay;//调度延迟
	void (*init_abort)(void);//中止调用(deinit,uninit)
	const char *init_name;//线程名
};

//静态初始化,仅声明时可以使用
#define Z_THREAD_INITIALIZER(thread, stack, stack_size,\
							 entry, p1, p2, p3,\
							 prio, options, delay, abort, tname)\
	{                                         \
	.init_thread = (thread),				  \
	.init_stack = (stack),					  \
	.init_stack_size = (stack_size),          \
	.init_entry = (k_thread_entry_t)entry,    \
	.init_p1 = (void *)p1,                    \
	.init_p2 = (void *)p2,                    \
	.init_p3 = (void *)p3,                    \
	.init_prio = (prio),                      \
	.init_options = (options),                \
	.init_delay = (delay),                    \
	.init_abort = (abort),                    \
	.init_name = STRINGIFY(tname),            \
	}


//静态定义和初始化一个线程,线程可以被安排为立即执行或延迟启动
//线程选项是特定于体系结构的,可以包括K_ESSENTIAL, K_FP_REGS和K_SSE_REGS
//可以使用“|”(逻辑OR操作符)分隔多个选项
//线程的ID可以通过name访问
//据观察,x86编译器默认将这些_static_thread_data结构对齐到32字节的边界
//因此浪费了空间,要解决这个问题,强制4字节对齐
//参数定义参见k_thread_create
#define K_THREAD_DEFINE(name, stack_size,                                   \
						entry, p1, p2, p3,                                  \
						prio, options, delay)                               \
	K_THREAD_STACK_DEFINE(_k_thread_stack_##name, stack_size);	            \
	struct k_thread _k_thread_obj_##name;				                    \
	Z_STRUCT_SECTION_ITERABLE(_static_thread_data, _k_thread_data_##name) = \
		Z_THREAD_INITIALIZER(&_k_thread_obj_##name,		                    \
			_k_thread_stack_##name, stack_size,                             \
			entry, p1, p2, p3, prio, options, delay, NULL, name);           \
	const k_tid_t name = (k_tid_t)&_k_thread_obj_##name

//获得thread线程的优先级 
__syscall int k_thread_priority_get(k_tid_t thread);

//设置thread线程为prio优先级
//如果调用者对自己进行操作,它会将自己的优先级降低到系统中其他线程的优先级以下
//并且调用者是可抢占的,最高优先级的线程将被调度进来
//改变当前涉及互斥优先级继承的线程的优先级可能会导致未定义的行为
__syscall void k_thread_priority_set(k_tid_t thread, int prio);

//设置调度程序的截止时间
//设置截止时间为当前时间的时间差,与k_cycle_get_32()使用的单位相同
//在选择具有相同静态优先级的线程时,调度程序(当启用了deadline调度时)将选择下一个到期的线程
//具有不同优先级的线程将根据它们的静态优先级进行调度
//截止日期在内部使用32位无符号整数存储
//调度队列中的“第一个”截止日期到“最后一个”截止日期之间的周期数必须小于2^31(即一个有符号的非负数)
//如果不遵守此规则,可能会导致调度的线程以不正确的截止日期顺序运行
//调度程序不保证线程将在该期限内调度
//也不需要额外的元数据(例如,“runtime”和“period”参数在Linux sched_setattr())
//允许内核验证调度的可实现性,这些特性可以在这个调用之上实现,它只是优先级选择逻辑的输入
//你应该在你的项目配置中启用@option{CONFIG_SCHED_DEADLINE}
//参数分别是:设置截止日期的线程,一个时间增量(以周期为单位)
#ifdef CONFIG_SCHED_DEADLINE
__syscall void k_thread_deadline_set(k_tid_t thread, int deadline);
#endif

//你应该在你的项目配置中启用@option{CONFIG_SCHED_DEADLINE}
//(?不应该是@option{CONFIG_SCHED_CPU_MASK})
#ifdef CONFIG_SCHED_CPU_MASK
//设置所有CPU启用掩码为零
//返回后,线程将不再在任何cpu上调度,线程当前不能运行
int k_thread_cpu_mask_clear(k_tid_t thread);

//设置所有CPU启用掩码为1
//返回后,线程将被调度在任何CPU上,线程当前不能运行
int k_thread_cpu_mask_enable_all(k_tid_t thread);

//使线程在指定的CPU上运行
//线程当前不能运行
int k_thread_cpu_mask_enable(k_tid_t thread, int cpu);

//防止线程在指定的CPU上运行
//线程当前不能运行
int k_thread_cpu_mask_disable(k_tid_t thread, int cpu);
#endif

//暂停线程
//这个例程防止内核调度程序将thread作为当前线程
//线程上的所有其他内部操作仍然被执行
//例如,它所等待的内核对象仍然被传递给它
//请注意,任何现有的超时(例如k_sleep(),或k_sem_take()的超时参数等)都将被取消
//在恢复时,线程将立即开始运行,并从阻塞调用返回
//如果线程已经挂起,则该例程没有效果
__syscall void k_thread_suspend(k_tid_t thread);

//恢复挂起的线程
//这个例程允许内核调度程序将thread作为当前线程,当它是下一个符合该角色的线程时
//如果线程当前没有挂起,则该例程没有效果
__syscall void k_thread_resume(k_tid_t thread);

//设置时间分段周期和范围,指定调度程序如何对可抢占线程执行时间切片
//开启时间切片功能,slice必须是非零值
//调度程序确保在其他优先级线程有机会执行之前,没有线程的运行时间超过指定的时间限制
//任何优先级高于prio的线程都可以被豁免,可以任意执行,而不会因为时间片而被抢占
//时间切片只限制一个线程可以持续执行的最大时间
//一旦调度程序选择一个线程执行,在调度优先级更高或相同的线程之前,没有保证线程执行的最小时间
//当前线程是该优先级中唯一有资格执行的线程时,这个例程没有效果
//线程在片周期到期后立即重新调度
//要禁用timeslicing,请将slice和prio设置为零
extern void k_sched_time_slice_set(int32_t slice, int prio);

//判断代码是否在中断级别运行,isr可以调用
//这个例程允许调用者自定义它的动作,取决于它是一个线程还是一个ISR
//如果被线程调用则返回false,如果ISR调用返回true
extern bool k_is_in_isr(void);

//判断代码是否在抢占线程中运行,isr可以调用
//这个例程允许调用者自定义它的动作,取决于它是否可以被另一个线程抢占
//如果满足以下所有条件,例程返回一个“true”值:
//-代码运行在一个线程,而不是在ISR
//-线程的优先级在可抢占范围内
//-线程没有锁定调度程序
//如果由ISR或合作线程调用返回零值,如果被抢占线程调用则返回非零值 
__syscall int k_is_preempt_thread(void);

//测试启动是否在主任务之前阶段,isr可以调用
//这个例程允许调用者自定义它的动作,这取决于它是否在内核完全激活之前被调用
//如果在内核初始化之前调用,返回true
//如果在内核初始化期间/之后被调用,返回false
static inline bool k_is_pre_kernel(void)
{
	extern bool z_sys_post_kernel;

	return !z_sys_post_kernel;
}

//锁定调度程序
//这个例程通过指示调度程序将当前线程视为合作线程来防止当前线程被其他线程抢占
//如果线程随后执行一个使其未就绪的操作,它将以正常方式被上下文切换
//当线程再次成为当前线程时,它的非抢占状态将被保持
//这个例程可以递归调用
//k_sched_lock()和k_sched_unlock()通常应该在正在执行的操作可以被isr安全中断时使用
//但是,如果涉及的处理量非常小,则可以通过使用irq_lock()和irq_unlock()获得更好的性能
extern void k_sched_lock(void);

//解锁调度程序
//此例程反转之前调用k_sched_lock()的效果
//在线程变为可抢占之前,每次调用k_sched_lock()时,线程必须调用这个例程一次
extern void k_sched_unlock(void);

//设置当前线程的自定义数据
//这个例程将当前线程的自定义数据设置为value
//内核本身不使用自定义数据,线程可以自由使用,它可以用作构建线程本地存储的框架
__syscall void k_thread_custom_data_set(void *value);

//获取当前线程的自定义数据
//这个例程返回当前线程的自定义数据
__syscall void *k_thread_custom_data_get(void);

//设置当前线程的名称
//设置当@option{CONFIG_THREAD_MONITOR}启用跟踪和调试时使用的线程的名称
//参数分别是:thread_id设置线程名称或者NULL设置当前线程,value名称字符串
//错误返回:
//-EFAULT内存访问错误提供的字符串
//-ENOSYS线程名配置选项未启用
//-EINVAL线程名太长
__syscall int k_thread_name_set(k_tid_t thread_id, const char *value);

//获取线程名,获取线程的名称
const char *k_thread_name_get(k_tid_t thread_id);

//将线程名复制到提供的缓冲区中
//参数分别是:thread_id线程获取名称信息,buf目标缓冲区,size目标缓冲区大小
//错误返回:
//-ENOSPC目标缓冲区太小
//-EFAULT内存访问错误
//-ENOSYS线程名称特性未启用
__syscall int k_thread_name_copy(k_tid_t thread_id, char *buf, size_t size);

//获取线程状态字符串
const char *k_thread_state_str(k_tid_t thread_id);

//生成空超时延迟
//如果请求的操作不能立即执行,这个宏会产生一个超时延迟,指示内核API不要等待
#define K_NO_WAIT Z_TIMEOUT_NO_WAIT

//从纳秒产生超时延迟
//这个宏产生一个超时延迟,它指示内核API等待到t纳秒来执行请求的操作
//请注意,计时器精度仅限于滴答率,而不是请求的值
#define K_NSEC(t)     Z_TIMEOUT_NS(t)

//以微秒为单位产生超时延迟
//这个宏产生一个超时延迟,指示内核API等待到t微秒来执行请求的操作
//请注意,计时器精度仅限于滴答率,而不是请求的值
#define K_USEC(t)     Z_TIMEOUT_US(t)

//从循环中产生超时延迟
//这个宏产生一个超时延迟,指示内核API等待t周期来执行请求的操作
#define K_CYC(t)     Z_TIMEOUT_CYC(t)

//系统计时产生超时延迟
//这个宏产生一个超时延迟,它指示内核API等待t ticks来执行请求的操作
#define K_TICKS(t)     Z_TIMEOUT_TICKS(t)

//以毫秒为单位产生超时延迟
//这个宏产生一个超时延迟,它指示内核API等待到ms毫秒来执行请求的操作
#define K_MSEC(ms)     Z_TIMEOUT_MS(ms)

//以秒为单位产生超时延迟
//这个宏产生一个超时延迟,它指示内核API等待s秒来执行请求的操作
#define K_SECONDS(s)   K_MSEC((s) * MSEC_PER_SEC)

//以分钟为单位产生超时延迟
//这个宏产生一个超时延迟,指示内核API等待m分钟来执行请求的操作
#define K_MINUTES(m)   K_SECONDS((m) * 60)

//以小时为单位产生超时延迟
//这个宏产生一个超时延迟,指示内核API等待h时来执行请求的操作
#define K_HOURS(h)     K_MINUTES((h) * 60)

//产生无限的超时延迟
//这个宏产生一个超时延迟,指示内核API等待必要的时间来执行请求的操作
#define K_FOREVER Z_FOREVER

#ifdef CONFIG_TIMEOUT_64BIT

//从系统计时生成一个绝对/正常运行时间超时值
//此宏生成一个超时延迟,表示在系统计时中指定的绝对正常运行时间值过期
//即系统正常运行时间到达指定的时间点后,该超时时间将立即过期
#define K_TIMEOUT_ABS_TICKS(t) \
	Z_TIMEOUT_TICKS(Z_TICK_ABS((k_ticks_t)MAX(t, 0)))

//以毫秒为单位生成绝对/正常运行时间超时值
//此宏生成一个超时延迟,表示在指定的绝对正常运行时间值时过期,以毫秒为单位
//即系统正常运行时间到达指定的时间点后,该超时时间将立即过期
#define K_TIMEOUT_ABS_MS(t) K_TIMEOUT_ABS_TICKS(k_ms_to_ticks_ceil64(t))

//以微秒为单位生成绝对/正常运行时间超时值
//此宏生成一个超时延迟,表示在指定的绝对正常运行时间值(以微秒为单位)时过期
//即在系统正常运行时间到达指定时间后立即超时
//注意,计时器精度受系统滴答率的限制,而不是请求的超时值
#define K_TIMEOUT_ABS_US(t) K_TIMEOUT_ABS_TICKS(k_us_to_ticks_ceil64(t))

//从纳秒生成一个绝对/正常运行时间超时值
//此宏生成一个超时延迟,表示在指定的绝对正常运行时间值(以纳秒为单位)时过期
//即在系统正常运行时间到达指定时间后立即超时
//注意,计时器精度受系统滴答率的限制,而不是请求的超时值
#define K_TIMEOUT_ABS_NS(t) K_TIMEOUT_ABS_TICKS(k_ns_to_ticks_ceil64(t))

//从系统周期中生成绝对/正常运行时间超时值
//此宏生成一个超时延迟,表示在指定的绝对正常运行时间值过期,以周期为单位
//即在系统正常运行时间到达指定时间后立即超时
//注意,计时器精度受系统滴答率的限制,而不是请求的超时值
#define K_TIMEOUT_ABS_CYC(t) K_TIMEOUT_ABS_TICKS(k_cyc_to_ticks_ceil64(t))

#endif

struct k_timer {//定时器
	//如果我们想使用动态计时器分配,_timeout结构必须在这里 
	//timeout.node用于空闲计时器的双链接列表中
	struct _timeout timeout;
	_wait_q_t wait_q;//等待这个计时器的(单)线程的等待队列
	void (*expiry_fn)(struct k_timer *timer);//定时器过期回调
	void (*stop_fn)(struct k_timer *timer);//k_timer_stop()后的回调
	k_timeout_t period;//周期
	uint32_t status;//状态
	void *user_data;//用户特定的数据,也用于支持遗留特性
	_OBJECT_TRACING_NEXT_PTR(k_timer)//track所用的宏配置
	_OBJECT_TRACING_LINKED_FLAG
};

#define Z_TIMER_INITIALIZER(obj, expiry, stop)\
	{                                         \
	.timeout = {                              \
	.node = {},                               \
	.fn = z_timer_expiration_handler,         \
	.dticks = 0,                              \
	},                                        \
	.wait_q = Z_WAIT_Q_INIT(&obj.wait_q),     \
	.expiry_fn = expiry,                      \
	.stop_fn = stop,                          \
	.status = 0,                              \
	.user_data = 0,                           \
	_OBJECT_TRACING_INIT                      \
	}

//动态定时器过期回调
//如果使用软件定时器时,在一个周期结束后响应,则需要实现它
typedef void (*k_timer_expiry_t)(struct k_timer *timer);

//如果计时器过早停止,则执行计时器的停止函数
//函数在停止计时器的调用上下文中运行
//由于k_timer_stop()可以从ISR调用,停止函数必须从中断上下文(ISR -ok)调用
//stop函数是可选的,只有当计时器被初始化时才会调用
typedef void (*k_timer_stop_t)(struct k_timer *timer);

//静态定义并初始化一个计时器
//参数分别是:name定时器变量的名称
//expiry_fn每次计时器过期时调用的函数,stop_fn在计时器运行时停止时调用的函数
#define K_TIMER_DEFINE(name, expiry_fn, stop_fn)    \
	Z_STRUCT_SECTION_ITERABLE(k_timer, name) =      \
		Z_TIMER_INITIALIZER(name, expiry_fn, stop_fn)

//初始化一个定时器
extern void k_timer_init(struct k_timer *timer,
						 k_timer_expiry_t expiry_fn,
						 k_timer_stop_t stop_fn);

//启动一个计时器,并将其状态重置为零
//计时器开始使用指定的持续时间和周期值进行倒数
//允许启动一个已经在运行的计时器,计时器的状态重置为零,计时器开始使用新的持续时间和周期值倒数
__syscall void k_timer_start(struct k_timer *timer,
							 k_timeout_t duration, k_timeout_t period);

//过早地停止一个正在运行的计时器,计时器的停止函数(如果存在的话)由调用者调用
//尝试停止一个未运行的计时器是允许的,但对计时器没有影响,isr可以调用
//如果要从isr调用@a k_timer_stop,则必须从isr调用停止处理程序
__syscall void k_timer_stop(struct k_timer *timer);

//读取定时器状态
//这个例程读取定时器的状态,该状态表明自从上次读取它的状态以来它已经过期的次数
//调用这个例程将定时器的状态重置为0
__syscall uint32_t k_timer_status_get(struct k_timer *timer);

//同步线程到计时器到期
//阻塞调用线程,直到计时器的状态不为零(表示它从上次检查以来至少过期了一次)或者计时器停止
//如果计时器状态已经非零,或者计时器已经停止,则调用者继续而不等待
//调用这个例程将定时器的状态重置为0
//这个例程不能被中断处理程序使用,因为它们不允许阻塞
__syscall uint32_t k_timer_status_sync(struct k_timer *timer);

#ifdef CONFIG_SYS_CLOCK_EXISTS

//获取计时器的下一次过期时间,以系统计时为单位
//这个例程返回计时器下次到期时达到的未来系统正常运行时间,以系统节拍为单位
//如果计时器未运行,则返回当前系统时间
__syscall k_ticks_t k_timer_expires_ticks(struct k_timer *timer);
static inline k_ticks_t z_impl_k_timer_expires_ticks(struct k_timer *timer)
{
	return z_timeout_expires(&timer->timeout);
}

//获得计时器下次到期前剩余的时间,以系统计时为单位
//此例程计算运行计时器下次到期前剩余的时间,以系统计时为单位,如果计时器未运行,则返回0
__syscall k_ticks_t k_timer_remaining_ticks(struct k_timer *timer);
static inline k_ticks_t z_impl_k_timer_remaining_ticks(struct k_timer *timer)
{
	return z_timeout_remaining(&timer->timeout);
}

//获取计时器下次到期前剩余的时间
//此例程计算运行计时器下次到期前剩余的(大约)时间,如果计时器未运行,则返回0
static inline uint32_t k_timer_remaining_get(struct k_timer *timer)
{
	return k_ticks_to_ms_floor32(k_timer_remaining_ticks(timer));
}

#endif

//将特定于用户的数据与计时器关联
//这个例程用定时器记录user_data,稍后检索
//它可以被使用,例如在一个跨多个子系统共享的定时器处理程序中检索特定于这个定时器关联的子系统的数据
__syscall void k_timer_user_data_set(struct k_timer *timer, void *user_data);
static inline void z_impl_k_timer_user_data_set(struct k_timer *timer, void *user_data)
{
	timer->user_data = user_data;
}

//从计时器中检索特定于用户的数据
__syscall void *k_timer_user_data_get(const struct k_timer *timer);
static inline void *z_impl_k_timer_user_data_get(const struct k_timer *timer)
{
	return timer->user_data;
}

//获取系统正常运行时间,以系统计时为单位
//这个例程返回自系统启动以来经过的时间
//以滴答(c.f. @option{CONFIG_SYS_CLOCK_TICKS_PER_SEC})为单位,这是解析内核时间的基本单位
__syscall int64_t k_uptime_ticks(void);

//让系统正常运行时间
//这个例程返回系统启动后经过的时间,以毫秒为单位
//虽然这个函数以毫秒为单位返回时间,但并不意味着它具有毫秒分辨率
//实际的分辨率取决于@option{CONFIG_SYS_CLOCK_TICKS_PER_SEC}配置选项
static inline int64_t k_uptime_get(void)
{
	return k_ticks_to_ms_floor64(k_uptime_ticks());
}

//获取系统运行时间(32位版本)
//这个例程以毫秒为单位返回系统正常运行时间的较低32位
//因为正确的转换需要系统时钟的完全精度,所以在k_uptime_get()上使用它没有任何好处
//除非您知道应用程序永远不会运行足够长的时间使系统时钟接近2^32滴答
//对这个函数的调用可能涉及中断阻塞和64位数学运算
//虽然这个函数以毫秒为单位返回时间,但并不意味着它具有毫秒分辨率
//实际的分辨率取决于@option{CONFIG_SYS_CLOCK_TICKS_PER_SEC}配置选项
static inline uint32_t k_uptime_get_32(void)
{
	return (uint32_t)k_uptime_get();
}

//获取运行时间
//这个例程计算当前系统正常运行时间和之前的参考时间之间经过的时间,以毫秒为单位
//参数分别是:reftime指向引用时间的指针,返回时更新为当前正常运行时间
static inline int64_t k_uptime_delta(int64_t *reftime)
{
	int64_t uptime, delta;

	uptime = k_uptime_get();
	delta = uptime - *reftime;
	*reftime = uptime;

	return delta;
}

//读取硬件时钟
//这个程序返回当前的时间,由系统的硬件时钟测量
//返回当前硬件时钟上行计数器(以周期计)
static inline uint32_t k_cycle_get_32(void)
{
	return arch_k_cycle_get_32();
}

struct k_queue {
	sys_sflist_t data_q;//带头尾节点的单向链表
	struct k_spinlock lock;//自旋锁
	_wait_q_t wait_q;//等待队列

	_POLL_EVENT;//拉取事件
	_OBJECT_TRACING_NEXT_PTR(k_queue)//trace所用
	_OBJECT_TRACING_LINKED_FLAG
};

#define Z_QUEUE_INITIALIZER(obj)                   \
	{                                              \
	.data_q = SYS_SFLIST_STATIC_INIT(&obj.data_q), \
	.lock = {},                                    \
	.wait_q = Z_WAIT_Q_INIT(&obj.wait_q),          \
	_POLL_EVENT_OBJ_INIT(obj)                      \
	_OBJECT_TRACING_INIT                           \
	}

extern void *z_queue_node_peek(sys_sfnode_t *node, bool needs_free);


//初始化一个队列
__syscall void k_queue_init(struct k_queue *queue);

//取消对队列的等待,isr可以调用
//这个例程导致queue上的第一个线程挂起
//如果有的话,从k_queue_get()调用返回NULL值(就像超时超时一样),如果k_poll()正在等待队列
//它将返回-EINTR和K_POLL_STATE_CANCELLED状态(在上述情况下,后续的k_queue_get()将返回NULL)
__syscall void k_queue_cancel_wait(struct k_queue *queue);

//添加一个元素到队列的末尾,isr可以调用
//这个例程将一个数据项data附加到queue队列末尾
//队列数据项必须在字边界上对齐,并且该项的第一个字保留给内核使用
//参数分别是:队列,数据项
extern void k_queue_append(struct k_queue *queue, void *data);

//添加一个元素到队列,isr可以调用
//这个例程将一个数据项data附加到queue队列
//有一个隐式内存分配用于从调用线程的资源池中创建额外的临时簿记数据结构
//该结构在删除项时自动释放,数据本身不会被复制
//参数分别是:队列,数据项
//错误返回:
//-ENOMEM如果调用者的资源池中没有足够的RAM
__syscall int32_t k_queue_alloc_append(struct k_queue *queue, void *data);

//在队列中添加一个元素,isr可以调用
//这个例程在queue队列前添加一个数据项
//队列数据项必须在字边界上对齐,并且该项的第一个字保留给内核使用
//参数分别是:队列,数据项
extern void k_queue_prepend(struct k_queue *queue, void *data);

//在队列中添加一个元素,isr可以调用
//这个例程在queue队列前添加一个数据项
//有一个隐式内存分配用于从调用线程的资源池中创建额外的临时簿记数据结构
//该结构在删除项时自动释放,数据本身不会被复制
//参数分别是:队列,数据项
//错误返回:
//-ENOMEM如果调用者的资源池中没有足够的RAM
__syscall int32_t k_queue_alloc_prepend(struct k_queue *queue, void *data);

//向队列中插入一个元素,isr可以调用
//这个例程将一个数据项插入到queue队列的前一个项之后
//队列数据项必须在字边界上对齐,并且该项的第一个字保留给内核使用
//参数分别是:队列,前一个数据项,数据项
extern void k_queue_insert(struct k_queue *queue, void *prev, void *data);

//原子地将一个元素列表附加到队列中,isr可以调用
//这个例程在一个操作中将一个数据项列表添加到queue队列
//数据项必须在一个单链表中,每个数据项中的第一个字指向下一个数据项,列表必须以null结束
//参数分别是:队列地址,单链表中第一个节点,单链表最后一个节点
//错误返回:
// -EINVAL对无效提供的数据
extern int k_queue_append_list(struct k_queue *queue, void *head, void *tail);

//原子式地将元素列表添加到队列中,isr可以调用
//这个例程在一个操作中将一个数据项列表添加到queue队列
//数据项必须位于使用sys_slist_t对象实现的单链接列表中,完成后,原始列表为空
//参数分别是:队列地址,对象的指针
//错误返回:
//-EINVAL对无效数据
extern int k_queue_merge_slist(struct k_queue *queue, sys_slist_t *list);

//从队列中获取一个元素,isr可以调用(timeout必须设置为K_NO_WAIT)
//这个例程从queue队列中删除第一个数据项,数据项的第一个字保留给内核使用
//参数分别是:队列地址,获取一个数据项或特殊值K_NO_WAIT和K_FOREVER中的一个的非负等待时间
//错误返回:
//如果返回时没有等待,或者等待时间超时,则为NULL
__syscall void *k_queue_get(struct k_queue *queue, k_timeout_t timeout);

//从队列中删除一个元素,isr可以调用
//这个例程从queue队列中删除数据项
//数据项的第一个字保留给内核使用
//从k_queue中删除元素依赖于sys_slist_find_and_remove,这不是一个常量时间操作
//参数分别是:队列,数据项
static inline bool k_queue_remove(struct k_queue *queue, void *data)
{
	return sys_sflist_find_and_remove(&queue->data_q, (sys_sfnode_t *)data);
}

//只有当一个元素不存在的时候才添加到队列中,isr可以调用
//这个例程将数据项附加到queue队列
//数据项的第一个字保留给内核使用
//将元素追加到k_queue依赖于sys_slist_is_node_in_list,这不是一个常量时间操作
//参数分别是:队列,数据项
static inline bool k_queue_unique_append(struct k_queue *queue, void *data)
{
	sys_sfnode_t *test;

	SYS_SFLIST_FOR_EACH_NODE(&queue->data_q, test) {
		if (test == (sys_sfnode_t *) data) {
			return false;
		}
	}

	k_queue_append(queue, data);
	return true;
}

//查询一个队列,看它是否有可用的数据,isr可以调用
//如果其他线程也试图从队列中读取数据,那么当这个函数返回时,数据可能已经消失了
//错误返回:
//如果队列为空,则返回非零
__syscall int k_queue_is_empty(struct k_queue *queue);
static inline int z_impl_k_queue_is_empty(struct k_queue *queue)
{
	return (int)sys_sflist_is_empty(&queue->data_q);
}

//返回队列头部的元素,不移除它
__syscall void *k_queue_peek_head(struct k_queue *queue);
static inline void *z_impl_k_queue_peek_head(struct k_queue *queue)
{
	return z_queue_node_peek(sys_sflist_peek_head(&queue->data_q), false);
}

//返回队列尾部的元素,不移除它
__syscall void *k_queue_peek_tail(struct k_queue *queue);

static inline void *z_impl_k_queue_peek_tail(struct k_queue *queue)
{
	return z_queue_node_peek(sys_sflist_peek_tail(&queue->data_q), false);
}

//静态定义和初始化一个队列
#define K_QUEUE_DEFINE(name)                   \
	Z_STRUCT_SECTION_ITERABLE(k_queue, name) = \
		Z_QUEUE_INITIALIZER(name)

//如果定义用户空间
//也即内核空间与用户空间隔离
#ifdef CONFIG_USERSPACE

struct k_futex {
//k_futex是一种轻量级互斥原语,设计目的是尽量减少对内核的影响
//无竞争操作仅依赖于对共享内存的原子访问,k_futex作为内核对象被跟踪
//并且可以驻留在用户内存中,因此任何访问都可以绕过内核对象权限管理机制	
	atomic_t val;
};

//z_futex_data是k_futex在内核端完成futex争用操作的辅助数据结构
//每个futex对象的结构z_futex_data在用户模式下是不可见的
struct z_futex_data {
	_wait_q_t wait_q;
	struct k_spinlock lock;
};

#define Z_FUTEX_DATA_INITIALIZER(obj)    \
	{                                    \
	.wait_q = Z_WAIT_Q_INIT(&obj.wait_q) \
	}

//在futex上挂起当前线程
//测试所提供的futex是否包含预期值,如果是则休眠
//直到其他线程对其调用k_futex_wake()
//参数分别是:实例,期望值(如果不同调用者不会等待它)
//非负等待时间(或者特殊值K_NO_WAIT或K_FOREVER中的一个)
//错误返回:
//-EACCES调用者没有读访问futex地址
//-EAGAIN futex值与期望的参数不匹配
//-EINVAL内核不能识别的Futex参数地址
//-ETIMEDOUT线程超时唤醒,而不是futex唤醒
__syscall int k_futex_wait(struct k_futex *futex, int expected,
						   k_timeout_t timeout);

//唤醒一个/所有线程挂起futex
//唤醒最高优先级的线程挂起在提供的futex上
//或唤醒所有挂起在提供的futex上的线程,其行为取决于wake_all
//结束后返回被唤醒的之前等待该futex的线程数
//参数分别是:唤醒挂起的线程,是否全部唤醒(如果为true,唤醒所有挂起的线程;
//如果为false,则唤醒优先级最高的线程)
//错误返回:
//-EACCES调用者没有访问futex地址
//-EINVAL内核不能识别的Futex参数地址
__syscall int k_futex_wake(struct k_futex *futex, bool wake_all);

#endif

struct k_fifo {//先进先出的思想与队列一致
	struct k_queue _queue;//实现是直接使用队列
};

#define Z_FIFO_INITIALIZER(obj)               \
	{                                         \
	._queue = Z_QUEUE_INITIALIZER(obj._queue) \
	}



//初始化一个FIFO队列,在它第一次使用之前
#define k_fifo_init(fifo) \
	k_queue_init(&(fifo)->_queue)

//取消对FIFO队列的等待,isr可以调用
//导致第一个线程挂起fifo(如果有的话)
//返回k_fifo_get()调用的NULL值(就像超时过期一样)
#define k_fifo_cancel_wait(fifo) \
	k_queue_cancel_wait(&(fifo)->_queue)

//添加一个元素到FIFO队列,isr可以调用
//将一个数据项添加到fifo
//FIFO数据项必须按字边界对齐,该项的第一个字保留给内核使用
//参数分别是:实例,数据项
#define k_fifo_put(fifo, data) \
	k_queue_append(&(fifo)->_queue, data)

//添加一个元素到FIFO队列,isr可以调用
//将一个数据项添加到fifo
//有一个隐式内存分配用于从调用线程的资源池中创建额外的临时簿记数据结构
//该结构在删除项时自动释放,数据本身不会被复制
//参数分别是:实例,数据项
//错误返回:
//-ENOMEM如果调用者的资源池中没有足够的RAM
#define k_fifo_alloc_put(fifo, data) \
	k_queue_alloc_append(&(fifo)->_queue, data)

//原子的(自动?)添加一个元素列表到FIFO,isr可以调用
//在一个操作中添加一个数据项的列表到fifo
//数据项必须在一个单链表中,每个数据项的第一个字指向下一个数据项;
//列表必须以null结束
//参数分别是:实例,单链表中第一个节点,单链表最后一个节点
#define k_fifo_put_list(fifo, head, tail) \
	k_queue_append_list(&(fifo)->_queue, head, tail)

//原子的(自动?)添加一个元素列表到FIFO队列,isr可以调用
//在一个操作中添加一个数据项的列表到fifo
//数据项必须位于使用sys_slist_t对象实现的单链表中
//完成后,sys_slist_t对象无效,必须通过sys_slist_init()重新初始化
//参数分别是:实例,数据项(单链表)
#define k_fifo_put_slist(fifo, list) \
	k_queue_merge_slist(&(fifo)->_queue, list)
	
//从FIFO队列中获取一个元素,isr可以调用(timeout必须设置为K_NO_WAIT)
//以“先进先出”的方式从fifo中删除一个数据项,数据项的第一个字保留给内核使用
//参数分别是:实例,等待时间(或者特殊值K_NO_WAIT和K_FOREVER中的一个)
#define k_fifo_get(fifo, timeout) \
	k_queue_get(&(fifo)->_queue, timeout)

//查询一个FIFO队列,看看它是否有可用的数据,isr可以调用
//如果其他线程也试图从FIFO读取数据,那么当这个函数返回时,数据可能已经消失了
#define k_fifo_is_empty(fifo) \
	k_queue_is_empty(&(fifo)->_queue)

//查看FIFO队列头部的元素
//从FIFO队列头部返回元素而不删除它,一个用例是FIFO对象的元素本身就是容器
//然后在每次迭代处理时,一个头容器将被窥视,一些数据将被处理出来
//只有当容器是空的,它才会从FIFO队列中完全删除
#define k_fifo_peek_head(fifo) \
	k_queue_peek_head(&(fifo)->_queue)

//查看FIFO队列尾部的元素
//返回元素从FIFO队列的尾部(没有删除它)
//如果FIFO队列中的元素本身就是容器,那么就可以这样做
//然后,向FIFO队列中的最后一个容器添加更多数据可能会有用
#define k_fifo_peek_tail(fifo) \
	k_queue_peek_tail(&(fifo)->_queue)

//静态定义和初始化一个FIFO队列
#define K_FIFO_DEFINE(name)                                      \
	Z_STRUCT_SECTION_ITERABLE_ALTERNATE(k_queue, k_fifo, name) = \
		Z_FIFO_INITIALIZER(name)

struct k_lifo {//后进先出的思想与队列相逆
	struct k_queue _queue;//实现是直接使用队列
};

#define Z_LIFO_INITIALIZER(obj)               \
	{                                         \
	._queue = Z_QUEUE_INITIALIZER(obj._queue) \
	}

//初始化一个LIFO队列对象,在它第一次使用之前
#define k_lifo_init(lifo) \
	k_queue_init(&(lifo)->_queue)

//向后进先出队列添加一个元素,isr可以调用
//将一个数据项添加到lifo
//LIFO队列数据项必须按单词边界对齐,并且该项的第一个单词保留给内核使用
//参数分别是:实例,数据项
#define k_lifo_put(lifo, data) \
	k_queue_prepend(&(lifo)->_queue, data)

//向后进先出队列添加一个元素,isr可以调用
//将一个数据项添加到lifo
//有一个隐式内存分配用于从调用线程的资源池中创建额外的临时簿记数据结构
//该结构在删除项时自动释放,数据本身不会被复制
//参数分别是:实例,数据项
//错误返回:
//-ENOMEM如果调用者的资源池中没有足够的RAM
#define k_lifo_alloc_put(lifo, data) \
	k_queue_alloc_prepend(&(lifo)->_queue, data)

//从后进先出队列中获取一个元素,isr可以调用(timeout必须设置为K_NO_WAIT)
//以“后进先出”的方式从LIFO中删除一个数据项,数据项的第一个字保留给内核使用
//参数分别是:实例,等待时间(或者特殊值K_NO_WAIT和K_FOREVER中的一个)
#define k_lifo_get(lifo, timeout) \
	k_queue_get(&(lifo)->_queue, timeout)

//静态定义并初始化一个后进先出队列
#define K_LIFO_DEFINE(name)                                      \
	Z_STRUCT_SECTION_ITERABLE_ALTERNATE(k_queue, k_lifo, name) = \
		Z_LIFO_INITIALIZER(name)

//缓冲区可以动态分配
#define K_STACK_FLAG_ALLOC	((uint8_t)1)

typedef uintptr_t stack_data_t;

struct k_stack {
	_wait_q_t wait_q;//等待队列
	struct k_spinlock lock;//自旋锁
	stack_data_t *base, *next, *top;//缓冲区(栈底,栈下一项,栈顶)

	_OBJECT_TRACING_NEXT_PTR(k_stack)//trace所用
	_OBJECT_TRACING_LINKED_FLAG
	uint8_t flags;
};

#define Z_STACK_INITIALIZER(obj, stack_buffer, stack_num_entries) \
	{                                        \
	.wait_q = Z_WAIT_Q_INIT(&obj.wait_q),	 \
	.base = stack_buffer,                    \
	.next = stack_buffer,                    \
	.top = stack_buffer + stack_num_entries, \
	_OBJECT_TRACING_INIT                     \
	}
	
//初始化一个堆栈对象,在它第一次使用之前
//参数分别是:实例,缓冲区起始,缓冲区大小
void k_stack_init(struct k_stack *stack,
				  stack_data_t *buffer, uint32_t num_entries);

//初始化一个堆栈对象,在它第一次使用之前
//内部缓冲区将从调用线程的资源池中分配
//如果调用了k_stack_cleanup(),或者启用了userspace
//并且堆栈对象丢失了对它的所有引用,那么该内存将被释放
//参数分别是:实例,缓冲区起始,缓冲区大小
//错误返回:
//-ENOMEM如果内存不能分配
__syscall int32_t k_stack_alloc_init(struct k_stack *stack,
									 uint32_t num_entries);

//释放一个堆栈分配的缓冲区
//一个堆栈对象通过k_stack_alloc_init()动态分配了一个缓冲区,这将释放它
//如果缓冲区不是动态分配的,这个函数什么也不做
//错误返回:
//-EAGAIN当对象仍在使用
int k_stack_cleanup(struct k_stack *stack);

//将一个元素推入堆栈,isr可以调用
//这个例程添加一个stack_data_t值data到stack
//参数分别是:实例,数据项
//错误返回:
//-ENOMEM如果栈满
__syscall int k_stack_push(struct k_stack *stack, stack_data_t data);

//从堆栈中弹出一个元素,isr可以调用(timeout必须设置为K_NO_WAIT)
//以“后进先出”的方式从stack中删除一个stack_data_t值,并将其存储在data中
//参数分别是:实例,数据项,等待时间(或者特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-EBUSY不等待返回
//-EAGAIN等待时间超时
__syscall int k_stack_pop(struct k_stack *stack, stack_data_t *data,
						  k_timeout_t timeout);

//静态定义和初始化一个堆栈
#define K_STACK_DEFINE(name, stack_num_entries)        \
	stack_data_t __noinit                              \
		_k_stack_buf_##name[stack_num_entries];        \
	Z_STRUCT_SECTION_ITERABLE(k_stack, name) =         \
		Z_STACK_INITIALIZER(name, _k_stack_buf_##name, \
				    stack_num_entries)

//工作队列的工作项
struct k_work;

//工作项处理函数类型
//当工作项被工作队列处理时,工作项的处理函数由工作队列的线程执行
typedef void (*k_work_handler_t)(struct k_work *work);

struct k_work_q {//工作队列
	struct k_queue queue;//实现是直接使用队列
	struct k_thread thread;//处理该工作队列的线程
};

enum {
	K_WORK_STATE_PENDING,//工作项暂挂状态
};

struct k_work {//工作项
	void *_reserved;//由k_queue实例使用
	k_work_handler_t handler;//工作项处理方式
	atomic_t flags[1];//原子锁
};

struct k_delayed_work {//延时工作项
	struct k_work work;//工作项
	struct _timeout timeout;//超时时间
	struct k_work_q *work_q;//所属工作队列
};

struct k_work_poll {//推送工作项
	struct k_work work;//工作项
	struct k_work_q *workq;//所属工作队列
	struct z_poller poller;//推送着
	struct k_poll_event *events;//推送事件
	int num_events;//事件数
	k_work_handler_t real_handler;//工作项处理方式
	struct _timeout timeout;//超时时间
	int poll_result;//推送结果
};

extern struct k_work_q k_sys_work_q;

#define Z_WORK_INITIALIZER(work_handler) \
	{                                    \
	._reserved = NULL,                   \
	.handler = work_handler,             \
	.flags = { 0 }                       \
	}

//初始化一个静态定义的工作队列工作项,在它第一次使用之前
#define K_WORK_DEFINE(work, work_handler) \
	struct k_work work = Z_WORK_INITIALIZER(work_handler)

//初始化一个工作队列工作项,在它第一次使用之前
static inline void k_work_init(struct k_work *work, k_work_handler_t handler)
{
	*work = (struct k_work)Z_WORK_INITIALIZER(handler);
}

//提交一个工作项,isr可以调用
//提交工作项work,由工作队列work_q处理
//如果由于先前的提交,工作项已经挂起在work_q或任何其他工作队列中,则此例程对工作项没有影响
//如果工作项已经被处理,或者正在被处理,那么它的工作就被认为是完成的,并且工作项可以被重新提交
//提交的工作项在未被工作队列处理之前不能被修改
//参数分别是:工作队列实例,工作项实例
static inline void k_work_submit_to_queue(struct k_work_q *work_q,
										  struct k_work *work)
{
	if (!atomic_test_and_set_bit(work->flags, K_WORK_STATE_PENDING)) {
		k_queue_append(&work_q->queue, work);
	}
}

//提交一个工作项到用户模式工作队列,isr可以调用
//提交一个工作项到一个在用户模式下运行的工作队列
//从调用者的资源池中分配临时内存,一旦工作线程消耗了k_work项,就释放该资源池
//工作队列线程必须对提交的k_work项具有内存访问权
//调用者必须具有对work_q参数的队列对象授予的权限
//否则与k_work_submit_to_queue()工作相同
//参数分别是:工作队列实例,工作项实例
//错误返回:
//-EBUSY如果工作项已经在某个工作队列中
//-ENOMEM如果没有内存分配线程资源池
static inline int k_work_submit_to_user_queue(struct k_work_q *work_q,
											  struct k_work *work)
{
	int ret = -EBUSY;

	if (!atomic_test_and_set_bit(work->flags, K_WORK_STATE_PENDING)) {
		ret = k_queue_alloc_append(&work_q->queue, work);

		//无法插入到队列中,清除挂起的部分,以便再次提交工作项
		if (ret != 0) {
			atomic_clear_bit(work->flags, K_WORK_STATE_PENDING);
		}
	}

	return ret;
}

//检查工作项是否挂起,isr可以调用
//指示工作项work是否挂起在工作队列的队列中
//检查工作是否挂起不能保证在使用此信息时工作仍将挂起
//调用方应确保以安全的方式使用该信息
static inline bool k_work_pending(struct k_work *work)
{
	return atomic_test_bit(work->flags, K_WORK_STATE_PENDING);
}

//检查一个被延迟的工作项是否挂起,isr可以调用
//指示工作项work是否在工作队列的队列中挂起或等待延迟超时
//检查被延迟的工作是否挂起不能保证在使用此信息时工作仍将挂起
//调用方应确保以安全的方式使用该信息
bool k_delayed_work_pending(struct k_delayed_work *work);

//启动一个工作队列
//启动工作队列work_q,工作队列生成永远运行的工作处理线程
//参数分别是:工作队列实例,堆栈空间(工作队列线程所用,如
//K_THREAD_STACK_DEFINE()所定义的),堆栈空间字节大小(工作队列
//线程所用它应该是传递给K_THREAD_STACK_DEFINE()的相同常量
//或者是K_THREAD_STACK_SIZEOF()的值),工作队列中线程的优先级
extern void k_work_q_start(struct k_work_q *work_q,
						   k_thread_stack_t *stack,
						   size_t stack_size, int prio);

//以用户模式启动工作队列
//它与k_work_q_start()的工作方式相同,除了它可以从用户模式调用
//并且创建的工作线程将在用户模式下运行
//调用者必须同时拥有work_q参数的线程和队列对象的权限
//并且优先级的限制与k_thread_create()相同
//参数分别是:工作队列实例,堆栈空间(工作队列线程所用,如
//K_THREAD_STACK_DEFINE()所定义的),堆栈空间字节大小(工作队列
//线程所用它应该是传递给K_THREAD_STACK_DEFINE()的相同常量
//或者是K_THREAD_STACK_SIZEOF()的值),工作队列中线程的优先级
extern void k_work_q_user_start(struct k_work_q *work_q,
								k_thread_stack_t *stack,
								size_t stack_size, int prio);

#define Z_DELAYED_WORK_INITIALIZER(work_handler)  \
	{                                             \
		.work = Z_WORK_INITIALIZER(work_handler), \
		.timeout = {                              \
			.node = {},                           \
			.fn = NULL,                           \
			.dticks = 0,                          \
		},                                        \
		.work_q = NULL,                           \
	}

//这个宏可以用来初始化一个静态定义的延迟工作项,在它第一次使用之前
#define K_DELAYED_WORK_DEFINE(work, work_handler) \
	struct k_delayed_work work = Z_DELAYED_WORK_INITIALIZER(work_handler)

//这个例程初始化一个延迟的工作项,在它第一次使用之前
static inline void k_delayed_work_init(struct k_delayed_work *work,
									   k_work_handler_t handler)
{
	*work = (struct k_delayed_work)Z_DELAYED_WORK_INITIALIZER(handler);
}

//提交一个延迟的工作项,isr可以调用
//将工作项work安排在delay延迟毫秒后由工作队列work_q处理
//为工作项启动异步倒计时,然后返回给调用者
//只有在倒计时完成时,工作项才会实际提交到工作队列,并变成挂起
//
//提交一个之前提交的仍在倒计时或未决的工作项将取消现有的提交
//并使用新的延迟重新开始倒计时
//这种行为本质上受制于预先存在的超时和工作队列的竞争条件
//因此必须小心地从外部同步此类重提交
//
//当一个工作项被提交到一个不同的队列后,尝试将其提交到一个队列会以-EALREADY失败
//直到工作项被成功调用k_delayed_work_cancel()来清除其内部状态
//延迟的工作项在被工作队列处理之前不能被修改
//参数分别是:工作队列实例,延迟工作项实例,延迟时间
//错误返回:
//-EINVAL如果先前提交的工作项必须取消,并且取消失败;或工作项正在被处理或已完成其工作
//-EADDRINUSE工作项被提交到不同的工作队列
extern int k_delayed_work_submit_to_queue(struct k_work_q *work_q,
										 struct k_delayed_work *work,
										 k_timeout_t delay);

//取消延迟的工作项,isr可以调用
//取消提交延迟的工作项work,工作项是否可以成功取消取决于它的状态
//当-EALREADY被返回时,调用者不能区分工作项处理程序是仍然被工作队列线程调用还是已经完成
//错误返回:
//-EINVAL未提交工作项;
//或工作项已成功取消;
//或Timeout处理程序正在将工作项提交到其队列的过程中;
//或工作队列线程已从队列中删除了工作项,但没有调用其处理程序
//-EALREADY工作队列线程已从队列中删除工作项并清除其挂起标志;
//或工作队列线程正在调用项处理程序;
//或工作项处理程序已完成
extern int k_delayed_work_cancel(struct k_delayed_work *work);

//提交一个工作项到系统工作队列,isr可以调用
//提交一个工作项work以被系统工作队列处理
//如果由于先前的提交,工作项已经挂起在系统工作队列或任何其他工作队列中,则此例程对工作项没有影响
//如果工作项已经被处理,者正在被处理,那么它的工作就被认为是完成的,并且工作项可以被重新提交
//提交给系统工作队列的工作项应该避免使用阻塞或产生的处理程序
//因为这可能会阻止系统工作队列及时处理其他工作项
static inline void k_work_submit(struct k_work *work)
{
	k_work_submit_to_queue(&k_sys_work_q, work);
}

//提交一个延迟的工作项到系统工作队列,isr可以调用
//将工作项目work安排为在delay延迟毫秒后被系统工作队列处理
//例程为工作项启动异步倒计时,然后返回给调用者
//只有在倒计时完成时,工作项才会实际提交到工作队列,并变成未决
//提交一个之前提交的仍在倒计时的工作项将取消现有的提交,并使用新的延迟重新开始倒计时
//如果工作项当前挂起在工作队列的队列中,因为倒计时已经完成,那么重新提交该项就太晚了
//并且重新提交失败而不会影响工作项,如果工作项已经被处理,或者正在被处理
//那么它的工作就被认为是完成的,并且工作项可以被重新提交
//当一个工作项已经被提交到一个不同的队列之后,尝试将其提交到一个队列会以-EALREADY失败
//直到工作项被调用k_delayed_work_cancel()来清除其内部状态
//提交给系统工作队列的工作项应该避免使用阻塞或产生的处理程序
//因为这可能会阻止系统工作队列及时处理其他工作项
//参数分别是:工作项实例,延迟时间
//错误返回:
//-EINVAL工作项正在被处理或已经完成它的工作
//-EADDRINUSE工作项被提交到不同的工作队列
static inline int k_delayed_work_submit(struct k_delayed_work *work,
										k_timeout_t delay)
{
	return k_delayed_work_submit_to_queue(&k_sys_work_q, work, delay);
}

//获取被延迟的工作被安排的时间
//在一个延迟的工作执行时计算系统正常运行时间,如果延迟的工作没有等待调度,则返回当前系统时间
static inline k_ticks_t k_delayed_work_expires_ticks(struct k_delayed_work *work)
{
	return z_timeout_expires(&work->timeout);
}

//在一个延迟的工作被安排之前的剩余时间,以系统计时为单位
//计算在一个延迟的工作被执行之前剩余的时间,如果延迟的工作没有等待调度,则返回0
static inline k_ticks_t k_delayed_work_remaining_ticks(struct k_delayed_work *work)
{
	return z_timeout_remaining(&work->timeout);
}

//在延迟的工作被安排之前的剩余时间
//计算在一个延迟的工作被执行之前剩余的(大约)时间,如果延迟的工作没有等待调度,则返回0
static inline int32_t k_delayed_work_remaining_get(struct k_delayed_work *work)
{
	return k_ticks_to_ms_floor32(z_timeout_remaining(&work->timeout));
}

//初始化一个被触发的工作项
//在第一次使用工作项之前,初始化一个工作队列触发的工作项
extern void k_work_poll_init(struct k_work_poll *work, k_work_handler_t handler);

//提交一个已触发的工作项,isr可以调用
//当一个给定的event事件有信号时,将工作项work安排给工作队列work_q来处理
//为工作项初始化内部轮询器,然后返回给调用者
//只有当其中一个被观察的事件发生时,工作项才会实际提交到工作队列并变成挂起状态
//提交一个先前提交的仍在等待事件的触发工作项将取消现有的提交,并使用新的事件列表重新安排它
//此行为本质上受已存在的已触发工作项和工作队列的竞争条件的影响,因此必须小心在外部同步此类重提交
//提供的事件数组以及一个被触发的工作项必须放置在持久内存中(直到工作处理程序执行或工作取消为止有效)
//并且在提交后不能修改
//参数分别是:工作队列实例,延迟工作项实例,触发工作的事件集,事件数,超时时间(超时后
//的工作将被安排执行,即使没有被触发)
//错误返回:
//-EINVAL工作项正在被处理或已经完成它的工作
//-EADDRINUSE工作项挂起在不同的工作队列
extern int k_work_poll_submit_to_queue(struct k_work_q *work_q,
									   struct k_work_poll *work,
									   struct k_poll_event *events,
									   int num_events,
									   k_timeout_t timeout);

//提交一个被触发的工作项到系统工作队列,isr可以调用
//当一个给定的event事件被触发时,这个例程将工作项work工作安排给系统工作队列处理
//为工作项初始化内部轮询器,然后返回给调用者
//只有当其中一个被观察的事件发生时,工作项才会实际提交到工作队列并变成挂起状态
//提交一个先前提交的仍在等待事件的触发工作项将取消现有的提交,并使用新的事件列表重新安排它
//此行为本质上受已存在的已触发工作项和工作队列的竞争条件的影响,因此必须小心在外部同步此类重提交
//提供的事件数组以及被触发的工作项必须在被工作队列处理后才能被修改
//参数分别是:延迟工作项实例,触发工作的事件集,事件数,超时时间(超时后的工作将被安排执行,即使没有被触发)
//错误返回:
//-EINVAL工作项正在被处理或已经完成它的工作
//-EADDRINUSE工作项挂起在不同的工作队列
static inline int k_work_poll_submit(struct k_work_poll *work,
									 struct k_poll_event *events,
									 int num_events,
									 k_timeout_t timeout)
{
	return k_work_poll_submit_to_queue(&k_sys_work_q, work,
									   events, num_events, timeout);
}

//取消一个已触发的工作项,isr可以调用
//取消被触发的工作项work的提交,只有在没有事件触发工作提交时,才可以取消已触发的工作项
extern int k_work_poll_cancel(struct k_work_poll *work);

struct k_mutex {//互斥锁
	_wait_q_t wait_q;//等待队列
	struct k_thread *owner;//互斥锁所有者
	uint32_t lock_count;//锁深度
	int owner_orig_prio;//源所有者优先级

	_OBJECT_TRACING_NEXT_PTR(k_mutex)//trace所用
	_OBJECT_TRACING_LINKED_FLAG
};

#define Z_MUTEX_INITIALIZER(obj)             \
	{                                        \
	.wait_q = Z_WAIT_Q_INIT(&obj.wait_q),    \
	.owner = NULL,                           \
	.lock_count = 0,                         \
	.owner_orig_prio = K_LOWEST_THREAD_PRIO, \
	_OBJECT_TRACING_INIT                     \
	}

//静态定义和初始化互斥锁
#define K_MUTEX_DEFINE(name) \
	Z_STRUCT_SECTION_ITERABLE(k_mutex, name) = \
		Z_MUTEX_INITIALIZER(name)

//在第一次使用互斥对象之前初始化它
__syscall int k_mutex_init(struct k_mutex *mutex);

//锁定互斥对象
//如果互斥锁被另一个线程锁定,调用该互斥锁的线程将一直等待,直到互斥锁可用或发生超时
//一个线程被允许锁定一个它已经锁定的互斥锁,操作立即完成,锁计数增加1
//isr中互斥锁不能被锁定
//参数分别是:互斥锁实例,等待时间(或者特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-EBUSY不等待返回
//-EAGAIN等待时间超时
__syscall int k_mutex_lock(struct k_mutex *mutex, k_timeout_t timeout);

//解锁互斥锁
//互斥锁必须已经被调用线程锁定
//互斥锁不能被另一个线程占用,直到调用它的线程解锁了它之前被那个线程锁定的次数
//互斥锁不能在isr中解锁,因为互斥锁只能在线程上下文中操作
//这是由于所有权和优先级继承语义的关系
//错误返回:
//-EINVAL互斥锁未被锁定
__syscall int k_mutex_unlock(struct k_mutex *mutex);

struct k_condvar {//条件变量
	_wait_q_t wait_q;//实现是直接使用队列
};

#define Z_CONDVAR_INITIALIZER(obj)            \
	{                                         \
		.wait_q = Z_WAIT_Q_INIT(&obj.wait_q), \
	}

//初始化一个条件变量
__syscall int k_condvar_init(struct k_condvar *condvar);

//发送信号向一个条件变量上挂起的线程
__syscall int k_condvar_signal(struct k_condvar *condvar);

//解除阻塞所有在条件变量上挂起的线程
__syscall int k_condvar_broadcast(struct k_condvar *condvar);

//等待释放互斥锁的条件变量
//自动释放当前拥有的互斥锁,阻塞当前线程等待condvar指定的条件变量,并最终再次获得互斥锁
//等待的线程只有在另一个线程使用相同的条件变量调用k_condvar_signal或k_condvar_broadcast后才会解除阻塞
//参数分别是:条件变量实例,互斥锁实例,等待时间(或特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-EAGAIN等待时间超时
__syscall int k_condvar_wait(struct k_condvar *condvar, struct k_mutex *mutex,
							 k_timeout_t timeout);

//静态定义并初始化一个条件变量
#define K_CONDVAR_DEFINE(name)                   \
	Z_STRUCT_SECTION_ITERABLE(k_condvar, name) = \
		Z_CONDVAR_INITIALIZER(name)

struct k_sem {//信号量
	_wait_q_t wait_q;//等待队列
	uint32_t count;//信号次数
	uint32_t limit;//信号最大限制
	_POLL_EVENT;//推送事件

	_OBJECT_TRACING_NEXT_PTR(k_sem)//trace所用
	_OBJECT_TRACING_LINKED_FLAG
};

#define Z_SEM_INITIALIZER(obj, initial_count, count_limit) \
	{                                     \
	.wait_q = Z_WAIT_Q_INIT(&obj.wait_q), \
	.count = initial_count,               \
	.limit = count_limit,                 \
	_POLL_EVENT_OBJ_INIT(obj)             \
	_OBJECT_TRACING_INIT                  \
	}

//这个例程在第一次使用信号量对象之前初始化它
//参数分别是:信号量实例,初始时计数,最大计数
//错误返回:
//-EINVAL非法值
__syscall int k_sem_init(struct k_sem *sem, unsigned int initial_count,
						 unsigned int limit);

//获取信号量,isr可以调用(timeout必须设置为K_NO_WAIT)
//参数分别是:信号量实例,等待时间(或者特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-EBUSY不等待返回
//-EAGAIN等待时间超时
__syscall int k_sem_take(struct k_sem *sem, k_timeout_t timeout);

//给出一个信号量,isr可以调用
//除非信号量已经达到其允许的最大计数
__syscall void k_sem_give(struct k_sem *sem);

//将一个信号量的计数重置为零
__syscall void k_sem_reset(struct k_sem *sem);
static inline void z_impl_k_sem_reset(struct k_sem *sem)
{
	sem->count = 0U;
}

//获取当前信号量的计数
__syscall unsigned int k_sem_count_get(struct k_sem *sem);
static inline unsigned int z_impl_k_sem_count_get(struct k_sem *sem)
{
	return sem->count;
}

//静态定义和初始化一个信号量
//参数分别是:信号量实例,初始时计数,最大计数
#define K_SEM_DEFINE(name, initial_count, count_limit)       \
	Z_STRUCT_SECTION_ITERABLE(k_sem, name) =                 \
		Z_SEM_INITIALIZER(name, initial_count, count_limit); \
	BUILD_ASSERT(((count_limit) != 0) &&                     \
		     ((initial_count) <= (count_limit)));

struct k_msgq {//消息队列
	_wait_q_t wait_q;//等待队列
	struct k_spinlock lock;//自旋锁
	size_t msg_size;//信息大小
	uint32_t max_msgs;//消息最大数量
	char *buffer_start;//消息缓冲起始
	char *buffer_end;//消息缓冲结束
	char *read_ptr;//读位置
	char *write_ptr;//写位置
	uint32_t used_msgs;//使用的消息数量

	_OBJECT_TRACING_NEXT_PTR(k_msgq)//trace所用
	_OBJECT_TRACING_LINKED_FLAG

	uint8_t flags;//消息队列
};

#define Z_MSGQ_INITIALIZER(obj, q_buffer, q_msg_size, q_max_msgs) \
	{                                                   \
	.wait_q = Z_WAIT_Q_INIT(&obj.wait_q),               \
	.msg_size = q_msg_size,                             \
	.max_msgs = q_max_msgs,                             \
	.buffer_start = q_buffer,                           \
	.buffer_end = q_buffer + (q_max_msgs * q_msg_size), \
	.read_ptr = q_buffer,                               \
	.write_ptr = q_buffer,                              \
	.used_msgs = 0,                                     \
	_OBJECT_TRACING_INIT                                \
	}

//消息队列动态分配标志
#define K_MSGQ_FLAG_ALLOC	BIT(0)

struct k_msgq_attrs {//消息队列属性
	size_t msg_size;//消息大小
	uint32_t max_msgs;//最大消息数
	uint32_t used_msgs;//使用的消息
};

//静态定义并初始化消息队列
//消息队列的环形缓冲区包含q_max_msgs消息的空间
//每个消息都是q_msg_size字节长,缓冲区对齐q_align -byte边界,该边界必须是2的幂
//为了确保每个消息以类似的方式对齐此边界,q_msg_size也必须是q_align的倍数
//参数分别是:消息队列实例,消息大小(字节),最大消息数,消息队列的环形缓冲区对齐
#define K_MSGQ_DEFINE(q_name, q_msg_size, q_max_msgs, q_align)		\
	static char __noinit __aligned(q_align)				    \
		_k_fifo_buf_##q_name[(q_max_msgs) * (q_msg_size)];	\
	Z_STRUCT_SECTION_ITERABLE(k_msgq, q_name) =			    \
	       Z_MSGQ_INITIALIZER(q_name, _k_fifo_buf_##q_name,	\
				  q_msg_size, q_max_msgs)

//初始化一个消息队列
//在消息队列对象第一次使用之前初始化它
//消息队列的环形缓冲区必须包含max_msgs消息的空间,每个消息的长度为msg_size字节
//缓冲区必须与N字节的边界对齐,其中N是2的幂(即1,2,4,…)
//为了确保每个消息以类似的方式对齐此边界,q_msg_size也必须是N的倍数
//参数分别是:消息队列实例,消息缓冲区,消息大小(字节),最大消息数
void k_msgq_init(struct k_msgq *q, char *buffer, size_t msg_size,
				 uint32_t max_msgs);

//初始化一个消息队列
//初始化一个消息队列对象,在它第一次使用之前,从调用线程的资源池中分配它的内部循环缓冲区
//为循环缓冲区分配的内存可以通过调用k_msgq_cleanup()来释放
//或者如果启用了用户空间并且msgq对象丢失了它的所有引用
//参数分别是:消息队列实例,消息大小(字节),最大消息数
//错误返回:
//-ENOMEM如果线程的资源池中内存不足
//-EINVAL如果size参数导致整数溢出
__syscall int k_msgq_alloc_init(struct k_msgq *msgq, size_t msg_size,
				uint32_t max_msgs);

//释放为队列分配的缓冲区
//释放为循环缓冲区分配的内存
//错误返回:
//-EBUSY队列不为空
int k_msgq_cleanup(struct k_msgq *msgq);

//发送消息到消息队列,isr可以调用
//这个例程发送一个消息到消息队列msgq
//消息内容从data复制到msgq,data指针不被保留,因此消息内容不会被这个函数修改
//参数分别是:消息队列实例,发送的消息,等待时间(或者特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-ENOMSG返回没有等待或队列清除
//-EAGAIN等待时间超时
__syscall int k_msgq_put(struct k_msgq *msgq, const void *data, k_timeout_t timeout);

//从消息队列中接收消息,isr可以调用(timeout必须设置为K_NO_WAIT)
//这个例程以“先进先出”的方式从消息队列msgq接收消息
//参数分别是:消息队列实例,接收的消息,等待时间(或者特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-ENOMSG返回无需等待
//-EAGAIN等待时间超时
__syscall int k_msgq_get(struct k_msgq *msgq, void *data, k_timeout_t timeout);

//从消息队列中查看/读取消息,isr可以调用
//这个例程以“先入先出”的方式从消息队列msgq读取消息,并将消息留在队列中
//参数分别是:消息队列实例,查看的消息
//错误返回:
//-ENOMSG当队列没有消息时返回
__syscall int k_msgq_peek(struct k_msgq *msgq, void *data);

//清除一个消息队列
//丢弃消息队列的环形缓冲区中所有未接收的消息
//任何等待向消息队列发送消息的阻塞线程将被解除阻塞,并看到-ENOMSG错误代码
__syscall void k_msgq_purge(struct k_msgq *msgq);

//获取消息队列的基本属性
//将消息队列的基本属性获取到attr参数中
//参数分别是:消息队列实例,属性实例
__syscall void  k_msgq_get_attrs(struct k_msgq *msgq,
								 struct k_msgq_attrs *attrs);

//获取消息队列中的空闲空间
//返回消息队列的环形缓冲区中未使用的条目的数量
__syscall uint32_t k_msgq_num_free_get(struct k_msgq *msgq);
static inline uint32_t z_impl_k_msgq_num_free_get(struct k_msgq *msgq)
{
	return msgq->max_msgs - msgq->used_msgs;
}

//获取消息队列中的消息数
//返回消息队列的环形缓冲区中的消息数量
__syscall uint32_t k_msgq_num_used_get(struct k_msgq *msgq);
static inline uint32_t z_impl_k_msgq_num_used_get(struct k_msgq *msgq)
{
	return msgq->used_msgs;
}

struct k_mbox_msg {//邮箱消息
	uint32_t _mailbox;//内部使用,需要接口保留支持
	size_t size;//消息大小
	uint32_t info;//应用定义的信息值、
	void *tx_data;//发送者的消息
	void *_rx_data;//内部使用,需要接口保留支持
	struct k_mem_block tx_block;//消息数据块
	k_tid_t rx_source_thread;//接收源线程ID
	k_tid_t tx_target_thread;//发送目标线程ID
	k_tid_t _syncing_thread;//仅内部使用,线程等待发送
#if (CONFIG_NUM_MBOX_ASYNC_MSGS > 0)
	struct k_sem *_async_sem;//仅内部使用,在异步发送时使用的信号量
#endif
};

struct k_mbox {//邮箱
	_wait_q_t tx_msg_queue;//发送(传输)消息等待队列
	_wait_q_t rx_msg_queue;//接收消息等待队列
	struct k_spinlock lock;//自旋锁

	_OBJECT_TRACING_NEXT_PTR(k_mbox)//trace所用
	_OBJECT_TRACING_LINKED_FLAG
};

#define Z_MBOX_INITIALIZER(obj)                       \
	{                                                 \
	.tx_msg_queue = Z_WAIT_Q_INIT(&obj.tx_msg_queue), \
	.rx_msg_queue = Z_WAIT_Q_INIT(&obj.rx_msg_queue), \
	_OBJECT_TRACING_INIT                              \
	}

//静态定义和初始化邮箱
#define K_MBOX_DEFINE(name) \
	Z_STRUCT_SECTION_ITERABLE(k_mbox, name) = \
		Z_MBOX_INITIALIZER(name) \

//在邮箱对象第一次使用之前初始化它
extern void k_mbox_init(struct k_mbox *mbox);

//同步发送邮箱消息
//向mbox发送一条消息,并等待接收方接收和处理它
//消息数据可能在缓冲区中,在内存池块中,或者不存在(即一个空消息)
//参数分别是:邮箱实例,发送消息实例,接收消息的等待时间(或者
//特殊值K_NO_WAIT和K_FOREVER中的一个)
//一旦接收到消息,这个例程就会等待消息被完全处理
//错误返回:
//-ENOMSG返回无需等待
//-EAGAIN等待时间超时
extern int k_mbox_put(struct k_mbox *mbox, struct k_mbox_msg *tx_msg,
					  k_timeout_t timeout);

//以异步方式发送邮箱消息
//发送一个消息到mbox,而不等待接收方处理它
//消息数据可能在缓冲区中,在内存池块中,或者不存在(即一个空消息)
//可选地,当消息已被接收方接收并完全处理时,将给出信号量sem
//参数分别是:邮箱实例,发送消息实例,信号量实例(如果不需要,NULL)
extern void k_mbox_async_put(struct k_mbox *mbox, struct k_mbox_msg *tx_msg,
							 struct k_sem *sem);

//接收邮箱信息
//从mbox接收一个消息,然后选择性地检索它的数据并处理该消息
//参数分别是:邮箱实例,接收消息实例,接收数据(或者NULL,将数据检索和消息处理
//延迟到以后),接收消息的等待时间(或者特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-ENOMSG返回无需等待
//-EAGAIN等待时间超时
extern int k_mbox_get(struct k_mbox *mbox, struct k_mbox_msg *rx_msg,
					  void *buffer, k_timeout_t timeout);

//将邮箱消息数据检索到缓冲区中
//通过将接收到的消息检索到缓冲区中,然后处理该消息来完成对该消息的处理
//或者,这个例程可以用来处理接收到的消息而不检索其数据
//参数分别是:接收消息实例,接收数据(NULL表示丢弃数据)
extern void k_mbox_data_get(struct k_mbox_msg *rx_msg, void *buffer);

struct k_pipe {//管道
	unsigned char *buffer;//管道缓冲区
	size_t         size;//缓冲区大小
	size_t         bytes_used;//被使用的空间
	size_t         read_index;//读索引
	size_t         write_index;//写索引
	struct k_spinlock lock;//自旋锁

	struct {//等待队列
		_wait_q_t      readers;//读等待队列
		_wait_q_t      writers;//写等待队列
	} wait_q;

	_OBJECT_TRACING_NEXT_PTR(k_pipe)//trace所用
	_OBJECT_TRACING_LINKED_FLAG
	uint8_t	       flags;//标志
};

//管道缓冲区动态分配标志
#define K_PIPE_FLAG_ALLOC	BIT(0)

#define Z_PIPE_INITIALIZER(obj, pipe_buffer, pipe_buffer_size) \
	{                                                  \
	.buffer = pipe_buffer,                             \
	.size = pipe_buffer_size,                          \
	.bytes_used = 0,                                   \
	.read_index = 0,                                   \
	.write_index = 0,                                  \
	.lock = {},                                        \
	.wait_q = {                                        \
		.readers = Z_WAIT_Q_INIT(&obj.wait_q.readers), \
		.writers = Z_WAIT_Q_INIT(&obj.wait_q.writers)  \
	},                                                 \
	_OBJECT_TRACING_INIT                               \
	.flags = 0                                         \
	}

//静态定义和初始化管道
//参数分别是:管道实例,缓冲区的字节大小(如果没有使用缓冲区
//则为零),缓冲区对齐(2的幂)
#define K_PIPE_DEFINE(name, pipe_buffer_size, pipe_align) \
	static unsigned char __noinit __aligned(pipe_align)	\
		_k_pipe_buf_##name[pipe_buffer_size];			\
	Z_STRUCT_SECTION_ITERABLE(k_pipe, name) =           \
		Z_PIPE_INITIALIZER(name, _k_pipe_buf_##name,    \
			pipe_buffer_size)

//初始化一个管道
//初始化一个管道对象,在它第一次使用之前
//参数分别是:管道实例,缓冲区(如果没有使用缓冲区则为NULL),缓冲区
//的字节大小(如果没有使用缓冲区则为零)
void k_pipe_init(struct k_pipe *pipe, unsigned char *buffer, size_t size);

//释放管道分配的缓冲区
//如果一个管道对象通过k_pipe_alloc_init()动态分配了一个缓冲区,这将释放它
//如果缓冲区不是动态分配的,这个函数什么也不做
//错误返回:
//-EAGAIN没有任何清理
int k_pipe_cleanup(struct k_pipe *pipe);

//初始化一个管道并为它分配一个缓冲区
//buffer区域的存储将从调用线程的资源池中分配
//如果调用了k_pipe_cleanup(),或者启用了userspace
//并且管道对象丢失了对它的所有引用,那么该内存将被释放
//这个函数只能在未初始化的管道对象上调用
//参数分别是:管道实例,缓冲区的字节大小(如果没有使用缓冲区则为零)
//错误返回:
//-ENOMEM如果内存不能分配
__syscall int k_pipe_alloc_init(struct k_pipe *pipe, size_t size);

//向管道写入数据
//将数据写入bytes_to_write到pipe管道
//参数分别是:管道实例,写入的数据,目标数据的大小(字节),实际
//写入字节,最小写入字节数,数据写入等待时间(或者
//特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-EIO返回没有等待;写入的数据字节为零
//-EAGAIN等待时间超时;从0到min_xfer减去一个数据字节(达不到最小写入字节数)
__syscall int k_pipe_put(struct k_pipe *pipe, void *data,
						 size_t bytes_to_write, size_t *bytes_written,
						 size_t min_xfer, k_timeout_t timeout);

//从管道读取数据
//从pipe管道中读取数据的bytes_to_read字节
//参数分别是:管道实例,读取的数据,目标数据的大小(字节),实际
//读取字节,最小读取字节数,数据读取等待时间(或者
//特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-EINVAL提供的无效参数
//-EIO返回没有等待;读取了零数据字节
//-EAGAIN等待时间超时;从0到@a min_xfer减去一个数据字节被读取。
__syscall int k_pipe_get(struct k_pipe *pipe, void *data,
						 size_t bytes_to_read, size_t *bytes_read,
						 size_t min_xfer, k_timeout_t timeout);

//将内存块写入管道
//将包含在内存块中的数据写到pipe管道中
//一旦块中的所有数据都写入管道,它将释放内存块block块,并给出信号量sem(如果指定的话)
//参数分别是:管道实例,含发送数据的内存块实例,发送
//数据字节数,信号量实例(在完成时发出信号(else NULL))
extern void k_pipe_block_put(struct k_pipe *pipe, struct k_mem_block *block,
							 size_t size, struct k_sem *sem);

//查询可以从pipe管道中读取的字节数
__syscall size_t k_pipe_read_avail(struct k_pipe *pipe);

//查询可能写入pipe管道的字节数
__syscall size_t k_pipe_write_avail(struct k_pipe *pipe);

struct k_mem_slab {//SLAB分配器(内存分配)
	_wait_q_t wait_q;//等待队列
	uint32_t num_blocks;//内存块
	size_t block_size;//块大小
	char *buffer;//缓冲区
	char *free_list;//空闲链表
	uint32_t num_used;//当前使用
#ifdef CONFIG_MEM_SLAB_TRACE_MAX_UTILIZATION
	uint32_t max_used;//最大使用
#endif

	_OBJECT_TRACING_NEXT_PTR(k_mem_slab)//trace所用
	_OBJECT_TRACING_LINKED_FLAG
};

#define Z_MEM_SLAB_INITIALIZER(obj, slab_buffer, slab_block_size, \
							   slab_num_blocks)                   \
	{                                     \
	.wait_q = Z_WAIT_Q_INIT(&obj.wait_q), \
	.num_blocks = slab_num_blocks,        \
	.block_size = slab_block_size,        \
	.buffer = slab_buffer,                \
	.free_list = NULL,                    \
	.num_used = 0,                        \
	_OBJECT_TRACING_INIT                  \
	}

//静态定义和初始化一个SLAB分配器
//SLAB分配器的缓冲区包含slab_num_blocks内存块
//这些内存块是slab_block_size字节长,缓冲区对齐到slab_align -byte边界
//为了确保每个内存块都以类似的方式对齐到这个边界
//slab_block_size也必须是slab_align的倍数
//参数分别是:SLAB分配器实例,内存块大小(字节),内存块数,缓冲区对齐(2的幂)
#define K_MEM_SLAB_DEFINE(name, slab_block_size, slab_num_blocks, slab_align) \
	char __noinit __aligned(WB_UP(slab_align))                             \
	   _k_mem_slab_buf_##name[(slab_num_blocks) * WB_UP(slab_block_size)]; \
	Z_STRUCT_SECTION_ITERABLE(k_mem_slab, name) =                          \
		Z_MEM_SLAB_INITIALIZER(name, _k_mem_slab_buf_##name,               \
					WB_UP(slab_block_size), slab_num_blocks)

//初始化一个SLAB分配器,在它第一次使用之前
//SLAB分配器内存板的缓冲区包含slab_num_blocks内存块
//这些内存块是slab_block_size字节长,缓冲区必须对齐到一个N字节的边界
//匹配一个字边界,其中N是2的幂(即32位系统上的4,8,16,…),为了确保
//每个内存块都以类似的方式对齐到这个边界,slab_block_size也必须是N的倍数
//参数分别是:SLAB分配器实例,缓冲区,每个内存块的大小(字节),内存块数
//错误返回:
//-EINVAL提供的无效数据
extern int k_mem_slab_init(struct k_mem_slab *slab, void *buffer,
						   size_t block_size, uint32_t num_blocks);

//从SLAB分配器分配内存,isr可以调用(timeout必须设置为K_NO_WAIT)
//从一个内存板中分配一个内存块
//参数分别是:SLAB分配器实例,分配出的内存块,等待时间(或者使用
//K_NO_WAIT返回而不等待,或者使用K_FOREVER等待)
//错误返回:
//-ENOMEM返回没有等待
//-EAGAIN等待时间超时
//-EINVAL提供的数据无效
extern int k_mem_slab_alloc(struct k_mem_slab *slab, void **mem,
							k_timeout_t timeout);

//释放从SLAB分配器分配的内存
//释放一个先前分配的内存块到它的关联SLAB分配器中
//参数分别是:SLAB分配器实例,分配出的内存块(由k_mem_slab_alloc()设置)
extern void k_mem_slab_free(struct k_mem_slab *slab, void **mem);

//获取SLAB分配器中已使用的块数
//获取当前在slab中分配的内存块的数量
static inline uint32_t k_mem_slab_num_used_get(struct k_mem_slab *slab)
{
	return slab->num_used;
}

//获取到目前为止在SLAB分配器中最大使用的块的数量
static inline uint32_t k_mem_slab_max_used_get(struct k_mem_slab *slab)
{
#ifdef CONFIG_MEM_SLAB_TRACE_MAX_UTILIZATION
	return slab->max_used;
#else
	ARG_UNUSED(slab);
	return 0;
#endif
}

//获取SLAB分配器中未使用的块的数量
static inline uint32_t k_mem_slab_num_free_get(struct k_mem_slab *slab)
{
	return slab->num_blocks - slab->num_used;
}

struct k_heap {//内核同步堆结构
	struct sys_heap heap;//系统堆
	_wait_q_t wait_q;//等待队列
	struct k_spinlock lock;//自旋锁
};

//初始化k_heap
//在用户指定的内存区域上构造一个同步的k_heap对象
//虽然任何对齐和大小都可以作为有效参数传递
//但内部sys_heap中的内部对齐限制意味着并非所有字节都可以作为分配的内存可用
//参数分别是:堆实例,内存空间,内存大小
void k_heap_init(struct k_heap *h, void *mem, size_t bytes);

//从k_heap分配对齐的内存,isr可以调用(timeout必须设置为K_NO_WAIT)
//在所有方面都像k_heap_alloc()
//除了返回的内存(如果可用)将在内存中有一个起始地址
//该地址是指定的2次幂对齐值(以字节表示)的倍数
//可以使用k_heap_free()将产生的内存返回给堆
//参数分别是:堆实例,字节对齐(必须是2的幂),请求字节数,等待时间(或K_NO_WAIT)
void *k_heap_aligned_alloc(struct k_heap *h, size_t align, size_t bytes,
						   k_timeout_t timeout);

//从k_heap分配内存,isr可以调用(timeout必须设置为K_NO_WAIT)
//从堆拥有的内存区域中分配并返回一个内存缓冲区
//如果没有立即可用的内存,调用将阻塞指定的超时(通过标准超时API
//或K_NO_WAIT或K_FOREVER构造),以等待内存被释放
//如果分配不能在超时时间到期时执行,将返回NULL
//参数分别是:堆实例,请求字节数,等待时间(或K_NO_WAIT)
static inline void *k_heap_alloc(struct k_heap *h, size_t bytes,
								 k_timeout_t timeout)
{
	return k_heap_aligned_alloc(h, sizeof(void *), bytes, timeout);
}

//释放k_heap_alloc()分配的空闲内存
//返回指定的内存块,它必须从k_heap_alloc()返回到堆
//供其他调用者使用,传递NULL块是合法的,没有任何效果
//参数分别是:堆实例,被分配的空间
void k_heap_free(struct k_heap *h, void *mem);

//这个宏定义并初始化一个静态内存区域和k_heap的请求大小
//内核启动后,可以使用&name,就像调用了k_heap_init()一样
#define K_HEAP_DEFINE(name, bytes) \
	char __aligned(sizeof(void *)) kheap_##name[bytes];	\
	Z_STRUCT_SECTION_ITERABLE(k_heap, name) = {         \
		.heap = {                                       \
			.init_mem = kheap_##name,                   \
			.init_bytes = (bytes),                      \
		 },	                                            \
	}

extern int z_mem_pool_alloc(struct k_mem_pool *pool,
							struct k_mem_block *block,
							size_t size, k_timeout_t timeout);
extern void *z_mem_pool_malloc(struct k_mem_pool *pool, size_t size);
extern void z_mem_pool_free(struct k_mem_block *block);
extern void z_mem_pool_free_id(struct k_mem_block_id *id);

//使用指定的对齐方式从堆中分配内存
//提供类似于aligned_alloc()的语义
//按照指定的对齐方式从堆中分配内存
//然而k_aligned_alloc()接受任何非零的size大小
//aligned_alloc()只接受size大小是align对齐的整数倍
//以上,aligned_alloc()引用:
//C11标准(ISO/IEC 9899:2011): 7.22.3.1
//aligned_alloc函数(p: 347-348)
//参数分别是:内存对齐(字节),请求的内存数量(字节)
extern void *k_aligned_alloc(size_t align, size_t size);

//从堆中分配内存
//提供了传统的malloc()语义,内存从堆内存池中分配
static inline void *k_malloc(size_t size)
{
	return k_aligned_alloc(sizeof(void *), size);
}

//从堆中分配的空闲内存
//提供了传统的free()语义,返回的内存必须是
//从堆内存池或k_mem_pool_malloc()中分配的
extern void k_free(void *ptr);

//从堆分配内存,数组风格
//提供了传统的calloc()语义,内存从堆内存池中分配并被置零
extern void *k_calloc(size_t nmemb, size_t size);

//内核的轮询机制
#ifdef CONFIG_POLL
#define _INIT_OBJ_POLL_EVENT(obj) do { (obj)->poll_event = NULL; } while (false)
#else
#define _INIT_OBJ_POLL_EVENT(obj) do { } while (false)
#endif

enum _poll_types_bits {//POLL类型位
	_POLL_TYPE_IGNORE,//可被使用去忽视一个事件
	_POLL_TYPE_SIGNAL,//被k_poll_signal_raise()使用为信号
	_POLL_TYPE_SEM_AVAILABLE,//信号可用性
	_POLL_TYPE_DATA_AVAILABLE,//queue/FIFO/LIFO数据可用性

	_POLL_NUM_TYPES
};

//POLL类型位
#define Z_POLL_TYPE_BIT(type) (1U << ((type) - 1U))

enum _poll_states_bits {//POLL状态位
	_POLL_STATE_NOT_READY,//创建事件时的默认状态
	_POLL_STATE_SIGNALED,//被k_poll_signal_raise()使用为信号
	_POLL_STATE_SEM_AVAILABLE,//信号可用性
	_POLL_STATE_DATA_AVAILABLE,//queue/FIFO/LIFO数据可用性
	_POLL_STATE_CANCELLED,//queue/FIFO/LIFO等待被取消

	_POLL_NUM_STATES
};

//POLL状态位
#define Z_POLL_STATE_BIT(state) (1U << ((state) - 1U))

#define _POLL_EVENT_NUM_UNUSED_BITS \
	(32 - (0 \
	       + 8 /* 标签 */ \
	       + _POLL_NUM_TYPES \
	       + _POLL_NUM_STATES \
	       + 1 /* 模式 */ \
	      ))




//k_poll_event.type位字段的值
#define K_POLL_TYPE_IGNORE 0
#define K_POLL_TYPE_SIGNAL Z_POLL_TYPE_BIT(_POLL_TYPE_SIGNAL)
#define K_POLL_TYPE_SEM_AVAILABLE Z_POLL_TYPE_BIT(_POLL_TYPE_SEM_AVAILABLE)
#define K_POLL_TYPE_DATA_AVAILABLE Z_POLL_TYPE_BIT(_POLL_TYPE_DATA_AVAILABLE)
#define K_POLL_TYPE_FIFO_DATA_AVAILABLE K_POLL_TYPE_DATA_AVAILABLE

//POLL模式
enum k_poll_modes {
	K_POLL_MODE_NOTIFY_ONLY = 0,//轮询线程在对象可用时不获取其所有权

	K_POLL_NUM_MODES
};

//k_poll_event.state位字段的值
#define K_POLL_STATE_NOT_READY 0
#define K_POLL_STATE_SIGNALED Z_POLL_STATE_BIT(_POLL_STATE_SIGNALED)
#define K_POLL_STATE_SEM_AVAILABLE Z_POLL_STATE_BIT(_POLL_STATE_SEM_AVAILABLE)
#define K_POLL_STATE_DATA_AVAILABLE Z_POLL_STATE_BIT(_POLL_STATE_DATA_AVAILABLE)
#define K_POLL_STATE_FIFO_DATA_AVAILABLE K_POLL_STATE_DATA_AVAILABLE
#define K_POLL_STATE_CANCELLED Z_POLL_STATE_BIT(_POLL_STATE_CANCELLED)

struct k_poll_signal {//轮询信号
	sys_dlist_t poll_events;//轮询事件链表
	unsigned int signaled;//如果事件已被触发为1否则为0,保持为1直到用户将其重置为0
	int result;//如果需要,传递给k_poll_signal_raise()的自定义结果值
};

#define K_POLL_SIGNAL_INITIALIZER(obj) \
	{                                                       \
	.poll_events = SYS_DLIST_STATIC_INIT(&obj.poll_events), \
	.signaled = 0,                                          \
	.result = 0,                                            \
	}
	
struct k_poll_event {//轮询事件
	sys_dnode_t _node;//轮询事件链表
	struct z_poller *poller;

	uint32_t tag:8;//可选的用户指定标记,不透明,不受API影响
	uint32_t type:_POLL_NUM_TYPES;//事件类型的位域(按位或K_POLL_TYPE_xxx值)
	uint32_t state:_POLL_NUM_STATES;//事件状态的位域(按位或K_POLL_STATE_xxx值)
	uint32_t mode:1;//操作模式,值来自枚举k_poll_modes中
	uint32_t unused:_POLL_EVENT_NUM_UNUSED_BITS;//32位字中未使用的位

	union {//每种类型的数据
		void *obj;
		struct k_poll_signal *signal;
		struct k_sem *sem;
		struct k_fifo *fifo;
		struct k_queue *queue;
	};
};

#define K_POLL_EVENT_INITIALIZER(_event_type, _event_mode, _event_obj) \
	{                                \
	.poller = NULL,                  \
	.type = _event_type,             \
	.state = K_POLL_STATE_NOT_READY, \
	.mode = _event_mode,             \
	.unused = 0,                     \
	.obj = _event_obj,               \
	}

#define K_POLL_EVENT_STATIC_INITIALIZER(_event_type, _event_mode, _event_obj, \
										event_tag)                            \
	{                                \
	.tag = event_tag,                \
	.type = _event_type,             \
	.state = K_POLL_STATE_NOT_READY, \
	.mode = _event_mode,             \
	.unused = 0,                     \
	.obj = _event_obj,               \
	}

//初始化一个struct k_poll_event实例
//在poll事件上调用此例程后,该事件将被放置在一个事件数组中,并传递给k_poll()
//参数分别是:初始化的事件,事件类型的一个位域(从K_POLL_TYPE_xxx值,只有应用于正在
//轮询的同一对象的值才能一起使用,选择K_POLL_TYPE_IGNORE将禁用该事件),模式(使用
//K_POLL_MODE_NOTIFY_ONLY),内核对象或轮询信号

extern void k_poll_event_init(struct k_poll_event *event, uint32_t type,
							  int mode, void *obj);

//等待一个或多个轮询事件发生
//允许一个线程并发地等待一个或多个轮询事件发生
//这些事件可以是可用的内核对象,如信号量或轮询信号事件
//
//当一个事件通知一个内核对象可用时,这个内核对象并没有被“给予”给调用k_poll()的线程:
//它仅仅是在k_poll()调用生效时发出这个对象可用的信号
//同样所有试图以常规方式获取对象的线程(即通过挂起对象)都优先于对对象进行轮询的线程
//这意味着在对象变为可用且其挂起队列为空之前,轮询线程永远不会获得对象上的轮询事件
//因此当被轮询的对象只有一个线程(即轮询线程)试图获取它们时,k_poll()调用更有效
//
//当k_poll()返回0时,调用者应该循环传递给k_poll()的所有事件
//并检查状态字段中预期的值,并采取相关的操作
//
//在再次调用k_poll()之前,用户必须将state字段重置为K_POLL_STATE_NOT_READY
//
//当从用户模式调用时,需要从调用者的资源池中分配一个临时内存
//
//参数分别是:要轮询的事件数组,数组中的事件数,等待时间(或者特殊值K_NO_WAIT和K_FOREVER中的一个)
//错误返回:
//-EAGAIN等待时间超时
//-EINTR轮询被中断,例如k_queue_cancel_wait()
//所有输出事件仍然被设置,有效的、取消的事件将被设置为K_POLL_STATE_CANCELLED
//换句话说,-EINTR状态意味着至少有一个输出事件是K_POLL_STATE_CANCELLED
//-ENOMEM线程资源池内存不足(仅用户模式)
//-EINVAL错误参数(仅用户模式)
__syscall int k_poll(struct k_poll_event *events, int num_events,
					 k_timeout_t timeout);

//初始化轮询信号对象
//通过k_poll_signal_raise()准备一个轮询信号对象
__syscall void k_poll_signal_init(struct k_poll_signal *signal);

//重置一个轮询信号对象的状态为无信号状态
__syscall void k_poll_signal_reset(struct k_poll_signal *signal);
static inline void z_impl_k_poll_signal_reset(struct k_poll_signal *signal)
{
	signal->signaled = 0U;
}

//获取轮询信号的有信号状态和结果值
//参数分别是:轮询信号对象(一个整数缓冲区,如果对象有信号,它将
//被写为非零),一个整数目标缓冲区(如果对象有信号,它将被写入结果值,如果
//没有信号,它将被写入未定义的值)
__syscall void k_poll_signal_check(struct k_poll_signal *signal,
								   unsigned int *signaled, int *result);

//发送轮询信号对象
//将准备一个轮询信号,它基本上是一个类型为K_POLL_TYPE_SIGNAL的轮询事件
//如果一个线程正在对该事件进行轮询,那么它将做好运行的准备,可以指定result结果值
//
//轮询信号包含一个'有信号'字段,当k_poll_signal_raise()设置该字段时
//该字段将一直保持设置状态,直到用户通过k_poll_signal_reset()将其设置为0
//因此,在再次传递给k_poll()之前,必须由用户重置它,否则k_poll()会认为它有信号,并立即返回
//
//即使这个函数返回一个错误,表明一个即将到期的轮询没有被通知,结果也会被存储
//并设置' terminated '字段,下一个k_poll()将检测错过的raise
//参数分别是:轮询信号,存储在信号的result字段中的值
//错误返回:
//-EAGAIN轮询线程的超时正在到期
__syscall int k_poll_signal_raise(struct k_poll_signal *signal, int result);

extern void z_handle_obj_poll_events(sys_dlist_t *events, uint32_t state);

//使CPU处于空闲状态
//这个函数使CPU处于空闲状态,直到事件唤醒它
//在常规系统中,空闲线程应该是唯一负责使CPU空闲并触发任何类型的电源管理的线程
//然而,在一些更受限制的系统中,如单线程系统,如果需要,只有一个线程负责此工作
//在某些架构中,在返回之前,函数会无条件地公开中断
static inline void k_cpu_idle(void)
{
	arch_cpu_idle();
}

//使CPU以原子方式空闲
//类似于k_cpu_idle(),但必须在中断锁定时调用
//开启中断并进入低功耗模式将是原子性的,也就是说
//在处理器进入低功耗模式之前没有开启中断的时间
//从低功耗模式醒来后,中断锁定状态将恢复为irq_unlock(key)
//参数分别是:从irq_lock()中获得的中断锁定键
static inline void k_cpu_atomic_idle(unsigned int key)
{
	arch_cpu_atomic_idle(key);
}

//平台相关性
#ifdef ARCH_EXCEPT
//该体系结构直接支持触发CPU异常
#define z_except_reason(reason)	ARCH_EXCEPT(reason)
#else

#if !defined(CONFIG_ASSERT_NO_FILE_INFO)
#define __EXCEPT_LOC() __ASSERT_PRINT("@ %s:%d\n", __FILE__, __LINE__)
#else
#define __EXCEPT_LOC()
#endif

//注意:这是不实现ARCH_EXCEPT()来产生一个真正的CPU异常的ARCH的实现
//当oops发生时,我们没有一个真正的异常框架来确定PC的值
//所以在我们跳转到致命错误处理程序之前打印文件和行号
#define z_except_reason(reason) do { \
		__EXCEPT_LOC();              \
		z_fatal_error(reason, NULL); \
	} while (false)

#endif

//致命地终止一个线程
//当线程遇到不可恢复的运行时条件并需要终止时,应该调用此函数
//这最终意味着什么是由_fatal_error_handler()实现决定的
//它将被调用,将导致代码K_ERR_KERNEL_OOPS
//如果从ISR上下文中调用,默认的系统致命错误处理程序将其
//视为不可恢复的系统错误,就像k_panic()一样
#define k_oops()	z_except_reason(K_ERR_KERNEL_OOPS)

//致命地终止系统
//当Zephyr内核遇到不可恢复的运行时条件并需要终止时,应该调用此函数
//这最终意味着什么是由_fatal_error_handler()实现决定的
//它将被调用,将导致代码K_ERR_KERNEL_PANIC
#define k_panic()	z_except_reason(K_ERR_KERNEL_PANIC)

//被一个或多个公共api使用的私有api
extern void z_init_thread_base(struct _thread_base *thread_base,
							   int priority, uint32_t initial_state,
							   unsigned int options);

//多线程配置
#ifdef CONFIG_MULTITHREADING
extern void z_init_static_threads(void);
//
#else
#define z_init_static_threads() do { } while (false)
#endif

extern bool z_is_thread_essential(void);
extern void z_timer_expiration_handler(struct _timeout *t);

//内核打印
#ifdef CONFIG_PRINTK
//发送一个字符缓冲区到控制台设备
__syscall void k_str_out(char *c, size_t n);
#endif

//禁止保留浮点上下文信息
//通知内核指定的线程将不再使用浮点寄存器
//一些架构对如何禁用浮点保留请求施加了限制,参见arch_float_disable
//这个例程应该只用于禁用当前已启用浮点支持的线程的浮点支持
//错误返回:
//-ENOSYS如果浮点禁用没有实现
//-EINVAL如果不能执行浮点禁用
__syscall int k_float_disable(struct k_thread *thread);

#ifdef CONFIG_THREAD_RUNTIME_STATS

//获取一个线程的运行时统计信息
//参数分别是:线程ID,统计信息
//错误返回:
//-EINVAL如果空指针
int k_thread_runtime_stats_get(k_tid_t thread,
							   k_thread_runtime_stats_t *stats);

//获取所有线程的运行时统计信息
//参数分别是:统计信息
//错误返回:
//-EINVAL如果空指针
int k_thread_runtime_stats_all_get(k_thread_runtime_stats_t *stats);

#endif

#ifdef __cplusplus
}
#endif

#include <tracing/tracing.h>//追踪
//此处是从上述定义到实现提供一个接口转变
//上述定义是可以被用户层使用,而下述是对接到实现的层
#include <syscalls/kernel.h>

#endif
#endif
