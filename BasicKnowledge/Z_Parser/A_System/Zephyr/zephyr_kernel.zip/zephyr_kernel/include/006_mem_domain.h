/*
 * zephyr内存域
 */

#ifndef INCLUDE_APP_MEMPORY_MEM_DOMAIN_H
#define INCLUDE_APP_MEMPORY_MEM_DOMAIN_H

#include <stdint.h>
#include <stddef.h>
#include <sys/dlist.h>
#include <toolchain.h>
#include <kernel/thread.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef CONFIG_USERSPACE
//静态声明内存分区
#ifdef _ARCH_MEM_PARTITION_ALIGN_CHECK
//如果需要地址对齐检查
#define K_MEM_PARTITION_DEFINE(name, start, size, attr) \
	_ARCH_MEM_PARTITION_ALIGN_CHECK(start, size);       \
	struct k_mem_partition name =                       \
		{(uintptr_t)start, size, attr}
//
#else
#define K_MEM_PARTITION_DEFINE(name, start, size, attr) \
	struct k_mem_partition name =                       \
		{(uintptr_t)start, size, attr}
#endif

//内存分区
//内存分区是线性地址空间中具有特定访问策略的内存区域
//起始地址的对齐和大小值的对齐可能会根据底层内存管理硬件的能力
//有不同的要求,任意的值不太可能起作用
struct k_mem_partition {
	uintptr_t start;//内存分区的起始地址
	size_t size;//内存分区大小
	k_mem_partition_attr_t attr;//内存分区属性
};

//内存域
//内存域是内存分区的集合,用于表示用户线程对线性地址空间的访问策略
//一个线程只能是一个内存域的成员,但是任何内存域都可以有多个作为成员的线程
//管理线程也可以是内存域的成员
//这对它们的内存访问没有影响,但在任何子线程继承父线程的内存域成员资格时很有用
//属于一个没有活动分区的内存域的用户线程将保证
//访问它自己的堆栈缓冲区、程序文本和只读数据
struct k_mem_domain {
#ifdef CONFIG_ARCH_MEM_DOMAIN_DATA
	struct arch_mem_domain arch;
#endif
	//内存域中的分区表
	struct k_mem_partition partitions[CONFIG_MAX_DOMAIN_PARTITIONS];
	sys_dlist_t mem_domain_q;//成员线程的双重链接列表
	uint8_t num_partitions;//域中活动分区的数量
};

//默认内存域
//所有线程都是某个内存域的成员,即使运行在supervisor mode
//线程属于这个默认内存域,如果它们没有添加到其他域或从其他域继承成员资格
//这个内存域添加了用于C库的z_libc_partition分区(如果存在)
extern struct k_mem_domain k_mem_domain_default;
//
#else
//为了支持以下api使用IS_ENABLED
struct k_mem_domain;
struct k_mem_partition;
#endif

//初始化内存域
//初始化内存域与给定的名称和内存分区
//请参阅文档k_mem_domain_add_partition()了解分区约束的详细信息(或者是源码,嘿嘿)
//不要在同一个内存域上多次调用k_mem_domain_init(),这样做是未定义的行为
//参数分别是:需要初始化的内存域,“parts”参数的数组项数,一个
//指向内存分区的指针数组(如果num_parts为零则可以为NULL)
extern void k_mem_domain_init(struct k_mem_domain *domain, uint8_t num_parts,
							  struct k_mem_partition *parts[]);
							  
//销毁一个内存域
//销毁一个内存域,所有成员线程都将被重新分配到默认内存域
//默认内存域不能被销毁
//此API已弃用,将在zephyr2.5中移除
__deprecated
extern void k_mem_domain_destroy(struct k_mem_domain *domain);

//为内存域添加一个内存分区。
//添加内存分区到内存域,分区必须遵循以下约束:
//-同一个内存域中的分区不能互相重叠
//-不能定义暴露私有内核数据结构或内核对象的分区
//-起始地址对齐和分区大小必须符合底层内存管理硬件的约束,每个架构都不同
//-内存域分区仅用于控制用户模式线程对内存的访问
//-如果开启了“CONFIG_EXECUTE_XOR_WRITE”,则该分区不能同时允许写和执行
//违反这些约束可能导致CPU异常或未定义的行为
//参数分别是:内存域实例,内存分区实例
extern void k_mem_domain_add_partition(struct k_mem_domain *domain,
									   struct k_mem_partition *part);

//从内存域删除内存分区
//从内存域中移除内存分区
//参数分别是:内存域实例,内存分区实例
extern void k_mem_domain_remove_partition(struct k_mem_domain *domain,
										  struct k_mem_partition *part);

//添加一个线程到内存域
//添加一个线程到内存域,它将从以前属于的任何内存域中删除
//参数分别是:内存域实例,线程句柄
extern void k_mem_domain_add_thread(struct k_mem_domain *domain,
									k_tid_t thread);

//删除一个线程从其内存域
//从它的内存域删除一个线程,它将被重新分配到默认内存域
__deprecated
extern void k_mem_domain_remove_thread(k_tid_t thread);

#ifdef __cplusplus
}
#endif
#endif
