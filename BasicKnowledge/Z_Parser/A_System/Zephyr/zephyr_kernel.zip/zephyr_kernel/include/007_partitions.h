/*
 * zephyr分区表
 */

#ifndef ZEPHYR_APP_MEMORY_PARTITIONS_H
#define ZEPHYR_APP_MEMORY_PARTITIONS_H

#ifdef CONFIG_USERSPACE
#include <kernel.h> //k_mem_partition结构体

#if defined(CONFIG_MBEDTLS)
//嵌入式TLS分区表
extern struct k_mem_partition k_mbedtls_partition;
#endif
#endif
#endif
