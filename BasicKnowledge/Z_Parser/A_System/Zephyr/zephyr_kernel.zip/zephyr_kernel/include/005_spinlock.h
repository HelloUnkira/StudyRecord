/*
 * zephyr底层,spinlock
 */
 
#ifndef ZEPHYR_INCLUDE_SPINLOCK_H_
#define ZEPHYR_INCLUDE_SPINLOCK_H_

#include <sys/atomic.h>
#include <sys/__assert.h>
#include <stdbool.h>
#include <arch/cpu.h>

#ifdef __cplusplus
extern "C" {
#endif

struct z_spinlock_key {
	int key;//自旋锁键值
};

//内核自旋锁
struct k_spinlock {
#ifdef CONFIG_SMP
	atomic_t locked;//原子锁
#endif

#ifdef CONFIG_SPIN_VALIDATE
	//将持有锁的线程存储在锁CPU ID的最低两位中
	uintptr_t thread_cpu;
#endif

#if defined(CONFIG_CPLUSPLUS) && !defined(CONFIG_SMP) && \
	!defined(CONFIG_SPIN_VALIDATE)
	//如果CONFIG_SMP和CONFIG_SPIN_VALIDATE都没有定义,k_spinlock结构体将没有成员
	//结果是,在C语言中,sizeof(k_spinlock)是0,而在c++中它是1
	//当k_spinlock嵌入到k_msgq这样的结构中时,这种大小的差异会导致问题
	//因为C和c++对于k_spinlock成员之后的成员的偏移量有不同的想法,为了防止这种情况
	//我们在用户选择c++支持时向k_spinlock添加一个1字节的虚拟成员,否则k_spinlock将为空
	char dummy;
#endif
};

//当使用断言时,有一个自旋锁验证框架可用
//它为内核代码的大小增加了相对较大的开销(大约3k左右),不适合在已知较小的平台上使用
#ifdef CONFIG_SPIN_VALIDATE
bool z_spin_lock_valid(struct k_spinlock *l);
bool z_spin_unlock_valid(struct k_spinlock *l);
void z_spin_lock_set_owner(struct k_spinlock *l);
BUILD_ASSERT(CONFIG_MP_NUM_CPUS < 4, "Too many CPUs for mask");
#endif

//自旋锁键类型
//该类型定义了一个“key”值
//用于自旋锁实现在调用k_spin_lock()时存储系统中断状态
//它将被传递给匹配的k_spin_unlock()
//这个类型是不透明的，不应该被应用程序代码检查
typedef struct z_spinlock_key k_spinlock_key_t;

//锁一个自旋锁
//锁定指定的自旋锁,返回一个表示解锁时需要的中断状态的键柄
//在返回时,调用线程保证不会在当前CPU上被挂起或中断,直到它调用k_spin_unlock()
//这个实现保证了互斥:每次只有一个CPU上的一个线程从k_spin_lock()返回
//如果其他CPU试图获取另一个CPU已经持有的锁,则会进入一个实现定义的繁忙循环(“旋转”),直到锁被释放
//独立的自旋锁可以嵌套,在持有另一个锁的同时锁定一个(未锁定的)旋转锁是合法的
//然而自旋锁不是递归的:尝试获取CPU已经持有的自旋锁将会死锁
//在只有一个CPU的情况下,k_spin_lock()的行为仍然和上面指定的一样,但显然不会发生旋转
//实现可以自由地在单处理器上下文中进行优化,使锁定减少到一个中断掩码操作
static ALWAYS_INLINE k_spinlock_key_t k_spin_lock(struct k_spinlock *l)
{
	ARG_UNUSED(l);
	k_spinlock_key_t k;

	//注意,我们需要使用底层特定于平台的锁实现
	//“irq_lock()”SMP上下文中的API实际上是全局自旋锁的包装器!
	k.key = arch_irq_lock();

#ifdef CONFIG_SPIN_VALIDATE
	__ASSERT(z_spin_lock_valid(l), "Recursive spinlock %p", l);
# ifdef KERNEL_COHERENCE
	__ASSERT_NO_MSG(arch_mem_coherent(l));
# endif
#endif

#ifdef CONFIG_SMP//在多处理器架构下,一旦抢锁失败需要死锁在此
	//如果自旋锁的锁原始值是0,新值是1,表明抢锁成功
	//返回真,此处取反退出死循环,否则,就等着
	while (!atomic_cas(&l->locked, 0, 1)) {
	}
#endif

#ifdef CONFIG_SPIN_VALIDATE
	z_spin_lock_set_owner(l);
#endif
	return k;
}

//解锁一个自旋锁
//释放由k_spin_lock()获取的锁,在这个函数被调用之后,任何CPU都可以获得这个锁
//如果k_spin_lock()中有其他cpu正在等待这个锁,那么其中一个cpu将与持有的锁同步返回
//自旋锁必须正确嵌套,必须对最近使用k_spin_lock()锁定的锁对象调用k_spin_unlock()
//使用它返回的键值,试图解锁嵌套错误的锁,或解锁未持有的锁
//或传递k_spin_lock()返回的密钥参数以外的密钥参数,都是非法的
//当设置了CONFIG_SPIN_VALIDATE时,框架可以检测到其中一些错误
static ALWAYS_INLINE void k_spin_unlock(struct k_spinlock *l, k_spinlock_key_t key)
{
	ARG_UNUSED(l);
#ifdef CONFIG_SPIN_VALIDATE
	__ASSERT(z_spin_unlock_valid(l), "Not my spinlock %p", l);
#endif

#ifdef CONFIG_SMP
	//严格地说,这里不需要atomic_clear()(这是一个返回旧值的交换操作)
	//我们总是设置一个0,并且(因为我们持有锁)知道现有状态不会因为竞争而改变
	//但是一些架构在这样使用时需要一个内存屏障,而我们没有一个用于此的Zephyr框架
	atomic_clear(&l->locked);
#endif
	arch_irq_unlock(key.key);
}

//内部函数:释放锁,但关闭本地中断
static ALWAYS_INLINE void k_spin_release(struct k_spinlock *l)
{
	ARG_UNUSED(l);
#ifdef CONFIG_SPIN_VALIDATE
	__ASSERT(z_spin_unlock_valid(l), "Not my spinlock %p", l);
#endif
#ifdef CONFIG_SMP
	atomic_clear(&l->locked);
#endif
}

#ifdef __cplusplus
}
#endif

#endif
