/*
 * zephyr线程结构
 */

#ifndef ZEPHYR_INCLUDE_KERNEL_THREAD_H_
#define ZEPHYR_INCLUDE_KERNEL_THREAD_H_

//k_thread_entry_t线程入口点函数类型
//线程的入口点函数在线程开始执行时被调用
//最多可以传递3个参数值给函数
//如果入口点函数返回,线程将永久终止执行
//线程在返回之前负责释放它可能拥有的任何共享资源(例如互斥锁和动态分配的内存)

#ifdef CONFIG_THREAD_MONITOR
struct __thread_entry {
	k_thread_entry_t pEntry;//线程入口点
	void *parameter1;//传入线程的参数1
	void *parameter2;//传入线程的参数2
	void *parameter3;//传入线程的参数3
};
#endif

//可以用于创建“虚拟”(?傀儡)线程，例如用于挂起对象
struct _thread_base {
	union {//这个线程在就绪/等待队列中的位置
		sys_dnode_t qnode_dlist;//链表实现
		struct rbnode qnode_rb;//红黑树实现
	};
	_wait_q_t *pended_on;//线程挂起的等待队列(只用于树,而不是dump链表)
	uint8_t user_options;//用户面对“线程选项”;include/kernel.h中定义的值
	uint8_t thread_state;//线程状态

	//调度程序锁计数和线程优先级
	//这两个字段控制线程的抢占性
	//锁定调度程序时,sched_locked减少,这意味着锁定从0xff到0x01的值
	//如果一个线程的优先值是负数,那么它就是coop
	//因此当它的值被视为unsigned时,就会看到0x80到0xff
	//通过将它们端到端放置,这意味着如果绑定的值大于或等于0x0080,线程是不可抢占的

	union {
		struct {
//大端模式
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
			uint8_t sched_locked;
			int8_t prio;
//小端模式
#else
			int8_t prio;
			uint8_t sched_locked;
#endif
		};
		uint16_t preempt;
	};

#ifdef CONFIG_SCHED_DEADLINE
	int prio_deadline;
#endif

	//红黑树所用关键字
	uint32_t order_key;

#ifdef CONFIG_SMP
	uint8_t is_idle;//对于每个cpu空闲线程,为True
	//来源于Linux中同步原语 的 每CPU变量
	uint8_t cpu;//最后运行的线程的CPU索引
	uint8_t global_lock_count;//irq_lock()调用的递归计数
#endif

#ifdef CONFIG_SCHED_CPU_MASK
	uint8_t cpu_mask;//可以在每个CPU上运行对应的位掩码
#endif

	void *swap_data;//api返回的数据

#ifdef CONFIG_SYS_CLOCK_EXISTS
	struct _timeout timeout;//这个线程在超时队列中的条目
#endif

	_wait_q_t join_waiters;
#if __ASSERT_ON
	atomic_t cookie;//用于检测在已经活动的线程上对k_thread_create()的调用
#endif
};

typedef struct _thread_base _thread_base_t;

#if defined(CONFIG_THREAD_STACK_INFO)
//包含线程的堆栈信息
struct _thread_stack_info {
	uintptr_t start;//堆栈开始-表示线程可写堆栈区域的起始地址
	//线程可写堆栈缓冲区大小,表示实际缓冲区的大小,从线程可写的“start”成员开始
	//这包括线程堆栈区域、为本地线程数据存储保留的任何区域
	//以及在线程初始化期间对初始线程堆栈指针进行随机调整而遗漏的任何区域
	size_t size;
	//size成员的调整值,移除用于TLS或随机堆栈基偏移的任何存储
	//(start + size - delta)是线程的初始堆栈指针,可能是0
	size_t delta;
};

typedef struct _thread_stack_info _thread_stack_info_t;
#endif

#if defined(CONFIG_USERSPACE)
struct _mem_domain_info {
	sys_dnode_t mem_domain_q_node;//内存域队列节点
	struct k_mem_domain *mem_domain;//线程的内存域
};
#endif

#ifdef CONFIG_THREAD_USERSPACE_LOCAL_DATA
struct _thread_userspace_local_data {
#if defined(CONFIG_ERRNO) && !defined(CONFIG_ERRNO_IN_TLS)
	int errno_var;//错误值
#endif
};
#endif

#ifdef CONFIG_THREAD_RUNTIME_STATS
struct k_thread_runtime_stats {
#ifdef CONFIG_THREAD_RUNTIME_STATS_USE_TIMING_FUNCTIONS
	timing_t execution_cycles;//线程执行周期
#else
	uint64_t execution_cycles;
#endif
};

typedef struct k_thread_runtime_stats k_thread_runtime_stats_t;

struct _thread_runtime_stats {
#ifdef CONFIG_THREAD_RUNTIME_STATS_USE_TIMING_FUNCTIONS
	timing_t last_switched_in;//时间戳,最后一次切换
#else
	uint32_t last_switched_in;
#endif

	k_thread_runtime_stats_t stats;
};
#endif

struct z_poller {//轮询所用
	bool is_polling;//正在轮询?
	uint8_t mode;//轮询模式
};


struct k_thread {
	struct _thread_base base;//线程基础部分
	//由体系结构定义,但所有的ARCH都需要这些
	struct _callee_saved callee_saved;
	void *init_data;//静态线程初始化数据

	//中止函数
	//这个函数指针,如果是非null,将在线程完全退出后运行一次
	//它可以在以下上下文中运行:
	//-空闲线程，如果线程自退出
	//-另一个线程调用k_thread_abort()
	//-一个特殊堆栈上的致命异常处理程序
	//它永远不会在线程本身的上下文中运行
	//提供了一个指向终止线程对象的指针
	//在此运行时,该线程对象已完全退出
	//它可以被k_thread_create()重用,或者返回到堆或slab池
	//此函数不运行任何类型的锁活动
	//如果其他线程试图同时释放或回收此对象
	//则有可能导致未定义行为的竞争	
	void (*fn_abort)(struct k_thread *aborted);

#if defined(CONFIG_POLL)
	struct z_poller poller;//轮询者
#endif

#if defined(CONFIG_THREAD_MONITOR)
	struct __thread_entry entry;//线程入口和参数描述
	struct k_thread *next_thread;//所有线程链表中的下一个线程
#endif

#if defined(CONFIG_THREAD_NAME)
	char name[CONFIG_THREAD_MAX_NAME_LEN];//线程名字
#endif

#ifdef CONFIG_THREAD_CUSTOM_DATA
	void *custom_data;//简要的线程本地存储
#endif

#ifdef CONFIG_THREAD_USERSPACE_LOCAL_DATA
	struct _thread_userspace_local_data *userspace_local_data;
#endif

#if defined(CONFIG_ERRNO) && !defined(CONFIG_ERRNO_IN_TLS)
#ifndef CONFIG_USERSPACE
	int errno_var;//线程错误变量
#endif
#endif

#if defined(CONFIG_THREAD_STACK_INFO)
	struct _thread_stack_info stack_info;//栈信息
#endif

#if defined(CONFIG_USERSPACE)
	struct _mem_domain_info mem_domain_info;//线程的内存域信息
	k_thread_stack_t *stack_obj;//线程堆栈的基址
	void *syscall_frame;//当前系统调用框架指针
#endif


#if defined(CONFIG_USE_SWITCH)
	//当使用__switch()时,一些以前特定于平台的项目成为核心操作系统的一部分
	int swap_retval;//z_swap()返回值
	void *switch_handle;//通过arch_switch()返回上下文句柄
#endif
	struct k_heap *resource_pool;//资源池

#if defined(CONFIG_THREAD_LOCAL_STORAGE)
	uintptr_t tls;//指向arch-specific TLS区域的指针
#endif

#ifdef CONFIG_THREAD_RUNTIME_STATS
	struct _thread_runtime_stats rt_stats;//运行时统计
#endif
	struct _thread_arch arch;//平台特殊:必须总是在最后
};

typedef struct k_thread _thread_t;
//线程ID号是线程地址,不同于Linux的进程标识符PID
typedef struct k_thread *k_tid_t;

#endif
