#ifndef SPECIAL_REDBLACK_TREE_H
#define SPECIAL_REDBLACK_TREE_H

///////////////////////////////////////////////////////////////////////////////
//红黑树头文件依赖项///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

#ifdef SPECIAL_REDBLACK_TREE_C
#include <stdbool.h>
#include <stdio.h>

//调试所用的断言检查
#define CHECK(n) if (n == NULL) printf("RBTree Func Fault");
#define ERROR_CHECK(n) if (n != 0) printf("RBTree Color Fault");

#endif

///////////////////////////////////////////////////////////////////////////////
//红/黑树比较谓词(!关键!),也即关键字排序二叉树/////////////////////////////////
//比较两个节点,根据树的排序标准////////////////////////////////////////////////
//如果节点A严格小于B,则返回true,否则返回false//////////////////////////////////
//注意,在插入过程中,被插入的新节点总是“A”//////////////////////////////////////
//而“B”是树中与它进行比较的现有节点////////////////////////////////////////////
//这个特征可用于(小心!)在节点之间//////////////////////////////////////////////
//实现“最近添加的最多/最少”语义,否则将比较为相等///////////////////////////////
///////////////////////////////////////////////////////////////////////////////

typedef bool (*redblack_node_lessthan)(rb_node *a, rb_node *b);

///////////////////////////////////////////////////////////////////////////////
//嵌入的数据集(省略逆向索引实现)///////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//一个指针的实际占用位数
#define PBITS(t) (8 * sizeof(t))
//因为它涉及到低地址对齐,所以低位并不可用
#define TBITS(t) ((sizeof(t)) < 8 ? 2 : 3)
//理论最大树深度,此处是根据平台对指针(地址总线位数)提供的实际长度决定
#define MAX_RBTREE_DEPTH (2 * (PBITS(int *) - TBITS(int *) - 1) + 1)
//嵌入的红黑树节点
typedef struct red_black_node {
    //根据地址对齐的规则
    //将节点的最低位用作红黑树的颜色标志位(此处的修改纯粹强迫症行为)
    //children[0]的最低位标志为1表明本节点为红色
    //children[1]的最低位标志为1表明本节点为黑色
    struct red_black_node *children[2];
} rb_node;

//维护的红黑树
typedef struct red_black_tree {
    //比较谓词
    redblack_node_lessthan lessthan_function;
    //红黑树根
    rb_node *root;
    //红黑树最大深度
    int max_depth;
#ifdef USE_RED_BLACK_TREE_STACK
    rb_node *iter_stack[MAX_RBTREE_DEPTH];
    unsigned char iter_left[MAX_RBTREE_DEPTH];
#endif
} rb_tree;

//遍历节点所需结构
typedef struct red_black_tree_foreach {
    rb_node **stack;
    char *is_left;
    int top;
} rb_tree_foreach;

///////////////////////////////////////////////////////////////////////////////
//核心操作集///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//红黑树核心动作,插入和删除节点
void rb_tree_insert(rb_tree *tree, rb_node *node);
void rb_tree_remove(rb_tree *tree, rb_node *node);
//获取树最小和最大节点
rb_node *rb_tree_get_minmax(rb_tree *tree, int side);
//获取树最小节点
static inline rb_node *rb_get_min(rb_tree *tree)
{
    return rb_tree_get_minmax(tree, 0);
}
//获取树最大节点
static inline rb_node *rb_get_max(rb_tree *tree)
{
    return rb_tree_get_minmax(tree, 1);
}
//该节点是否存在于树中
//(可以通过简单地测试指针值本身来使用它来实现一个“set”构造)
bool rb_contains(rb_tree *tree, rb_node *node);
//获取节点的孩子
rb_node *rb_child(rb_node *node, int side);
//该节点是否为黑色节点
int rb_is_black(rb_node *node);

///////////////////////////////////////////////////////////////////////////////
//其他操作集///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

#ifndef USE_RED_BLACK_TREE_STACK
typedef void (*rb_visit_t)(rb_node *node, void *cookie);
void rb_tree_walk(rb_node *node, rb_visit_t visit_fn, void *cookie);
//非常简单的递归枚举
//(低代码大小,但需要一个单独的功能可能对用户来说是笨拙的
//并且没有办法提前打破循环)
static inline void rb_walk(rb_tree *tree, rb_visit_t visit_fn, void *cookie)
{
    rb_tree_walk(tree->root, visit_fn, cookie);
}
#endif

///////////////////////////////////////////////////////////////////////////////
//宏迭代器/////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//为迭代器所需的静态初始化
#ifdef USE_RED_BLACK_TREE_STACK
#define _RB_FOREACH_INIT(tree, node) { \
    .stack   = &(tree)->iter_stack[0], \
    .is_left = &(tree)->iter_left[0],  \
    .top     = -1                      \
}
#else
#define _RB_FOREACH_INIT(tree, node) {                           \
    .is_left = (char *)alloca((tree)->max_depth * sizeof(char)), \
    .stack   = (rb_node **) alloca((tree)->max_depth *           \
                                    sizeof(rb_node *)),          \
    .top     = -1                                                \
}
#endif

rb_node *rb_tree_foreach_next(rb_tree *tree, rb_tree_foreach *f);
//不递归地按顺序遍历树
//(在循环期间对树结构的更改将产生不正确的结果)
#define RB_FOR_EACH(tree, node)                                     \
    for (rb_tree_foreach foreach = _RB_FOREACH_INIT(tree, node);    \
        (node = rb_tree_foreach_next(tree, &foreach)); )

//在rbtree上循环使用隐式的容器字段逻辑
#define RB_FOR_EACH_CONTAINER(tree, node, field)                   \
    for (rb_tree_foreach foreach = _RB_FOREACH_INIT(tree, node);   \
        ({rb_node *n = rb_tree_foreach_next(tree, &foreach);       \
          node = n ? CONTAINER_OF(n, __typeof__(*(node)), field) : \
          NULL;}) != NULL; )

#endif
