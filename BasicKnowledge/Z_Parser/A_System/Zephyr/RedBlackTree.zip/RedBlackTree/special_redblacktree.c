#define SPECIAL_REDBLACK_TREE_C
#include "special_redblacktree.h"

///////////////////////////////////////////////////////////////////////////////
//辅助操作集1//////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//获取红黑树节点的一个孩子
static rb_node *get_child(rb_node *n, int side)
{
    CHECK(n);
    if (side != 0) 
        return (rb_node *) 
           (((unsigned int) n->children[1]) & (~1UL));
    else    
        return (rb_node *)
           (((unsigned int) n->children[0]) & (~1UL));
    return NULL;
}

//设置红黑树节点的一个孩子
static void set_child(rb_node *n, int side, void *val)
{
    CHECK(n);//要保留节点的颜色位
    if (side) 
        n->children[1] = (void *)((unsigned int) val | \
                                 ((unsigned int) n->children[1] & 1UL));
    else
        n->children[0] = (void *)((unsigned int) val | \
                                 ((unsigned int) n->children[0] & 1UL));
}

//红黑树的颜色
enum rb_color { RED = 0, BLACK = 1, ERROR = 2 };
static enum rb_color get_color(rb_node *n)
{
    CHECK(n);
    if (((unsigned int)n->children[0]) & 1UL)
        return RED;
    if (((unsigned int)n->children[1]) & 1UL)
        return BLACK;
    ERROR_CHECK(ERROR);
    return ERROR;
}

//本节点是红色
static bool is_red(rb_node *n)
{
    return get_color(n) == RED;
}

//本节点是黑色
static bool is_black(rb_node *n)
{
    return get_color(n) == BLACK;
}

//设置本节点颜色
static void set_color(rb_node *n, enum rb_color color)
{
    CHECK(n);
    if (color == RED)
    {
        n->children[0] |= 1UL;
        n->children[1] &= ~1UL;
    }
    if (color == BLACK)
    {
        n->children[0] &= ~1UL;
        n->children[1] |= 1UL;
    }
    ERROR_CHECK(color == ERROR);
}

//获取其最小,和最大值节点
rb_node *rb_tree_get_minmax(rb_tree *tree, int side)
{
    rb_node *n;
    //迭代,依照其side确定是往左迭代还是往右迭代
    for (n = tree->root; n != NULL && get_child(n, side) != NULL;
         n = get_child(n, side)) ;
    //注意其简化:一个节点的关键字大小为:
    //           左孩子 < 本节点 < 右孩子
    return n;
}

//获得孩子位于父亲的左边或右边
static int get_side(rb_node *parent, rb_node *child)
{
    CHECK(get_child(parent, 0) == child || \
          get_child(parent, 1) == child);

    if(get_child(parent, 0) == child)
        return 0;
    if(get_child(parent, 1) == child)
        return 1;
    ERROR_CHECK(ERROR);
    return ERROR;
}

#ifndef USE_RED_BLACK_TREE_STACK
//递归遍历整个节树点
void rb_tree_walk(rb_node *node, rb_visit_t visit_fn, void *cookie)
{
    if (node != NULL) {
        rb_tree_walk(get_child(node, 0), visit_fn, cookie);
        visit_fn(node, cookie);
        rb_tree_walk(get_child(node, 1), visit_fn, cookie);
    }
}
#endif

//获取node的孩子
rb_node *rb_tree_child(rb_node *node, int side)
{
    return get_child(node, side);
}

//判断节点是否为黑色
int rb_tree_is_black(rb_node *node)
{
    return is_black(node);
}

//树是否包含该节点
bool rb_contains(rb_tree *tree, rb_node *node)
{
    rb_node *n = tree->root;
    //从根遍历到底,直到找到或者到底
    while (n != NULL && n != node) {
        n = get_child(n, tree->lessthan_fn(n, node));
    }
    return n == node;
}

///////////////////////////////////////////////////////////////////////////////
//核心操作集1//////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//交换所提供堆栈顶部的两个节点的位置,并相应地修改堆栈,不改变任何一个节点的颜色
//也就是说,它会影响以下跃迁(如果N在P的另一边,当然也会影响其镜像):……
static void rotate(rb_node **stack, int stacksz)
{
    CHECK(stack);
    CHECK(stacksz >= 2);
    //注意stacksz位置是多偏移一格的,所以实际栈顶位置-1
    rb_node *parent = stack[stacksz - 2];//不管如何,栈顶下一个一定是父节点
    rb_node *child = stack[stacksz - 1];//栈顶为子节点
    //注意这是左右旋转的一种合并实现
    //child节点,parent节点,a节点在同一侧.而b节点在另一侧
    int side = get_side(parent, child);
    rb_node *a = get_child(child, side);
    rb_node *b = get_child(child, side == 0 ? 1 : 0);
    
    if (stacksz >= 3) {//存在祖父节点时
        //因为栈迭代是单项迭代的,所以其父节点的上一节点为祖父节点
        rb_node *grandparent = stack[stacksz - 3];
        //旋转是在父节点与子节点中进行的
        //那么祖父节点对其孩子节点的索引方向并不改变
        //只是其子节点变成父节点了而已
        set_child(grandparent, get_side(grandparent, parent), child);
    }
    
    //左右旋转的通性:旋转后父子节点关系交换,其同一侧为b节点,a节点未改变
    set_child(child, side, a);//本质没有完成动作(因为a节点一直是其孩子)
    set_child(child, side == 0 ? 1 : 0, parent);//父子节点交换继承
    set_child(parent, side, b);//父亲一定继承b节点
    //更新堆栈中俩个节点的关系
    stack[stacksz - 2] = child;
    stack[stacksz - 1] = parent;
}

///////////////////////////////////////////////////////////////////////////////
//核心操作集2//////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//将树向下搜索到一个与“node”参数相同的节点
//(应该分配至少包含tree->max_depth条目的堆栈!返回压入堆栈的条目数)
static int find_and_stack(rb_tree *tree, rb_node *node, rb_node **stack)
{
    CHECK(tree);
    int sz = 0;
    //初始化遍历节点时,根节点入栈
    stack[sz++] = tree->root;
    //初始化完成,先获取根节点目标
    //之后每一次获取栈顶的节点目标
    while (stack[sz - 1] != node) {
        //如果栈顶目标并不与node相等,依照关键字大小寻找下一位置
        int side = tree->lessthan_fn(node, stack[sz - 1]) ? 0 : 1;
        //如果node小于栈顶节点,下一栈顶为当前节点的左孩子
        //如果node不小于栈顶节点,下一栈顶为当前节点的右孩子
        rb_node *ch = get_child(stack[sz - 1], side);
        //如果孩子存在时,将孩子入栈,否则结束查找
        if (ch != NULL) {
            stack[sz++] = ch;
        } else {
            break;
        }
        //当没有找到参数相同的节点break退出时
        //此时栈顶保留了最后一次查找记录
        //它停留的位置其孩子刚好为空(适合插入)
    }
    return sz;
}

//所提供堆栈顶部的节点是红色的,它的父节点也是红色的
//迭代修复这棵树,使它再次成为有效的红黑树
static void fix_extra_red(rb_node **stack, int stacksz)
{
    CHECK(stack);
    while (stacksz > 1) {
        rb_node *node = stack[stacksz - 1];//获得目标节点
        rb_node *parent = stack[stacksz - 2];//获得其父节点

        //正确的子颜色是循环的先决条件
        //(目标节点的左右孩子要么不存在(不存在视为黑色),要么为黑色)
        CHECK(!get_child(node, 0) || is_black(get_child(node, 0)));
        CHECK(!get_child(node, 1) || is_black(get_child(node, 1)));
        //父节点已经为黑色了(要么根节点,或合法树节点)
        if (is_black(parent)) {
            return;
        }

        //红节点不可以为根节点,所以它必定要有父亲
        CHECK(stacksz >= 2);
        rb_node *grandparent = stack[stacksz - 3];//获取祖父节点
        //获得父亲节点位于祖父节点的左边或右边
        int side = get_side(grandparent, parent);
        //获取父亲节点的兄弟节点
        rb_node *aunt = get_child(grandparent, side == 0 ? 1 : 0);
        //叔叔节点为红色(此时父亲节点与叔叔节点都是红色,黑色节点下沉)
        if ((aunt != NULL) && is_red(aunt)) {
            set_color(grandparent, RED);//祖父节点为红色
            set_color(parent, BLACK);//父亲节点为黑色
            set_color(aunt, BLACK);//叔叔节点为黑色
            //由于为了下沉黑色节点导致祖父节点为红色
            //现在回退到祖父节点去调整它
            stacksz -= 2;//退掉父亲节点与本节点
            continue;
        }
        
        //叔叔节点不存在或为黑色,在本地旋转以修正整个树
        //第一次需要确认节点,父亲节点,祖父节点在同一侧(如上a,node,parent)
        int parent_side = get_side(parent, node);
        //如果父节点和本节点不在同一侧,先将其旋转至同一侧
        if (parent_side != side) {
            rotate(stack, stacksz);//旋转交换父节点和本节点
            node = stack[stacksz - 1];
        }
        
        //旋转本节点(它已经成为父节点)与祖父节点
        rotate(stack, stacksz - 1);
        set_color(stack[stacksz - 3], BLACK);//新的祖父节点为黑色
        set_color(stack[stacksz - 2], RED);//新的父节点为红色
        
        //如果是到这种情况,需要注意一下流程:
        //本节点(插入时的颜色为红色),父节点为红色,兄弟节点为黑色
        //旋转过后,本节点晋升为祖父节点(染成黑色),原父节点和祖父节点成为新的
        //父节点和兄弟节点(染成红色),原兄弟节点下层,原黑色不变
        return;
    }

    //我们退出循环是因为已经到了根节点,但根节点一定是黑色的
    set_color(stack[0], BLACK);
}

//删除黑色节点导致树不平衡
//调用一个节点N(在堆栈的顶部),在执行删除操作后,它的子树
//中“丢失了一个黑”，根据结构,N必须是黑色的(因为如果它是红色
//它将通过重新上色而被简单地固定)，迭代修复这棵树
//使它再次成为有效的红黑树，“null_node”指针用于删除无子黑节点的情况
//为了简单起见,树munging需要一个真实的节点,所以我们使用它
//然后在完成时将其清理(用父节点中的一个简单的NULL子节点替换它)
static void fix_missing_black(rb_node **stack, int stacksz,
                              rb_node *null_node)
{
    //调整一直到根节点或者调整完毕
    while (stacksz > 1) {
        rb_node *c0, *c1, *inner, *outer;
        rb_node *n = stack[stacksz - 1];//获得该节点,它的子树丢失了一个黑
        rb_node *parent = stack[stacksz - 2];//获得该节点的父节点
        //获得孩子位于父亲的左边或右边
        int n_side = get_side(parent, n);
        //获得该节点的兄弟节点
        rb_node *sib = get_child(parent, n_side == 0 ? 1 : 0);
        //节点如果不是黑色,有问题
        CHECK(is_black(n));
        //确保兄弟结点是黑色的,如果需要,将N向下旋转一层(在rotate()之后
        //我们的父结点是上一个兄弟结点的子结点,所以N在树中较低)
        if (!is_black(sib)) {
            //要注意的一点:如果兄弟节点为红色
            //那么父节点和它的所有子节点必为黑色
            stack[stacksz - 1] = sib;//兄弟节点覆盖当前节点
            rotate(stack, stacksz);//旋转兄弟节点与父节点
            set_color(parent, RED);//原父节点下沉为兄弟节点,染成红色
            set_color(sib, BLACK);//原兄弟节点晋升为父节点,染成黑色
            //对兄弟节点旋转意味着自己下沉一级,将自己重新加入到集合中
            //现在它是原父节点(现在兄弟节点)的子节点
            stack[stacksz++] = n;
            //重新定位新的父节点
            parent = stack[stacksz - 2];
            //重新定位新的兄弟节点(旋转并不改变其归向,所以使用原归项没有问题)
            sib = get_child(parent, n_side == 0 ? 1 : 0);
        }
        
        //注意,旋转到下一级的时候
        //它的新兄弟一定是存在的,因为如果不存在
        //那么树在旋转之前本身就不是平衡的
        CHECK(sib);
        c0 = get_child(sib, 0);//获得新的兄弟的左孩子
        c1 = get_child(sib, 1);//获得新的兄弟的右孩子
        //兄弟节点孩子颜色都是黑色
        if ((c0 == NULL || is_black(c0)) && (c1 == NULL || is_black(c1))) {
            if (n == null_node) {
                //如果是要删除的节点,断开亲子关联
                //否则就只是纯粹的旋转染色调整
                set_child(parent, n_side, NULL);
            }
            //兄弟只有黑孩子的情况有简单的解决办法
            set_color(sib, RED);//将新兄弟节点染成红色
            
            if (is_black(parent)) {
                //通过将兄弟结点的子树着色为红色来平衡它
                //然后我们的父结点就会缺少一个黑色,所以向上迭代
                stacksz--;
                continue;
            } else {
                //重新上色使整个树OK
                //(父节点是红色直接染成黑色即可完成)
                set_color(parent, BLACK);
                return;
            }
        }

        //至少兄弟存在一个红色节点
        CHECK((c0 && is_red(c0)) || (c1 && is_red(c1)));

        //我们知道兄弟姐妹至少有一个红色的孩子
        //固定它,使远/外的位置(即在N的对面)肯定是红色的
        //如果远处位置是红色的(即在N的对面)不管里面是红是黑都不重要
        outer = get_child(sib, n_side == 0 ? 1 : 0);
        if (!(outer != NULL && is_red(outer))) {
            //获得内部的节点
            inner = get_child(sib, n_side);
            stack[stacksz - 1] = sib;//将兄弟节点写入到栈顶
            stack[stacksz++] = inner;//对内部的节点(红节点)向外旋转
            rotate(stack, stacksz);//旋转内部节点与兄弟节点
            set_color(sib, RED);//原兄弟节点染成红色
            set_color(inner, BLACK);//新的兄弟节点染成黑色(在N的对面)

            sib = stack[stacksz - 2];//兄弟节点更新
            outer = get_child(sib, n_side == 0 ? 1 : 0);
            stack[stacksz - 2] = n;//将堆栈状态恢复为N在顶部
            stacksz--;//回退,此时栈顶为N
        }

        //最后,兄弟结点必须在远/外插槽中有一个红色的子结点
        //我们可以旋转sib和我们的父元素并重新着色以生成一个有效的树
        CHECK(is_red(outer));
        //交换父亲与兄弟的颜色
        set_color(sib, get_color(parent));//兄弟是黑色的,但不确定父亲是什么颜色
        set_color(parent, BLACK);//黑色是已知的信息
        set_color(outer, BLACK);//远处的红孩子要染成黑色以补色
        stack[stacksz - 1] = sib;//更新栈顶为兄弟
        rotate(stack, stacksz);//旋转父亲和兄弟,已完成旋转
        if (n == null_node) {
            //如果当前节点是要删除的节点,断开亲子关联
            set_child(parent, n_side, NULL);
        }
        return;
    }
}

///////////////////////////////////////////////////////////////////////////////
//核心操作集3//////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//插入一个节点
void rb_insert(rb_tree *tree, rb_node *node)
{
    CHECK(tree);
    CHECK(node);
    //新节点的左右孩子为空
    set_child(node, 0, NULL);
    set_child(node, 1, NULL);
    //如果是第一次插入,也即树中没有节点
    if (tree->root == NULL) {
        tree->root = node;//直接成为根节点
        tree->max_depth = 1;//标记其最大深度为1
        set_color(node, BLACK);//根节点必须染成黑色
        return;//插入完成
    }
    
    //如果不是第一次插入,现在为插入准备对应的栈
#ifdef USE_RED_BLACK_TREE_STACK
    rb_node **stack = &tree->iter_stack[0];
#else
    rb_node *stack[tree->max_depth + 1];
#endif
    //寻找到插入的位置
    int stacksz = find_and_stack(tree, node, stack);
    //获得其父节点
    rb_node *parent = stack[stacksz - 1];
    //确认当前节点应该插入到父节点的哪一边
    int side = tree->lessthan_fn(node, parent) ? 0 : 1;
    //将节点插入到父节点,建立亲子关系
    set_child(parent, side, node);
    //当前节点染成红色(中途插入的节点都要染成红色)
    set_color(node, RED);
    //将当前节点插入到用以调整所在的堆栈之中
    stack[stacksz++] = node;
    //修复该树,使得它重新平衡并遵守红黑树的原语
    fix_extra_red(stack, stacksz);
    //更新最大树深度
    if (stacksz > tree->max_depth) {
        tree->max_depth = stacksz;
    }
    //也许单次旋转会上浮到根部,所以需要重新更新关联关系
    tree->root = stack[0];
    //根的颜色必须是黑色的
    CHECK(is_black(tree->root));
}

//删除一个节点
void rb_remove(rb_tree *tree, rb_node *node)
{
    rb_node *tmp;
    //现在为删除准备对应的栈
#ifdef USE_RED_BLACK_TREE_STACK
    rb_node **stack = &tree->iter_stack[0];
#else
    rb_node *stack[tree->max_depth + 1];
#endif
    //找到要删除的节点
    int stacksz = find_and_stack(tree, node, stack);
    //没找到,直接退出
    if (node != stack[stacksz - 1]) {
        return;
    }

    //我们只能删除一个有0或1个子节点的节点
    //如果我们有两个,那么选择边0的“最大”子节点(最小的1也可以)
    //并与它交换我们在树中的位置
    if (get_child(node, 0) != NULL && get_child(node, 1) != NULL) {
        int stacksz0 = stacksz;
        rb_node *hiparent, *loparent;
        rb_node *node2 = get_child(node, 0);//获得它的左孩子
        //保存当前节点的父亲
        hiparent = stacksz > 1 ? stack[stacksz - 2] : NULL;
        stack[stacksz++] = node2;//左孩子加入集合中
        //迭代找左孩子的右孩子
        while (get_child(node2, 1)) {
            node2 = get_child(node2, 1);
            stack[stacksz++] = node2;
        }
        //保持要交换的节点的父亲
        loparent = stack[stacksz - 2];

        //现在交换node/node2在树中的位置
        //设计注意事项:这是一个侵入性数据结构对我们造成相当严重伤害的地方
        //您在教科书中看到的树通过在两个节点之间交换“数据”指针来实现这一点
        //但我们有一些特殊情况需要检查
        //原则上,这是通过在节点之间交换子指针
        //并将指向它们的节点从它们的父节点重新定位来实现的,但是:
        //(1)上面的节点可能是树的根,没有父节点
        //(2)下面的节点可能是上面节点的直接子节点
        //还记得交换两个节点的颜色位
        //当然,我们没有父指针,所以跟踪这个结构的堆栈也需要交换!
        if (hiparent != NULL) {
            //父亲存在,高父亲指向低孩子
            set_child(hiparent, get_side(hiparent, node), node2);
        } else { //否则就是根指向低孩子
            tree->root = node2;
        }

        //如果低父亲与node节点一致(node和node2是亲子关系)
        if (loparent == node) {
            //交换它们的亲子关系
            set_child(node, 0, get_child(node2, 0));
            set_child(node2, 0, node);
        } else {//跨度亲子关系
            //更新低父亲指向高孩子
            set_child(loparent, get_side(loparent, node2), node);
            //交换俩个节点的左孩子(左孩子可能存在)
            tmp = get_child(node, 0);
            set_child(node, 0, get_child(node2, 0));
            set_child(node2, 0, tmp);
        }
        //交换俩个节点的右孩子
        set_child(node2, 1, get_child(node, 1));
        set_child(node, 1, NULL);//原node2的右孩子一定不存在
        //更新它们的堆栈关系
        tmp = stack[stacksz0 - 1];
        stack[stacksz0 - 1] = stack[stacksz - 1];
        stack[stacksz - 1] = tmp;

        //交换俩个节点的颜色
        int ctmp = get_color(node);
        set_color(node, get_color(node2));
        set_color(node2, ctmp);
    }
    
    //纠错检查,node不可能还有俩个孩子
    CHECK(!get_child(node, 0) || !get_child(node, 1));

    //获取node的孩子,不确定是否有,有就要过来即可
    rb_node *child = get_child(node, 0);
    if (child == NULL) {
        child = get_child(node, 1);
    }
    
    //如果一开始就是删除的根节点
    if (stacksz < 2) {
        tree->root = child;//更新根节点
        if (child != NULL) {//根节点必须为黑色
            set_color(child, BLACK);
        } else {//如果是空树,情况最大深度
            tree->max_depth = 0;
        }
        return;
    }
    
    //获得要删除节点node的父亲
    rb_node *parent = stack[stacksz - 2];

    //特殊情况:如果要删除的节点是没有子节点的
    //那么我们在做缺少的黑色旋转时将它留在原地
    //当它们隔离它时将用适当的NULL替换它
    if (child == NULL) {
        if (is_black(node)) {
            //删除的黑色节点没有孩子,注意节点并没有删除
            fix_missing_black(stack, stacksz, node);
        } else {
            //红色的无子节点可以直接删除
            set_child(parent, get_side(parent, node), NULL);
        }
    } else {
        //删除的节点有一个孩子,重建亲子关系
        set_child(parent, get_side(parent, node), child);
        //检查颜色,如果一个是红色(至少一个是黑色在一个有效的树)
        //那么我们完成,否则我们有一个缺失的黑色,我们需要修复
        if (is_red(node) || is_red(child)) {
            //有一个是红色节点,那直接子节点染成黑色就可以了
            //相当于node为红时直接删除,node为黑时,用染黑child顶替
            set_color(child, BLACK);
        } else {
            //俩个节点都为黑色,但已经删除了node节点
            stack[stacksz - 1] = child;//让孩子节点顶替上去
            //节点已经删除了,直接修复即可
            fix_missing_black(stack, stacksz, NULL);
        }
    }
    
    //我们可能已经旋转到根了!
    tree->root = stack[0];
}

///////////////////////////////////////////////////////////////////////////////
//辅助操作集2//////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//将节点及其左侧的子节点链压入foreach结构中的堆栈
//返回最后一个节点,即下一个要迭代的节点
//根据构造节点总是右子节点或根节点,所以is_left必须为false
static inline rb_node *stack_left_limb(rb_node *n, rb_tree_foreach *f)
{
    f->top++;
    f->stack[f->top] = n;//指定节点入栈
    f->is_left[f->top] = 0;//该节点不为左孩子

    //迭代将该节点的全部左孩子入栈
    while ((n = get_child(n, 0)) != NULL) {
        f->top++;
        f->stack[f->top] = n;
        f->is_left[f->top] = 1;//全部都是左孩子
    }
    return f->stack[f->top];//返回最低栈顶的位置
}

//foreach跟踪通过alloca()分配的动态堆栈工作
//当前节点在栈[top]中(因此它的父节点是栈[top-1])
//每个堆叠节点与其父节点的侧存储在is_left[]中(即
//如果is_left[top]为真,则node/stack[top]是堆栈[top-1]的左子节点)
//top == -1的特殊情况表明堆栈未初始化,我们需要从根入栈初始化堆栈
rb_node *rb_tree_foreach_next(rb_tree *tree, rb_tree_foreach *f)
{
    rb_node *n;
    //根节点合法检查
    if (tree->root == NULL) {
        return NULL;
    }
    //初始化条件,选择根的最左边的子节点作为
    //我们的第一个节点,在此过程中初始化堆栈
    if (f->top == -1) {
        return stack_left_limb(tree->root, f);
    }

    //如果一个节点有一个子节点
    //那么它的下一个子节点就是它的右子树的最左边的子节点
    n = get_child(f->stack[f->top], 1);
    if (n != NULL) {
        return stack_left_limb(n, f);
    }

    //否则如果该节点是其父节点的左子节点
    //则下一个节点就是父节点(注意根节点堆叠在上面,is_left设置为0
    //因此即使该节点没有父节点,该条件仍然有效)
    if (f->is_left[f->top] != 0) {
        return f->stack[--f->top];
    }

    //如果我们没有左树并且是右子树
    //那么我们的父树已经被遍历了
    //所以向上遍历堆栈寻找左子树(它的父树没有被遍历,因此是下一个)
    while ((f->top > 0) && (f->is_left[f->top] == 0)) {
        f->top--;
    }

    f->top--;
    return f->top >= 0 ? f->stack[f->top] : NULL;
}
